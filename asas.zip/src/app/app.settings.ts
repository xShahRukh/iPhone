import { environment } from '../environments/environment';

export class AppSettings {
  public static timer = 30000;

  public static API = {
    // Login apis
    LOGIN: environment.apiUrl + 'validUser', // all

    // Roles List
    GET_ROLES_LIST1: environment.apiUrl + 'roles/get/all/roles/by/employee',
    GET_ROLES_USERS_LIST: environment.apiUrl + 'roles/users/list/',

    LOW_STOCK_ITEMS_COUNT: environment.apiUrl + 'links/link_module/lowstock_items_count',
    // Location APIs
    ADD_LOCATIONS: environment.apiUrl + 'add/locations',
    GET_LOCATIONS: environment.apiUrl + 'get/locations',
    GET_LIST_OF_SUPERVISIORSLIST: environment.apiUrl + 'get/supervisorslist',
    ADDNEW_MAINTENANCE: environment.apiUrl + 'add/newmaintainence/service',
    GET_MAINTENANCESERVICESLIST: environment.apiUrl + 'get/maintain/services',
    GET_SUPERVISOR_LIST: environment.apiUrl + 'incidents/get/supervisors/list/',
    GET_EQ_TYPE_LIST: environment.apiUrl + 'equipments/gettypedetails',
    GET_OWNERS: environment.apiUrl + 'equipments/owername',
    GET_SUPPLIER_LIST: environment.apiUrl + 'supplier/getSupplierList',
    ADD_SUPPLIER_LIST: environment.apiUrl + 'supplier/addSupplierList',
    GET_EMPLS: environment.apiUrl + 'supplier/getemployees',
    ADD_EQUIPMENTS: environment.apiUrl + 'equipments/addequipments',
    GET_LISTOFEQU: environment.apiUrl + 'equipments/getequipments',

    GETFULLDETAILS: environment.apiUrl + 'equipments/getequipmentsdetails',
    LINK_MAINTENANCE: environment.apiUrl + 'equipments/maintenance',
    GETSUPERVISORLIST: environment.apiUrl + 'equipments/supervisour',
    GETSUPERVISORUNDER: environment.apiUrl + 'employee/underreportingmanager',
    LINK_MAINTENANCE_EMPS: environment.apiUrl + 'maintenance/addmaintenancedet',
    GETUSERSLIST: environment.apiUrl + 'equipments/listtomatainuser',
    ADDMIANTENANCE_USER: environment.apiUrl + 'maintenance/addhistorybyuser',
    GETLIST_OF_DASHBOARD: environment.apiUrl + 'dashboard/type',
    CLOSE_ACTION: environment.apiUrl + 'close/service',
    GET_SUPPLIER_DASH: environment.apiUrl + 'dashboard/Suppliertype',
    GET_MAINTENAANCELST: environment.apiUrl + 'suppliers/getlist',
    GET_DASH: environment.apiUrl + 'equipments/equipmentCountByLocation',
    GET_WORKING_STATUS: environment.apiUrl + 'equipments/equipmentBytypeLocation',
    ADD_TYPES: environment.apiUrl + 'equipments/add_type',
    GET_EMPLOYEES_LIST: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',

    // HSE staff apis
    ADD_COORDINATOR: environment.apiUrl + 'locations/addcoordinator',

    // Non Conformanece
    GETCOUNTDASHLIST: environment.apiUrl + 'nc/dash/list/',

    // Inspection APIS
    GET_INSPECTION_TYPE_DET: environment.apiUrl + 'get/inspection/Type/Details',
    ADD_INSPECTOR: environment.apiUrl + 'add/inspection',
    ADD_REMARKS: environment.apiUrl + 'add/remarks',
    GETWITHINDATES: environment.apiUrl + 'get/inspection/between/',

    // get superviso list
    GET_SUPERVISOR_LIST_COUNT: environment.apiUrl + '/get/countofpermits/supervisor',
    GETLISTLOCATIONS: environment.apiUrl + 'get/locations',
    GET_INSPECTION_HISTORY: environment.apiUrl + 'inspection/history/',
    GETOGP_WITH_INC_NC: environment.apiUrl + 'ongoingprj/inc_nc',
    GET_PERMITS_LIST: environment.apiUrl + 'links/link_module/get_All_Links_Data/',
    DEPARTMENTS: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    SENT_NOTIFICATION: environment.apiUrl + 'send_notification_by_dept',
    SMILEICONS: environment.apiUrl + 'emoticons',
    NOTIFICATION: environment.apiUrl + 'notifications',
    notificationSave: environment.apiUrl + 'send_notification',
    NOTIFICATION_SEND: environment.apiUrl + 'notifications_sent',
    GET_USERS: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',
    NOTIFICATION_READ: environment.apiUrl + 'notification_mark_read',
    NOTIFICATION_ALL: environment.apiUrl + 'all_notifications',
    EMPLOYEE_DASHBOARD: environment.apiUrl + 'employee/dashboard'
  };
  public static notification_image = environment.apiUrl + 'notification_image';

  public static Injures_one1 = [
    { id: 1, title: 'Head', Parts: 'Head', checked: '', img: 'head.png' },
    { id: 2, title: 'Face', Parts: 'Face', checked: '', img: 'face.png' },
    { id: 3, title: 'Neck', Parts: 'Neck', checked: '', img: 'neck.png' },
    {
      id: 4,
      title: 'Upper Back',
      Parts: 'Upper_Back',
      checked: '',
      img: 'lower_back.png'
    },
    {
      id: 5,
      title: 'Lower Back',
      Parts: 'Lower_Back',
      checked: '',
      img: 'upper_back.png'
    },
    { id: 6, title: 'Chest', Parts: 'Chest', checked: '', img: 'chest.png' },
    {
      id: 7,
      title: 'Abdomen',
      Parts: 'Abdomen',
      checked: '',
      img: 'abdomen.png'
    },
    {
      id: 8,
      title: 'Pelvis/Groin',
      Parts: 'Pelvis_Groin',
      checked: '',
      img: 'pelvis.png'
    },
    { id: 9, title: 'Lips', Parts: 'Lips', checked: '', img: 'lips.PNG' },
    { id: 10, title: 'Teeth', Parts: 'Teeth', checked: '', img: 'teeth.png' },
    {
      id: 11,
      title: 'Tongue',
      Parts: 'Tongue',
      checked: '',
      img: 'tongue.PNG'
    },
    { id: 12, title: 'Nose', Parts: 'Nose', checked: '', img: 'nose.PNG' },
    {
      id: 13,
      title: 'Fingers',
      Parts: 'Fingers',
      checked: '',
      img: 'fingers.png'
    },
    { id: 14, title: 'Toes', Parts: 'Toes', checked: '', img: 'toes.png' }
  ];
  public static Injures_two2 = [
    {
      id: 15,
      title: 'Shoulder',
      Parts: 'Shoulder',
      left_form: 'l_Shoulder',
      right_form: 'r_Shoulder',
      left_img: 'left_shoulder.png',
      right_img: 'right_shoulder.png'
    },
    {
      id: 16,
      title: 'Arm Pit',
      Parts: 'ArmPit',
      left_form: 'l_Arm_Pit',
      right_form: 'r_Arm_Pit',
      left_img: 'left_armpit.png',
      right_img: 'right_armpit.png'
    },
    {
      id: 17,
      title: 'Upper Arm',
      Parts: 'UpperArm',
      left_form: 'l_Upper_Arm',
      right_form: 'r_Upper_Arm',
      left_img: 'left_upper_arm.png',
      right_img: 'right_upper_arm.png'
    },
    {
      id: 18,
      title: 'Lower Arm',
      Parts: 'LowerArm',
      left_form: 'l_Lower_Arm',
      right_form: 'r_Lower_Arm',
      left_img: 'left_lower_arm.png',
      right_img: 'right_lower_arm.png'
    },
    {
      id: 19,
      title: 'Elbow',
      Parts: 'Elbow',
      left_form: 'l_Elbow',
      right_form: 'r_Elbow',
      left_img: 'left_elbow.png',
      right_img: 'right_elbow.png'
    },
    {
      id: 20,
      title: 'Wrist',
      Parts: 'Wrist',
      left_form: 'l_Wrist',
      right_form: 'r_Wrist',
      left_img: 'left_wrist.png',
      right_img: 'right_wrist.png'
    },
    {
      id: 21,
      title: 'Hand',
      Parts: 'Hand',
      left_form: 'l_Hand',
      right_form: 'r_Hand',
      left_img: 'left_hand.png',
      right_img: 'right_hand.png'
    },
    {
      id: 22,
      title: 'Buttocks',
      Parts: 'Buttocks',
      left_form: 'l_Buttocks',
      right_form: 'r_Buttocks',
      left_img: 'buttocks.png',
      right_img: 'buttocks.png'
    },
    {
      id: 23,
      title: 'Hip',
      Parts: 'Hip',
      left_form: 'l_Hip',
      right_form: 'r_Hip',
      left_img: 'left_hip.png',
      right_img: 'right_hip.png'
    },
    {
      id: 24,
      title: 'Thigh',
      Parts: 'Thigh',
      left_form: 'l_Thigh',
      right_form: 'r_Thigh',
      left_img: 'left_tigh.png',
      right_img: 'right_tigh.png'
    },
    {
      id: 25,
      title: 'Lower Leg',
      Parts: 'LowerLeg',
      left_form: 'l_Lower_Leg',
      right_form: 'r_Lower_Leg',
      left_img: 'left_lower_leg.png',
      right_img: 'right_lower_leg.png'
    },
    {
      id: 26,
      title: 'Knee',
      Parts: 'Knee',
      left_form: 'l_Knee',
      right_form: 'r_Knee',
      left_img: 'left_knee.png',
      right_img: 'right_knee.png'
    },
    {
      id: 27,
      title: 'Ankle',
      Parts: 'Ankle',
      left_form: 'l_Ankle',
      right_form: 'r_Ankle',
      left_img: 'left_ankle.png',
      right_img: 'right_ankle.png'
    },
    {
      id: 28,
      title: 'Eyes',
      Parts: 'Eyes',
      left_form: 'l_Eyes',
      right_form: 'r_Eyes',
      left_img: 'left_eye.PNG',
      right_img: 'right_eye.PNG'
    },
    {
      id: 29,
      title: 'Ears',
      Parts: 'Ears',
      left_form: 'l_Ears',
      right_form: 'r_Ears',
      left_img: 'left_ear.png',
      right_img: 'right_ear.png'
    }
    // {id:30, title: 'Others', Parts: 'Others', type: '' },
  ];
  public static Injures_one = [
    {
      id: 1,
      title: 'Head',
      Parts: 'Head',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'head.png'
    },
    {
      id: 2,
      title: 'Face',
      Parts: 'Face',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'face.png'
    },
    {
      id: 3,
      title: 'Neck',
      Parts: 'Neck',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'neck.png'
    },
    {
      id: 4,
      title: 'Upper Back',
      Parts: 'Upper_Back',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'lower_back.png'
    },
    {
      id: 5,
      title: 'Lower Back',
      Parts: 'Lower_Back',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'upper_back.png'
    },
    {
      id: 6,
      title: 'Chest',
      Parts: 'Chest',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'chest.png'
    },
    {
      id: 7,
      title: 'Abdomen',
      Parts: 'Abdomen',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'abdomen.png'
    },
    {
      id: 8,
      title: 'Pelvis/Groin',
      Parts: 'Pelvis_Groin',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'pelvis.png'
    },
    {
      id: 9,
      title: 'Lips',
      Parts: 'Lips',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'lips.PNG'
    },
    {
      id: 10,
      title: 'Teeth',
      Parts: 'Teeth',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'teeth.png'
    },
    {
      id: 11,
      title: 'Tongue',
      Parts: 'Tongue',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'tongue.PNG'
    },
    {
      id: 12,
      title: 'Nose',
      Parts: 'Nose',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'nose.PNG'
    },
    {
      id: 13,
      title: 'Fingers',
      Parts: 'Fingers',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'fingers.png'
    },
    {
      id: 14,
      title: 'Toes',
      Parts: 'Toes',
      checked: '',
      report: false,
      investigate: '',
      details: '',
      img: 'toes.png'
    }
  ];
  public static Injures_two = [
    {
      id: 15,
      title: 'Shoulder',
      Parts: 'Shoulder',
      left_form: 'l_Shoulder',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Shoulder',
      left_img: 'left_shoulder.png',
      right_img: 'right_shoulder.png'
    },
    {
      id: 16,
      title: 'Arm Pit',
      Parts: 'ArmPit',
      left_form: 'l_ArmPit',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_ArmPit',
      left_img: 'left_armpit.png',
      right_img: 'right_armpit.png'
    },
    {
      id: 17,
      title: 'Upper Arm',
      Parts: 'UpperArm',
      left_form: 'l_UpperArm',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_UpperArm',
      left_img: 'left_upper_arm.png',
      right_img: 'right_upper_arm.png'
    },
    {
      id: 18,
      title: 'Lower Arm',
      Parts: 'LowerArm',
      left_form: 'l_LowerArm',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_LowerArm',
      left_img: 'left_lower_arm.png',
      right_img: 'right_lower_arm.png'
    },
    {
      id: 19,
      title: 'Elbow',
      Parts: 'Elbow',
      left_form: 'l_Elbow',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Elbow',
      left_img: 'left_elbow.png',
      right_img: 'right_elbow.png'
    },
    {
      id: 20,
      title: 'Wrist',
      Parts: 'Wrist',
      left_form: 'l_Wrist',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Wrist',
      left_img: 'left_wrist.png',
      right_img: 'right_wrist.png'
    },
    {
      id: 21,
      title: 'Hand',
      Parts: 'Hand',
      left_form: 'l_Hand',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Hand',
      left_img: 'left_hand.png',
      right_img: 'right_hand.png'
    },
    {
      id: 22,
      title: 'Buttocks',
      Parts: 'Buttocks',
      left_form: 'l_Buttocks',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Buttocks',
      left_img: 'buttocks.png',
      right_img: 'buttocks.png'
    },
    {
      id: 23,
      title: 'Hip',
      Parts: 'Hip',
      left_form: 'l_Hip',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Hip',
      left_img: 'left_hip.png',
      right_img: 'right_hip.png'
    },
    {
      id: 24,
      title: 'Thigh',
      Parts: 'Thigh',
      left_form: 'l_Thigh',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Thigh',
      left_img: 'left_tigh.png',
      right_img: 'right_tigh.png'
    },
    {
      id: 25,
      title: 'Lower Leg',
      Parts: 'LowerLeg',
      left_form: 'l_LowerLeg',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_LowerLeg',
      left_img: 'left_lower_leg.png',
      right_img: 'right_lower_leg.png'
    },
    {
      id: 26,
      title: 'Knee',
      Parts: 'Knee',
      left_form: 'l_Knee',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Knee',
      left_img: 'left_knee.png',
      right_img: 'right_knee.png'
    },
    {
      id: 27,
      title: 'Ankle',
      Parts: 'Ankle',
      left_form: 'l_Ankle',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Ankle',
      left_img: 'left_ankle.png',
      right_img: 'right_ankle.png'
    },
    {
      id: 28,
      title: 'Eyes',
      Parts: 'Eyes',
      left_form: 'l_Eyes',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Eyes',
      left_img: 'left_eye.PNG',
      right_img: 'right_eye.PNG'
    },
    {
      id: 29,
      title: 'Ears',
      Parts: 'Ears',
      left_form: 'l_Ears',
      report1: '',
      investiagte1: '',
      details1: '',
      report2: '',
      investiagte2: '',
      details2: '',
      right_form: 'r_Ears',
      left_img: 'left_ear.png',
      right_img: 'right_ear.png'
    }
    // {id:30, title: 'Others', Parts: 'Others', type: '' },
  ];
}
