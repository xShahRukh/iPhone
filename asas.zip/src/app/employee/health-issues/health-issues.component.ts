import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import * as _ from 'underscore';
import { DepartmentService } from '../department/department.service';

declare var $;

@Component({
  selector: 'app-health-issues',
  templateUrl: './health-issues.component.html',
  styleUrls: ['./health-issues.component.css']
})
export class HealthIssuesComponent implements OnInit {
  HealthIssuesList: any = [];
  loading: Boolean = true;
  dataItem: any = new Object();
  AddHealthIssuesForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      healthissue_name: {
        required: 'Name is required'
      },
      healthissue_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const healthissue_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const healthissue_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '', disabled: false }, [Validators.required]);

    this.AddHealthIssuesForm = this.fb.group({
      healthissue_name: healthissue_name,
      healthissue_code: healthissue_code,
      status: status
    });

    this.getHealthIssuesList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    // if (this.AddHealthIssuesForm) {
    //   const controlBlurs: Observable<any>[] = this.formInputElements.map(
    //     (formControl: ElementRef) =>
    //       Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
    //   );
    //   Observable.arguments
    //     .merge(this.AddHealthIssuesForm.valueChanges, ...controlBlurs)
    //     .debounceTime(800)
    //     .subscribe(value => {
    //       this.displayMessage = this.genericValidator.processMessages(
    //         this.AddHealthIssuesForm
    //       );
    //     });
    // }
  }

  getHealthIssuesList() {
    const body = { type: 'In-active' };
    this._addDeptServices.getHealthIssuesList(body).subscribe(data => {
      console.log('HealthIssues list', data.data[0].health_issues);
      if (data.error) {
        this.loading = false;
        this.HealthIssuesList = data.data[0].health_issues;
      } else {
        this.HealthIssuesList = [];
        this.loading = false;
      }
    });
    console.log(this.HealthIssuesList);
  }

  addNewHealthIssues() {
    const body = {
      table: 'health_issues',
      shortname: this.AddHealthIssuesForm.controls['healthissue_code'].value,
      fullname: this.AddHealthIssuesForm.controls['healthissue_name'].value
    };
    this._addDeptServices.addNewCommonData(body).subscribe(addData => {
      if (addData.error) {
        // success toaster
        this.toastr.successToastr('Health issues details added successfully', 'Success!');
        this.AddHealthIssuesForm.reset();
        this.getHealthIssuesList();
        $('#addhealthissuePop').modal('hide');
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editHealthissue(item) {
    this.AddHealthIssuesForm.patchValue({
      healthissue_code: item.hlth_issue_code,
      healthissue_name: item.itemName,
      status: item.status
    });
    this.dataItem = item;
  }

  editHealthIssues() {
    const body = {
      id: this.dataItem.id.toString(),
      table: 'health_issues',
      shortname: this.AddHealthIssuesForm.controls['healthissue_code'].value,
      fullname: this.AddHealthIssuesForm.controls['healthissue_name'].value,
      status: this.AddHealthIssuesForm.controls['status'].value.toString()
    };

    this._addDeptServices.editCommonDatabyid(body).subscribe(editData => {
      if (editData.error) {
        // success toaster
        this.toastr.successToastr('Health issues details updated successfully', 'Success!');
        this.AddHealthIssuesForm.reset();
        this.getHealthIssuesList();
        $('#editallrgyPop').modal('hide');
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }

  resetForm() {
    this.AddHealthIssuesForm.reset();
    this.AddHealthIssuesForm.patchValue({
      status: '1'
    });
  }
}
