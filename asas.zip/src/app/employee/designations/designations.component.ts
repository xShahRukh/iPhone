import { Component, OnInit, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { ToastrManager } from 'ng6-toastr-notifications';
import { DepartmentService } from '../department/department.service';

@Component({
  selector: 'app-designations',
  templateUrl: './designations.component.html',
  styleUrls: ['./designations.component.css']
})
export class DesignationsComponent implements OnInit {
  designationsList: any[];
  loading: Boolean = true;
  dataItem: any = new Object();
  AddDesgForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      dept_name: {
        required: 'Name is required'
      },
      dept_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const dept_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const dept_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '', disabled: false }, [Validators.required]);

    this.AddDesgForm = this.fb.group({
      dept_name: dept_name,
      dept_code: dept_code,
      status: status
    });

    this.getdeptsList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AddDesgForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
      );
      Observable.arguments
        .merge(this.AddDesgForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(this.AddDesgForm);
        });
    }
  }

  getdeptsList() {
    this._addDeptServices.get_Designations().subscribe(data => {
      console.log('Department list', data);
      if (!data.error) {
        this.designationsList = data.data;
        this.loading = false;
      } else {
        this.designationsList = [];
        this.loading = false;
      }
    });
  }

  addNewDept() {
    console.log('Department Data', this.AddDesgForm.value);
    const body = {
      table: 'designations',
      shortname: this.AddDesgForm.controls['dept_code'].value,
      fullname: this.AddDesgForm.controls['dept_name'].value
    };
    this._addDeptServices.addNewCommonData(body).subscribe(addData => {
      console.log(addData);
      if (addData.error) {
        // success toaster
        this.toastr.successToastr('Designation details added successfully`', 'Success!');
        this.AddDesgForm.reset();
        this.getdeptsList();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editDept(item) {
    console.log('From List', item);
    this.AddDesgForm.patchValue({
      dept_code: item.short_name,
      dept_name: item.designation,
      status: item.status
    });
    // this.type_status = item.status;
    this.dataItem = item;
  }

  editDepartment() {
    console.log('Designation Data', this.AddDesgForm.value);
    const body = {
      table: 'designations',
      id: this.dataItem.id.toString(),
      fullname: this.AddDesgForm.controls['dept_name'].value,
      shortname: this.AddDesgForm.controls['dept_code'].value,
      status: this.AddDesgForm.controls['status'].value.toString()
    };

    this._addDeptServices.editCommonDatabyid(body).subscribe(editData => {
      console.log(editData);
      if (editData.error) {
        this.AddDesgForm.reset();
        this.getdeptsList();
        // success toaster
        this.toastr.successToastr('Designation details updated successfully', 'Success!');
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }

  resetForm() {
    this.AddDesgForm.reset();
  }
}
