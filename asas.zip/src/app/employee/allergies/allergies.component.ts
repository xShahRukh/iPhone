import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { ToastrManager } from 'ng6-toastr-notifications';
import { DepartmentService } from '../department/department.service';

@Component({
  selector: 'app-allergies',
  templateUrl: './allergies.component.html',
  styleUrls: ['./allergies.component.css']
})
export class AllergiesComponent implements OnInit {
  AllergieList;
  loading: Boolean = true;
  dataItem: any = new Object();
  AddAllergieForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      alrg_name: {
        required: 'Name is required'
      },
      alrg_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const alrg_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const alrg_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '', disabled: false }, [Validators.required]);

    this.AddAllergieForm = this.fb.group({
      alrg_name: alrg_name,
      alrg_code: alrg_code,
      status: status
    });

    this.getallergieList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    // if (this.AddAllergieForm) {
    //   const controlBlurs: Observable<any>[] = this.formInputElements.map(
    //     (formControl: ElementRef) =>
    //       Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
    //   );
    //   Observable.arguments
    //     .merge(this.AddAllergieForm.valueChanges, ...controlBlurs)
    //     .debounceTime(800)
    //     .subscribe(value => {
    //       this.displayMessage = this.genericValidator.processMessages(
    //         this.AddAllergieForm
    //       );
    //     });
    // }
  }

  getallergieList() {
    const body = { type: 'Inactive' };
    this._addDeptServices.getAllergieList(body).subscribe(data => {
      if (data.error) {
        this.loading = false;
        this.AllergieList = data.data[3].allergies;
      } else {
        this.AllergieList = [];
        this.loading = false;
      }
    });
    console.log(this.AllergieList);
  }

  addNewAllergie() {
    const body = {
      table: 'allergies',
      shortname: this.AddAllergieForm.controls['alrg_code'].value,
      fullname: this.AddAllergieForm.controls['alrg_name'].value
    };
    this._addDeptServices.addNewCommonData(body).subscribe(addData => {
      if (addData.error) {
        // success toaster
        this.toastr.successToastr('New Allergie details added successfully', 'Success!');
        this.AddAllergieForm.reset();
        this.getallergieList();
      } else {
        // warning toaster
        this.toastr.errorToastr(addData.message, 'Warning!');
      }
    });
  }

  editAllergy(item) {
    this.AddAllergieForm.patchValue({
      alrg_code: item.alrg_code,
      alrg_name: item.allergy,
      status: item.status
    });
    this.dataItem = item;
  }

  editAllergie() {
    const body = {
      table: 'allergies',
      shortname: this.AddAllergieForm.controls['alrg_code'].value,
      fullname: this.AddAllergieForm.controls['alrg_name'].value,
      id: this.dataItem.id.toString(),
      status: this.AddAllergieForm.controls['status'].value.toString()
    };

    this._addDeptServices.editCommonDatabyid(body).subscribe(editData => {
      if (editData.error) {
        // success toaster
        this.toastr.successToastr('Allergie details updated successfully', 'Success!');
        this.AddAllergieForm.reset();
        this.getallergieList();
      } else {
        // warning toaster
        this.toastr.errorToastr(editData.message, 'Warning!');
      }
    });
  }

  resetForm() {
    this.AddAllergieForm.reset();
    this.AddAllergieForm.patchValue({
      status: '1'
    });
  }
}
