import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UsersComponent } from './users/users.component';
import { EmpDepartmentComponent } from './department/department.component';
import { AllergiesComponent } from './allergies/allergies.component';
import { PhobiasComponent } from './phobias/phobias.component';
import { DisablitiesComponent } from './disablities/disablities.component';
import { HealthIssuesComponent } from './health-issues/health-issues.component';
import { DesignationsComponent } from './designations/designations.component';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';

const emproutes: Routes = [
  { path: 'EmpDashboard', component: EmployeeDashboardComponent },
  { path: 'EmpDept', component: EmpDepartmentComponent },
  { path: 'User', component: UsersComponent },
  { path: 'Allergie', component: AllergiesComponent },
  { path: 'Disablities', component: DisablitiesComponent },
  { path: 'Phobias', component: PhobiasComponent },
  { path: 'HealthIssues', component: HealthIssuesComponent },
  { path: 'AddDesg', component: DesignationsComponent },

  { path: '', redirectTo: 'EmpDashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'EmpDashboard', pathMatch: 'full' }
];
export const EmployeeRouting: ModuleWithProviders = RouterModule.forChild(emproutes);
