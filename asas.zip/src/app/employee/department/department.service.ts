import { Injectable } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { EmployeeSettings } from '../employee.settings';

@Injectable()
export class DepartmentService {
  constructor(private _apiService: ApiService) {}

  // Common for Departments, health issues
  addNewCommonData(body) {
    return this._apiService.callApi(EmployeeSettings.API.ADD_DEPARTMENT_LIST, 'post', body);
  }

  editCommonDatabyid(body) {
    return this._apiService.callApi(EmployeeSettings.API.EDIT_DEPARTMENT_LIST, 'post', body);
  }

  // GET_DEPARTMENT_LIST
  getDeptList() {
    const body = {};
    return this._apiService.callApi(EmployeeSettings.API.GET_DEPARTMENT_LIST, 'get', body);
  }

  // GET_DESIGNATIONS
  get_Designations() {
    const body = {};
    return this._apiService.callApi(EmployeeSettings.API.GET_DESIGNATIONS, 'get', body);
  }

  // GET_ALLERGIE_LIST
  getAllergieList(value) {
    const body = value;
    return this._apiService.callApi(EmployeeSettings.API.GET_ALLERGIE_LIST, 'post', body);
  }

  getDisabiltiesList(value) {
    const body = value;
    return this._apiService.callApi(EmployeeSettings.API.GET_ALLERGIE_LIST, 'post', body);
  }

  getHealthIssuesList(value) {
    const body = value;
    return this._apiService.callApi(EmployeeSettings.API.GET_ALLERGIE_LIST, 'post', body);
  }

  getPhobiasList(value) {
    const body = value;
    return this._apiService.callApi(EmployeeSettings.API.GET_ALLERGIE_LIST, 'post', body);
  }

  // ASSIGNED_ROLES_EMPLOYEES
  getAssignesroles() {
    return this._apiService.callApi(EmployeeSettings.API.ASSIGNED_ROLES_EMPLOYEES, 'get', {});
  }
}
