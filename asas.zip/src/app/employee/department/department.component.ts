import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { ToastrManager } from 'ng6-toastr-notifications';
import { DepartmentService } from './department.service';
declare var $;

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class EmpDepartmentComponent implements OnInit {
  departmentsList: any[];
  loading: Boolean = true;
  dataItem: any = new Object();
  AdddeptForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      dept_name: {
        required: 'Name is required'
      },
      dept_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const dept_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const dept_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '', disabled: false }, [Validators.required]);

    this.AdddeptForm = this.fb.group({
      dept_name: dept_name,
      dept_code: dept_code,
      status: status
    });

    this.getdeptsList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AdddeptForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
      );
      Observable.arguments
        .merge(this.AdddeptForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(this.AdddeptForm);
        });
    }
  }

  getdeptsList() {
    this._addDeptServices.getDeptList().subscribe(data => {
      console.log('Department list', data);
      if (!data.error) {
        this.departmentsList = data.data;
        this.loading = false;
      } else {
        this.departmentsList = [];
        this.loading = false;
      }
    });
  }

  addNewDept() {
    console.log('Department Data', this.AdddeptForm.value);
    const body = {
      table: 'departments',
      shortname: this.AdddeptForm.controls['dept_code'].value,
      fullname: this.AdddeptForm.controls['dept_name'].value
    };
    this._addDeptServices.addNewCommonData(body).subscribe(addData => {
      console.log(addData);
      if (addData.success) {
        // success toaster
        this.toastr.successToastr('New Department added successfully', 'Success!');
        this.AdddeptForm.reset();
        this.getdeptsList();
        $('#adddeptPop').modal('hide');
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editDept(item) {
    console.log('From List', item);
    this.AdddeptForm.patchValue({
      dept_code: item.short_name,
      dept_name: item.fullname,
      status: item.status
    });
    // this.type_status = item.status;
    this.dataItem = item;
  }

  editDepartment() {
    console.log('Department Data', this.AdddeptForm.value);
    const body = {
      table: 'departments',
      id: this.dataItem.id.toString(),
      fullname: this.AdddeptForm.controls['dept_name'].value,
      shortname: this.AdddeptForm.controls['dept_code'].value,
      status: this.AdddeptForm.controls['status'].value.toString()
    };

    this._addDeptServices.editCommonDatabyid(body).subscribe(editData => {
      console.log(editData);
      if (!editData.success) {
        this.AdddeptForm.reset();
        this.getdeptsList();
        // success toaster
        this.toastr.successToastr('Department details updated successfully', 'Success!');
        $('#editDocCatPop').modal('hide');
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }

  resetForm() {
    this.AdddeptForm.reset();
    this.AdddeptForm.patchValue({
      status: 1
    });
  }
}
