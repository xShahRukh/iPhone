import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

// Third Party Plugins
import { ModalModule } from 'ngx-modal';
import { CalendarModule } from 'primeng/primeng';
import { MyDatePickerModule } from 'mydatepicker';
import { CustomFormsModule } from 'ng2-validation';
import { EditorModule } from 'primeng/editor';
import { CKEditorModule } from 'ng2-ckeditor';
import { AutoCompleteModule } from 'primeng/primeng';
import { DataTableModule } from 'angular-6-datatable';
import { ToastrModule } from 'ng6-toastr-notifications';
import { ChartModule } from 'angular2-highcharts';

// common Services
import { SharedModule } from '../common/shareds.module';

import { ApiService } from '../common/services/api.service';
import { UserService } from './users/user.service';
import { DepartmentService } from './department/department.service';
import { UploadService } from '../common/services/upload.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { EmployeeRouting } from './employee.routing';
import { UsersComponent } from './users/users.component';
import { EmpDepartmentComponent } from './department/department.component';
import { AllergiesComponent } from './allergies/allergies.component';
import { PhobiasComponent } from './phobias/phobias.component';
import { DisablitiesComponent } from './disablities/disablities.component';
import { HealthIssuesComponent } from './health-issues/health-issues.component';
import { DesignationsComponent } from './designations/designations.component';
import { EmployeeDashboardComponent } from './employee-dashboard/employee-dashboard.component';
import { EmpTopMenuComponent } from './emp-top-menu/emp-top-menu.component';

declare var require;
export function highchartsFactory() {
  const Highcharts = require('highcharts');
  const Exporting = require('highcharts/modules/exporting');
  const More = require('highcharts/highcharts-more');
  const Solid = require('highcharts/modules/solid-gauge');
  const Heatmap = require('highcharts/modules/heatmap');
  const Pointline = require('highcharts/modules/export-data');
  const threeD = require('highcharts/highcharts-3d');
  const Funnel = require('highcharts/modules/funnel');
  Heatmap(Highcharts);
  Exporting(Highcharts);
  threeD(Highcharts);
  More(Highcharts);
  Solid(Highcharts);
  Pointline(Highcharts);
  threeD(Highcharts);
  Funnel(Highcharts);
  return Highcharts;
}

@NgModule({
  declarations: [
    UsersComponent,
    EmpDepartmentComponent,
    AllergiesComponent,
    PhobiasComponent,
    DisablitiesComponent,
    HealthIssuesComponent,
    DesignationsComponent,
    EmployeeDashboardComponent,
    EmpTopMenuComponent
  ],
  imports: [
    CommonModule,
    EmployeeRouting,
    FormsModule,
    EditorModule,
    CKEditorModule,
    ReactiveFormsModule,
    CustomFormsModule,
    DataTableModule,
    AutoCompleteModule,
    ModalModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    CKEditorModule,
    CalendarModule,
    EditorModule,
    SharedModule,
    ChartModule,
    ToastrModule.forRoot()
  ],

  providers: [ApiService, DepartmentService, UserService, UploadService]
})
export class EmployeeModule {}
