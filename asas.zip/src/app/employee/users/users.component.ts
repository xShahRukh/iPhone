import { IMyDpOptions } from "mydatepicker";
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from "@angular/forms";
import { ToastrManager } from "ng6-toastr-notifications";
import { Router } from "@angular/router";
import { ApiService } from "../../common/services/api.service";
import { GenericValidator } from "../../common/generic-validator";
import * as _ from "underscore";
import { CustomValidators } from "ng2-validation";
import * as moment from "moment";
import { XlsxToJsonService } from "../../common/services/xlsx-to-json-service";
import { Observable } from "rxjs";
import { DepartmentService } from "../department/department.service";
import { UserService } from "./user.service";
@Component({
  selector: "app-users",
  templateUrl: "./users.component.html",
  styleUrls: ["./users.component.css"]
})
export class UsersComponent implements OnInit {
  venderdet: any = [];
  result1;
  picName: any = [];
  file_exist: any;
  fileformat;
  alphabetRegex: any;
  mobileex: any;
  emailRegex: any;
  item: any = new Object();
  UsersList: any;
  loading: Boolean = true;
  dataItem: any = new Object();
  AdduserForm: FormGroup;
  public tableList = true;
  public addform = false;
  public excelupload: boolean;
  public result: any;
  private xlsxToJsonService: XlsxToJsonService = new XlsxToJsonService();
  cur_emp_id = null;
  emp;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  health_issues_list: any = [];
  disabilities_list: any = [];
  phobias_list: any = [];
  allergies_list: any = [];
  dept_list: any = [];
  designations_list: any = [];
  model;
  query;
  searchedvalue;
  query1 = true;
  @ViewChild("myInput", {static:false})
  myInputVariable: any;

  updateid = 0;
  emp_radio_type = null;
  @ViewChild("ref", {static:false})
  ref: ElementRef;
  dropdownList = [];
  selectedItems = [];
  selectedItems1 = [];
  selectedItems2 = [];
  selectedItems3 = [];
  dropdownSettings = {};
  dropdownSettings1 = {};
  dropdownSettings2 = {};
  dropdownSettings3 = {};

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _userService: UserService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public _deptService: DepartmentService
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      emp_name: { required: "Name is required" },
      emp_id: { required: "User Id is required" },
      email: {
        required: "Email Id is required",
        pattern: "Email Id should Contain atleast @ , . characters. "
      },
      contact1: {
        required: "Contact1 no. is required",
        pattern: "Contact1 no. should start with [789]{1}[0-9]{9}"
      },
      contact2: {
        required: "Alternate Contact no. is required",
        pattern: "Alternate Contact2 no. should start with [789]{1}[0-9]{9}",
        notEqualTo: "Alternate Contact2 no. should not match with Contact1 no."
      },
      emergency_contact1: { required: "Emergency1 contact is required" },
      emergency_contact2: {
        required: "Emergency contact is required"
      },
      designation: { required: "Designation is required" },
      department: { required: "Department is required" },
      prev_experience: { required: "prev_Experience is required" },
      gender: { required: "Gender is required" },
      date_of_birth: { required: "DOB is required" },
      date_of_joining: { required: "Date of Joining required" },
      date_of_leaving: { required: "Date of Leaving required" },
      health_issues: { required: "Health Issues required" },
      disabilities: { required: "Disabilities required" },
      phobias: { required: "Phobias Required" },
      allergies: { required: "Allergies Required" },
      emp_type: { required: "Emp type Required" },
      report_to: { required: "Reporting to is Required" }
    };
  }
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    height: "32px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  public myDatePickerOptions1: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    height: "32px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  public myDatePickerOptions2: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    height: "32px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.emailRegex = "/^w+([.-]?w+)*@w+([.-]?w+)*(.w{2,3})+$/";
    this.mobileex = "[7-9]{1}[0-9]{9}";
    this.alphabetRegex = "/^[a-zA-Z ]*$/";

    const emp_name = new FormControl({ value: "" }, [Validators.required]);
    const emp_id = new FormControl({ value: "" }, [Validators.required]);
    const email = new FormControl({ value: "" }, [Validators.required]);
    const contact1 = new FormControl({ value: "" }, [Validators.required]);
    const contact2 = new FormControl(
      { value: "" },
      CustomValidators.notEqualTo(contact1)
    );
    const emergency_contact_name = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const emergency_contact1 = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const emergency_contact2 = new FormControl({ value: "" });
    const designation = new FormControl({ value: "" }, [Validators.required]);
    const department = new FormControl({ value: "" }, [Validators.required]);
    const prev_experience = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const gender = new FormControl({ value: "" }, [Validators.required]);
    const date_of_birth = new FormControl({ value: "" }, [Validators.required]);
    const date_of_joining = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const date_of_leaving = new FormControl({ value: "" });
    const health_issues = new FormControl({ value: "" });
    const disabilities = new FormControl({ value: "" });
    const phobias = new FormControl({ value: "" });
    const allergies = new FormControl({ value: "" });
    const emp_type = new FormControl({ value: "" }, [Validators.required]);
    const vendor = new FormControl({ value: "" });
    const report_to = new FormControl({ value: "" }, [Validators.required]);
    const relation = new FormControl({ value: "" });
    this.AdduserForm = this.fb.group({
      emp_name: emp_name,
      emp_id: emp_id,
      email: email,
      contact1: contact1,
      contact2: contact2,
      emergency_contact_name: emergency_contact_name,
      emergency_contact1: emergency_contact1,
      emergency_contact2: emergency_contact2,
      designation: designation,
      department: department,
      prev_experience: prev_experience,
      gender: gender,
      date_of_birth: date_of_birth,
      date_of_joining: date_of_joining,
      date_of_leaving: date_of_leaving,
      health_issues: health_issues,
      disabilities: disabilities,
      phobias: phobias,
      allergies: allergies,
      emp_type: emp_type,
      report_to: report_to,
      vendor: vendor,
      relation: relation
    });
    this.get_HalthIssues();
    this.get_Departments();
    this.get_Designations();
    this.getusersList();
    this.getvenderdet();
    this.dropdownSettings = {
      singleSelection: false,
      text: "Select Health Issues",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
    this.dropdownSettings2 = {
      singleSelection: false,
      text: "Select Disabilities",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
    this.dropdownSettings3 = {
      singleSelection: false,
      text: "Select Phobias",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };
    this.dropdownSettings1 = {
      singleSelection: false,
      text: "Select Allergies",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class"
    };

    //   let t = [{id:1,value:'one'},{id:1,value:'three'},{id:1,value:'two'}]
    //  let tt= Object.keys(t).reduce(function (previous, key) {
    //     previous.value += t[key].value+',';
    //     return {id:t[key].id,value1:previous}
    // }, { value: 0 });
    // console.log(tt,'tttt');
  }

  onDateChanged(event) {
    console.log(event);
    this.myDatePickerOptions2 = {
      dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
      editableDateField: false,
      showTodayBtn: true,
      sunHighlight: true,
      satHighlight: false,
      markCurrentDay: true,
      markCurrentMonth: true,
      markCurrentYear: true,
      inline: false,
      height: "32px",
      width: "100%",
      componentDisabled: false,
      showClearDateBtn: true,
      openSelectorOnInputClick: true,
      disableUntil: event.date
    };

    this.myDatePickerOptions = {
      dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
      editableDateField: false,
      showTodayBtn: true,
      sunHighlight: true,
      satHighlight: false,
      markCurrentDay: true,
      markCurrentMonth: true,
      markCurrentYear: true,
      inline: false,
      height: "32px",
      width: "100%",
      componentDisabled: false,
      showClearDateBtn: true,
      openSelectorOnInputClick: true,
      disableSince: event.date
    };
  }

  save(value) {
    this.searchedvalue = value.emp_id;
    console.log(this.searchedvalue);
    this.query = value.emp_name;
    this.query1 = false;
    console.log(
      "Reference value" + <HTMLInputElement>this.ref.nativeElement.value
    );
  }
  valuechange(e) {
    console.log("f");
    this.query1 = true;
  }
  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AdduserForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, "blur")
      );
      Observable.arguments
        .merge(this.AdduserForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(
            this.AdduserForm
          );
        });
    }
  }

  getusersList() {
    this._userService.getUsersList().subscribe(docs => {
      console.log(docs, "docs categories list");
      if (docs.error) {
        this.UsersList = docs.data;
        this.loading = false;
      } else {
        this.UsersList = [];
      }
    });
  }

  get_Departments() {
    this._deptService.getDeptList().subscribe(data => {
      if (!data.error) {
        this.dept_list = data.data;
      } else {
        this.dept_list = [];
      }
    });
  }

  get_Designations() {
    this._deptService.get_Designations().subscribe(data => {
      if (!data.error) {
        this.designations_list = data.data;
      } else {
        this.designations_list = [];
      }
    });
  }

  get_HalthIssues() {
    const body = { type: "active" };
    this._deptService.getAllergieList(body).subscribe(data => {
      console.log("Health Issues List", data.data);
      if (data.error) {
        this.health_issues_list = data.data[0].health_issues;
        // this.health_issues_list.unshift({ value: '' });
        // this.health_issues_list.unshift({ value: 'select' });
        this.disabilities_list = data.data[1].disabilities;
        this.phobias_list = data.data[2].phobias;
        this.allergies_list = data.data[3].allergies;
        console.log("health issue", this.health_issues_list);
      } else {
        console.log("No Data found");
      }
    });
  }

  openaddform() {
    this.tableList = false;
    this.AdduserForm.controls["emp_id"].enable();
    this.AdduserForm.controls["date_of_birth"].enable();
    // this.AdduserForm.controls['date_of_leaving'].disable();
    this.AdduserForm.reset();
    this.selectedItems = [];
    this.selectedItems1 = [];
    this.selectedItems2 = [];
    this.selectedItems3 = [];
    this.addform = true;
    this.excelupload = false;
  }

  closeaddform() {
    this.tableList = true;
    this.addform = false;
    this.excelupload = false;
    this.AdduserForm.reset();
    this.selectedItems = [];
    this.selectedItems1 = [];
    this.selectedItems3 = [];
    this.selectedItems2 = [];
  }
  openExcelform() {
    this.addform = false;
    this.tableList = false;
    this.excelupload = true;
  }

  addNewUser() {
    const element = [];
    const element2 = [];
    const element3 = [];
    const element1 = [];
    for (let hl = 0; hl < this.selectedItems.length; hl++) {
      element.push(this.selectedItems[hl].hlth_issue_code);
    }
    for (let hl = 0; hl < this.selectedItems1.length; hl++) {
      element1.push(this.selectedItems1[hl].dis_code);
    }
    for (let hl = 0; hl < this.selectedItems2.length; hl++) {
      element2.push(this.selectedItems2[hl].phob_code);
    }
    for (let hl = 0; hl < this.selectedItems3.length; hl++) {
      element3.push(this.selectedItems3[hl].alrg_code);
    }
    if (this.updateid > 0) {
      const body = {};
      body["eid"] = this.updateid;
      body["emp_name"] = this.AdduserForm.value.emp_name;
      body["emp_id"] = this.cur_emp_id;
      body["email"] = this.AdduserForm.value.email;
      body["contact1"] = this.AdduserForm.value.contact1;
      body["contact2"] = this.AdduserForm.value.contact2;
      body[
        "emergency_contact_name"
      ] = this.AdduserForm.value.emergency_contact_name;
      body["emergency_contact1"] = this.AdduserForm.value.emergency_contact1;
      body["emergency_contact2"] = this.AdduserForm.value.emergency_contact2;
      body["designation"] = this.AdduserForm.value.designation;
      body["department"] = this.AdduserForm.value.department;
      body["prev_experience"] = this.AdduserForm.value.prev_experience;
      body["gender"] = this.AdduserForm.value.gender;
      if (this.AdduserForm.value.date_of_birth) {
        body["date_of_birth"] = this.AdduserForm.value.date_of_birth.formatted;
      }

      body[
        "date_of_joining"
      ] = this.AdduserForm.value.date_of_joining.formatted;

      if (this.model) {
        body[
          "date_of_leaving"
        ] = this.AdduserForm.value.date_of_leaving.formatted;
      } else {
        body["date_of_leaving"] = "";
      }

      body["health_issues"] = element.toString();
      body["disabilities"] = element1.toString();
      body["phobias"] = element2.toString();
      body["allergies"] = element3.toString();
      body["emp_type"] = this.AdduserForm.value.emp_type;
      body["report_to"] = this.searchedvalue;
      body["vendor"] = this.AdduserForm.value.vendor;
      body["relation"] = this.AdduserForm.value.relation;

      console.log(body);

      this._userService.updateEmployee(body).subscribe(res => {
        console.log(res);
        if (res.error) {
          console.log(res.message);
          this.toastr.successToastr(res.message, "Success!");
          this.updateid = 0;
          this.AdduserForm.reset();
          this.selectedItems = [];
          this.selectedItems1 = [];
          this.selectedItems3 = [];
          this.selectedItems2 = [];
          this.getusersList();
          this.addform = false;
          this.tableList = true;
        } else {
          this.toastr.warningToastr(res.message, "Warning!");
          this.addform = true;
          this.tableList = false;
        }
      });
    } else {
      const body = {};
      body["emp_name"] = this.AdduserForm.value.emp_name;
      body["emp_id"] = this.AdduserForm.value.emp_id;
      body["email"] = this.AdduserForm.value.email;
      body["contact1"] = this.AdduserForm.value.contact1;
      body["contact2"] = this.AdduserForm.value.contact2;
      body[
        "emergency_contact_name"
      ] = this.AdduserForm.value.emergency_contact_name;
      body["emergency_contact1"] = this.AdduserForm.value.emergency_contact1;
      body["emergency_contact2"] = this.AdduserForm.value.emergency_contact2;
      body["designation"] = this.AdduserForm.value.designation;
      body["department"] = this.AdduserForm.value.department;
      body["prev_experience"] = this.AdduserForm.value.prev_experience;
      body["gender"] = this.AdduserForm.value.gender;
      body["date_of_birth"] = this.AdduserForm.value.date_of_birth.formatted;
      body[
        "date_of_joining"
      ] = this.AdduserForm.value.date_of_joining.formatted;
      body["relation"] = this.AdduserForm.value.relation;
      if (this.model) {
        body[
          "date_of_leaving"
        ] = this.AdduserForm.value.date_of_leaving.formatted;
      } else {
        body["date_of_leaving"] = "";
      }
      body["health_issues"] = element.toString();
      body["disabilities"] = element1.toString();
      body["phobias"] = element2.toString();
      body["allergies"] = element3.toString();
      body["emp_type"] = this.AdduserForm.value.emp_type;
      body["vendor"] = this.AdduserForm.value.vendor;
      body["report_to"] = this.searchedvalue;
      console.log(body);

      this._userService.addEmployee(body).subscribe(res => {
        if (res.success) {
          console.log(res.message);
          this.toastr.successToastr(res.message, "Success!");
          this.updateid = 0;
          this.AdduserForm.reset();
          this.getusersList();
          this.addform = false;
          this.tableList = true;
        } else {
          this.toastr.warningToastr(res.message, "Warning!");
          this.addform = true;
          this.tableList = false;
        }
      });
    }
  }

  editUser(item) {
    this.query1 = false;
    this.addform = true;
    this.tableList = false;
    this.cur_emp_id = item.emp_id;
    this.updateid = item.eid;
    this.searchedvalue = item.reporting_to;
    this.selectedItems = [];
    this.selectedItems1 = [];
    this.selectedItems3 = [];
    this.selectedItems2 = [];
    // this.query = item.reporting_name;
    this.query = item.reporting_to;
    console.log("Edited data", item);
    if (item.emp_id) {
      this.AdduserForm.controls["emp_id"].disable();
    }
    if (item.date_of_birth) {
      this.AdduserForm.controls["date_of_birth"].disable();
    }

    if (item.health_issues == null) {
      this.AdduserForm.patchValue({
        health_issues: ""
      });
    } else {
      for (let im = 0; im < item.health_issues.split(",").length; im++) {
        for (let lj = 0; lj < this.health_issues_list.length; lj++) {
          if (
            item.health_issues.split(",")[im] ===
            this.health_issues_list[lj].hlth_issue_code
          ) {
            this.selectedItems.push({
              id: this.health_issues_list[lj].id,
              itemName: this.health_issues_list[lj].itemName,
              hlth_issue_code: this.health_issues_list[lj].hlth_issue_code
            });
          }
        }
      }
    }

    if (item.disabilities == null) {
      this.AdduserForm.patchValue({
        disabilities: ""
      });
    } else {
      for (let im = 0; im < item.disabilities.split(",").length; im++) {
        for (let lj = 0; lj < this.disabilities_list.length; lj++) {
          if (
            item.disabilities.split(",")[im] ===
            this.disabilities_list[lj].dis_code
          ) {
            this.selectedItems1.push({
              id: this.disabilities_list[lj].id,
              itemName: this.disabilities_list[lj].itemName,
              dis_code: this.disabilities_list[lj].dis_code
            });
          }
        }
      }
    }

    if (item.phobias == null) {
      this.AdduserForm.patchValue({
        phobias: ""
      });
    } else {
      for (let im = 0; im < item.phobias.split(",").length; im++) {
        for (let lj = 0; lj < this.phobias_list.length; lj++) {
          if (item.phobias.split(",")[im] === this.phobias_list[lj].phob_code) {
            this.selectedItems2.push({
              id: this.phobias_list[lj].id,
              itemName: this.phobias_list[lj].itemName,
              phob_code: this.phobias_list[lj].phob_code
            });
          }
        }
      }
    }

    if (item.allergies == null) {
      this.AdduserForm.patchValue({
        allergies: ""
      });
    } else {
      for (let im = 0; im < item.allergies.split(",").length; im++) {
        for (let lj = 0; lj < this.allergies_list.length; lj++) {
          if (
            item.allergies.split(",")[im] === this.allergies_list[lj].alrg_code
          ) {
            this.selectedItems3.push({
              id: this.allergies_list[lj].id,
              itemName: this.allergies_list[lj].itemName,
              alrg_code: this.allergies_list[lj].alrg_code
            });
          }
        }
      }
    }

    this.AdduserForm.patchValue({
      date_of_birth: {
        date: {
          year: new Date(item.date_of_birth).getFullYear(),
          month: new Date(item.date_of_birth).getMonth() + 1,
          day: new Date(item.date_of_birth).getDate()
        },
        formatted: moment(item.date_of_birth).format("YYYY-MM-DD")
      },
      date_of_joining: {
        date: {
          year: new Date(item.date_of_joining).getFullYear(),
          month: new Date(item.date_of_joining).getMonth() + 1,
          day: new Date(item.date_of_joining).getDate()
        },
        formatted: moment(item.date_of_joining).format("YYYY-MM-DD")
      },
      emp_name: item.emp_name,
      emp_id: item.emp_id,
      email: item.email,
      contact1: item.contact1,
      contact2: item.contact2,
      emergency_contact_name: item.emergency_contact_name,
      emergency_contact1: item.emergency_contact1,
      emergency_contact2: item.emergency_contact2,
      designation: item.desig_short,
      department: item.dept_short,
      prev_experience: item.prev_experience,
      gender: item.gender,
      emp_type: item.emp_type,
      vendor: item.vendor_id,
      relation: item.relation
    });
    if (
      item.date_of_leaving === "0000-00-00" ||
      item.date_of_leaving === null
    ) {
      this.AdduserForm.patchValue({
        date_of_leaving: ""
      });
    } else {
      this.AdduserForm.patchValue({
        date_of_leaving: {
          date: {
            year: new Date(item.date_of_leaving).getFullYear(),
            month: new Date(item.date_of_leaving).getMonth() + 1,
            day: new Date(item.date_of_leaving).getDate()
          },
          formatted: moment(item.date_of_leaving).format("YYYY-MM-DD")
        }
      });
    }
    this.AdduserForm.controls["date_of_leaving"].enable();
    this.onDateChanged({
      date: {
        year: new Date(item.date_of_joining).getFullYear(),
        month: new Date(item.date_of_joining).getMonth() + 1,
        day: new Date(item.date_of_joining).getDate()
      }
    });
  }

  viewCategory(item) {
    console.log(item);
    this.item = item;
  }

  // result1;
  handleFile(event) {
    const file = event.target.files[0];
    this.xlsxToJsonService.processFileToJson({}, file).subscribe(data => {
      this.result = data["sheets"].Sheet1;
      //  this.myModal.nativeElement.className = 'modal fade show';
      console.log(typeof this.result);
      this.result1 = _.toArray(this.result);
      document.getElementById("openModalButton").click();
      this.reset();
    });
  }

  Submit() {
    if (this.emp_radio_type === "add") {
      this._userService.addEmployee_excel(this.result1).subscribe(res => {
        if (res.success) {
          console.log(res.message);
          this.toastr.successToastr(res.message, "Success!");
          this.updateid = 0;
          this.AdduserForm.reset();
          this.getusersList();
          this.addform = false;
          this.tableList = true;
          this.excelupload = false;
        } else {
          this.toastr.warningToastr(res.message, "Warning!");
          this.addform = true;
          this.tableList = false;
          this.excelupload = true;
        }
      });
    }
    if (this.emp_radio_type === "update") {
      this._userService.updateEmployee_excel(this.result1).subscribe(res => {
        if (res.success) {
          console.log(res.message);
          this.toastr.successToastr(res.message, "Success!");
          this.updateid = 0;
          this.AdduserForm.reset();
          this.getusersList();
          this.addform = false;
          this.tableList = true;
          this.excelupload = false;
        } else {
          this.toastr.warningToastr(res.message, "Warning!");
          this.addform = true;
          this.tableList = false;
          this.excelupload = true;
        }
      });
    }
  }

  reset() {
    console.log(this.myInputVariable.nativeElement.files);
    this.myInputVariable.nativeElement.value = "";
    console.log(this.myInputVariable.nativeElement.files);
  }

  change_emptype() {
    console.log(this.AdduserForm.value.emp_type);
    if (this.AdduserForm.value.emp_type !== "Contracter") {
      this.AdduserForm.patchValue({
        vendor: 0
      });
    } else {
      this.AdduserForm.patchValue({
        vendor: ""
      });
    }
  }

  getvenderdet() {
    this._userService.getvenderdetails().subscribe(docs => {
      console.log(docs);
      this.venderdet = [];
      if (docs.success) {
        this.venderdet = docs.data;
      }
    });
  }

  // reset() {
  //   console.log(this.myInputVariable.nativeElement.files);
  //   this.myInputVariable.nativeElement.value = '';
  //   console.log(this.myInputVariable.nativeElement.files);
  getvendername(value) {
    const ven = _.filter(this.venderdet, function (o) {
      return o.vendor_id === value;
    });
    console.log(ven);
    if (ven.length !== 0) {
      return ven[0].vendor_name;
    } else {
      return "--";
    }
  }

  excel_Add($event) {
    // console.log($event.target.value);
    this.emp_radio_type = $event.target.value;
  }
  // get_Employee_name(emp_id) {
  //   if (emp_id) {
  //     console.log(emp_id,_.findWhere(this.UsersList, { emp_id: emp_id }));
  //     this.emp = _.findWhere(this.UsersList, { emp_id: emp_id }).emp_name;
  //     return this.emp;
  //   } else {
  //     return '';
  //   }
  // }

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }

  onItemSelect1(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect1(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll1(items: any) {
    console.log(items);
  }
  onDeSelectAll1(items: any) {
    console.log(items);
  }

  onItemSelect2(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect2(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll2(items: any) {
    console.log(items);
  }
  onDeSelectAll2(items: any) {
    console.log(items);
  }

  onItemSelect3(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect3(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll3(items: any) {
    console.log(items);
  }
  onDeSelectAll3(items: any) {
    console.log(items);
  }
}
