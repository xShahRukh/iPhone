import { Injectable } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { EmployeeSettings } from '../employee.settings';

@Injectable()
export class UserService {
  constructor(private _apiService: ApiService) {}

  // ADD_DOCUMENT_DETAI
  getUsersList() {
    const body = {};
    return this._apiService.callApi(EmployeeSettings.API.GET_EMPLOYEES_LIST, 'get', body);
  }
  addEmployee(value) {
    const body = JSON.stringify(value);
    return this._apiService.callApi(EmployeeSettings.API.ADD_EMPLOYEE, 'post', body);
  }

  updateEmployee(value) {
    const body = JSON.stringify(value);
    return this._apiService.callApi(EmployeeSettings.API.UPDATE_EMPLOYEE, 'post', body);
  }

  addEmployee_excel(value) {
    const body = JSON.stringify(value);
    return this._apiService.callApi(EmployeeSettings.API.EMPLOYEES_EXCEL, 'post', body);
  }
  updateEmployee_excel(value) {
    const body = JSON.stringify(value);
    return this._apiService.callApi(EmployeeSettings.API.EMPLOYEES_EXCEL_UPDATE, 'post', body);
  }

  getvenderdetails() {
    return this._apiService.callApi(EmployeeSettings.API.GET_VENDERDET, 'get', '');
  }
}
//
