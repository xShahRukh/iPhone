import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { DepartmentService } from '../department/department.service';

@Component({
  selector: 'app-phobias',
  templateUrl: './phobias.component.html',
  styleUrls: ['./phobias.component.css']
})
export class PhobiasComponent implements OnInit {
  PhobiasList: any = [];
  loading: Boolean = true;
  dataItem: any = new Object();
  AddPhobiasForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      phobias_name: {
        required: 'Name is required'
      },
      phobias_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const phobias_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const phobias_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '', disabled: false }, [Validators.required]);

    this.AddPhobiasForm = this.fb.group({
      phobias_name: phobias_name,
      phobias_code: phobias_code,
      status: status
    });

    this.getPhobiasList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    // if (this.AddPhobiasForm) {
    //   const controlBlurs: Observable<any>[] = this.formInputElements.map(
    //     (formControl: ElementRef) =>
    //       Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
    //   );
    //   Observable.arguments
    //     .merge(this.AddPhobiasForm.valueChanges, ...controlBlurs)
    //     .debounceTime(800)
    //     .subscribe(value => {
    //       this.displayMessage = this.genericValidator.processMessages(
    //         this.AddPhobiasForm
    //       );
    //     });
    // }
  }

  getPhobiasList() {
    const body = { type: 'In-active' };
    this._addDeptServices.getPhobiasList(body).subscribe(data => {
      console.log('Phobias list', data.data[2].phobias);
      if (data.error) {
        this.loading = false;
        this.PhobiasList = data.data[2].phobias;
      } else {
        this.PhobiasList = [];
        this.loading = false;
      }
    });
    console.log(this.PhobiasList);
  }

  addNewPhobia() {
    const body = {
      table: 'phobias',
      shortname: this.AddPhobiasForm.controls['phobias_code'].value,
      fullname: this.AddPhobiasForm.controls['phobias_name'].value
    };
    this._addDeptServices.addNewCommonData(body).subscribe(addData => {
      if (addData.error) {
        // success toaster
        this.toastr.successToastr('Phobia details added successfully', 'Success!');
        this.AddPhobiasForm.reset();
        this.getPhobiasList();
      } else {
        // warning toaster
        this.toastr.errorToastr(addData.message, 'Warning!');
      }
    });
  }

  editPhobia(item) {
    this.AddPhobiasForm.patchValue({
      phobias_code: item.phob_code,
      phobias_name: item.phobia,
      status: item.status
    });
    this.dataItem = item;
  }

  editPhobias() {
    const body = {
      id: this.dataItem.id.toString(),
      table: 'phobias',
      shortname: this.AddPhobiasForm.controls['phobias_code'].value,
      fullname: this.AddPhobiasForm.controls['phobias_name'].value,
      status: this.AddPhobiasForm.controls['status'].value.toString()
    };

    this._addDeptServices.editCommonDatabyid(body).subscribe(editData => {
      if (editData.error) {
        // success toaster
        this.toastr.successToastr('Phobia details updated successfully', 'Success!');
        this.getPhobiasList();
        this.AddPhobiasForm.reset();
      } else {
        // warning toaster
        this.toastr.errorToastr(editData.message, 'Warning!');
      }
    });
  }

  resetForm() {
    this.AddPhobiasForm.reset();
    this.AddPhobiasForm.patchValue({
      status: 1
    });
  }
}
