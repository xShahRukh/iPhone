import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as _ from 'underscore';
import { ApiService } from 'src/app/common/services/api.service';

declare let require: any;
const Highcharts = require('highcharts');
declare var $: any;
Highcharts.setOptions({
  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});

@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {
  spinner = false;
  gender: Object;
  job_status: Object;
  emp_categories: Object;
  Joinings_resignations: Object;

  constructor(private router: Router, public _apiService: ApiService) {}

  ngOnInit() {
    this.employeeDashboard();
  }

  employeeDashboard() {
    this.spinner = true;
    this._apiService.employeeDashboard().subscribe(response => {
      console.log(response);
      if (response.success) {
        const chartColor = ['#50b332', '#1a8dc7', '#df6811'];
        let i = 0;
        response.data.genderCount.forEach(element => {
          element['color'] = chartColor[i++];
        });
        const employeeType = ['#50b332', '#406f07', '#759a47'];
        i = 0;
        response.data.employeeType.forEach(element => {
          element['color'] = employeeType[i++];
        });
        this.gender = {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            height: 210,
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            marginBottom: 0,
            marginTop: 0,
            marginLeft: 0,
            options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
            }
          },
          title: {
            text: ''
          },
          tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
          },
          exporting: {
            enabled: false
          },
          credits: {
            enabled: false
          },
          legend: {
            width: 240,
            floating: true,
            align: 'left',
            x: 20, // = marginLeft - default spacingLeft
            verticalAlign: 'bottom',
            y: 10,
            itemDistance: 5,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            }
          },
          plotOptions: {
            pie: {
              center: ['50%', '40%'],
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                enabled: false,
                format: '<b>{point.name}</b>: {point.y}'
              },
              showInLegend: true,
              depth: 35
            }
          },
          series: [
            {
              name: 'Employees',
              colorByPoint: true,
              data: response.data.genderCount
            }
          ]
        };

        this.job_status = {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            height: 210,
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            // marginBottom: 0,
            marginTop: 0,
            marginLeft: 0,
            options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
            }
          },
          title: {
            text: ''
          },
          tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
          },
          exporting: {
            enabled: false
          },
          credits: {
            enabled: false
          },
          legend: {
            width: 240,
            floating: true,
            align: 'left',
            x: 0, // = marginLeft - default spacingLeft
            verticalAlign: 'bottom',
            y: 20,
            itemDistance: 5,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            }
          },
          plotOptions: {
            pie: {
              center: ['50%', '50%'],
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                enabled: false,
                format: '<b>{point.name}</b>: {point.y}'
              },
              showInLegend: true,
              depth: 35
            }
          },
          series: [
            {
              name: 'Employees',
              colorByPoint: true,
              data: response.data.employeeType
            }
          ]
        };

        this.emp_categories = {
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            marginBottom: 0,
            marginTop: 0,
            marginLeft: 0,
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            options3d: {
              enabled: true,
              alpha: 45,
              beta: 0
            }
          },
          title: {
            text: ''
          },
          tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
          },
          exporting: {
            enabled: false
          },
          credits: {
            enabled: false
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              center: ['50%', '30%'],
              dataLabels: {
                enabled: false,
                format: '<b>{point.name}</b>: {point.y}'
              },
              showInLegend: true,
              depth: 35
            }
          },
          legend: {
            align: 'center',
            itemDistance: 5,
            itemMarginTop: 0,
            itemMarginBottom: 3,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            },
            itemHoverStyle: {
              color: 'gray'
            }
          },
          series: [
            {
              name: 'Employees',
              colorByPoint: true,
              data: response.data.employeeDepartment
            }
          ]
        };

        this.Joinings_resignations = {
          chart: {
            type: 'column',
            height: 450,
            marginTop: 40,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: false
          },
          subtitle: {
            text: false
          },
          credits: {
            enabled: false
          },
          exporting: {
            enabled: false
          },
          legend: {
            align: 'center',
            itemDistance: 5,
            itemMarginTop: 0,
            itemMarginBottom: 3,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            },
            itemHoverStyle: {
              color: 'gray'
            }
          },
          xAxis: {
            categories: _.pluck(response.data.employeeDojDob, 'monthName'),
            crosshair: true,
            style: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            }
          },
          yAxis: {
            min: 0,
            title: {
              // text: 'Rainfall (mm)'
              text: false
            }
          },
          tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat:
              '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
              '<td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
          },
          plotOptions: {
            column: {
              pointPadding: 0.2,
              borderWidth: 0
            },
            showInLegend: true
          },
          series: [
            {
              name: 'Employee Joinings',
              data: _.pluck(response.data.employeeDojDob, 'joining'),
              color: '#50b232'
            },
            {
              name: 'Employee Resignees',
              data: _.pluck(response.data.employeeDojDob, 'leaving'),
              color: '#1a8dc7'
            }
          ]
        };
      }
      this.spinner = false;
    });
  }
}
