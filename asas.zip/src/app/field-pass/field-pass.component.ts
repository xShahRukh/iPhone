import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-field-pass',
  templateUrl: './field-pass.component.html',
  styleUrls: ['./field-pass.component.css']
})
export class FieldPassComponent implements OnInit {
  fieldpass: any = [];
  constructor() {}

  ngOnInit() {
    this.getFieldPassData();
  }
  getFieldPassData() {
    this.fieldpass = {
      chart: {
        type: 'column',
        height: 300,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
        // options3d: {
        //   enabled: true,
        //   alpha: 10,
        //   beta: 0,
        //   viewDistance: 20,
        //   depth: 40
        // }
      },

      title: {
        text: 'Field Pass Management'
      },

      xAxis: {
        categories: [
          'Digboi',
          'Naharkatiya',
          'Moran',
          'Rudrasagar',
          'Galeki',
          'Hugrijan',
          'Angui',
          'Lakwa'
        ],
        labels: {
          skew3d: true,
          style: {
            fontSize: '12px'
          }
        },
        title: {
          text: ''
        }
      },

      yAxis: {
        allowDecimals: false,
        min: 0,
        title: {
          text: ''
        },
        labels: {
          enabled: false
        }
      },
      legend: {
        symbolRadius: 0,
        align: 'center',
        x: 0,
        verticalAlign: 'top',
        y: 20,
        itemStyle: {
          font: '9pt Trebuchet MS, Verdana, sans-serif'
          // color: '#A0A0A0'
        }
      },
      tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat:
          '<span style="color:{series.color}">\u25CF</span> {series.name}: {point.y} / {point.stackTotal}'
      },
      credits: {
        enabled: false
      },
      exporting: {
        enabled: false
      },
      plotOptions: {
        column: {
          stacking: 'normal',
          depth: 40,
          dataLabels: {
            enabled: false,
            color: 'white'
          }
        }
      },

      series: [
        {
          name: 'Pending',
          data: [5, 4, 0, 2, 3, 2, 1, 0],
          stack: 'pass',
          color: '#7ACC86'
        },
        {
          name: 'Rejected',
          data: [1, 1, 0, 1, 0, 0, 1, 0],
          stack: 'pass',
          color: '#F9E570'
        },
        {
          name: 'Received',
          data: [2, 1, 3, 1, 4, 2, 0, 1],
          stack: 'pass',
          color: '#60A6C1'
        },
        {
          name: 'Applied',
          data: [8, 6, 3, 4, 7, 4, 2, 1],
          stack: 'pass',
          color: '#FF887F'
        }
      ]
    };
  }
}
