import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FieldPassComponent } from './field-pass.component';

describe('FieldPassComponent', () => {
  let component: FieldPassComponent;
  let fixture: ComponentFixture<FieldPassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FieldPassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FieldPassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
