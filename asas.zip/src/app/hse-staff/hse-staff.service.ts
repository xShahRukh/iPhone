import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../common/services/api.service';
import { AppSettings } from '../app.settings';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';

@Injectable()
export class HseStaffService {
  constructor(
    private _apiService: ApiService,
    public _http: Http,
    private http: Http
  ) {}

  getUsersList() {
    return this._apiService.callApi(
      AppSettings.API.GET_EMPLOYEES_LIST,
      'GET',
      {}
    );
  }

  getlistoflocat() {
    const body = {};
    return this._apiService.callApi(AppSettings.API.GET_LOCATIONS, 'GET', body);
  }

  // Add coordinator
  addcoordinator(body) {
    return this._apiService.callApi(
      AppSettings.API.ADD_COORDINATOR,
      'POST',
      body
    );
  }
}
