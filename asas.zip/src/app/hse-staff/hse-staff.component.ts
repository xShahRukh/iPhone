import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl,
  FormArray
} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Observable } from 'rxjs/Observable';
import * as _ from 'underscore';
import { GenericValidator } from '../common/generic-validator';
import { ApiService } from '../common/services/api.service';
import { HseStaffService } from './hse-staff.service';

@Component({
  selector: 'app-hse-staff',
  templateUrl: './hse-staff.component.html',
  styleUrls: ['./hse-staff.component.css']
})
export class HseStaffComponent implements OnInit {
  LocationsList: any[];
  loading;
  dataItem: any = new Object();
  LocationForm: FormGroup;
  Emp_selected = [];
  dropdownSettings_Emp: any = [];

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  showForm = '';
  loc_ids_det = [];
  UsersList = [];
  type = '';
  supervisorForm = false;
  constUsersList = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _hsestaffService: HseStaffService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      location_name: {
        required: 'Name is required'
      },
      supervisor: {
        required: 'Supervisors are required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  async ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    await this.getusersList();
    this.dropdownSettings_Emp = {
      text: 'Select Coordinator',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      singleSelection: true,
      showCheckbox: true
    };
  }

  async getusersList() {
    this.loading = true;
    this.UsersList = [];
    this.constUsersList = [];
    await this._hsestaffService.getUsersList().subscribe(async docs => {
      this.loading = false;
      if (!docs.success) {
        const user_status = _.filter(docs.data, function(o) {
          return o.status === 1;
        });
        await user_status.forEach(element => {
          this.UsersList.push({
            id: element.emp_id,
            itemName: element.emp_name,
            text: element.emp_name,
            value: element.emp_name
          });
        });
        this.UsersList = _.sortBy(this.UsersList, 'itemName');
        this.constUsersList = this.UsersList;
        await this.getlistoflocations();
      } else {
        this.UsersList = [];
      }
    });
  }

  addNewRow(value) {
    const control = <FormArray>this.LocationForm.controls['parent_id'];
    control.push(this.initItemRows(value));
  }

  initItemRows(value) {
    return this.fb.group({
      parent_id: new FormControl('', [Validators.required]),
      datatoShow: [value]
    });
  }

  getlistoflocations() {
    this.loading = true;
    this.backtoForm();
    this._hsestaffService.getlistoflocat().subscribe(data => {
      if (!data.error) {
        data.data.forEach(element => {
          const name = _.filter(this.UsersList, function(o) {
            return o.id === element.coordinator;
          });
          element['coordinator_name'] = name[0].itemName;
        });
        this.LocationsList = data.data;
        this.refreshform();
        this.loading = false;
      } else {
        this.LocationsList = [];
        this.loading = false;
      }
    });
  }

  backtoForm() {
    this.showForm = 'table';
  }

  addform() {
    this.type = '';
    this.showForm = 'form';
    this.refreshform();
  }

  async addNewCoOrdinator() {
    if (
      this.LocationForm.value['coordinatorName'][0].id ===
      sessionStorage.getItem('userid')
    ) {
      this._apiService.Coordinator = true;
    }
    const body = [];
    if (
      this.LocationForm.value['parent_id'][
        this.LocationForm.value['parent_id'].length - 1
      ].parent_id === 'All'
    ) {
      this.LocationForm.value['parent_id'][
        this.LocationForm.value['parent_id'].length - 1
      ].datatoShow.forEach(element => {
        body.push({
          loc_id: element.loc_id,
          coordinator: this.LocationForm.value['coordinatorName'][0].id,
          coordinator_status: this.LocationForm.controls['status'].value
        });
      });
    } else {
      body.push({
        loc_id: this.LocationForm.value['parent_id'][
          this.LocationForm.value['parent_id'].length - 1
        ].parent_id,
        coordinator: this.LocationForm.value['coordinatorName'][0].id,
        coordinator_status: this.LocationForm.controls['status'].value
      });
    }

    // await body.forEach(async element => {
    //   const childCheck = await this.checkForchild(element);
    //   await console.log(childCheck);
    // });
    this._hsestaffService.addcoordinator({ data: body }).subscribe(addData => {
      if (!addData.error) {
        this.type = '';
        this.supervisorForm = false;
        this.toastr.successToastr('Coordinator details saved successfully');
        this.LocationForm.reset();
        this.getlistoflocations();
      } else {
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editpermit(item) {
    this.type = 'edit';
    this.showForm = 'form';
    const status = new FormControl({ value: '1', disabled: false }, [
      Validators.required
    ]);
    this.LocationForm = this.fb.group({
      coordinatorName: new FormControl({ value: [], disabled: false }, [
        Validators.required
      ]),
      loc_id: '',
      parent_id: this.fb.array([]),
      status: status
    });
    this.Emp_selected = [];
    // ----------------------------------------
    this.Emp_selected = _.filter(this.UsersList, function(o) {
      return o.id === item.coordinator;
    });

    this.LocationForm.patchValue({
      coordinatorName: this.Emp_selected,
      status: item.status,
      loc_id: item.loc_id
    });
    this.dataItem = item;

    const pids_det = _.filter(this.LocationsList, function(o) {
      return parseInt(o.parent_id, 0) === parseInt(item.parent_id, 0);
    });

    this.loc_ids_det = [];
    this.loc_ids_det.push({
      ids: item.loc_id,
      data: pids_det
    });
    this.checklocid(item.parent_id);
    for (let j = this.loc_ids_det.length - 1; j >= 0; j--) {
      if (j === this.loc_ids_det.length - 1) {
        this.loc_ids_det[j]['data'] = _.filter(this.LocationsList, function(o) {
          return parseInt(o.parent_id, 0) === 0;
        });
      }
      this.EditNewRow(this.loc_ids_det[j]);
    }
  }

  EditNewRow(value) {
    const control = <FormArray>this.LocationForm.controls['parent_id'];
    control.push(this.initItemRowsEdit(value));
  }

  initItemRowsEdit(value) {
    return this.fb.group({
      parent_id: new FormControl(value.ids, [Validators.required]),
      datatoShow: [value.data]
    });
  }

  checklocid(pid) {
    const pids_det = _.filter(this.LocationsList, function(o) {
      return o.loc_id === parseInt(pid, 0);
    });
    if (pids_det.length) {
      if (pids_det[0].parent_id) {
        const b = this.checkpids(pids_det[0].parent_id);
        if (b.length) {
          this.checklocid(b[0].parent_id);
        }
      } else {
        this.checkpids(null);
      }
    }
  }

  checkpids(pid) {
    let pids_det = [];
    if (pid) {
      pids_det = _.filter(this.LocationsList, function(o) {
        return o.parent_id === parseInt(pid, 0);
      });
    } else {
      pids_det = _.filter(this.LocationsList, function(o) {
        return o.parent_id == null;
      });
    }
    if (pids_det.length) {
      this.loc_ids_det.push({
        ids: this.loc_ids_det[this.loc_ids_det.length - 1].data[0].parent_id,
        data: pids_det
      });
    } else {
      this.loc_ids_det.push({
        ids: this.loc_ids_det[this.loc_ids_det.length - 1].data[0].parent_id,
        data: pids_det
      });
    }
    return pids_det;
  }

  refreshform() {
    const nullids = _.filter(this.LocationsList, function(o) {
      return o.parent_id == null || o.parent_id === 0;
    });

    const status = new FormControl({ value: 1, disabled: false }, [
      Validators.required
    ]);
    this.LocationForm = this.fb.group({
      coordinatorName: new FormControl({ value: [], disabled: false }, [
        Validators.required
      ]),
      loc_id: '',
      parent_id: this.fb.array([this.initItemRows(nullids)]),
      status: status
    });
    this.Emp_selected = [];
  }

  findnextchild(value) {
    const frm_len = this.LocationForm.value.parent_id.length;
    for (let i = frm_len - 1; i > value; i--) {
      this.deleteRow(i);
    }
    const pid = this.LocationForm.value.parent_id[value].parent_id;
    const withpids = _.filter(this.LocationsList, function(o) {
      return o.parent_id === parseInt(pid, 0);
    });
    if (withpids.length) {
      this.addNewRow(withpids);
    }
  }

  deleteRow(index) {
    const control = <FormArray>this.LocationForm.controls['parent_id'];
    control.removeAt(index);
  }

  getlocation_name(value) {
    let loc_nam = value.location_name;
    while (true) {
      if (value.parent_id) {
        const pids = value.parent_id;
        const withpids = _.filter(this.LocationsList, function(o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam = loc_nam + ', ' + withpids[0].location_name;
        value = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    return loc_nam;
  }

  getlocation_nameReverse(value) {
    let loc_nam = [];
    loc_nam.push(value.location_name);
    while (true) {
      if (value.parent_id) {
        const pids = value.parent_id;
        const withpids = _.filter(this.LocationsList, function(o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        value = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    return _.chain(loc_nam)
      .reverse()
      .value();
  }

  // async checkForchild(value) {
  //   const getAllChilds = await _.filter(this.LocationsList, function(o) {
  //     return o.parent_id === value.loc_id;
  //   });
  //   await getAllChilds.forEach(async element => {
  //     if (element.parent_id) {
  //       await this.checkForchild(element);
  //     } else {
  //       return await [
  //         {
  //           loc_id: element.loc_id,
  //           coordinator_status: element.coordinator_status
  //         }
  //       ];
  //     }
  //   });
  //   if (!getAllChilds.length) {
  //     return await [
  //       {
  //         loc_id: value.loc_id,
  //         coordinator_status: value.coordinator_status
  //       }
  //     ];
  //   }
  // }
}
