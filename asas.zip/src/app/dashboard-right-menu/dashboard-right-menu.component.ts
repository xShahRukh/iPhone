import { Component, OnInit } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
// import { DashboardService } from '../dashboard/dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../common/services/api.service';
import { SharedService } from '../common/services/shared.service';
// import { HolidaysService } from '../settingspages/holidays/holidays.service';
// import { NOTICEBOARDSERVICE } from '../notice-board/notice-boardservice';
import { environment } from 'src/environments/environment.prod';
import * as moment from 'moment';
import * as _ from 'underscore';

@Component({
  selector: 'app-dashboard-right-menu',
  templateUrl: './dashboard-right-menu.component.html',
  styleUrls: ['./dashboard-right-menu.component.css']
})
export class DashboardRightMenuComponent implements OnInit {
  holidaydate: any;
  holiday: any;
  widgetData: any;
  leavecount: any;
  leavestotal: any;
  projectscount: any;
  projectscompleted: any;
  visitorscount: any;
  graphvisitorsDays = [];
  graphvisitorsData = [];
  visitorsData = {};
  expectedList = {};
  presentList = {};
  directorCountData = [];
  employeeShiftCount = [];
  role;
  resourceEngaged = 0;
  noticeBoardData = [];
  unapprovedVisitors = [];
  todayVisitors = [];
  upcomingVisitors = [];
  // Url = environment.serverPath;
  // shifts dynamic
  shiftTimings = [];
  upcomingMeeting: any;
  upcomingMeetingsList = [];
  employeeDetails: any = [];
  title: any;
  holidayList: any = [];
  holiday_curr_startdate: any;
  enable_prev: boolean;

  constructor(
    public toastr: ToastrManager,
    // private _dashboardService: DashboardService,
    public router: Router,
    private _route: ActivatedRoute,
    public service: ApiService,
    public _sharedService: SharedService
  ) {}

  ngOnInit() {
    this.role = sessionStorage.getItem('role');
    // Right Side List
    this.getHolidayslist();
    this.getDirectorUpcomingMeetings();
    this.visitorStatusCount();
    this.getNotifications();
    // Right Side List

    // upcoming visitors list
    this.upcomingVisitorsList();
  }

  // Right Side Start

  //  Holidays Start
  getHolidayslist() {
    // this._holidayService
    //   .getHolidaysListALL({
    //     location: sessionStorage.getItem('location'),
    //     group: sessionStorage.getItem('leave_group')
    //   })
    //   .subscribe(data => {
    //     console.log(data);
    //     if (data.success) {
    //       this.holidayList = data.data;
    //       const k1 = _.filter(this.holidayList, function (num) {
    //         return (
    //           moment(num.dt).format('YYYY-MM-DD') >=
    //           moment().format('YYYY-MM-DD')
    //         );
    //       });
    //       for (let ele = 0; ele < k1.length; ele++) {
    //         const d = +moment(k1[ele].dt).format('D');
    //         const curr_d = +moment().format('D');
    //         if (d === curr_d || d > curr_d) {
    //           this.holidaydate = k1[ele].dt;
    //           this.holiday = k1[ele].holiday;
    //           this.holiday_curr_startdate = k1[ele].dt;
    //           this.enable_prev = false;
    //           break;
    //         }
    //       }
    //     }
    //   });
  }

  upcomingVisitorsList() {
    // this._dashboardService.getUpcomingVisitorsList().subscribe(data => {
    //   if (data.success) {
    //     this.unapprovedVisitors = data.unapprovedVisitors;
    //     this.todayVisitors = data.todayVisitors;
    //     this.upcomingVisitors = data.upcomingVisitors;
    //   }
    // });
  }

  changecaseholiday(event) {
    if (event === 'add') {
      for (let ele1 = 0; ele1 < this.holidayList.length; ele1++) {
        if (this.holidaydate === this.holidayList[ele1].dt) {
          this.holidaydate = this.holidayList[ele1 + 1].dt;
          this.holiday = this.holidayList[ele1 + 1].holiday;
          this.enable_prev = true;
          break;
        }
      }
    } else if (event === 'sub') {
      for (let ele1 = 0; ele1 < this.holidayList.length; ele1++) {
        if (this.holidaydate === this.holidayList[ele1].dt) {
          this.holidaydate = this.holidayList[ele1 - 1].dt;
          this.holiday = this.holidayList[ele1 - 1].holiday;
          if (
            moment(this.holidaydate).format('YYYY-MM-DD') <=
            moment(this.holiday_curr_startdate).format('YYYY-MM-DD')
          ) {
            this.enable_prev = false;
          }
          break;
        }
      }
    }
  }

  // Upcoming Meetings
  getDirectorUpcomingMeetings() {
    // this._dashboardService.getUpcomingMeeting().subscribe(data => {
    //   if (data.success) {
    //     console.log('upcoming meetings', data.data, data.data.length);
    //     this.upcomingMeeting = data.data;
    //     // this.upcomingMeetingsList = data.data;
    //     if (this.upcomingMeeting.length > 0) {
    //       this.upcomingMeeting.forEach(item => {
    //         this.upcomingMeetingsList.push({
    //           meeting_date: moment(item.meeting_date).format('MMMM DD, YYYY'),
    //           start_time: item.start_time,
    //           end_time: item.end_time,
    //           venue: item.venue,
    //           details: item.details
    //         });
    //       });
    //     }
    //   }
    // });
  }

  // visitor status count
  visitorStatusCount() {
    // this._dashboardService.getVisitorStatusCount().subscribe(data => {
    //   if (data.success) {
    //     console.log(data.data);
    //     this.visitorsData = data.data;
    //     console.log(
    //       'visitors',
    //       typeof this.visitorsData,
    //       this.visitorsData['today_count'],
    //       this.visitorsData
    //     );
    //   }
    // });
  }

  // Notifications
  getNotifications() {
    this.noticeBoardData = [];
    // this._noticeBoardService.getnotifications(this.role).subscribe(data => {
    //   if (data.success) {
    //     if (data.data.length > 0) {
    //       this.noticeBoardData = _.filter(data.data, item => item.status === 1);
    //     }
    //   }
    // });
  }
  // Right Side End
}
