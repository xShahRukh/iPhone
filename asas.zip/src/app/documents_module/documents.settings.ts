import { environment } from '../../environments/environment';

export class DocumentsSettings {
  public static API = {
    GET_DOCUMENT_TYPES: environment.apiUrl + 'documentType/list/',
    ADD_NEW_DOCUMENT_TYPE: environment.apiUrl + 'documentType/add/',
    EDIT_DOCUMENT_TYPE: environment.apiUrl + 'documentType/edit/',
    GET_DOCUMENT_CATEGORIES: environment.apiUrl + 'documentCategory/list/',
    ADD_NEW_DOCUMENT_CATEGORY: environment.apiUrl + 'documentCategory/add/',
    EDIT_DOCUMENT_CATEGORY: environment.apiUrl + 'documentCategory/edit/',

    GET_DOCUMENT_DETAILS: environment.apiUrl + 'document/data/',
    GET_DOCUMENT_LIST: environment.apiUrl + 'processed/documents/list/',
    GET_DOCUMENT_LIST_MR: environment.apiUrl + 'all/processed/documents/list/',
    CREATE_DOCUMENT_DETAILS: environment.apiUrl + 'document/create/',
    UPDATE_DOCUMENT_DETAILS: environment.apiUrl + 'document/details/update/',
    ADD_DOCUMENT_DETAILS: environment.apiUrl + 'document/save/',
    GET_RELEASED_DOCUMENT_LIST: environment.apiUrl + 'released/documents/list/',
    GET_ARCHIVED_DOCUMENT_LIST: environment.apiUrl + 'archived/documents/list/',
    GET_DOCUMENT_USERS: environment.apiUrl + 'document/users/',
    GET_DOCUMENT_ID: environment.apiUrl + 'document/by/id/',
    EDIT_DOCUMENT_DETAILS: environment.apiUrl + 'document/update/',
    UPLOAD_DOCUMENT_DETAILS: environment.apiUrl + 'document/upload/',
    DOCUMENT_LINK_STATUS_MR: environment.apiUrl + 'documents/link/status/',
    ADD_DOCUMENT_LINK_BY_MR: environment.apiUrl + 'link/documents/',
    ADD_REVIEW: environment.apiUrl + 'document/suggestions/',
    SUGGESTIONS: environment.apiUrl + 'document/suggestions/list/',
    RELEASE_DOCUMENT: environment.apiUrl + 'document/release/',

    // Get Complete Employees List
    GET_EMPLOYEES_LIST: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/'
  };
}
