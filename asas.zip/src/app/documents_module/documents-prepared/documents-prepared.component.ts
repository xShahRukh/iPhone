import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { GenericValidator } from '../../common/generic-validator';

@Component({
  selector: 'app-documents-prepared',
  templateUrl: './documents-prepared.component.html',
  styleUrls: ['./documents-prepared.component.css']
})
export class DocumentsPreparedComponent implements OnInit {
  userid: string;
  reviewer_id: any;
  document_id: any;
  typesList1: any = [];
  imagePath: any = '';
  binaryString: any;
  ImgCode: any;
  base64textString: any;
  rolesArray = [];
  id: any = new Object();
  rolesusersList: any = [];
  docForm: FormGroup;
  showButton = true;
  doctypesList: any;
  categoriesList: any;
  typesList: any = [];
  loading: Boolean = true;
  user_name = '';

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  mr;
  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: 'Registration No is required'
      },
      service_code: {
        required: 'Service Code is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl([], [Validators.required]);
    const doc_category = new FormControl([], [Validators.required]);
    const doc_name = new FormControl([], [Validators.required]);
    const docdata = new FormControl([], [Validators.required]);
    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      docdata: docdata
    });
    this.getRoles();
  }

  getRoles() {
    this.rolesArray = [];
    this._apiService
      .getRoles1({ emp_id: sessionStorage.getItem('userid') })
      .subscribe(data => {
        if (!data.error) {
          this.rolesArray = data.data;
          console.log(this.rolesArray);
          this.mr = this.rolesArray.filter(
            ite => ite.role_name === 'MR' && ite.module_name === 'Documentation'
          );
          console.log(this.mr[0].module_name);
          if (this.mr[0].module_name === 'Documentation') {
            this.getdoclistmr();
          } else {
            this.getdoclistotherthanmr();
          }
        } else {
          this.rolesArray = [];
        }
      });
  }

  getdoclistmr() {
    this._documentservice.getDocumentsMR().subscribe(docs => {
      if (!docs.error) {
        // for (let k = 0; k < this.typesList.length; k++) {
        //   this.typesList[k].link_status = '1';
        // }
        const body = {
          check_role: 'Review'
        };
        this._documentservice.getDocumentlinkstatus(body).subscribe(docs2 => {
          if (!docs.error) {
            this.typesList1 = docs2.data;
            for (let i = 0; i < docs.data.prepared.length; i++) {
              const doc_id = docs.data.prepared[i]['doc_id'];
              const list = this.typesList1.filter(obj2 => {
                return obj2.doc_id === doc_id;
              });
              this.typesList[i] = docs.data.prepared[i];
              if (list.length) {
                this.typesList[i]['link_status'] = '1';
                this.typesList[i]['reviewerName'] = list[0]['userid'];
              } else {
                this.typesList[i]['link_status'] = '0';
              }
            }
            // this.typesList = docs.data.prepared;
            // this.getlinkstatus();
          } else {
            this.typesList1 = [];
          }
        });
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
  }

  getdoclistotherthanmr() {
    this._documentservice.getDocuments().subscribe(docs => {
      if (!docs.error) {
        this.typesList = docs.data.prepared;
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
  }

  getlinkstatus() {
    for (let t = 0; t < this.typesList.length; t++) {
      for (let m = 0; m < this.typesList1.length; m++) {
        if (this.typesList[t].doc_id === this.typesList1[m].doc_id) {
          this.typesList[t].link_status = this.typesList1[m].name;
          break;
        }
      }
    }
  }

  photoURL() {
    return this.base64textString;
  }

  viewDocument(item) {
    console.log(item);
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }

  addreviewer(id) {
    this.document_id = id.doc_id;
    this.getRolesuserlist();
  }

  getRolesuserlist() {
    const body = {
      role: 'Review'
    };
    this._apiService.getRolesUserslist(body).subscribe(data => {
      this.rolesusersList = data.data;
    });
  }

  userselect(event) {
    this.reviewer_id = event.target.value;
  }

  adddocumentlink() {
    const body = {
      doc_id: this.document_id.toString(),
      role: 'Review',
      userid: this.reviewer_id.toString()
    };
    this._documentservice.addDocumentlinkbymr(body).subscribe(data => {
      if (!data.error) {
        // success toaster
        this.toastr.successToastr(data.message, 'Success!');
        this.getRoles();
      } else {
        // warning toaster
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }
}
