import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ApiService } from '../../common/services/api.service';
import { Router } from '@angular/router';
import { DocumentsService } from '../documents/documents.service';

@Component({
  selector: 'app-documents-review-user',
  templateUrl: './documents-review-user.component.html',
  styleUrls: ['./documents-review-user.component.css']
})
export class DocumentsReviewUserComponent implements OnInit {
  typesList: any = [];
  loading: Boolean = true;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.getdoclist();
  }

  getdoclist() {
    this._documentservice.getDocuments().subscribe(docs => {
      console.log('docs prepared list', docs);
      if (!docs.error) {
        this.typesList = docs.data.reviewed;
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }
}
