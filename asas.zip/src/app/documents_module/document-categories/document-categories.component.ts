import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ApiService } from '../../common/services/api.service';
import { DocumentsService } from '../documents/documents.service';

@Component({
  selector: 'app-document-categories',
  templateUrl: './document-categories.component.html',
  styleUrls: ['./document-categories.component.css']
})
export class DocumentCategoriesComponent implements OnInit {
  categoriesList: any = [];
  category_code = '';
  category_name = '';
  type_status: Number = 0;
  loading: Boolean = true;
  dataItem: any = new Object();

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public _documentservice: DocumentsService,
    public vcr: ViewContainerRef
  ) {
    
  }

  ngOnInit() {
    this._documentservice.getDocumentCategories().subscribe(docs => {
      if (!docs.error) {
        this.categoriesList = docs.data;
        this.loading = false;
      } else {
        this.categoriesList = [];
      }
    });
  }

  codeGenerator() {
    this.category_code = this.category_name.toLowerCase().split(' ').join('_')
    this.category_name = this.toTitleCase(this.category_name)
    console.log(this.category_name)
  }

  toTitleCase = function (str) {
    str = str.toLowerCase().split(' ');
    for (var i = 0; i < str.length; i++) {
      str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1);
    }
    return str.join(' ');
  }

  addNewDocCat() {
    const body = {
      category_code: this.category_code,
      category_name: this.category_name
    };

    this._documentservice.addNewDocumentCategory(body).subscribe(addData => {
      this.loading = true;

      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');

        this._documentservice.getDocumentCategories().subscribe(docs => {
          this.category_code = '';
          this.category_name = '';
          if (!docs.error) {
            this.categoriesList = docs.data;
            this.loading = false;
          } else {
            this.categoriesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editCategory(item) {
    this.category_code = item.document_category;
    this.category_name = item.document_category_name;
    this.type_status = item.status;
    this.dataItem = item;
  }

  editDocCategory() {
    const body = {
      category_code: this.category_code,
      category_name: this.category_name,
      dc_id: this.dataItem.dc_id.toString(),
      status: this.type_status.toString()
    };

    this._documentservice.editNewDocumentCategory(body).subscribe(editData => {
      this.loading = true;

      if (!editData.error) {
        // success toaster
        this.toastr.successToastr("Updated Successfully", 'Success!');

        this._documentservice.getDocumentCategories().subscribe(docs => {
          this.category_code = '';
          this.category_name = '';
          this.type_status = 0;
          if (!docs.error) {
            this.categoriesList = docs.data;
            this.loading = false;
          } else {
            this.categoriesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr("Update fails", 'Warning!');
      }
    });
  }
}
