import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { GenericValidator } from '../../common/generic-validator';
import * as moment from 'moment';

@Component({
  selector: 'app-documents-approved',
  templateUrl: './documents-approved.component.html',
  styleUrls: ['./documents-approved.component.css']
})
export class DocumentsApprovedComponent implements OnInit {
  document_id: any;
  version_increment;
  effimpldate: Date;
  releaseDate: Date;
  yesterday = new Date(Date.now() - 864e5);
  typesList1: any = [];
  roles = '';
  imagePath: any = '';
  binaryString: any;
  ImgCode: any;
  base64textString: any;

  // id: any = new Object();

  docForm: FormGroup;
  showButton = true;
  doctypesList: any;
  categoriesList: any;
  typesList: any = [];
  loading: Boolean = true;

  public options = {
    position: ['bottom', 'left'],
    timeOut: 5000,
    lastOnBottom: true
  };

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: this.yesterday.getFullYear(),
      month: this.yesterday.getMonth() + 1,
      day: this.yesterday.getDate()
    }
  };

  public myDatePickerOptions2: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: this.yesterday.getFullYear(),
      month: this.yesterday.getMonth() + 1,
      day: this.yesterday.getDate()
    }
  };

  onDateChanged(event: IMyDateModel) {
    this.releaseDate = event.jsdate;
  }

  onDateChanged1(event: IMyDateModel) {
    this.effimpldate = event.jsdate;
  }

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: 'Registration No is required'
      },
      service_code: {
        required: 'Service Code is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl([], [Validators.required]);
    const doc_category = new FormControl([], [Validators.required]);
    const doc_name = new FormControl([], [Validators.required]);
    const docdata = new FormControl([], [Validators.required]);
    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      docdata: docdata
    });
    this.getdoclist();
  }

  getdoclist() {
    this._documentservice.getDocumentsMR().subscribe(docs => {
      if (!docs.error) {
        this.typesList = docs.data.approved;
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
    const body = {
      check_role: 'Approve'
    };
    this._documentservice.getDocumentlinkstatus(body).subscribe(docs => {
      if (!docs.error) {
        this.typesList1 = docs.data;
        this.getlinkstatus();
      } else {
        this.typesList1 = [];
      }
    });
  }

  getlinkstatus() {
    for (let t = 0; t < this.typesList.length; t++) {
      for (let m = 0; m < this.typesList1.length; m++) {
        if (this.typesList[t].doc_id === this.typesList1[m].doc_id) {
          this.typesList[t].link_status = this.typesList1[m].name;
          break;
        }
      }
    }
  }

  photoURL() {
    return this.base64textString;
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }

  release(item) {
    this.document_id = item.doc_id;
  }

  releasedocument() {
    const body = {
      doc_id: this.document_id,
      version: this.version_increment,
      release_date: this.releaseDate,
      effective_implementation: moment(this.effimpldate).format('YYYY-MM-DD')
    };
    this._documentservice.documentrelease(body).subscribe(docs => {
      if (!docs.error) {
        this.toastr.successToastr(docs.message);
        this.getdoclist();
      } else {
        this.toastr.warningToastr(docs.message);
      }
    });
  }
}
