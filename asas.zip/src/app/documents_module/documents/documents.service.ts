import { Injectable } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { DocumentsSettings } from '../documents.settings';

@Injectable()
export class DocumentsService {
  constructor(private _apiService: ApiService) { }

  // ADD_DOCUMENT_DETAILS
  createDocumentdata(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.CREATE_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  // UPDATE_DOCUMENT_DETAILS
  updateDocumentdata(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.UPDATE_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  // ADD_DOCUMENT_DETAILS
  addDocumentdata(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.ADD_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  // GET_DOCUMENT_LIST
  getDocuments() {
    const body = {};
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_LIST,
      'get',
      body
    );
  }

  // GET_DOCUMENT_LIST
  getDocumentDetails(body) {
    // const body = {};
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  uploadDocument(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.UPLOAD_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  editDocumentdata(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.EDIT_DOCUMENT_DETAILS,
      'post',
      body
    );
  }

  // GET_DOCUMENT_LIST_MR
  getDocumentsMR() {
    const body = {};
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_LIST_MR,
      'get',
      body
    );
  }

  // DOCUMENT_LINK_STATUS_MR
  getDocumentlinkstatus(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.DOCUMENT_LINK_STATUS_MR,
      'post',
      body
    );
  }

  // ADD_DOCUMENT_LINK_BY_MR
  addDocumentlinkbymr(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.ADD_DOCUMENT_LINK_BY_MR,
      'post',
      body
    );
  }

  // RELEASE_DOCUMENT
  documentrelease(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.RELEASE_DOCUMENT,
      'post',
      body
    );
  }

  // get list of all document types
  getDocumentTypes() {
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_TYPES,
      'get',
      {}
    );
  }

  // add new document type
  addNewDocumentType(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.ADD_NEW_DOCUMENT_TYPE,
      'post',
      body
    );
  }

  // edit document type
  editNewDocumentType(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.EDIT_DOCUMENT_TYPE,
      'post',
      body
    );
  }

  // get list of all document categories
  getDocumentCategories() {
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_CATEGORIES,
      'get',
      {}
    );
  }

  // add new category
  addNewDocumentCategory(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.ADD_NEW_DOCUMENT_CATEGORY,
      'post',
      body
    );
  }

  // edit document type
  editNewDocumentCategory(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.EDIT_DOCUMENT_CATEGORY,
      'post',
      body
    );
  }

  // document users
  documentUsers(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_USERS,
      'post',
      body
    );
  }

  // GET_DOCUMENT_ID
  documentByid(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.GET_DOCUMENT_ID,
      'post',
      body
    );
  }

  // GET_DOCUMENT_ID
  addReview(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.ADD_REVIEW,
      'post',
      body
    );
  }

  // suggestions by role and doc id
  suggestionslist(body) {
    return this._apiService.callApi(
      DocumentsSettings.API.SUGGESTIONS,
      'post',
      body
    );
  }

  // suggestions by role and doc id
  getEmployeesList() {
    return this._apiService.callApi(
      DocumentsSettings.API.GET_EMPLOYEES_LIST,
      'get',
      {}
    );
  }
}
