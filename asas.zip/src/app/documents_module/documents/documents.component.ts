import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from "@angular/forms";
import { ToastrManager } from "ng6-toastr-notifications";
import { Router } from "@angular/router";
import { ApiService } from "../../common/services/api.service";
import { DocumentsService } from "./documents.service";
import { DomSanitizer } from "@angular/platform-browser";
import { GenericValidator } from "../../common/generic-validator";
import { EditorModule } from "primeng/editor";

@Component({
  selector: "app-documents",
  templateUrl: "./documents.component.html",
  styleUrls: ["./documents.component.css"]
})
export class DocumentsComponent implements OnInit {
  roles: string;
  document_id = "";
  doc_category = "";
  doctype = "";
  doc_type = "";
  item: any = {};
  doccatname: any;
  doctypename: any;
  imagePath: any = "";
  binaryString: any;
  ImgCode: any;
  base64textString: any;
  text: string;

  public step1 = true;
  public step2: boolean;
  public step3: boolean;
  public step4: boolean;
  public editsection: boolean;
  public addsection: boolean;
  public showInput: boolean;
  public openoverwritebtn = true;
  public closeoverwritebtn: boolean;

  @ViewChild("selectedFile", {static:false})
  selectedFile: ElementRef;

  docForm: FormGroup;
  showButton = true;
  doctypesList: any;
  categoriesList: any;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  public loading: Boolean = true;
  empList = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: "Registration No is required"
      },
      service_code: {
        required: "Service Code is required"
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const doc_category = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const doc_name = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    // const version_changes = new FormControl({ value: '', disabled: false }, [
    //   Validators.required
    // ]);

    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      // version_changes: version_changes,
      // managingType: new FormControl({ value: '', disabled: false }, [
      //   Validators.required
      // ]),
      empId: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ])
    });

    this.getDocumentCategories();
    this.getDocumentTypes();
    this.getEmployeesList();

    if (Object.keys(this._apiService.docobject).length === 0) {
      this.addsection = true;
      this.editsection = false;

      this.doctype = "";
      this.doc_category = "";
      this.doctypename = "";
      this.doccatname = "";
      this.ImgCode = "";
    } else {
      this.item = this._apiService.docobject;
      this.addsection = false;
      this.editsection = true;
      this.docForm.patchValue({
        doc_type: this.item.document_type,
        doc_category: this.item.document_category,
        doc_name: this.item.document_name
        // version_changes: this.item.version_changes
      });
      this.doctypename = this.item.type_name;
      this.doccatname = this.item.category_name;
      this.document_id = this.item.doc_id;
      // this.ImgCode = this.item.document;
    }
  }

  getEmployeesList() {
    this.empList = [];
    this._documentservice.getEmployeesList().subscribe(docs => {
      if (docs.error) {
        this.empList = docs.data;
      }
    });
  }

  getDocumentCategories() {
    this._documentservice.getDocumentCategories().subscribe(docs => {
      if (!docs.error) {
        this.categoriesList = docs.data;
        this.categoriesList = this.categoriesList.filter(
          item => item.status === 1
        );
      } else {
        this.categoriesList = [];
      }
    });
  }

  getDocumentTypes() {
    this._documentservice.getDocumentTypes().subscribe(docs => {
      if (!docs.error) {
        this.doctypesList = docs.data;
        this.doctypesList = this.doctypesList.filter(item => item.status === 1);
      } else {
        this.doctypesList = [];
      }
    });
  }

  doctypeselect(event) {
    console.log(this.doctypesList, this.doctypename, event.target.value);
    for (let dt = 0; dt < this.doctypesList.length; dt++) {
      if (this.doctypesList[dt].dt_id === +event.target.value) {
        this.doctypename = this.doctypesList[dt].document_type_name;
        console.log(this.doctypename);
      }
    }
  }

  doccatselect(event) {
    for (let dc = 0; dc < this.categoriesList.length; dc++) {
      if (this.categoriesList[dc].dc_id === +event.target.value) {
        this.doccatname = this.categoriesList[dc].document_category_name;
      }
    }
  }

  addNewDoc(reqdata) {
    for (let k = 0; k < this._apiService.rolesArray.length; k++) {
      if (
        this._apiService.rolesArray[k].emp_id ===
        sessionStorage.getItem("userid") &&
        (this._apiService.rolesArray[k].role_name === "MR" ||
          this._apiService.rolesArray[k].role_name === "Prepare")
      ) {
        this.roles = this._apiService.rolesArray[k].role_name;
      }
    }

    console.log(this.roles);
    if (this.docForm.valid) {
      const body = {
        document_type: this.docForm.controls["doc_type"].value,
        document_category: this.docForm.controls["doc_category"].value,
        document_name: this.docForm.controls["doc_name"].value,
        emp_id: this.docForm.controls["empId"].value,
        // document: this.ImgCode,
        // version_changes: this.docForm.controls['version_changes'].value,
        roles: this.roles
      };
      if (reqdata === "share") {
        body["share"] = "1";
      } else if (reqdata === "save") {
        body["share"] = "0";
      }

      this._documentservice.createDocumentdata(body).subscribe(addData => {
        if (!addData.error) {
          // success toaster

          this.toastr.successToastr(
            "Document Created Successfully",
            "Success!"
          );
          setTimeout(() => {
            this.router.navigate(["/document/documentDashboard"]);
          }, 1000);
        } else {
          // warning toaster
          this.toastr.warningToastr(addData.message, "Warning!");
        }
      });
    } else {
      this.toastr.errorToastr("Please Fill Mandiatory Fields(*)");
    }
  }

  showinputfile() {
    this.showInput = true;
    this.closeoverwritebtn = true;
    this.openoverwritebtn = false;
  }

  closeinputfile() {
    this.showInput = false;
    this.closeoverwritebtn = false;
    this.openoverwritebtn = true;
  }

  editDoc(reqdata) {
    if (this.docForm.valid && this.ImgCode) {
      const body = {
        document_type: this.docForm.controls["doc_type"].value.toString(),
        document_category: this.docForm.controls[
          "doc_category"
        ].value.toString(),
        document_name: this.docForm.controls["doc_name"].value,
        document: this.ImgCode,
        version_changes: this.docForm.controls["version_changes"].value,
        doc_id: this.document_id.toString()
      };
      if (reqdata === "share") {
        body["share"] = "1";
      } else if (reqdata === "save") {
        body["share"] = "0";
      }

      this._documentservice.editDocumentdata(body).subscribe(editData => {
        this.loading = true;

        if (!editData.error) {
          // success toaster
          this.toastr.successToastr(
            "Documented Editted Successfully",
            "Success!"
          );
          this.router.navigate(["/document/hseDocuments"]);
        } else {
          // warning toaster
          this.toastr.warningToastr(editData.message, "Warning!");
        }
      });
    } else {
      this.toastr.errorToastr("Please Fill Mandiatory Fields(*)");
    }
  }

  handleFileSelect(event) {
    const files = event.target.files;
    const file = files[files.length - 1];
    const reader = new FileReader();
    reader.onload = this._handleReaderLoaded.bind(this);
    reader.readAsBinaryString(file);
  }

  _handleReaderLoaded(readerEvt) {
    this.binaryString = readerEvt.target.result;
    this.base64textString = btoa(this.binaryString);
    this.ImgCode = this.base64textString;
  }

  photoURL(id) {
    return "data:application/pdf;base64," + id;
  }

  movetostep1() {
    this.step1 = true;
    this.step2 = false;
    this.step3 = false;
    this.step4 = false;
  }

  movetostep2() {
    this.step1 = false;
    this.step2 = true;
    this.step3 = false;
    this.step4 = false;
  }

  movetostep3() {
    this.step1 = false;
    this.step2 = false;
    this.step3 = true;
    this.step4 = false;
  }

  movetostep4() {
    this.step1 = false;
    this.step2 = false;
    this.step3 = false;
    this.step4 = true;
  }
}
