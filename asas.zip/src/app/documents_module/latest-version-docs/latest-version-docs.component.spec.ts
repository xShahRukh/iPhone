import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LatestVersionDocsComponent } from './latest-version-docs.component';

describe('LatestVersionDocsComponent', () => {
  let component: LatestVersionDocsComponent;
  let fixture: ComponentFixture<LatestVersionDocsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LatestVersionDocsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LatestVersionDocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
