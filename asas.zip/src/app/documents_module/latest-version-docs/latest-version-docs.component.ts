import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { DocumentsService } from '../documents/documents.service';

@Component({
  selector: 'app-latest-version-docs',
  templateUrl: './latest-version-docs.component.html',
  styleUrls: ['./latest-version-docs.component.css']
})
export class LatestVersionDocsComponent implements OnInit {
  loading: any;
  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    private router: Router,
    public vcr: ViewContainerRef,
    public _documentservice: DocumentsService
  ) {}

  typesList: any = [
    { phase: 'Initiation', document_name: 'Project Initiation', version: '1.2' },
    { phase: 'Initiation', document_name: 'Project Charter', version: '1.1' },
    { phase: 'Planning', document_name: 'Project Plan', version: '2.1' },
    { phase: 'Planning', document_name: 'Work Breakdown Structure', version: '1.0' },
    { phase: 'Planning', document_name: 'Project Schedule', version: '1.0' },
    { phase: 'Planning', document_name: 'Training Plan', version: '1.0' },
    { phase: 'Planning', document_name: 'Test Plan', version: '1.1' },
    { phase: 'Planning', document_name: 'Release Plan', version: '1.2' },
    { phase: 'Planning', document_name: 'Quality Plan', version: '1.5' },
    { phase: 'Execution & Monitoring', document_name: 'Issue Log', version: '1.7' },
    { phase: 'Execution & Monitoring', document_name: 'Risk Log', version: '2.5' },
    { phase: 'Execution & Monitoring', document_name: 'Minutes of Meeting', version: '1.0' },
    { phase: 'Execution & Monitoring', document_name: 'Change Management', version: '3.2' },
    { phase: 'Execution & Monitoring', document_name: 'Design Standards', version: '1.0' },
    { phase: 'Execution & Monitoring', document_name: 'Coding Standards', version: '1.0' },
    { phase: 'Closure', document_name: 'Acceptance Test Report', version: '1.2' },
    { phase: 'Closure', document_name: 'User Guide', version: '1.4' },
    { phase: 'Closure', document_name: 'Training Material', version: '1.8' },
    { phase: 'Closure', document_name: 'Release Notes', version: '1.1' }
  ];

  ngOnInit() {}
}
