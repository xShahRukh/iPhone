import {
  Component, 
  OnInit, 
  ViewContainerRef, 
  ViewChildren, 
  ElementRef
}from '@angular/core'; 
import {FormBuilder, FormControlName }from '@angular/forms'; 
import {ToastrManager }from 'ng6-toastr-notifications'; 
import {Router }from '@angular/router'; 
import {ApiService }from '../../common/services/api.service'; 
import {DomSanitizer }from '@angular/platform-browser'; 
import {DocumentsService }from '../documents/documents.service'; 
import {GenericValidator }from '../../common/generic-validator'; 

@Component( {
  selector:'app-documents-approver-user', 
  templateUrl:'./documents-approver-user.component.html', 
  styleUrls:['./documents-approver-user.component.css']
})
export class DocumentsApproverUserComponent implements OnInit {
  roles:string; 
  typesList:any = []; 
  loading:Boolean = true; 

  @ViewChildren(FormControlName,  {read:ElementRef })
  formInputElements:ElementRef[]; 
  displayMessage: {[key:string]:string } =  {}; 
  public validationMessages: {[key:string]: {[key:string]:string }}; 
  public genericValidator:GenericValidator; 

  public filterQuery = ''; 
  public rowsOnPage = 20; 
  public sortBy = 'color'; 
  public sortOrder = 'asc'; 

  constructor(
    public fb:FormBuilder, 
    private router:Router, 
    public _apiService:ApiService, 
    public _documentservice:DocumentsService, 
    public toastr:ToastrManager, 
    public vcr:ViewContainerRef, 
    public sanitizer:DomSanitizer
  ) {
    
    this.genericValidator = new GenericValidator(this.validationMessages); 
    this.validationMessages =  {
      reg_no: {
        required:'Registration No is required'
      }, 
      service_code: {
        required:'Service Code is required'
      }
    }; 
  }

  ngOnInit() {
    this.getdoclist(); 
  }

  getdoclist() {
    this._documentservice.getDocuments().subscribe(docs =>  {
      if ( ! docs.error) {
        this.typesList = docs.data.approved; 
        this.loading = false; 
      }else {
        this.typesList = []; 
      }
    }); 
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item; 
    this.router.navigate(['/document/documentView']); 
  }
}
