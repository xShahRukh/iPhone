import { Component, OnInit } from '@angular/core';
import { Options } from 'ng5-slider';
import { ApiService } from '../../common/services/api.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-document-dashboard',
  templateUrl: './document-dashboard.component.html',
  styleUrls: ['./document-dashboard.component.css']
})
export class DocumentDashboardComponent implements OnInit {
  fieldpass: any = [];
  constructor(
    public _apiService: ApiService,
    public _route: ActivatedRoute,
    public router: Router
  ) {}

  graphData: any = [
    { y: 56, color: '#7ACC86' },
    { y: 67, color: '#F9E570' },
    { y: 82, color: '#60A6C1' },
    { y: 36, color: '#FF887F' },
    { y: 99, color: '#F0B67F' },
    { y: 35, color: '#60A6C1' },
    { y: 66, color: '#F9E570' }
  ];
  minComp = 75;
  red: String = '#7ACC86';
  green: String = '#F9E570';
  ambar: String = '#60A6C1';

  options: Options = {
    floor: 50,
    ceil: 100
  };

  ngOnInit() {
    this.dataSet();
    if (
      this._apiService.findIndexInData1({
        data: this._apiService.rolesArray,
        where1: 'module_name',
        where2: 'role_name',
        what1: 'Documentation',
        what2: 'MR'
      }) === -1
    ) {
      this.router.navigate(['/document/documentsReleased']);
    }
  }
  ngOnChange() {
    this.dataSet();
  }
  dataSet() {
    const dt = this.graphData;
    dt.forEach(d => {
      if (d.y < 50) {
        d.color = this.red;
      } else if (d.y < this.minComp) {
        d.color = this.ambar;
      } else {
        d.color = this.green;
      }
    });
    this.getFieldPassData();
  }
  getFieldPassData() {
    this.fieldpass = {
      chart: {
        inverted: true,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: '% Compliance'
      },
      exporting: { enabled: false },
      credits: { enabled: false },
      plotOptions: {
        series: {
          borderWidth: 0,
          dataLabels: {
            enabled: true,
            format: '{point.y:.1f}%'
          }
        }
      },

      yAxis: {
        plotLines: [
          {
            color: 'green', // Color value
            // dashStyle: 'longdashdot', // Style of the plot line. Default to solid
            value: this.minComp, // Value of where the line will appear
            width: 2 // Width of the line
          }
        ]
      },
      xAxis: {
        categories: [
          'Procurement Management',
          'Sub-contractor Management',
          'Project Management',
          'Quality Management',
          'Health & Safety Management',
          'Recruitment Management',
          'IT Security'
        ]
      },
      tooltip: {
        headerFormat: '<b>{point.key}</b><br>',
        pointFormat:
          '<span style="color:{series.color}">\u25CF</span> Compliance: {point.y} %'
      },

      series: [
        {
          type: 'column',
          colorByPoint: true,
          data: this.graphData,
          showInLegend: false
        }
      ]
    };
  }
}
