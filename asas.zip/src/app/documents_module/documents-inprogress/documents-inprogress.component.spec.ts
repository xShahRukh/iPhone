import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsInprogressComponent } from './documents-inprogress.component';

describe('DocumentsInprogressComponent', () => {
  let component: DocumentsInprogressComponent;
  let fixture: ComponentFixture<DocumentsInprogressComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentsInprogressComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsInprogressComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
