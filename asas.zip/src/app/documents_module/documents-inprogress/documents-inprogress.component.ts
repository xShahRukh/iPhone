import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { GenericValidator } from '../../common/generic-validator';
import { EditorModule } from 'primeng/editor';

@Component({
  selector: 'app-documents-inprogress',
  templateUrl: './documents-inprogress.component.html',
  styleUrls: ['./documents-inprogress.component.css']
})
export class DocumentsInprogressComponent implements OnInit {
  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: 'Registration No is required'
      },
      service_code: {
        required: 'Service Code is required'
      }
    };
  }

  binaryString: any;
  ImgCode: any;
  base64textString: any;
  approver_id: any;
  userId: String;
  docItem: any = {};
  document: any = {};
  docForm: FormGroup;
  doctypesList: any;
  categoriesList: any;
  typesList: any = [];
  type_code = '';
  type_name = '';
  type_status: Number = 0;
  loading: Boolean = true;
  dataItem: any = new Object();

  document_id: any;
  rolesusersList: any = [];

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';

  public showInput: Number = 0;

  empList;
  reviewer_id;

  ngOnInit() {
    this.userId = sessionStorage.getItem('userid');
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl([], [Validators.required]);
    const doc_category = new FormControl([], [Validators.required]);
    const doc_name = new FormControl([], [Validators.required]);
    const version_changes = new FormControl([], [Validators.required]);

    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      version_changes: version_changes
    });
    this.getdoclist();

    this.getDocumentCategories();
    this.getDocumentTypes();
    this.getEmployeesList();
  }

  // ngOnChange() {
  //   this.userid = sessionStorage.getItem('userid')
  // }

  getdoclist() {
    console.log(
      this._apiService.findIndexInData1({
        data: this._apiService.rolesArray,
        where1: 'module_name',
        where2: 'role_name',
        what1: 'Documentation',
        what2: 'MR'
      }),
      this._apiService.rolesArray
    );
    if (
      this._apiService.findIndexInData1({
        data: this._apiService.rolesArray,
        where1: 'module_name',
        where2: 'role_name',
        what1: 'Documentation',
        what2: 'MR'
      }) > -1
    ) {
      this._documentservice.getDocumentsMR().subscribe(docs => {
        if (!docs.error) {
          this.typesList = docs.data.inprogress;
          console.log(this.typesList, 'in progress documents');
          this.loading = false;
        } else {
          this.typesList = [];
        }
      });
    } else {
      this._documentservice.getDocuments().subscribe(docs => {
        if (!docs.error) {
          this.typesList = docs.data.inprogress;
          console.log(this.typesList, 'in progress documents');
          this.loading = false;
        } else {
          this.typesList = [];
        }
      });
    }
  }

  getDocumentCategories() {
    this._documentservice.getDocumentCategories().subscribe(docs => {
      if (!docs.error) {
        this.categoriesList = docs.data;
      } else {
        this.categoriesList = [];
      }
    });
  }

  getDocumentTypes() {
    this._documentservice.getDocumentTypes().subscribe(docs => {
      if (!docs.error) {
        this.doctypesList = docs.data;
      } else {
        this.doctypesList = [];
      }
    });
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }

  editDoc(item) {
    this._apiService.docobject = item;
    this.router.navigate(['/document/document']);
    // this.documentEditform = true;
    // this.documentList = false;
    // this.docForm.patchValue({
    //   doc_type: item.document_type,
    //   doc_category: item.document_category,
    //   doc_name: item.document_name,
    //   version_changes: item.version_changes
    // });
  }

  editDocData(item) {
    this.docItem = item;
  }

  writeDocument(item) {
    this.docItem = item;
    const body = {
      doc_id: item.doc_id
    };
    this._documentservice.getDocumentDetails(body).subscribe(docData => {
      this.document = docData.data;
      this.ImgCode = docData.data.document;
    });
  }

  editDocType() {
    const body = {
      type_code: this.type_code,
      type_name: this.type_name,
      dt_id: this.dataItem.dt_id.toString(),
      status: this.type_status.toString()
    };

    this._documentservice.editNewDocumentType(body).subscribe(editData => {
      this.loading = true;

      if (!editData.error) {
        // success toaster
        this.toastr.successToastr(editData.message, 'Success!');

        this._documentservice.getDocumentTypes().subscribe(docs => {
          this.type_code = '';
          this.type_name = '';
          this.type_status = 0;
          if (!docs.error) {
            this.typesList = docs.data;
            this.loading = false;
          } else {
            this.typesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }

  getEmployeesList() {
    this.empList = [];
    this._documentservice.getEmployeesList().subscribe(docs => {
      if (docs.error) {
        this.empList = docs.data;
      }
    });
  }

  userselect(event) {
    this.reviewer_id = event.target.value;
  }

  addapprover(id) {
    this.document_id = id.doc_id;
  }

  userselect1(event) {
    console.log('selected approver', event.target.value);
    this.approver_id = event.target.value;
  }

  addreviewer(id) {
    this.document_id = id.doc_id;
  }

  getRolesuserlist() {
    const body = {
      role: 'Review'
    };
    this._apiService.getRolesUserslist(body).subscribe(data => {
      this.rolesusersList = data.data;
    });
  }

  adddocumentlink() {
    const body = {
      doc_id: this.document_id,
      role: 'Review',
      userid: this.reviewer_id
    };
    this._documentservice.addDocumentlinkbymr(body).subscribe(data => {
      if (!data.error) {
        // success toaster
        this.toastr.successToastr(data.message, 'Success!');
        this.getdoclist();
        // this.getRoles();
      } else {
        // warning toaster
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }

  adddocumentlink1() {
    const body = {
      doc_id: this.document_id,
      role: 'Approve',
      userid: this.approver_id
    };
    this._documentservice.addDocumentlinkbymr(body).subscribe(data => {
      console.log(data);

      if (!data.error) {
        // success toaster
        this.toastr.successToastr(data.message, 'Success!');
        this.getdoclist();
      } else {
        // warning toaster
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }

  UpdateDocumentDetails() {
    const body = {
      doc_id: this.dataItem.doc_id,
      document_name: this.docItem.document_name,
      document_type: this.docItem.document_type,
      document_category: this.docItem.document_category
    };
    this._documentservice.updateDocumentdata(body).subscribe(data => {
      console.log(data);

      if (!data.error) {
        // success toaster
        this.toastr.successToastr(data.message, 'Success!');
        this.getdoclist();
      } else {
        // warning toaster
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }

  // msg
  handleFileSelect(event) {
    const files = event.target.files;
    const file = files[files.length - 1];
    const reader = new FileReader();
    reader.onload = this._handleReaderLoaded.bind(this);
    reader.readAsBinaryString(file);
  }

  _handleReaderLoaded(readerEvt) {
    this.binaryString = readerEvt.target.result;
    this.base64textString = btoa(this.binaryString);
    this.ImgCode = this.base64textString;
  }

  photoURL(id) {
    return 'data:application/pdf;base64,' + id;
  }

  // upload document
  uploadDocument(share: number) {
    const body = {
      document: this.ImgCode,
      version_changes: this.document.version_changes,
      doc_id: this.document.doc_id,
      share: share
    };
    this._documentservice.uploadDocument(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr(data.message, 'Success!');
        this.getdoclist();
      } else {
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }
}
