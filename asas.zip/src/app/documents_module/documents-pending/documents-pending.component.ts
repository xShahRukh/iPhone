import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { GenericValidator } from '../../common/generic-validator';

@Component({
  selector: 'app-documents-pending',
  templateUrl: './documents-pending.component.html',
  styleUrls: ['./documents-pending.component.css']
})
export class DocumentsPendingComponent implements OnInit {
  docForm: FormGroup;
  doctypesList: any;
  categoriesList: any;
  typesList: any = [];
  type_code = '';
  type_name = '';
  type_status: Number = 0;
  loading: Boolean = true;
  dataItem: any = new Object();

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: 'Registration No is required'
      },
      service_code: {
        required: 'Service Code is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl([], [Validators.required]);
    const doc_category = new FormControl([], [Validators.required]);
    const doc_name = new FormControl([], [Validators.required]);
    const version_changes = new FormControl([], [Validators.required]);

    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      version_changes: version_changes
    });
    this.getdoclist();

    this.getDocumentCategories();
    this.getDocumentTypes();
  }

  getdoclist() {
    if (
      this._apiService.findIndexInData1({
        data: this._apiService.rolesArray,
        where1: 'module_name',
        where2: 'role_name',
        what1: 'Documentation',
        what2: 'MR'
      }) > -1
    ) {
      this._documentservice.getDocumentsMR().subscribe(docs => {
        if (!docs.error) {
          this.typesList = docs.data.pending;
          this.loading = false;
        } else {
          this.typesList = [];
        }
      });
    } else {
      this._documentservice.getDocuments().subscribe(docs => {
        if (!docs.error) {
          this.typesList = docs.data.pending;
          this.loading = false;
        } else {
          this.typesList = [];
        }
      });
    }
  }

  getDocumentCategories() {
    this._documentservice.getDocumentCategories().subscribe(docs => {
      if (!docs.error) {
        this.categoriesList = docs.data;
      } else {
        this.categoriesList = [];
      }
    });
  }

  getDocumentTypes() {
    this._documentservice.getDocumentTypes().subscribe(docs => {
      if (!docs.error) {
        this.doctypesList = docs.data;
      } else {
        this.doctypesList = [];
      }
    });
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }

  editDoc(item) {
    this._apiService.docobject = item;
    this.router.navigate(['/document/document']);
    // this.documentEditform = true;
    // this.documentList = false;
    // this.docForm.patchValue({
    //   doc_type: item.document_type,
    //   doc_category: item.document_category,
    //   doc_name: item.document_name,
    //   version_changes: item.version_changes
    // });
  }

  editDocType() {
    const body = {
      type_code: this.type_code,
      type_name: this.type_name,
      dt_id: this.dataItem.dt_id.toString(),
      status: this.type_status.toString()
    };

    this._documentservice.editNewDocumentType(body).subscribe(editData => {
      this.loading = true;

      if (!editData.error) {
        // success toaster
        this.toastr.successToastr(editData.message, 'Success!');

        this._documentservice.getDocumentTypes().subscribe(docs => {
          this.type_code = '';
          this.type_name = '';
          this.type_status = 0;
          if (!docs.error) {
            this.typesList = docs.data;
            this.loading = false;
          } else {
            this.typesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }
}
