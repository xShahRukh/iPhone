import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentWritingComponent } from './document-writing.component';

describe('DocumentWritingComponent', () => {
  let component: DocumentWritingComponent;
  let fixture: ComponentFixture<DocumentWritingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentWritingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentWritingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
