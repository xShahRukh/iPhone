import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-document-writing',
  templateUrl: './document-writing.component.html',
  styleUrls: ['./document-writing.component.css']
})
export class DocumentWritingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
