import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ReleasedDocumentService } from './documents-released.service';
import { Router } from '@angular/router';
import { DocumentsService } from '../documents/documents.service';

@Component({
  selector: 'app-documents-released',
  templateUrl: './documents-released.component.html',
  styleUrls: ['./documents-released.component.css']
})
export class DocumentsReleasedComponent implements OnInit {
  typesList: any = [];
  loading = true;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'asc';

  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    private router: Router,
    public vcr: ViewContainerRef,
    public _documentservice: DocumentsService,
    public _relesedService: ReleasedDocumentService
  ) {}

  ngOnInit() {
    this._relesedService.getReleasedDocuments().subscribe(docs => {
      console.log(docs, 'getReleasedDocuments');
      if (!docs.error) {
        this.typesList = docs.data;
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }
}
