import { Injectable } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { DocumentsSettings } from '../documents.settings';

@Injectable()
export class ReleasedDocumentService {
  constructor(private _apiService: ApiService) {}

  // GET_RELEASED_DOCUMENT_LIST
  getReleasedDocuments() {
    const body = {};
    return this._apiService.callApi(DocumentsSettings.API.GET_RELEASED_DOCUMENT_LIST, 'get', body);
  }
}
