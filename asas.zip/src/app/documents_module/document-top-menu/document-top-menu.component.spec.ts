import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentTopMenuComponent } from './document-top-menu.component';

describe('DocumentTopMenuComponent', () => {
  let component: DocumentTopMenuComponent;
  let fixture: ComponentFixture<DocumentTopMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentTopMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentTopMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
