import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DocumentDashboardComponent } from './document-dashboard/document-dashboard.component';
import { HseDocumnetsComponent } from './hse-documnets/hse-documnets.component';
import { DocumentTypesComponent } from './document-types/document-types.component';
import { DocumentCategoriesComponent } from './document-categories/document-categories.component';
import { DocumentsComponent } from './documents/documents.component';
import { DocumentsReleasedComponent } from './documents-released/documents-released.component';
import { DocumentsPendingComponent } from './documents-pending/documents-pending.component';
import { DocumentsReviewUserComponent } from './documents-review-user/documents-review-user.component';
import { DocumentsApproverUserComponent } from './documents-approver-user/documents-approver-user.component';
import { DocumentViewComponent } from './document-view/document-view.component';
import { DocumentsApprovedComponent } from './documents-approved/documents-approved.component';
import { DocumentsReviewedComponent } from './documents-reviewed/documents-reviewed.component';
import { DocumentsPreparedComponent } from './documents-prepared/documents-prepared.component';
import { DocumentsInprogressComponent } from './documents-inprogress/documents-inprogress.component';
import { DocumentsArchivedComponent } from './documents-archived/documents-archived.component';
import { LatestVersionDocsComponent } from './latest-version-docs/latest-version-docs.component';

const documentsroutes: Routes = [
  { path: 'documentDashboard', component: DocumentDashboardComponent },
  { path: 'hseDocuments', component: HseDocumnetsComponent },
  { path: 'documentTypes', component: DocumentTypesComponent },
  { path: 'documentCategories', component: DocumentCategoriesComponent },
  { path: 'document', component: DocumentsComponent },
  { path: 'documentsReleased', component: DocumentsReleasedComponent },
  { path: 'documentsLatest', component: LatestVersionDocsComponent },
  { path: 'documentsArchived', component: DocumentsArchivedComponent },
  { path: 'documentsInProgress', component: DocumentsInprogressComponent },
  { path: 'documentsPending', component: DocumentsPendingComponent },
  { path: 'documentsReviewed', component: DocumentsReviewedComponent },
  { path: 'documentsReviewUser', component: DocumentsReviewUserComponent },
  { path: 'documentsPrepared', component: DocumentsPreparedComponent },
  { path: 'documentsApproved', component: DocumentsApprovedComponent },
  { path: 'documentsApprovedUser', component: DocumentsApproverUserComponent },
  { path: 'documentView', component: DocumentViewComponent },

  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard', pathMatch: 'full' }
];

export const documentsRouting: ModuleWithProviders = RouterModule.forChild(documentsroutes);
