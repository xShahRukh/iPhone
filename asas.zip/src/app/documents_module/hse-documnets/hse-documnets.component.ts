import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';

@Component({
  selector: 'app-hse-documnets',
  templateUrl: './hse-documnets.component.html',
  styleUrls: ['./hse-documnets.component.css']
})
export class HseDocumnetsComponent implements OnInit {
  constructor(public _apiService: ApiService, private router: Router) {
    
  }

  ngOnInit() {
    this._apiService.page = 'serviceDetails';
    this._apiService.selectedDoc = {};
    this._apiService.docobject = {};
  }

  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
}
