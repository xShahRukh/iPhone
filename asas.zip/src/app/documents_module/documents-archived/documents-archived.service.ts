import {Injectable }from '@angular/core'; 
import {ApiService }from '../../common/services/api.service'; 
import {DocumentsSettings }from '../documents.settings'; 

@Injectable()
export class DocumentsArchivedService {
  constructor(private _apiService:ApiService) {}

  // GET_ARCHIVED_DOCUMENT_LIST
  getArchivedDocuments() {
    const body =  {}; 
    return this._apiService.callApi(
      DocumentsSettings.API.GET_ARCHIVED_DOCUMENT_LIST, 
      'get', 
      body
    ); 
  }
}
