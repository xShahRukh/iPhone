import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { GenericValidator } from '../../common/generic-validator';

@Component({
  selector: 'app-documents-reviewed',
  templateUrl: './documents-reviewed.component.html',
  styleUrls: ['./documents-reviewed.component.css']
})
export class DocumentsReviewedComponent implements OnInit {
  approver_id: any;
  rolesusersList: any;
  document_id: any;
  typesList1: any;
  imagePath: any = '';
  binaryString: any;
  ImgCode: any;
  base64textString: any;

  docForm: FormGroup;
  showButton = true;
  doctypesList: any;
  categoriesList: any;
  typesList: any = [];
  loading: Boolean = true;
  id = new Object();

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  rolesArray: any[];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _documentservice: DocumentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {
    
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: 'Registration No is required'
      },
      service_code: {
        required: 'Service Code is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const doc_type = new FormControl([], [Validators.required]);
    const doc_category = new FormControl([], [Validators.required]);
    const doc_name = new FormControl([], [Validators.required]);
    const docdata = new FormControl([], [Validators.required]);
    this.docForm = this.fb.group({
      doc_type: doc_type,
      doc_category: doc_category,
      doc_name: doc_name,
      docdata: docdata
    });
    this.getdoclist();
  }

  getdoclist() {
    this._documentservice.getDocumentsMR().subscribe(docs => {
      console.log('docs approved list of mr', docs);
      if (!docs.error) {
        this.loading = false;

        const body = {
          check_role: 'Approve'
        };
        this._documentservice.getDocumentlinkstatus(body).subscribe(docs2 => {
          console.log('docs link Status list of approve', docs2);

          if (!docs.error) {
            this.typesList1 = docs2.data;
            for (let i = 0; i < docs.data.reviewed.length; i++) {
              const doc_id = docs.data.reviewed[i]['doc_id'];
              const list = this.typesList1.filter(obj2 => {
                return obj2.doc_id === doc_id;
              });
              this.typesList[i] = docs.data.reviewed[i];
              if (list.length) {
                this.typesList[i]['link_status'] = '1';
                this.typesList[i]['approverName'] = list[0]['userid'];
              } else {
                this.typesList[i]['link_status'] = '0';
              }
            }
            // this.typesList = docs.data.prepared;
            // this.getlinkstatus();
          } else {
            this.typesList1 = [];
          }
        });
      } else {
        this.typesList = [];
      }
    });
  }

  getlinkstatus() {
    for (let t = 0; t < this.typesList.length; t++) {
      for (let m = 0; m < this.typesList1.length; m++) {
        if (this.typesList[t].doc_id === this.typesList1[m].doc_id) {
          this.typesList[t].link_status = this.typesList1[m].name;
          break;
        }
      }
    }
    console.log('Updated TypeList', this.typesList);
  }

  photoURL() {
    return this.base64textString;
  }

  viewDocument(item) {
    this._apiService.selectedDoc = item;
    this.router.navigate(['/document/documentView']);
  }

  addapprover(id) {
    console.log('doc_id', id.doc_id);
    this.document_id = id.doc_id;
    this.getRolesuserlist();
  }

  getRolesuserlist() {
    const body = {
      role: 'Approve'
    };
    this._apiService.getRolesUserslist(body).subscribe(data => {
      this.rolesusersList = data.data;
      console.log('Roles List', this.rolesusersList);
    });
  }

  userselect(event) {
    console.log('selected approver', event.target.value);
    this.approver_id = event.target.value;
  }

  adddocumentlink() {
    const body = {
      doc_id: this.document_id.toString(),
      role: 'Approve',
      userid: this.approver_id.toString()
    };
    this._documentservice.addDocumentlinkbymr(body).subscribe(data => {
      console.log(data);

      if (!data.error) {
        // success toaster
        this.toastr.successToastr(data.message, 'Success!');
        this.getdoclist();
      } else {
        // warning toaster
        this.toastr.warningToastr(data.message, 'Warning!');
      }
    });
  }
}
