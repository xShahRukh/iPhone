import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { DocumentsService } from '../documents/documents.service';

@Component({
  selector: 'app-document-types',
  templateUrl: './document-types.component.html',
  styleUrls: ['./document-types.component.css']
})
export class DocumentTypesComponent implements OnInit {
  typesList: any = [];
  type_code = '';
  type_name = '';
  type_status: Number = 0;
  loading: Boolean = true;
  dataItem: any = new Object();

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public _documentservice: DocumentsService
  ) {}

  ngOnInit() {
    this._documentservice.getDocumentTypes().subscribe(docs => {
      if (!docs.error) {
        this.typesList = docs.data;
        this.loading = false;
      } else {
        this.typesList = [];
      }
    });
  }

  codeGenerator() {
    this.type_code = this.type_name
      .toLowerCase()
      .split(' ')
      .join('_');
    this.type_name = this.toTitleCase(this.type_name);
    console.log(this.type_name);
  }

  toTitleCase = function(str) {
    str = str.toLowerCase().split(' ');
    for (let i = 0; i < str.length; i++) {
      str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1);
    }
    return str.join(' ');
  };

  addNewDocType() {
    const body = {
      type_code: this.type_code,
      type_name: this.type_name
    };

    this._documentservice.addNewDocumentType(body).subscribe(addData => {
      this.loading = true;

      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');

        this._documentservice.getDocumentTypes().subscribe(docs => {
          this.type_code = '';
          this.type_name = '';
          if (!docs.error) {
            this.typesList = docs.data;
            this.loading = false;
          } else {
            this.typesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editType(item) {
    this.type_code = item.document_type;
    this.type_name = item.document_type_name;
    this.type_status = item.status;
    this.dataItem = item;
  }

  editDocType() {
    const body = {
      type_code: this.type_code,
      type_name: this.type_name,
      dt_id: this.dataItem.dt_id.toString(),
      status: this.type_status.toString()
    };

    this._documentservice.editNewDocumentType(body).subscribe(editData => {
      this.loading = true;

      if (!editData.error) {
        // success toaster
        this.toastr.successToastr(editData.message, 'Success!');

        this._documentservice.getDocumentTypes().subscribe(docs => {
          this.type_code = '';
          this.type_name = '';
          this.type_status = 0;
          if (!docs.error) {
            this.typesList = docs.data;
            this.loading = false;
          } else {
            this.typesList = [];
          }
        });
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }
}
