import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Third Party Plugins
import { ModalModule } from 'ngx-modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { DataTableModule } from 'angular-6-datatable';
import { CalendarModule } from 'primeng/primeng';
import { MyDatePickerModule } from 'mydatepicker';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { CustomFormsModule } from 'ng2-validation';
import { EditorModule } from 'primeng/editor';
import { CKEditorModule } from 'ng2-ckeditor';
import { AutoCompleteModule } from 'primeng/primeng';

import { ApiService } from '../common/services/api.service';

import { DocumentDashboardComponent } from './document-dashboard/document-dashboard.component';
import { HseDocumnetsComponent } from './hse-documnets/hse-documnets.component';
import { DocumentTypesComponent } from './document-types/document-types.component';
import { DocumentCategoriesComponent } from './document-categories/document-categories.component';
import { DocumentsComponent } from './documents/documents.component';
import { DocumentsService } from './documents/documents.service';
import { DocumentsReleasedComponent } from './documents-released/documents-released.component';
import { DocumentsArchivedService } from './documents-archived/documents-archived.service';
import { ReleasedDocumentService } from './documents-released/documents-released.service';
import { DocumentsPendingComponent } from './documents-pending/documents-pending.component';
import { DocumentsReviewedComponent } from './documents-reviewed/documents-reviewed.component';
import { DocumentsPreparedComponent } from './documents-prepared/documents-prepared.component';
import { DocumentsApprovedComponent } from './documents-approved/documents-approved.component';
import { DocumentViewComponent } from './document-view/document-view.component';
import { DocumentsReviewUserComponent } from './documents-review-user/documents-review-user.component';
import { DocumentsApproverUserComponent } from './documents-approver-user/documents-approver-user.component';
import { LatestVersionDocsComponent } from './latest-version-docs/latest-version-docs.component';

import { documentsRouting } from './documents.routing';
import { SharedModule } from '../common/shareds.module';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { DocumentTopMenuComponent } from './document-top-menu/document-top-menu.component';
import { DocumentsInprogressComponent } from './documents-inprogress/documents-inprogress.component';
import { DocumentsArchivedComponent } from './documents-archived/documents-archived.component';
import { Ng5SliderModule } from 'ng5-slider';

declare var require;

export function highchartsFactory() {
  const Highcharts = require('highcharts');
  const Exporting = require('highcharts/modules/exporting');
  const More = require('highcharts/highcharts-more');
  const Solid = require('highcharts/modules/solid-gauge');
  const Heatmap = require('highcharts/modules/heatmap');
  const Pointline = require('highcharts/modules/export-data');
  const threeD = require('highcharts/highcharts-3d');
  const Funnel = require('highcharts/modules/funnel');
  Heatmap(Highcharts);
  Exporting(Highcharts);
  threeD(Highcharts);
  More(Highcharts);
  Solid(Highcharts);
  Pointline(Highcharts);
  threeD(Highcharts);
  Funnel(Highcharts);
  return Highcharts;
}

@NgModule({
  declarations: [
    DocumentDashboardComponent,
    HseDocumnetsComponent,
    DocumentTypesComponent,
    DocumentCategoriesComponent,
    DocumentsComponent,
    DocumentsReleasedComponent,
    DocumentsPendingComponent,
    DocumentsReviewedComponent,
    DocumentsPreparedComponent,
    DocumentsApprovedComponent,
    DocumentViewComponent,
    DocumentsReviewUserComponent,
    DocumentsApproverUserComponent,
    DocumentTopMenuComponent,
    DocumentsInprogressComponent,
    DocumentsArchivedComponent,
    LatestVersionDocsComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    CKEditorModule,
    ReactiveFormsModule,
    CustomFormsModule,
    DataTableModule,
    AutoCompleteModule,
    documentsRouting,
    SharedModule,
    ModalModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    CalendarModule,
    ToastrModule.forRoot(),
    EditorModule,
    ChartModule,
    Ng5SliderModule
  ],

  providers: [
    ApiService,
    DocumentsService,
    ReleasedDocumentService,
    DocumentsArchivedService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    }
  ]
})
export class DocumentsModule {}
