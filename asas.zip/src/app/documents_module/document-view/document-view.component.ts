import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Location } from '@angular/common';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { DocumentsService } from '../documents/documents.service';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-document-view',
  templateUrl: './document-view.component.html',
  styleUrls: ['./document-view.component.css']
})
export class DocumentViewComponent implements OnInit {
  userId: any;
  users1: any;
  item: any = {};
  users: any = [];
  binaryString: any;
  ImgCode: any;
  base64textString: any;
  sessionRole: string;
  reviewSugg = [];
  approveSugg = [];
  suggestion: any;
  reviewStatus: Boolean = false;
  approveStatus: Boolean = false;
  relDoc: any = {};
  d = new Date();

  public startDateOptions: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: this.d.getDate() - 1
    }
  };

  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public _documentservice: DocumentsService,
    public sanitizer: DomSanitizer,
    public router: Router,
    public _location: Location
  ) {}

  ngOnInit() {
    this.userId = sessionStorage.getItem('userid');
    document.body.style.backgroundColor = '#37434f';
    if (!this._apiService.selectedDoc) {
      this.router.navigate(['/document/documentsReleased']);
    } else {
      this.documentUsers();

      this.item = this._apiService.selectedDoc;
      console.log(this.item, 'itemsss');
      this.reviewSuggestions();
      this.approveSuggestions();

      // var reader = new FileReader();
      // reader.onload = this._handleReaderLoaded.bind(this);
      // reader.readAsBinaryString(file);
    }
    this.getDocumentDetails();
    // this.viewStatusUpdate();
  }
  ngOnDestory() {
    document.body.style.backgroundColor = '';
  }
  // ngOnChange() {
  //   this.viewStatusUpdate();
  // }

  getDocumentDetails() {
    const body = { doc_id: this._apiService.selectedDoc.doc_id };

    this._documentservice.getDocumentDetails(body).subscribe(dt => {
      this.item = dt.data;
    });
  }

  _handleReaderLoaded(readerEvt) {
    this.binaryString = readerEvt.target.result;
    this.base64textString = btoa(this.binaryString);
    this.ImgCode = 'data:application/pdf;base64,' + this.base64textString;

    // this.ImgCode = "data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64," + this.base64textString;
    // this.photoURL(this.ImgCode);
  }

  documentUsers() {
    const body = { doc_id: this._apiService.selectedDoc.doc_id };

    this._documentservice.documentUsers(body).subscribe(users => {
      this.users = users.data;
    });
    this._documentservice.documentByid(body).subscribe(data => {
      this.users1 = data.data;
    });
  }

  reviewF() {
    this.addReview(1);
  }

  reviewB() {
    this.addReview(0);
  }

  approveF() {
    this.addApprove(1);
  }

  approveB() {
    this.addApprove(0);
  }

  addReview(status) {
    const body = {
      role: 'Review',
      doc_id: this._apiService.selectedDoc.doc_id.toString(),
      userid: sessionStorage.userid,
      suggestion: this.suggestion,
      forward: status
    };

    this._documentservice.addReview(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr(data.message);
        this.reviewSuggestions();
        this.getDocumentDetails();
      } else {
        this.toastr.warningToastr(data.message);
      }
    });
  }

  addApprove(status) {
    const body = {
      role: 'Approve',
      doc_id: this._apiService.selectedDoc.doc_id.toString(),
      userid: sessionStorage.userid,
      suggestion: this.suggestion,
      forward: status
    };

    this._documentservice.addReview(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr(data.message);
        this.approveSuggestions();
        this.getDocumentDetails();
      } else {
        this.toastr.warningToastr(data.message);
      }
    });
  }

  reviewSuggestions() {
    const body = {
      role: 'Review',
      doc_id: this._apiService.selectedDoc.doc_id.toString(),
      userid: sessionStorage.userid
    };
    this._documentservice.suggestionslist(body).subscribe(data => {
      // toastr code here
      this.reviewSugg = data.data;
      // this.toastr.successToastr(data.message);
    });
  }

  approveSuggestions() {
    const body = {
      role: 'Approve',
      doc_id: this._apiService.selectedDoc.doc_id.toString(),
      userid: sessionStorage.userid
    };
    this._documentservice.suggestionslist(body).subscribe(data => {
      // toastr code here
      this.approveSugg = data.data;
      // this.toastr.successToastr(data.message);
    });
  }

  photoURL(id) {
    return 'data:application/pdf;base64,' + id;
  }

  goBack() {
    document.body.style.backgroundColor = '';
    this._location.back();
  }

  ChangeDate(event) {
    this.relDoc.start_date = event.date;
  }

  releaseDocument() {
    const body = {
      doc_id: this.item.doc_id,
      document_name: this.item.document_name,
      document_category: this.item.document_category,
      document_type: this.item.document_type,
      version: this.relDoc.version,
      release_note: this.relDoc.release_note,
      start_date: this.relDoc.start_date
    };
    this._documentservice.documentrelease(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr(data.message);
        this.reviewSuggestions();
        this.getDocumentDetails();
      } else {
        this.toastr.warningToastr(data.message);
      }
    });
  }
}
