import { Component, OnInit, ViewChild } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";
import { CustomFormsModule } from "ng2-validation";

import { Search } from "../models/search";
import { AppSettings } from "../../app.settings";
import { TrainigService } from "../services/training.service";
import { User } from "../models/user.interface";
import { every } from "rxjs/operators/every";
import { TrainingSettings } from "../training.settings";

@Component({
  selector: "app-search",
  templateUrl: "./search.component.html",
  styleUrls: ["./search.component.css"]
})
export class SearchComponent implements OnInit {
  @ViewChild("f", {static:false}) form: any;
  visitorForm: FormGroup;
  serach: Search;
  roleArray; // get roles from api setting
  vehicleTypeArray; // get vechicle type  app setting
  type; // get visitor type  app setting
  visitortype = "0";
  role = "driver";
  executiveType = "non-executive";
  errorMessage = false;
  errorMessage1 = false;
  errorMessage2 = false;
  errorMessage3 = false;
  message;
  user: User;
  spin = false; // disable spinner
  examSearchCompleted = false;

  constructor(
    private _fb: FormBuilder,
    public _trainingService: TrainigService
  ) {
    this.examSearchCompleted = true;
  }

  ngOnInit() {
    if (this._trainingService.type === "vehicle") {
      this.examSearchCompleted = true;
    } else {
      this.examSearchCompleted = false;
    }
    if (!this._trainingService.currentState) {
      this._trainingService.currentState = 1;
    }
    // get role from app settings
    this.roleArray = TrainingSettings.roles;
    this.vehicleTypeArray = TrainingSettings.vehicleType;
    this.type = TrainingSettings.type;
    this._trainingService.showSearchComponent = true;
  }

  // // selected role
  selectedRole() {
    switch (this._trainingService.type) {
      case "visitor":
        this._trainingService.users[0].role = "visitor";
        this._trainingService.users[0].aadhar = "";
        this.executiveType = "";
        break;
      case "vehicle":
        this._trainingService.vehicleType = "0";
        this._trainingService.users[0].role = "Driver";
        this._trainingService.users[0].aadhar = "";
        this._trainingService.users[1].role = "Cleaner";
        this._trainingService.users[1].aadhar = "";
        this.executiveType = "";
        break;
    }
  }

  handleUserRegistered(type, result) {
    if (
      this._trainingService.driverExists &&
      this._trainingService.cleanerExists &&
      this._trainingService.vehicleExists
    ) {
      this._trainingService.currentState = 3;
      this.validateExamUsers();
    }
  }

  handleVehicleRegistered(result) {
    // console.log('vechicle registration', result, this._trainingService.examQueue.length)
    // if vehicle is register call validateExamUsers
    // if (result === 'true' && this._trainingService.examQueue.length !== 2) {
    //   this.validateExamUsers();
    // }

    if (result === "true" && this._trainingService.examQueue.length !== 2) {
      this.validateExamUsers();
    } else {
      this._trainingService.currentState = 3;
    }
  }

  async validateExamUsers() {
    this.examSearchCompleted = false;

    const body = [];
    // type, aadhar
    if (
      this._trainingService.examQueue.indexOf(
        this._trainingService.users[0].aadhar
      ) === -1
    ) {
      body.push({
        type: this._trainingService.users[0].role,
        aadhar: this._trainingService.users[0].aadhar
      });
    }
    if (
      this._trainingService.examQueue.indexOf(
        this._trainingService.users[1].aadhar
      ) === -1
    ) {
      body.push({
        type: this._trainingService.users[1].role,
        aadhar: this._trainingService.users[1].aadhar
      });
    }
    if (this._trainingService.type === "vehicle") {
      // console.log('vehicle', body)
      await this._trainingService
        .getExamUsers({ users: body })
        .subscribe(data => {
          // console.log('exam validate', data)
          this._trainingService.examQueue = [
            ...this._trainingService.examQueue,
            ...data.data.map(item => item.aadhar)
          ];
          // console.log(`exam queue`, this._trainingService.examQueue)
          this.examSearchCompleted = true;
          // console.log(this._trainingService.examQueue.length, 'ExamQueue length')
          // console.log(this._trainingService.currentState, 'current state after register')
          // console.log(this._trainingService.examTempQueue, 'ExamQueueTemp')
        });
      if (this._trainingService.examQueue.length === 1) {
        // console.log(this._trainingService.examQueue.length)
        this._trainingService.currentState = 3;
      }
    } else {
      // console.log('visitor')
      this._trainingService.getExamUsers({ users: body }).subscribe(data => {
        // console.log('exam validate', data)
        this._trainingService.examQueue = [
          ...this._trainingService.examQueue,
          ...data.data.map(item => item.aadhar)
        ];
        // console.log(`exam queue`, this._trainingService.examQueue)
        // this._trainingService.currentState = 3
        if (this._trainingService.examQueue.length === 1) {
          this._trainingService.currentState = 3;
        }
      });
    }
  }

  changeColor(event) {
    // console.log('event', event)
    this.errorMessage = false;
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
  // vehicle no
  changeError() {
    this.errorMessage1 = false;
  }
  changeError1(event) {
    this.errorMessage2 = false;
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
  selectType(data) {
    if (data.target.value !== "0") {
      this.errorMessage3 = false;
    }
  }

  // search and save visitor into data base
  searchVisitor() {
    if (this._trainingService.type === "vehicle") {
      if (
        this._trainingService.vehicleNo === "" ||
        this._trainingService.vehicleNo.trim() === ""
      ) {
        this.errorMessage1 = true;
        return;
      }
      if (this._trainingService.vehicleType === "0") {
        this.errorMessage3 = true;
        // console.log('1232')
        return;
      } else {
        this.errorMessage3 = false;
      }
    }
    // console.log(this.executiveType)
    this._trainingService.exeType = this.executiveType;
    // console.log(this._trainingService.exeType)
    if (this._trainingService.users[0].aadhar === "") {
      this.errorMessage = true;
      return;
    }
    if (this._trainingService.type === "vehicle") {
      if (
        this._trainingService.vehicleNo === "" ||
        this._trainingService.vehicleNo.trim() === ""
      ) {
        this.errorMessage1 = true;
        return;
      }
      // this._trainingService.users[1].aadhar
      if (
        this._trainingService.users[1].aadhar === "" ||
        this._trainingService.users[0].aadhar ===
        this._trainingService.users[1].aadhar
      ) {
        this.errorMessage2 = true;
        return;
      }

      // if (this._trainingService.users[0].aadhar === this._trainingService.users[1].aadhar) {
      //   this.errorMessage2 = true
      // }
    }
    this.spin = true;
    //  visitor role
    if (this._trainingService.type === "visitor") {
      const body = {};
      body["type"] = this._trainingService.type;
      body["aadhar"] = this._trainingService.users[0].aadhar.trim();
      this._trainingService.searchVisitor(body).subscribe(data => {
        if (data.success) {
          // testing for executive for user exists
          if (this._trainingService.exeType === "executive" && data.user) {
            this._trainingService.userExists = true;
            this._trainingService.currentState = 4;
            this.spin = false;
          } else if (
            this._trainingService.exeType === "executive" &&
            data.pass === 0
          ) {
            this._trainingService.userExists = true;
            this._trainingService.currentState = 4;
            this.spin = false;
          } else {
            this._trainingService.userExists = data.user;
            if (this._trainingService.userExists || data.pass === 0) {
              this._trainingService.userExists = true;
              this._trainingService.currentState = 3;
              this.validateExamUsers();
              this.spin = false;
            } else if (this._trainingService.userExists || data.pass === 1) {
              this._trainingService.userExists = true;
              this._trainingService.currentState = 4;
              this.spin = false;
            } else {
              this._trainingService.currentState = 2;
            }
            this.spin = false;
          }
        }
      });
    } else {
      // vehicle role
      const body = {};
      if (this._trainingService.vehicleNo.trim() === "") {
        return;
      }
      this._trainingService.vehicleNo = this._trainingService.vehicleNo.trim();
      body["vehNo"] = this._trainingService.vehicleNo.trim();
      body["type"] = this._trainingService.type;
      body["driver"] = {
        role: this._trainingService.users[0].role,
        aadhar: this._trainingService.users[0].aadhar.trim()
      };
      body["cleaner"] = {
        role: this._trainingService.users[1].role,
        aadhar: this._trainingService.users[1].aadhar
      };
      this._trainingService.searchVehicle(body).subscribe(data => {
        if (data.success) {
          // load drive module
          this._trainingService.driverExists = data.driverExists;
          this._trainingService.cleanerExists = data.cleanerExists;
          this._trainingService.vehicleExists = data.vehicleExists;

          if (
            this._trainingService.driverExists &&
            this._trainingService.cleanerExists &&
            this._trainingService.vehicleExists
          ) {
            this._trainingService.currentState = 3;
            // console.log(`twice ?`)
            this.validateExamUsers();
          } else {
            this._trainingService.currentState = 2;
          }
          this.spin = false;
        }
      });
    }

    // this._trainingService.users[0].name = ''
    // this._trainingService.users[0].mobile = ''
    // this._trainingService.users[0].email = ''
  }

  reset() {
    this.errorMessage = false;
    this.errorMessage1 = false;
    this.errorMessage2 = false;
    this.errorMessage3 = false;
    this._trainingService.examQueue.indexOf("");
    this.role = "";
    this._trainingService.vehicleNo = "";
    this._trainingService.users[0].aadhar = "";
    this._trainingService.users[0].role = "";
    this.executiveType = "non-executive";
    this._trainingService.reset();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this._trainingService.reset();
  }
}
