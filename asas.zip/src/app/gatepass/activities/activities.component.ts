import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import { OnDestroy } from '@angular/core';
import { TrainingSettings } from '../training.settings';
import { Subscription } from 'rxjs';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent implements OnInit, OnDestroy {
  activityData = [];
  activityDetails = [];
  activityInfo = [];
  showActivity = true;
  noActivity = false;
  msg;
  updateDate;
  timer;
  // spinner = false
  private activitySub: Subscription;

  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {
    // this.getActivities()
    this.activitySub = this.timer.subscribe(t => {
      this.getActivitiesWithInterval();
    });
  }
  // getActivities() {
  //   const body = {}
  //   body['id'] = ''
  //   this._trainingService.getActivities(body).subscribe(data => {
  //     this.activityData = data.data
  //     this.updateDate = this.activityData[0].updated_at
  //     if (data.success === true) {
  //       this.showActivity = true
  //       this.noActivity = false
  //       this.activityData.forEach(item => {
  //         this.activityDetails.push({
  //           name: item.name,
  //           aadhar: item.aadhar,
  //           role: item.role,
  //           status: item.status,
  //           type: item.type,
  //           // updated_at: moment(item.updated_at).format('ddd MMM DD HH:mm')
  //           updated_at: moment(item.updated_at).fromNow()
  //         })
  //       })
  //     } else {
  //       this.showActivity = false
  //       this.noActivity = true
  //       this.msg = this.activityData
  //     }

  //   })
  // }

  getActivitiesWithInterval() {
    setTimeout(() => {
      this.getActivitiesWithInterval();
    }, 100000);
    const body = {};
    if (this.updateDate === undefined) {
      body['id'] = '';
    } else {
      body['id'] = moment(this.updateDate).format('YYYY-MM-DD HH:mm:ss');
    }
    this._trainingService.getActivities(body).subscribe(
      data => {
        // this.spinner = true
        if (data.success) {
          this.activityData = data.data;
          this.showActivity = true;
          this.noActivity = false;
          this.updateDate = this.activityData[0].updated_at;
          this.activityData.forEach(item => {
            this.activityInfo.push({
              name: item.name,
              aadhar: item.aadhar,
              role: item.role,
              status: item.status,
              type: item.type.charAt(0).toUpperCase() + item.type.slice(1),
              updated_at: moment(item.updated_at).format('YYYY-MM-DD HH:mm:ss')
            });
          });
          // this.activityDetails = this.activityInfo
          this.activityDetails = [...this.activityInfo, ...this.activityDetails];
          this.activityInfo = [];
          if (this.activityDetails.length > 200) {
            for (let i = this.activityDetails.length; i > 200; i--) {
              this.activityDetails.pop();
            }
          }
        } else {
          if (!data.success && data.message && this.activityDetails.length === 0) {
            this.msg = data.message;
            this.showActivity = false;
            this.noActivity = true;
          }
        }
      },
      error => {
        // this.spinner = true;
        this.toastr.errorToastr('Server Error');
      }
    );
  }

  ngOnDestroy() {
    this.activitySub.unsubscribe();
  }
}
