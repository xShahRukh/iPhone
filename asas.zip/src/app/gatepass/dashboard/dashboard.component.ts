import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class TrainingDashboardComponent implements OnInit {

  constructor(public router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
  }

  Back() {
    this.router.navigate(['/training/gatepassDashboard']);
  }
}
