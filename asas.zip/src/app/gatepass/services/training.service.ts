import { Injectable } from '@angular/core';
import { Search } from '../models/search';
import { TrainingSettings } from '../training.settings';
import { Http, Headers, Response, RequestOptions, ResponseContentType } from '@angular/http';
import { User } from '../models/user.interface';
import { ApiService } from 'src/app/common/services/api.service';

@Injectable()
export class TrainigService {
  // common varibles used across ehs module
  currentState; // search, register, generateExam, generateGatepass
  type = '0'; // visitor or vehicle
  users = [];
  examUsers: User[]; // users for whom we have to generate exam
  exeType;
  public showUserRegistrationComponent = false; // disable registration component
  public showgenerateExamcomponent = false; // disable generate exam component
  public showSearchComponent = true; // enable search component
  public showGenerategatepass = false;
  public showExamComponent = false; // disable generate gate pass
  public appointmentList = [];

  // For Vehicle Part
  // check driver exists
  public driverExists = true;
  public cleanerExists = true;
  public vehicleExists = true;
  public userExists = true;
  examQueue = [];
  examTempQueue = [];

  vehicleNo = '';
  vehicleType = 'lv'; // lv, hv, fl
  pollutionExpiry;
  registrationExpiry;

  constructor(private _apiService: ApiService, private http: Http) {
    this.users = [
      { role: '', aadhar: '', name: '', mobile: '', email: '' },
      { role: '', aadhar: '', name: '', mobile: '', email: '' }
    ];
  }

  searchVisitor(values: any = '') {
    // let search: Search
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.EHSSEARCH, 'post', body);
  }
  getGatePass(values: any = '') {
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.GET_GATEPASS, 'POST', body);
  }

  //  register user
  registerUser(values: any = '') {
    // let search: Search
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.EHS_USER_REGISTER, 'post', body);
  }

  //  register vehicle
  registerVehicle(values: any = '') {
    // let search: Search
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.EHS_VEHICLE_REGISTER, 'post', body);
  }

  getBusySystems() {
    return this._apiService.callApi(TrainingSettings.API.GET_BUSY_SYSTEMS, 'GET');
  }
  getExamDetails(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_EXAM_DETAILS, 'POST', body);
    // return this.http.post(TrainingSettings.API.GET_EXAM_DETAILS, body, this.token()).map((response: Response) => response.json())
  }
  getInOutHistory(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_IN_OUT_HISTORY, 'POST', body);
    // return this.http.post(TrainingSettings.API.GET_IN_OUT_HISTORY, body, this.token()).map((response: Response) => response.json())
  }
  getExamId(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_EXAM_ID, 'POST', body);
  }

  // insert gatepass
  insertGatePass(values: any) {
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.INSERT_GATE_PASS, 'post', body);
  }
  insertGatePassVehicle(values: any = '') {
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.INSERT_GATE_PASS_VEHICLE, 'post', body);
  }
  getExamUsers(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_EXAM_USERS, 'POST', body);
  }
  getActivities(body) {
    console.log(body, 'body');
    return this._apiService.callApi(TrainingSettings.API.GET_ACTIVITIES, 'POST', body);
  }

  // vehicle type apis

  searchVehicle(values: any = '') {
    const body = JSON.stringify(values);
    return this._apiService.callApi(TrainingSettings.API.EHS_SEARCH_VEHICLE, 'post', body);
  }

  //  set timeout interval
  setOutInterval() {
    setTimeout(() => {
      this.currentState = 1;
      this.type = '0';
      this.users[0].aadhar = '';
      this.users[0].name = '';
      this.users[0].mobile = '';
      this.users[0].email = '';
      this.users[1].aadhar = '';
      this.users[1].name = '';
      this.users[1].email = '';
      this.vehicleNo = '';
      this.examQueue = [];
      this.examTempQueue = [];
    }, 5000);
  }

  getvidoesUrl(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_VIDEOS_URL, 'POST', body);
  }
  getQuestions(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_QUESTIONS, 'POST', body);
  }
  result(body) {
    return this._apiService.callApi(TrainingSettings.API.RESULT, 'POST', body);
  }
  AppointmentDetails(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_APPOINTMENT_DETAILS, 'POST', body);
  }
  getGatepassVerification(values: any = '') {
    const body = values;
    console.log(body);
    return this._apiService.callApi(TrainingSettings.API.GATEPASS_VERIFICATION, 'POST', body);
  }
  getAppointments(body) {
    return this._apiService.callApi(TrainingSettings.API.GET_APPOINMENT_DATA, 'POST', body);
  }
  Appoinment(body) {
    return this._apiService.callApi(TrainingSettings.API.APPOINTMENT, 'POST', body);
  }
  deleteAppointment(body) {
    return this._apiService.callApi(TrainingSettings.API.DELETE_APPOINTMENT, 'POST', body);
  }

  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }

  // state change
  previousState(value) {
    console.log(value, 'value');
    // if (value === 3) {
    //   value = value - 1
    // }
    // this.currentState = value
    // this.currentState = this.currentState - 1
    // console.log('currentstate', this.currentState)
    // // search component
    // if (this.currentState === 1) {
    //   console.log('ehs search')
    //   // this.showSearchComponent = true
    //   // this.showExamComponent = false
    //   // this.showgenerateExamcomponent = false
    //   // this.showUserRegistrationComponent = false
    //   // this.showGenerategatepass = false
    // }
    // // register component
    // // if (this.currentState === 2) {
    // //   console.log('ehs register')
    // //   this.showSearchComponent = false
    // //   this.showExamComponent = false
    // //   this.showUserRegistrationComponent = true
    // // }
    // if (this.currentState === 2) {
    //   console.log('exam generation')
    //   this.showExamComponent = true
    //   this.showSearchComponent = false
    //   this.showUserRegistrationComponent = false
    //   this.showgenerateExamcomponent = false
    // }
    // if (this.currentState === 3) {
    //   console.log('Generate GatePass')
    //   this.showGenerategatepass = true
    //   this.showExamComponent = false
    //   this.showSearchComponent = false
    //   this.showUserRegistrationComponent = false
    // }

    // switch case
  }
  // currentStates
  // 1: Search
  // 2: Register
  // 3: Generate Exam
  // 4: Generate Gatepass

  reset() {
    this.currentState = 1;
    this.users = [
      { role: '', aadhar: '', name: '', mobile: '', email: '' },
      { role: '', aadhar: '', name: '', mobile: '', email: '' }
    ];
    console.log(this.examQueue.indexOf(this.users[0].aadhar === ''));
    console.log(this.examQueue.indexOf(this.users[1].aadhar === ''));
    this.type = '0';
    this.examQueue = [];
    this.examTempQueue = [];
    this.registrationExpiry = '';
    this.pollutionExpiry = '';
    this.vehicleNo = '';
    console.log(this.currentState, 'testing current state');
  }
}
