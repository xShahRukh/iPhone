import { environment } from '../../environments/environment';

export class TrainingSettings {
  public static timer = 30000;

  public static messages = {
    // Login
    ENTER_USERNAME_PASSWORD: 'Please enter your username and password',
    LOGIN_FAILED: 'Login failed',

    // Customer
    CUSTOMER_DATA_FAILED: 'Error retrieving Customer data',

    // Dashboard
    DASHBOARD_DATA_FAILED: 'Error retrieving Dashboard data',
    // Report
    REPORT_DATA_FAILED: 'Error retrieving Report data'
  };

  public static API = {
    EHSSEARCH: environment.apiUrl + 'training_search',
    GET_GATEPASS: environment.apiUrl + 'gatePassIdDetails',
    EHS_USER_REGISTER: environment.apiUrl + 'createUser',
    GET_EXAM_ID: environment.apiUrl + 'generateExam',
    GET_BUSY_SYSTEMS: environment.apiUrl + 'busySystems',
    GET_EXAM_USERS: environment.apiUrl + 'validateExamUsers',
    // GET_GATEPASS: environment.apiUrl + 'gatePassIdDetails',
    GET_EXAM_DETAILS: environment.apiUrl + 'getexam_details',
    GET_IN_OUT_HISTORY: environment.apiUrl + 'inout_details',
    INSERT_GATE_PASS: environment.apiUrl + 'generateGatepass',
    INSERT_GATE_PASS_VEHICLE:
      environment.apiUrl + 'generateGatepassVehicle',
    GET_ACTIVITIES: environment.apiUrl + 'log_activities',
    // vehicle api call
    EHS_SEARCH_VEHICLE: environment.apiUrl + 'training_search_vehicle',
    GET_VIDEOS_URL: environment.apiUrl + 'getVideoUrl',
    GET_QUESTIONS: environment.apiUrl + 'getQuestions',
    RESULT: environment.apiUrl + 'result',
    GET_APPOINMENT_DATA: environment.apiUrl + 'getAppointmentData',
    APPOINTMENT: environment.apiUrl + 'appointment',
    GET_APPOINTMENT_DETAILS: environment.apiUrl + 'getAppointmentDetails',
    // VENDOR_PAYSLIPS: environment.apiUrl + 'vendorPayslips',
    DELETE_APPOINTMENT: environment.apiUrl + 'deleteAppointment',
    EHS_VEHICLE_REGISTER: environment.apiUrl + 'createVehicle',
    GATEPASS_VERIFICATION: environment.apiUrl + 'verifyGatepass'
  };

  public static roles = [
    { title: 'Driver', value: 'driver' },
    { title: 'Cleaner', value: 'cleaner' }
  ];
  public static vehicleType = [
    { title: 'Heavy Vehicle', value: 'hv' },
    { title: 'Light Vehicle', value: 'lv' },
    { title: 'Fork Lift', value: 'fl' }
  ];
  public static type = [
    { title: 'Visitor', value: 'visitor' },
    { title: 'Vehicle', value: 'vehicle' }
  ];

  public static Systems = ['1', '2', '3', '4', '5'];

  public static vehicleGatepassChecklist = [
    'License verified: ',
    'Pollution certificate verified: ',
    'Registration Verified: '
  ];
}
