import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TrainigService } from '../services/training.service';
import * as moment from 'moment';

@Component({
  selector: 'app-vehicle',
  templateUrl: './vehicle.component.html',
  styleUrls: ['./vehicle.component.css']
})
export class VehicleComponent implements OnInit {
  currentState = 2; //  state of the component
  spin = false; // disable spinner
  errorMessage = false;
  title;
  maxDate;
  @Output() vehicleRegistered = new EventEmitter();

  constructor(public _trainingService: TrainigService) {}

  ngOnInit() {
    this.maxDate = new Date();
    // console.log(this._ehsService.currentState, 'ehs Vehicle')
  }

  changeColor() {
    this.errorMessage = false;
  }

  registerVehicle() {
    if (this._trainingService.vehicleNo.trim() === '' || this._trainingService.vehicleNo.trim() === '') {
      this.errorMessage = true;
      return;
    }

    this.spin = true;
    const body = {};

    body['type'] = this._trainingService.type.trim();
    body['vehNo'] = this._trainingService.vehicleNo.trim();
    body['pollutionExpiry'] = moment(this._trainingService.pollutionExpiry).format('YYYY-MM-DD');
    body['registrationExpiry'] = moment(this._trainingService.registrationExpiry).format('YYYY-MM-DD');
    this._trainingService.registerVehicle(body).subscribe(data => {
      if (data.success) {
        this._trainingService.currentState += 1;
        // console.log(this._trainingService.currentState)
        this.spin = false;
        // console.log('data in user register', data)
        this.vehicleRegistered.emit('true');
        this._trainingService.vehicleExists = true;
        this._trainingService.pollutionExpiry = '';
        this._trainingService.registrationExpiry = '';
      } else {
        this.spin = false;
        return;
      }
    });
  }

  backtoSearch() {
    this._trainingService.users[0].name = '';
    this._trainingService.users[0].mobile = '';
    this._trainingService.users[0].email = '';
    this._trainingService.previousState(this.currentState);
    this._trainingService.reset();
  }
}
