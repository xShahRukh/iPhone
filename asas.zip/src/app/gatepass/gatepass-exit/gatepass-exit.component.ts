import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-gatepass-exit',
  templateUrl: './gatepass-exit.component.html',
  styleUrls: ['./gatepass-exit.component.css']
})
export class GatepassExitComponent implements OnInit {
  gatePassId;
  title;
  aadharNumber;
  entryTime;
  name;
  mobile;
  getIdDetails = [];
  gatePassExit = true;
  gatePassDetails = false;
  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {
    this.title = 'Gate Pass Exit';
  }

  Submit(value) {
    const body = {};
    if (value === '1') {
      body['confirm'] = '';
      body['id'] = this.gatePassId;
      this._trainingService.getGatePass(body).subscribe(data => {
        this.getIdDetails = data.data;
        this.aadharNumber = this.getIdDetails[0].aadhar;
        this.gatePassId = this.getIdDetails[0].id;
        this.name = this.getIdDetails[0].name;
        this.entryTime = moment(this.getIdDetails[0].entry_tm).format('YYYY-MM-DD HH:mm');
      });
      this.gatePassDetails = true;
      this.gatePassExit = false;
      this.title = 'Gate Pass Holder Details';
    }
    if (value === '2') {
      body['id'] = this.gatePassId;
      body['confirm'] = true;
      this._trainingService.getGatePass(body).subscribe(data => {
        if (data.success) {
          swal({
            position: 'top-right',
            type: 'success',
            title: 'Updated successfully ',
            showConfirmButton: false,
            timer: 2500
          }).catch(swal.noop);
        } else {
          this.toastr.errorToastr('Error!..');
        }
      });
      this.gatePassId = '';
      this.gatePassDetails = false;
      this.gatePassExit = true;
    }
  }
  Reset() {
    this.gatePassId = '';
  }
  back() {
    this.gatePassDetails = false;
    this.gatePassExit = true;
  }
}
