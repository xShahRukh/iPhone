import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GatepassExitComponent } from './gatepass-exit.component';

describe('GatepassExitComponent', () => {
  let component: GatepassExitComponent;
  let fixture: ComponentFixture<GatepassExitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GatepassExitComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GatepassExitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
