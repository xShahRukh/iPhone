import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TrainingDashboardComponent } from './dashboard/dashboard.component';
import { TrainingVideosComponent } from './training-videos/training-videos.component';
import { VerifyGatepassComponent } from './verify-gatepass/verify-gatepass.component';
import { UserAppointmentsComponent } from './user-appointments/user-appointments.component';
import { GatepassDashboardComponent } from './gatepass-dashboard/gatepass-dashboard.component';


const routes: Routes = [
    // { path: 'search', component: SearchComponent },
    { path: 'trainingDashboard', component: TrainingDashboardComponent },
    { path: 'gatepassDashboard', component: GatepassDashboardComponent },
    { path: 'verifyGatepass', component: VerifyGatepassComponent},
    { path: 'userAppointment', component: UserAppointmentsComponent },

    { path: 'trainingvideos/:id', component: TrainingVideosComponent },
    { path: '', redirectTo: 'gatepassDashboard', pathMatch: 'full' },
    { path: '**', redirectTo: 'gatepassDashboard' },
  ];

  export const routing: ModuleWithProviders = RouterModule.forChild(routes);
