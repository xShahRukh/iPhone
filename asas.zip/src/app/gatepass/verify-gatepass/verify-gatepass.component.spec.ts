import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyGatepassComponent } from './verify-gatepass.component';

describe('VerifyGatepassComponent', () => {
  let component: VerifyGatepassComponent;
  let fixture: ComponentFixture<VerifyGatepassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VerifyGatepassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyGatepassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
