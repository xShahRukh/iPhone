import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Routes, RouterModule, Router, ActivatedRoute } from '@angular/router';
import { TrainigService } from '../services/training.service';
import * as moment from 'moment';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-verify-gatepass',
  templateUrl: './verify-gatepass.component.html',
  styleUrls: ['./verify-gatepass.component.css']
})
export class VerifyGatepassComponent implements OnInit {
  barcode = '';
  dataList = [];
  userList = [];
  showRole = false;
  verified = false;
  verificationTime = '';
  notVerified = false;
  constructor(
    private _trainingService: TrainigService,
    private route: ActivatedRoute,
    public router: Router,
    public toastr: ToastrManager,
    vcr: ViewContainerRef
  ) {}

  ngOnInit() {}
  getVerification() {
    const body = {};
    body['barcode'] = this.barcode;
    this._trainingService.getGatepassVerification(body).subscribe(data => {
      if (data.success) {
        this.showRole = true;
        this.dataList = data.data;
        this.userList = data.res;
        this.verified = true;
        this.notVerified = false;
        this.verificationTime = moment(this.dataList[0].verification_time).format(
          'YYYY-MM-DD HH:mm'
        );
        if (this.dataList[0].role === 'vehicle') {
          for (let i = 0; i < this.userList.length; i++) {
            if (this.dataList[0].driver === this.userList[i].aadhar) {
              this.userList[i]['type'] = 'Driver';
            } else if (this.dataList[0].cleaner === this.userList[i].aadhar) {
              this.userList[i]['type'] = 'Cleaner';
            }
          }
        } else {
          for (let i = 0; i < this.userList.length; i++) {
            this.userList[i]['type'] = 'Visitor';
          }
        }
      } else {
        this.dataList = [];
        this.userList = [];
        this.verified = false;
        this.notVerified = true;
        this.showRole = false;
        this.toastr.errorToastr(data.message);
      }
    });
  }

  Back() {
    this.router.navigate(['/training/gatepassDashboard']);
  }

  Reset() {
    this.barcode = '';
    this.verified = false;
    this.notVerified = false;
    this.showRole = false;
    this.dataList = [];
    this.userList = [];
  }
}
