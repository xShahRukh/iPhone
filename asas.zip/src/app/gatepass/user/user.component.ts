import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TrainigService } from '../services/training.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  currentState = 2; //  state of the component
  spin = false; // disable spinner
  errorMessage = false;
  errorMessage1 = false;
  errorMessage2 = false;
  duplicateData = false;
  visitorData = true;
  title;
  msg;
  @Input() role;
  @Output() userRegistered = new EventEmitter();

  constructor(public _trainingService: TrainigService) {}

  ngOnInit() {
    // console.log(this._trainingService.currentState, 'user current state')
    // console.log(this.role, 'checking role')
    switch (this.role) {
      case 'driver':
        this.title = 'Driver';
        break;
      case 'cleaner':
        this.title = 'Cleaner';
        break;
    }
  }

  changeColor() {
    this.errorMessage = false;
  }
  changeColor1(event) {
    this.errorMessage1 = false;
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
  changeColor2() {
    this.errorMessage2 = false;
  }

  registerUser(form: NgForm) {
    // console.log(this._trainingService.exeType)
    // console.log('error', form, )
    // driver and user validation
    if (this._trainingService.type === 'visitor' || this.role === 'driver') {
      if (this._trainingService.users[0].name === '' || this._trainingService.users[0].name.trim() === '') {
        this.errorMessage = true;
        return;
      }
      if (this._trainingService.users[0].mobile.length < 10 || this._trainingService.users[0].mobile.trim() === '') {
        this.errorMessage1 = true;
        return;
      }
      // if (this._trainingService.users[0].email === '') {
      //   this.errorMessage2 = true
      //   return
      // }
      if (
        this._trainingService.users[0].email === '' ||
        !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this._trainingService.users[0].email)
      ) {
        this.errorMessage2 = true;
        return;
      }
    }
    // cleaner validation
    if (this._trainingService.type === 'vehicle' && this.role === 'cleaner') {
      // console.log('cleaner', this._trainingService.users[1].name, 'o', this._trainingService.users[0].name)
      if (!this._trainingService.users[1].name || this._trainingService.users[1].name.trim() === '') {
        // console.log('cleaner1')
        this.errorMessage = true;
        return;
      }
      if (this._trainingService.users[1].mobile.length < 10 || this._trainingService.users[1].mobile.trim() === '') {
        // console.log('cleaner2')
        this.errorMessage1 = true;
        return;
      }
      // if (this._trainingService.users[1].email === undefined) {
      //   console.log('cleaner3')
      //   this.errorMessage2 = true
      //   return
      // }
      if (
        this._trainingService.users[1].email === '' ||
        !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this._trainingService.users[1].email)
      ) {
        this.errorMessage2 = true;
        return;
      }
    }

    this.spin = true;
    const body = {};
    if (this._trainingService.type === 'visitor') {
      this._trainingService.users[0].name = this._trainingService.users[0].name.trim();
      this._trainingService.users[0].mobile = this._trainingService.users[0].mobile.trim();
      this._trainingService.users[0].email = this._trainingService.users[0].email.trim();
      body['type'] = this._trainingService.type.trim();
      body['aadhar'] = this._trainingService.users[0].aadhar.trim();
      body['name'] = this._trainingService.users[0].name.trim();
      body['mobile'] = this._trainingService.users[0].mobile.trim();
      body['email'] = this._trainingService.users[0].email.trim();
    }

    if (this._trainingService.type === 'vehicle') {
      this._trainingService.users[0].name = this._trainingService.users[0].name.trim();
      this._trainingService.users[0].mobile = this._trainingService.users[0].mobile.trim();
      this._trainingService.users[0].email = this._trainingService.users[0].email.trim();
      if (this.role === 'driver') {
        body['type'] = this._trainingService.type.trim();
        body['aadhar'] = this._trainingService.users[0].aadhar.trim();
        body['name'] = this._trainingService.users[0].name.trim();
        body['mobile'] = this._trainingService.users[0].mobile.trim();
        body['email'] = this._trainingService.users[0].email.trim();
      } else {
        body['type'] = this._trainingService.type.trim();
        body['aadhar'] = this._trainingService.users[1].aadhar.trim();
        body['name'] = this._trainingService.users[1].name.trim();
        body['mobile'] = this._trainingService.users[1].mobile.trim();
        body['email'] = this._trainingService.users[1].email.trim();
      }
    }

    // console.log('user body', body)
    this._trainingService.registerUser(body).subscribe(data => {
      if (data.success) {
        if (this._trainingService.exeType === 'executive') {
          this.spin = false;
          // this._trainingService.showGenerategatepass = true
          this._trainingService.showUserRegistrationComponent = false; // disable Registration
          this._trainingService.showgenerateExamcomponent = false; // disable generate exam component
          this._trainingService.showSearchComponent = false; // disable search component
          this._trainingService.currentState = 4;
        } else {
          this.spin = false;
          this._trainingService.showgenerateExamcomponent = true; // enable generate exam component
          this._trainingService.showSearchComponent = false; // disable search component
          this._trainingService.showUserRegistrationComponent = false; // disalbe user registration component

          if (this.role === 'user' && this._trainingService.exeType !== 'executive') {
            this._trainingService.examQueue.push(this._trainingService.users[0].aadhar);
            this._trainingService.userExists = true;
            this._trainingService.currentState = 3;
            // console.log('user')
          }
          if (this.role === 'user' && this._trainingService.exeType === 'executive') {
            this._trainingService.examQueue.push(this._trainingService.users[0].aadhar);
            this._trainingService.userExists = true;
            this._trainingService.currentState = 4;
            // console.log('user')
          }
          // console.log('data in user register', data)
          if (this.role === 'driver') {
            // console.log(this.role)
            this._trainingService.examQueue.push(this._trainingService.users[0].aadhar);
            this._trainingService.driverExists = true;
          }
          if (this.role === 'cleaner') {
            // console.log(this.role)
            this._trainingService.users[1].mobile = '';
            this._trainingService.examQueue.push(this._trainingService.users[1].aadhar);
            this._trainingService.cleanerExists = true;
          }
          this.userRegistered.emit('true');
        }
      } else {
        // console.log(data.success, 'testing data.data')
        this.msg = data.message;
        this.spin = false;
        this.visitorData = false;
        this.duplicateData = true;
        return;
      }
    });
  }

  backtoSearch() {
    this._trainingService.vehicleNo = '';
    // console.log(this._trainingService.examQueue.indexOf(this._trainingService.users[0].aadhar), 'testing index of')
    this._trainingService.reset();
    // this._trainingService.currentState = 1
    // this._trainingService.users[0].name = ''
    // this._trainingService.users[0].mobile = ''
    // this._trainingService.users[0].email = ''
    // this._trainingService.users[0].aadhar = ''
    // this._trainingService.users[1].name = ''
    // this._trainingService.users[1].mobile = ''
    // this._trainingService.users[1].email = ''
    // this._trainingService.users[1].aadhar = ''
    // this._trainingService.type = '0'
    // this._trainingService.examQueue = []
    // this._trainingService.examTempQueue = []
    // this._trainingService.previousState(this.currentState)
  }
}
