import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-training-videos',
  templateUrl: './training-videos.component.html',
  styleUrls: ['./training-videos.component.css']
})
export class TrainingVideosComponent implements OnInit {
  videoData = [];
  IndexI = 0;
  urlData;
  selectionop1;
  selectionop2;
  selectionop3;
  selectionop4;
  result;
  message;
  total;
  type;
  v_id;
  longPath;
  docPath;
  exam = false;
  showVideo = true;
  resultPage = false;
  msg = false;
  examStarted = false;
  examQuestions = [];
  examQuestions1 = [];
  examQuestions2 = [];
  answer = [];
  selection: any;
  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    private route: ActivatedRoute,
    vcr: ViewContainerRef,
    public router: Router,
    public sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    this.docPath = '../../assets/sample.doc';
    this.longPath = '../../assets/Manoj Varma resume(updated).pdf';
    this.v_id = this.route.snapshot.params['id'];
    this.getVideos();
    const date = moment()
      .add(180, 'days')
      .format('YYYY-MM-DD');
    // setTimeout(() => this.examStarted ? this.msg : this.getVideos(), 3000);
  }

  getVideos() {
    // console.log(`in get videos`)
    this.examStarted = false;
    setTimeout(() => (this.examStarted ? this.msg : this.getVideos()), 3000);
    const body = {};
    body['system_no'] = this.v_id;
    this._trainingService.getvidoesUrl(body).subscribe(data => {
      if (data.success === true) {
        this.examStarted = true;
        this.showVideo = true;
        this.msg = false;
        this.videoData = data.data;
        this.urlData = this.videoData[0].video_url;
        this.type = this.videoData[0].role;
      } else {
        this.msg = true;
        this.message = data.message;
      }
    });
  }

  Next() {
    this.examStarted = true;
    this.exam = true;
    this.showVideo = false;
    this.resultPage = false;
    const body = {};
    body['id'] = this.videoData[0].id;
    this._trainingService.getQuestions(body).subscribe(data => {
      this.examQuestions = data.data;
      this.total = this.examQuestions.length;
    });
  }

  Selection(value, index) {
    this.answer[index] = value.target.value;
  }

  // Forward() {
  //   this.IndexI++
  //   console.log(this.IndexI)
  // }

  // Previous() {
  //   this.IndexI--
  // }

  submit() {
    const body = {};
    let count = 0;
    for (let i = 0; i < this.answer.length; i++) {
      if (this.answer[i] === this.examQuestions[i].answer) {
        count++;
      }
    }
    this.result = count;
    this.total = this.examQuestions.length;
    body['aadhar'] = this.videoData[0].aadhar;
    body['score'] = this.result;
    if (this.result > this.videoData[0].min_score) {
      body['result'] = 1;
      body['expire_dt'] = moment()
        .add(180, 'days')
        .format('YYYY-MM-DD');
    } else {
      body['result'] = 0;
      body['expire_dt'] = '';
    }
    this._trainingService.result(body).subscribe(data => {});
    this.examStarted = false;
    this.resultPage = true;
    this.exam = false;
  }

  ok() {
    this.resultPage = false;
    this.examStarted = false;
    this.exam = false;
    this.msg = false;
    this.getVideos();
  }
}
