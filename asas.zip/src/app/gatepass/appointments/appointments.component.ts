import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import { ApiService } from '../../common/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-appointments',
  templateUrl: './appointments.component.html',
  styleUrls: ['./appointments.component.css']
})
export class AppointmentsComponent implements OnInit {
  today;
  appointment = false;
  noAppointment = false;
  appointmentDetails = [];
  msg;
  checkRole = false;
  rolesData = [];
  spinner = false;
  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    private _apiService: ApiService,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {
    this.spinner = false;
    this.today = moment().format('YYYY-MM-DD');
    // console.log(this.today)
    this.getAppointmentDetails();
    this._apiService.getRoles1({ emp_id: sessionStorage.getItem('userid') }).subscribe(datas => {
      if (!datas.success) {
        this._apiService.rolesArray = datas.data;
        this.rolesData = this._apiService.rolesArray;
        console.log(this.rolesData);
        this.rolesData.forEach(item => {
          if (item.display_name === 'Audit Manager') {
            this.checkRole = true;
          }
        });
      }
    });
  }

  delete(id, name) {
    this.spinner = false;
    console.log(id);
    const body = {};
    body['id'] = id;
    if (confirm('Are you sure you want to delete this Appointment?') === true) {
      this._trainingService.deleteAppointment(body).subscribe(data => {
        if (data.success) {
          this.spinner = true;
          this.toastr.successToastr('Your appointment is deleted successfully');
          this.getAppointmentDetails();
        } else {
          this.spinner = true;
          this.toastr.errorToastr(data.message);
        }
      });
    } else {
      this.spinner = true;
    }
  }
  getAppointmentDetails() {
    this.spinner = false;
    const body = {};
    body['dt'] = this.today;
    this._trainingService.AppointmentDetails(body).subscribe(
      data => {
        if (data.success) {
          this.spinner = true;
          this.appointmentDetails = data.data;
          this._trainingService.appointmentList = data.data;
          this.appointment = true;
        } else {
          this.spinner = true;
          this.appointment = false;
          this.msg = data.message;
        }
      },
      error => {
        this.spinner = true;
        this.toastr.errorToastr('Server Error ');
      }
    );
  }
}
