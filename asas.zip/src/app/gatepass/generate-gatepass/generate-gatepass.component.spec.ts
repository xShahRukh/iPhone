import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateGatepassComponent } from './generate-gatepass.component';

describe('GenerateGatepassComponent', () => {
  let component: GenerateGatepassComponent;
  let fixture: ComponentFixture<GenerateGatepassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateGatepassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateGatepassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
