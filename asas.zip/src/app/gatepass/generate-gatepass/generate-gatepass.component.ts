import { Component, OnInit, ElementRef, ViewChild } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import * as _ from "underscore";
// import { QRCodeComponent } from 'angular2-qrcode';

import { TrainigService } from "../services/training.service";

@Component({
  selector: "app-generate-gatepass",
  templateUrl: "./generate-gatepass.component.html",
  styleUrls: ["./generate-gatepass.component.css"]
})
export class GenerateGatepassComponent implements OnInit {
  videosrc: any;
  webcamUrl;
  localstream;
  src: string;
  @ViewChild("imgRef", {static:false}) img: ElementRef;
  errorMessage = false;
  errorMessage1 = false;
  showform = true;
  show = false;
  camera = false;
  canvas = false;

  constructor(
    public trainingService: TrainigService,
    private sanitizer: DomSanitizer,
    private element: ElementRef
  ) { }

  // gatepass input fields
  whom = "";
  currentState = 3;
  purpose = "";
  gatepassCode;
  list = [];
  FilterList = [];
  showQrCode = false;
  showGatepassForm = true;

  showGatePassPage = true;
  generateId = true;
  showgatePass = false;
  hideGatePass = false;
  spin = false;
  selectList;

  ngOnInit() {
    this.trainingService.showGenerategatepass = true;
    this.currentState = 3;
    this.showGatepassForm = true;
    this.showGatePassPage = true;
    // this.showCam();
    this.trainingService.appointmentList.forEach(item => {
      this.list.push({
        id: item.id,
        emp_code: item.emp_code,
        emp_name: item.emp_name,
        purpose: item.purpose,
        visitor_name: item.visitor_name
      });
    });
  }

  // webcam
  private showCam() {
    const nav = <any>navigator;

    nav.getUserMedia =
      nav.getUserMedia || nav.mozGetUserMedia || nav.webkitGetUserMedia;

    const promise = new Promise<string>((resolve, reject) => {
      nav.getUserMedia(
        { video: true },
        stream => {
          // Needed for turning off the camera
          this.localstream = stream;
          resolve(stream);
        },
        err => reject(err)
      );
    })
      .then(stream => {
        this.webcamUrl = URL.createObjectURL(stream);
        this.videosrc = this.sanitizer.bypassSecurityTrustResourceUrl(
          this.webcamUrl
        );
        this.element.nativeElement.querySelector("#myVideo").autoplay = true;
      })
      .catch(error => { });
  }

  turnON() {
    this.showform = false;
    this.src = null;
    this.showCam();
    // this.camera = true;
    // this.canvas = false;
  }

  turnOFF() {
    // console.log('turnoff called')
    // var video = <HTMLVideoElement>document.getElementById('myVideo');
    // video.pause();
    // video.src = '';
    this.localstream.getTracks()[0].stop();
  }

  // view images
  snap() {
    const video = <HTMLVideoElement>document.getElementById("myVideo");
    const c = <HTMLCanvasElement>document.getElementById("myCanvas");
    const ctx = c.getContext("2d");
    ctx.drawImage(video, 0, 0, c.width, c.height);
    this.src = c.toDataURL("image/png");

    // this.img.nativeElement.src = this.src;
    // this.camera = false;
    // this.canvas = true;
    this.showform = true;
    this.turnOFF();
  }

  changeColor() {
    this.errorMessage = false;
  }

  changeColor1() {
    this.errorMessage1 = false;
  }

  // insert purpose and whom
  generateGatepass() {
    this.whom = this.whom.trim();
    this.purpose = this.purpose.trim();
    if (this.whom === "") {
      this.errorMessage = true;
      return;
    }
    if (this.purpose === "") {
      this.errorMessage1 = true;
      return;
    }
    this.errorMessage = true;
    this.generateId = false;
    this.spin = true;
    // console.log(this.currentState, 'currentState')
    const body = {};
    if (this.trainingService.type === "visitor") {
      body["visitor_type"] = this.trainingService.exeType;
    } else {
      body["visitor_type"] = "";
    }
    body["aadhar"] = this.trainingService.users[0].aadhar;
    body["type"] = this.trainingService.type;
    (body["whom"] = this.whom), (body["image"] = this.src);
    body["purpose"] = this.purpose;
    // console.log('body is ', body)

    this.trainingService.insertGatePass(body).subscribe(data => {
      if (data.success) {
        if (data.data.gatePassId !== undefined) {
          this.gatepassCode = data.data;
          this.showgatePass = true;
          this.generateId = false;
          this.showGatepassForm = false;
          this.showQrCode = true;
        } else {
          this.hideGatePass = true;
          this.showgatePass = false;
          this.generateId = false;
          this.showGatepassForm = false;

          this.gatepassCode = data.data.message;
        }
      } else {
        this.showgatePass = false;
        return;
      }
      this.spin = false;
    });
  }

  selectType(event) {
    const id = event.target.value;
    if (id === "0") {
      this.show = true;
      this.whom = "";
      this.purpose = "";
    } else {
      this.show = true;
      this.FilterList = _.filter(this.list, function (item) {
        return item.id === parseInt(id, 10);
      });
      this.whom = this.FilterList[0].emp_name;
      this.purpose = this.FilterList[0].purpose;
    }
  }

  // print
  print(printSectionId: string) {
    window.print();
  }
  reset() {
    this.gatepassCode = "";
    this.showGatePassPage = false;
    // this.eshService.currentState = 1
    // this.eshService.type = '0'
    // this.eshService.users[0].aadhar = ''
    // this.eshService.users[0].name = ''
    // this.eshService.users[0].mobile = ''
    // this.eshService.users[0].email = ''
    // this.eshService.users[1].aadhar = ''
    // this.eshService.users[1].name = ''
    // this.eshService.users[1].mobile = ''
    // this.eshService.users[1].email = ''
    // this.eshService.users[1].aadhar = ''
    this.trainingService.reset();
  }
}
