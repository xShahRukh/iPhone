import { Component, OnInit, ViewContainerRef, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';

import { User } from '../models/user.interface';
import { AppSettings } from '../../app.settings';
import { TrainingSettings } from '../training.settings';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-generate-exam',
  templateUrl: './generate-exam.component.html',
  styleUrls: ['./generate-exam.component.css']
})
export class GenerateExamComponent implements OnInit {
  currentState;
  selectsystem = '';
  state;
  examId;
  Sno;
  examIdDetails = [];
  systemNo = [];
  busySystem;
  systemNumber = [];
  comma = ',';
  examUsersData = [];
  examDetails = [];
  examIdData = false;
  spin = false;
  // examIdResponse = false
  backToPrevious = false;
  errorMessage;
  errorMessage3 = false;

  @Input() role;
  @Output() examGenerate = new EventEmitter();
  // userRole:

  constructor(
    public _trainingService: TrainigService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {
    this._trainingService.showExamComponent = true;
    this._trainingService.getBusySystems().subscribe(data => {
      this.busySystem = Object.values(data.data);
      this.spin = false;
      this.systemNo = TrainingSettings.Systems;
      if (this.busySystem[0].systems != null) {
        this.systemNumber = this.busySystem[0].systems.split(',');
      } else {
        this.systemNo.forEach(item => {
          this.systemNumber.push({
            value: item
          });
        });
      }

      this.systemNumber = _.difference(this.systemNo, this.systemNumber);
    });

    // this.currentState = 2
    // console.log(this.currentState, 'currentstate')
    this.spin = true;
    const body = {};
    const vf = [];
    vf[0] = body;

    switch (this.role) {
      case 'driver':
      case 'user':
        body['type'] = this._trainingService.users[0].role;
        body['aadhar'] = this._trainingService.users[0].aadhar;
        break;
      case 'cleaner':
        body['type'] = this._trainingService.users[1].role;
        body['aadhar'] = this._trainingService.users[1].aadhar;
    }

    this._trainingService.getExamUsers({ users: vf }).subscribe(data => {
      this.examIdData = true;
      // this.examIdResponse = false
      this.spin = false;
      this.examUsersData = data.data;
      if (this.examUsersData.length === 0) {
        // this.examIdResponse = true
        this.examIdData = false;
        this.examDetails['0'] = 'Exam already has been taken';
      } else {
        this._trainingService.users[0].aadhar = this.examUsersData[0].aadhar;
        this._trainingService.users[0].role =
          this.examUsersData[0].type.charAt(0).toUpperCase() + this.examUsersData[0].type.slice(1);
      }
    });
  }

  printToCart(printSectionId: string) {
    window.print();
  }

  Submit() {
    this.spin = true;
    // this.examIdResponse = false
    this.examIdData = false;

    let body;

    if (this._trainingService.type === 'visitor') {
      body = {
        aadhar: this._trainingService.users[0].aadhar,
        role:
          this.examUsersData[0].type.charAt(0).toLowerCase() + this.examUsersData[0].type.slice(1),
        systemNo: this.selectsystem
      };
    }

    if (this._trainingService.type === 'vehicle') {
      if (this.role === 'driver') {
        this.role = 'Cleaner';
        body = {
          aadhar: this._trainingService.users[0].aadhar,
          role: this._trainingService.users[0].role,
          systemNo: this.selectsystem,
          vehicleType: this._trainingService.vehicleType
        };
      }

      if (this.role === 'cleaner') {
        body = {
          aadhar: this._trainingService.users[1].aadhar,
          role: this._trainingService.users[1].role,
          systemNo: this.selectsystem,
          vehicleType: this._trainingService.vehicleType
        };
      }
    }

    this._trainingService.getExamId(body).subscribe(data => {
      if (data.success) {
        this.examDetails['0'] = 'Your Exam System Number is:';
        this.examDetails += data.systemNo;
        // this.examIdResponse = true
        this.spin = false;
        if (this._trainingService.type === 'visitor') {
          // console.log('genrate exam')
          if (this._trainingService.examQueue.indexOf(body['aadhar']) !== -1) {
            this._trainingService.examQueue = _.without(
              this._trainingService.examQueue,
              _.findWhere(this._trainingService.examQueue, body['aadhar'])
            );
            // console.log(`exam queue afte rremoving`, this._trainingService.examQueue, this._trainingService.examQueue.length)
            this._trainingService.examTempQueue.push(body['aadhar']);
          }
          this._trainingService.currentState = 4;
          this._trainingService.setOutInterval();
        }
        this.examIdData = false;

        if (this._trainingService.examQueue.indexOf(body['aadhar']) !== -1) {
          this._trainingService.examQueue.splice(
            this._trainingService.examQueue.indexOf(body['aadhar']),
            1
          );
          // this._trainingService.examQueue =
          _.without(
            this._trainingService.examQueue,
            _.findWhere(this._trainingService.examQueue, body['aadhar'])
          );
          // console.log(`exam queue afte rremoving`, this._trainingService.examQueue, this._trainingService.examQueue.length)
          this._trainingService.examTempQueue.push(body['aadhar']);
        }
        // if (this._trainingService.examQueue.length === 1) {
        //   this._trainingService.currentState = 3
        // }
        if (this._trainingService.examQueue.length === 0) {
          this._trainingService.currentState = 4;
          this._trainingService.setOutInterval();
        }
        this.examGenerate.emit('true');
      } else {
        this.spin = false;
        // this.examIdResponse = false
        this.examIdData = false;
        this.errorMessage = data.message;
        return;
      }
    });
  }

  reset() {
    // console.log(this._trainingService.examQueue.indexOf(this._trainingService.users[0].aadhar), 'testing index of')
    this._trainingService.vehicleNo = '';
    // this._trainingService.currentState = 1
    this.selectsystem = '';
    // this._trainingService.previousState(this.currentState)
    this._trainingService.type = '0';
    this._trainingService.reset();
  }
}
