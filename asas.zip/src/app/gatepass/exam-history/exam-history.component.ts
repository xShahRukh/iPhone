import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-exam-history',
  templateUrl: './exam-history.component.html',
  styleUrls: ['./exam-history.component.css']
})
export class ExamHistoryComponent implements OnInit {
  examId;
  examHistory = [];
  examSearch = true;
  examDetails = false;
  examNotTaken = false;
  examPage = true;
  exam;
  aadhar;
  examData;
  spin = false;
  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {}

  Submit() {
    this.spin = true;
    const body = {};
    body['id'] = this.aadhar;
    this._trainingService.getExamDetails(body).subscribe(data => {
      this.spin = false;
      if (!data.success) {
        this.spin = false;
        this.examData = data.data;
        this.examNotTaken = true;
        this.examDetails = false;
        this.examPage = false;
        this.examSearch = false;
      } else {
        this.spin = false;
        this.examHistory = data.data;
        this.examSearch = false;
        this.examDetails = true;
      }
    });
  }

  reset() {
    this.aadhar = '';
  }

  Back() {
    this.examId = '';
    this.aadhar = '';
    this.examHistory = [];
    this.examSearch = true;
    this.examDetails = false;
    this.examNotTaken = false;
    this.examPage = true;
  }

  omit_special_number(event) {
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
}
