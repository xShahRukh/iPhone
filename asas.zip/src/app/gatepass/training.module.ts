import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomFormsModule } from 'ng2-validation';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// import { AppComponent } from '../app.component';
// import { AppSettings } from '../app.settings';
import { routing } from './training.routing';
import { TrainigService } from './services/training.service';

// common Services

// Auth Guards
import { AuthGuard } from '../common/guards/auth.guard';
import { TrainingDashboardComponent } from './dashboard/dashboard.component';
import { SearchComponent } from './search/search.component';
import { AppointmentsComponent } from './appointments/appointments.component';
import { ExamHistoryComponent } from './exam-history/exam-history.component';
import { ActivitiesComponent } from './activities/activities.component';
import { InoutHistoryComponent } from './inout-history/inout-history.component';
import { GenerateExamComponent } from './generate-exam/generate-exam.component';
import { GenerateGatepassComponent } from './generate-gatepass/generate-gatepass.component';
import { GenerateGatepassVehicleComponent } from './generate-gatepass-vehicle/generate-gatepass-vehicle.component';
import { UserComponent } from './user/user.component';
import { VehicleComponent } from './vehicle/vehicle.component';
import { GatepassExitComponent } from './gatepass-exit/gatepass-exit.component';
import { TrainingVideosComponent } from './training-videos/training-videos.component';
// import { QRCodeModule } from 'angular2-qrcode';
import { CalendarModule } from 'primeng/primeng';
import { NgxBarcodeModule } from 'ngx-barcode';
import { VerifyGatepassComponent } from './verify-gatepass/verify-gatepass.component';
import { UserAppointmentsComponent } from './user-appointments/user-appointments.component';
import { SpinnerModule } from 'angular2-spinner/dist';
import { GatepassDashboardComponent } from './gatepass-dashboard/gatepass-dashboard.component';
import { SharedModule } from '../common/shareds.module';
import { ApiService } from '../common/services/api.service';

// import { SlimScroll } from 'angular-io-slimscroll';

@NgModule({
  declarations: [
    TrainingDashboardComponent,
    SearchComponent,
    AppointmentsComponent,
    ExamHistoryComponent,
    ActivitiesComponent,
    InoutHistoryComponent,
    GenerateExamComponent,
    GenerateGatepassComponent,
    GenerateGatepassVehicleComponent,
    UserComponent,
    VehicleComponent,
    GatepassExitComponent,
    TrainingVideosComponent,
    VerifyGatepassComponent,
    UserAppointmentsComponent,
    GatepassDashboardComponent
  ],
  imports: [
    CommonModule,
    routing,
    FormsModule,
    ReactiveFormsModule,
    SpinnerModule,
    SharedModule,
    // QRCodeModule,
    NgxBarcodeModule,
    CalendarModule
  ],
  providers: [TrainigService, ApiService, AuthGuard]
})
export class TrainingModule {}
