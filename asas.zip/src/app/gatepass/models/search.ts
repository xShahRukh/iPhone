export interface Search {
    aadhar: String;
    role: String;
    vechicleType: String;
    name: String;
    email: String;
    mobile: String;
    vehicleno: String;
  }
