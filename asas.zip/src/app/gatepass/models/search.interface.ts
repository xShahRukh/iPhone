export interface Search {
    aadhar: string;
    role: string;
    vehicleType: string;
    name: string;
    email: string;
  }
