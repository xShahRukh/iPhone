export class User {
    aadhar: number;
    role: string;
    systemNo?: number;
  }
