import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InoutHistoryComponent } from './inout-history.component';

describe('InoutHistoryComponent', () => {
  let component: InoutHistoryComponent;
  let fixture: ComponentFixture<InoutHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InoutHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InoutHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
