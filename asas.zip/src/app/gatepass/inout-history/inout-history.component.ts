import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { TrainigService } from '../services/training.service';
import swal from 'sweetalert2';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-inout-history',
  templateUrl: './inout-history.component.html',
  styleUrls: ['./inout-history.component.css']
})
export class InoutHistoryComponent implements OnInit {
  aadharnum = '';
  aadharSearch = true;
  inOutHistory = false;
  inOutNoData = false;
  inOutData = [];
  inOutDetails = [];
  entry_tm;
  exit_tm;
  spin = false;
  errorMessage = false;
  constructor(
    private _trainingService: TrainigService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    public router: Router
  ) {}

  ngOnInit() {}
  changeColor1() {
    this.errorMessage = false;
  }

  Submit() {
    // if(this.aadhar.trim() === '') {
    //  alert('Please fill valid details')
    //   return
    // }
    // this.spin = true
    const body = {};
    body['id'] = this.aadharnum.trim();
    if (this.aadharnum === '' || this.aadharnum.trim() === '') {
      this.errorMessage = true;
      // this.spin = false
      return;
    }
    this._trainingService.getInOutHistory(body).subscribe(data => {
      if (!data.success) {
        // this.spin = false
        this.inOutData = data.data;
        this.inOutNoData = true;
        this.aadharSearch = false;
      } else {
        // this.spin = false
        this.aadharSearch = false;
        this.inOutHistory = true;
        this.inOutData = data.data;
        // console.log(this.inOutData)
        this.inOutDetails = [];
        this.inOutData.forEach(item => {
          this.entry_tm = moment(item.entry_tm).format('YYYY-MM-DD');
          this.exit_tm = moment(item.exit_tm).format('YYYY-MM-DD');
          if (moment(this.exit_tm).isAfter(this.entry_tm)) {
            // console.log('after')
            this.inOutDetails.push({
              name: item.name,
              date: moment(item.entry_tm).format('YYYY-MM-DD'),
              entry_time: moment(item.entry_tm).format('YYYY_MM_DD HH:mm'),
              exit_time: moment(item.exit_tm).format('YYYY_MM_DD HH:mm')
            });
          } else {
            // console.log('before')
            this.inOutDetails.push({
              name: item.name,
              date: moment(item.entry_tm).format('YYYY-MM-DD'),
              entry_time: moment(item.entry_tm).format('HH:mm'),
              exit_time: moment(item.exit_tm).format('HH:mm')
            });
          }
        });
      }
    });
  }
  Reset() {
    this.inOutDetails = [];
    this.aadharnum = '';
    this.aadharSearch = true;
    this.inOutHistory = false;
    this.inOutNoData = false;
    this.errorMessage = false;
  }
  // omit_special_number(event) {
  //   let k;
  //   k = event.charCode;  //         k = event.keyCode;  (Both can be used)
  //   return ((k >= 48 && k <= 57));
  // }
}
// const vf = [];
// for (let i = 0; i < this._ehsService.users.length; i++) {
//   vf[i] = {
//     type: this._ehsService.type,
//     aadhar: this._ehsService.users[i].aadhar
//   }
// }
