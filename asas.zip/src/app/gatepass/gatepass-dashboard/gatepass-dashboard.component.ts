import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-gatepass-dashboard',
  templateUrl: './gatepass-dashboard.component.html',
  styleUrls: ['./gatepass-dashboard.component.css']
})
export class GatepassDashboardComponent implements OnInit {

  constructor(public router: Router, private _route: ActivatedRoute) { }

  ngOnInit() {
  }
  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
}
