import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
// import { QRCodeComponent } from 'angular2-qrcode';
import { AppSettings } from '../../app.settings';

import { TrainigService } from '../services/training.service';
import { TrainingSettings } from '../training.settings';


@Component({
  selector: 'app-generate-gatepass-vehicle',
  templateUrl: './generate-gatepass-vehicle.component.html',
  styleUrls: ['./generate-gatepass-vehicle.component.css']
})
export class GenerateGatepassVehicleComponent implements OnInit {
  errorMessage = false;
  checklist = TrainingSettings.vehicleGatepassChecklist;
  totalChecks = 0;

  constructor(
    public trainingService: TrainigService,
    private sanitizer: DomSanitizer,
    private element: ElementRef
  ) {}

  // gatepass input fields
  whom = '';
  currentState = 3;
  purpose = '';
  gatepassCode;
  showQrCode = false;
  showGatepassForm = true;
  takePicture = true;
  showGatePassPage = true;
  generateId = true;
  showgatePass = false;
  hideGatePass = false;
  spin = false;
  noData = false;
  msg;
  ngOnInit() {
    this.trainingService.showGenerategatepass = true;
    this.currentState = 3;
    this.showGatepassForm = true;
    // console.log(this.eshService.currentState, 'gatepass vehicle current state')
    this.showGatePassPage = true;
    // this.showCam();
  }

  checkItem(event) {
    if (event.target.checked) {
      ++this.totalChecks;
    } else {
      --this.totalChecks;
    }
    // console.log(this.totalChecks, this.checklist.length)
  }
  changeColor() {
    this.errorMessage = false;
  }

  // insert purpose and whom
  generateGatepass() {
    this.whom = this.whom.trim();
    this.purpose = this.purpose.trim();
    if (this.whom === '' && this.purpose === '') {
      this.errorMessage = true;
      return;
    }
    this.errorMessage = true;
    this.generateId = false;
    this.spin = true;
    // console.log(this.currentState, 'currentState')
    const body = {};
    // body['aadhar'] = this.trainingService.users[0].aadhar
    body['vehicleNo'] = this.trainingService.vehicleNo;
    body['vehicleType'] = this.trainingService.vehicleType;
    body['type'] = this.trainingService.type;
    (body['whom'] = this.whom),
      (body['driver'] = this.trainingService.users[0].aadhar),
      (body['cleaner'] = this.trainingService.users[1].aadhar),
      (body['purpose'] = this.purpose);
    // console.log('body is ', body)

    this.trainingService.insertGatePassVehicle(body).subscribe(data => {
      if (data.success) {
        if (data.data.gatePassId !== undefined) {
          this.gatepassCode = data.data;
          this.showgatePass = true;
          this.generateId = false;
          this.showGatepassForm = false;
          this.showQrCode = true;
        } else {
          this.hideGatePass = true;
          this.showgatePass = false;
          this.generateId = false;
          this.showGatepassForm = false;

          this.gatepassCode = data.data.message;
        }
      } else {
        this.msg = data.message;
        this.noData = true;
        this.spin = false;
        this.showgatePass = false;
        return;
      }
      this.spin = false;
    });
  }

  // print
  print(printSectionId: string) {
    window.print();
  }
  reset() {
    this.trainingService.reset();
  }
}
