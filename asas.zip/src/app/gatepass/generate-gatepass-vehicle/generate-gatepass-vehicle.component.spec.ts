import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateGatepassVehicleComponent } from './generate-gatepass-vehicle.component';

describe('GenerateGatepassVehicleComponent', () => {
  let component: GenerateGatepassVehicleComponent;
  let fixture: ComponentFixture<GenerateGatepassVehicleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateGatepassVehicleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateGatepassVehicleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
