import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import * as moment from 'moment';
import * as _ from 'underscore';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { TrainigService } from '../services/training.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
// import { AppointmentService } from '../appointments/appointments.service';
@Component({
  selector: 'app-user-appointments',
  templateUrl: './user-appointments.component.html',
  styleUrls: ['./user-appointments.component.css']
})
export class UserAppointmentsComponent implements OnInit {
  emp_code;
  name;
  company;
  purpose;
  dt;
  msg;
  maxDate;
  appointmentData = [];
  showAppointment: boolean;
  addAppointment: boolean;
  appointment: boolean;
  noAppointment: boolean;
  spinner = false;
  currentDate;
  constructor(
    // private _trainingService: AppointmentService,
    public toastr: ToastrManager,
    vcr: ViewContainerRef,
    private _trainingService: TrainigService,
    private _fb: FormBuilder,
    public router: Router,
    private _route: ActivatedRoute
  ) {}

  ngOnInit() {
    this.currentDate = moment().format('YYYY-MM-DD');
    this.spinner = false;
    this.maxDate = new Date();
    this.emp_code = sessionStorage.getItem('userid');
    this.getAppointmentData();
  }

  getAppointmentData() {
    // this.appointment = true
    // this.showAppointment = true
    const body = {};
    body['emp_code'] = this.emp_code;
    this._trainingService.getAppointments(body).subscribe(data => {
      this.spinner = true;
      if (data.success) {
        this.appointmentData = [];
        data.data.forEach(item => {
          this.appointmentData.push({
            id: item.id,
            company: item.company,
            emp_code: item.emp_code,
            purpose: item.purpose,
            visitor_name: item.visitor_name,
            dt: moment(item.dt).format('YYYY-MM-DD')
          });
        });
        // this.appointmentData = data.data;
        console.log('appointments', this.appointmentData);
        this.showAppointment = true;

        // const previousDates = []
        // data.data.forEach(item => {
        //   previousDates.push({
        //     date:moment(item.dt).format('YYYY-MM-DD')
        //   })

        // });
        // console.log('dates',previousDates)
      } else {
        this.appointment = false;
        this.showAppointment = false;
        this.noAppointment = true;
        this.msg = 'No Appointments';
      }
      // console.log(this.appointmentData.length, 'length')
      // console.log(this.appointmentData.length, 'length')
      // if (!data.success) {

      // } else {

      // }
    });
  }

  delete(id, name) {
    this.spinner = false;
    console.log(id);
    const body = {};
    body['id'] = id;
    if (confirm('Are you sure you want to delete this Appointment?') === true) {
      this._trainingService.deleteAppointment(body).subscribe(data => {
        if (data.success) {
          this.spinner = true;
          this.toastr.successToastr('Your appointment is deleted successfully');
          this.getAppointmentData();
        } else {
          this.spinner = true;
          this.toastr.errorToastr(data.message);
        }
      });
    } else {
      this.spinner = true;
    }
    // console.log(id)

    // this._trainingService.deleteAppointment(body).subscribe(data => {
    //   console.log(data.data)
    //   this.getAppointmentData()
    // })
  }

  reset() {
    this.name = '';
    this.company = '';
    this.purpose = '';
    this.dt = '';
  }

  add() {
    this.noAppointment = false;
    this.appointment = true;
    this.showAppointment = false;
    this.addAppointment = true;
  }

  back() {
    this.name = '';
    this.company = '';
    this.purpose = '';
    this.dt = '';

    // console.log(this.appointmentData)
    if (this.appointmentData === undefined || this.appointmentData.length === 0) {
      this.noAppointment = true;
      this.appointment = false;
      this.showAppointment = false;
      this.addAppointment = false;
    } else {
      this.addAppointment = false;
      this.showAppointment = true;
      this.noAppointment = false;
    }
  }

  submit() {
    this.spinner = false;
    if (
      this.emp_code.trim() === '' ||
      this.name.trim() === '' ||
      this.company.trim() === '' ||
      this.purpose.trim() === ''
    ) {
      this.spinner = true;
      this.toastr.errorToastr('Please fill the fields with valid data');
      return;
    }
    this.emp_code = this.emp_code.trim();
    this.name = this.name.trim();
    this.company = this.company.trim();
    this.purpose = this.purpose.trim();
    const body = {};
    body['emp_code'] = this.emp_code;
    body['name'] = this.name;
    body['company'] = this.company;
    body['purpose'] = this.purpose;
    body['dt'] = moment(this.dt).format('YYYY-MM-DD');
    this._trainingService.Appoinment(body).subscribe(data => {
      if (data.success) {
        this.toastr.successToastr('Appointment added successfully');
      }
      this.spinner = true;
      this.reset();
      this.showAppointment = true;
      this.addAppointment = false;
      this.getAppointmentData();
    });
  }
  fromDate(value) {
    console.log(value);
  }

  omit_special_char(event) {
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return (k >= 65 && k <= 90) || (k >= 97 && k <= 122) || k === 32;
  }
  omit_special_letters(event) {
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return (k >= 65 && k <= 90) || (k >= 97 && k <= 122) || (k >= 48 && k <= 57) || k === 32;
  }

  Return() {
    this.router.navigate(['/dashboard']);
  }
}
