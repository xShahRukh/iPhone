import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild,
  Pipe,
  PipeTransform
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router, ActivatedRoute } from '@angular/router';
import { FileUploader, FileItem } from 'ng2-file-upload';
import {
  DomSanitizer,
  BrowserModule,
  SafeResourceUrl
} from '@angular/platform-browser';
import * as _ from 'underscore';
import { environment } from 'src/environments/environment';
import { LoactionService } from '../locations/locations.service';
import { IncidentsAddService } from '../intial_incidents/incidents-add/incidents-add.service';
import { ApiService } from '../common/services/api.service';
import { IncidentsListManagerService } from '../intial_incidents/incidents-list-manager/incidents-list-service';
import { IncidentsViewService } from '../intial_incidents/incidents-view/incidents-view.service';
import { IncidentSettings } from '../intial_incidents/incidents.settings';
import { AppSettings } from '../app.settings';
import { IncidentViewService } from './incidentviewservice';
@Component({
  selector: 'app-incidentview',
  templateUrl: './incidentview.component.html',
  styleUrls: ['./incidentview.component.css']
})
export class IncidentviewComponent implements OnInit {
  risk_full_det: any = [];
  risk_det: any = [];
  inv_severity: any;
  value = '';
  dropdownSettings: {};
  incidentslist: any;
  investigatorslist: any = [];
  img_url: string;
  text_to_show: any;
  parts_list: any = [];
  id: any = [];
  base64_data: any = '';
  type: any = '';
  hospitaldetails = [];
  damages_parts_emp: any = [];
  actions_list: any = [];
  actions: any = [];
  damages: any = [];
  injuries: any = [];
  investigators: any = [];
  witness: any = [];
  causes: any = [];
  costs: any = [];
  loading = true;
  main_incident: any = [];
  DispIncident = [];
  others: any = [];
  first_aids: any = [];
  popimg;
  image_dataDisp = [];
  trainings: any = [];
  updatedetails = {};

  InvestigationForm: FormGroup;
  closeForm: FormGroup;
  recallForm: FormGroup;
  incdetails: any = new Object();
  incident_id: any;
  locations: any;
  LocationsListStatic = [];
  coloursList = [];
  returnedDetails: any = [];
  constructor(
    public fb: FormBuilder,
    private router: Router,
    private _route: ActivatedRoute,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer,
    public _incidents_list_mr_service: IncidentsListManagerService,
    public _incidents_view_service: IncidentViewService,
    public locationservice: LoactionService
  ) {
    this.img_url = environment.api_image_url;
  }
  incident_data: any = [];
  actioner_data: any = [];
  selectedlist: any = [];

  trainingDropDownSettings = {
    text: 'Select Training',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    classes: 'myclass custom-class',
    singleSelection: true
  };
  riskDropDownSettings = {
    text: 'Select risk',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    classes: 'myclass custom-class',
    singleSelection: true
  };

  async ngOnInit() {
    // this._apiService.incidentObj.popimg;
    this.popimg = this._apiService.incidentObj;
    this.getlistoflocations();
    this.main_incident = this._apiService.incidentObj;
    this.getIncidents_by_id();

    this.InvestigationForm = this.fb.group({
      emp_no: new FormControl([], [Validators.required]),
      incident_id: new FormControl('', [Validators.required]),
      type: new FormControl('', [Validators.required])
    });
    this.closeForm = this.fb.group({
      incident_id: new FormControl('', [Validators.required]),
      management_comments: new FormControl('', [Validators.required]),
      incident_risk: new FormControl(0, [Validators.required]),
      risk_id: new FormControl(0, [Validators.required]),
      risk_threat_id: new FormControl(0, [Validators.required]),
      plan_imporve: new FormControl('', [Validators.required]),
      training_ids: new FormControl('', [Validators.required])
    });

    this.recallForm = this.fb.group({
      incident_id: new FormControl('', [Validators.required]),
      reason_comments: new FormControl('', [Validators.required]),
      incident_number: new FormControl('', [Validators.required])
    });
  }

  back_page() {
    this.router.navigate(['/incident_report_dashboard']);
  }

  getinvestigatorslist(value) {
    this._incidents_list_mr_service
      .getinvestigatorslist({ role_name: value })
      .subscribe(docs => {
        this.loading = false;
        if (docs.error) {
          this.incident_data = docs.data;
        } else {
          this.incident_data = [];
        }
      });
  }

  async getIncidents_by_id() {
    this.loading = true;
    let i = 0;
    const body = {
      incident_id: JSON.stringify(this.main_incident.incident_id)
    };
    this.coloursList = [];
    if (typeof this.main_incident.incident_id === 'number') {
      const a = await [];
      await a.push(this.main_incident.incident_id);
      await a.forEach(element => {
        this.coloursList.push({
          incident_id: element,
          // dispColour: this.getRandomColor()
          dispColour: IncidentSettings.BasicColors[i++],
          ids: i
        });
      });
    } else {
      await this.main_incident.incident_id.split(',').forEach(element => {
        this.coloursList.push({
          incident_id: element,
          // dispColour: this.getRandomColor()
          dispColour: IncidentSettings.BasicColors[i++]
            ? IncidentSettings.BasicColors[i]
            : this.getRandomColor(),
          ids: i
        });
      });
    }
    this.returnedDetails = [];
    await this._incidents_view_service
      .getIncidents_by_id(body)
      .subscribe(async docs => {
        this.loading = false;
        this.returnedDetails = docs.data;
        if (this.returnedDetails['incident'].length > 0) {
          this.updatedetails = this.returnedDetails.incident[0];
        }
        console.log(this.updatedetails);
        this.DispIncident = docs.data.incident;
        this.main_incident.amount = 0;
        docs.data.costs.forEach(element => {
          this.main_incident.amount += element.amount;
        });
        await this.DispIncident.forEach(element => {
          const val = _.filter(this.coloursList, function(o) {
            return (
              parseInt(o.incident_id, 0) === parseInt(element.incident_id, 0)
            );
          });
          element['dispColour'] = this.getIncColour(element);
          element['ids'] = val[0]['ids'];
        });

        await docs.data.damages.forEach(async element => {
          const itemName = await this.getlocation_name(element.location);
          let itemNameList = (await itemName) ? itemName.toString() : '';
          itemNameList = await itemNameList.replace(/,/g, ' ⇨ ');
          // element['locHistory'] = await itemNameList;
          const a = [];
          a.push({
            id: element,
            locHistory: itemNameList
          });
          element = a;
        });
        this.inv_severity = docs.data.incident.inv_severity;
        await this.getRaisedColour(docs.data.causes, 'cause_code');
        this.causes = await docs.data.causes;
        await this.getRaisedColour(docs.data.damages, 'damage');
        this.damages = await docs.data.damages;
        await this.getRaisedColour(docs.data.injured_emps, 'name');
        this.injuries = docs.data.injured_emps;
        await this.getRaisedColour(docs.data.investigators, 'name');
        this.investigators = docs.data.investigators;
        await this.getRaisedColour(docs.data.witness, 'name');
        this.witness = docs.data.witness;
        await this.getRaisedColour(docs.data.actions, 'name');
        this.actions = docs.data.actions;
        await this.getRaisedColour(docs.data.costs, 'incident_id');
        this.costs = docs.data.costs;

        this.actions_list = docs.data.actions_list;
        this.damages_parts_emp = docs.data.injuries;
        this.first_aids = docs.data.first_aid;
        this.others = docs.data.others;
        const IDS = [];
        if (typeof this.main_incident.incident_id === 'number') {
          IDS.push(this.main_incident.incident_id.toString());
        } else {
          this.main_incident.incident_id.split(',').forEach(element => {
            const a = [];
            IDS.push(element);
            const itemName = this.getlocation_name(element.location);
            let itemNameList = itemName ? itemName.toString() : '';
            itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
            a.push({
              id: element,
              locHistory: itemNameList
            });
            element = a;
          });
        }
        this.image_dataDisp = [];
        IDS.forEach(element => {
          this._incidents_view_service.getImagePath(element).subscribe(data => {
            const check = data['_body'].type.split('/');
            if (check[0] === 'image') {
              this.image_dataDisp.push(data.url);
            }
          });
        });
      });
  }

  getLocationName(value) {
    const lc1 = _.filter(this.locations, function(o) {
      return o.loc_id.toString() === value.toString();
    });
    if (lc1.length) {
      return lc1[0].location_name;
    } else {
      return '-';
    }
  }

  get_image(value) {
    if (value.side !== 'right' && value.side !== 'left') {
      const part_one = _.filter(AppSettings.Injures_one, function(o) {
        return o.Parts === value.part;
      });
      return part_one[0].img;
    } else {
      const part_one = _.filter(AppSettings.Injures_two, function(o) {
        return o.Parts === value.part;
      });
      if (part_one[0]) {
        if (value.side === 'right') {
          return part_one[0].left_img;
        } else {
          return part_one[0].right_img;
        }
      } else {
        return '';
      }
    }
  }

  open_image_popup(value) {
    this.loading = true;
    this.id = value;
    const part_one = _.filter(this.damages_parts_emp, function(o) {
      return o.emp_id === value.emp_id;
    });

    const part_two = _.filter(this.first_aids, function(d) {
      return (
        d.person_id === value.emp_id && d.incident_id === value.incident_id
      );
    });
    this.getRaisedColourParts(part_one);
    if (part_two[0]) {
      this._incidents_view_service
        .gethospitalreport({ ifh_id: part_two[0].ifh_id })
        .subscribe(docs => {
          if (!docs.error) {
            this.loading = false;
            this.hospitaldetails = docs.data;
            for (let z = 0; z < docs.data.length; z++) {
              if (docs.data[z].img) {
                let a = [];
                a = docs.data[z].img.split('@@');
                const p = [];
                for (let y = 0; y < a.length; y++) {
                  let b = [];
                  b = a[y].split('$$');
                  const c = [];
                  if (y === 0) {
                    c['type'] = b[0];
                  } else {
                    c['type'] = b[0].substr(1);
                  }
                  c['text'] = b[1];
                  p.push(c);
                }
                this.hospitaldetails[z]['image_data'] = p;
              }
            }
          } else {
            this.hospitaldetails = [];
          }
          if (this.hospitaldetails[0].image_data != null) {
            this.hospitaldetails[0].image_data = this.hospitaldetails[0].image_data.filter(
              item => item.type !== ''
            );
          }
        });
    } else {
      this.hospitaldetails = [];
      this.loading = false;
    }
  }

  opne_proof_det(value, no) {
    this.text_to_show = no;
    this.type = value.type;
    this.base64_data = value.text;
  }

  imgURL(type, id) {
    return 'data:' + type + ';base64,' + id;
  }

  photoURL(id) {
    return 'data:application/pdf;base64,' + id;
  }

  view_img() {
    this.type = this.main_incident.image_type;
    this.base64_data = this.main_incident.image_data;
  }

  add_investigation(value) {
    if (this.main_incident.status === 1) {
      this.dropdownSettings = {
        text: 'Select Investigater Name',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: true,
        classes: 'myclass custom-class',
        singleSelection: true
      };
      const c = 'investigator';
      this.getinvestigatorslist(c);
      if (typeof this.main_incident.incident_id === 'number') {
        this.InvestigationForm.patchValue({
          incident_id: this.main_incident.incident_id.toString(),
          type: 'investigation'
        });
      } else {
        this.InvestigationForm.patchValue({
          incident_id: this.main_incident.incident_id,
          type: 'investigation'
        });
      }
    } else if (this.main_incident.status === 3) {
      this.dropdownSettings = {
        text: 'Select Actioner Name',
        selectAllText: 'Select All',
        unSelectAllText: 'UnSelect All',
        enableSearchFilter: true,
        classes: 'myclass custom-class',
        singleSelection: true
      };
      const d = 'Actioner';
      this.getinvestigatorslist(d);

      if (typeof this.main_incident.incident_id === 'number') {
        this.InvestigationForm.patchValue({
          incident_id: this.main_incident.incident_id.toString(),
          type: 'action'
        });
      } else {
        this.InvestigationForm.patchValue({
          incident_id: this.main_incident.incident_id,
          type: 'action'
        });
      }
    }
  }

  addactioner() {
    const data_in_no = [];
    for (let a = 0; a < this.selectedlist.length; a++) {
      data_in_no.push(this.selectedlist[a].id);
    }
    const body_submit = {
      incident_id: this.InvestigationForm.value.incident_id,
      investigators: data_in_no.toString(),
      type: this.InvestigationForm.value.type
    };

    this._incidents_list_mr_service
      .addinvestigators(body_submit)
      .subscribe(docs => {
        if (!docs.error) {
          this.toastr.successToastr('', 'Actioner assigned successfully');
          this.InvestigationForm.reset();
          this.getIncidents_by_id();
          this.back_page();
        } else {
          this.toastr.errorToastr(
            'Error..!',
            'There was a issue in adding Actioner'
          );
        }
      });
  }

  open_close_pop(value) {
    this.closeForm.reset();

    if (typeof this.main_incident.incident_id === 'number') {
      this.closeForm.patchValue({
        incident_id: value.incident_id.toString()
      });
    } else {
      this.closeForm.patchValue({
        incident_id: value.incident_id
      });
    }
    this._incidents_list_mr_service.risk_details().subscribe(docs => {
      this.risk_det = [];
      if (docs.success) {
        this.risk_det = docs.data;
        this.trainings = docs.data1;
      }
    });
  }

  incident_items(item) {
    this.incdetails = item;
    this.recallForm.reset();
    this.recallForm.patchValue({
      incident_id: this.main_incident.incident_id.toString(),
      incident_number: this.main_incident.incident_number
    });
  }

  recall_action() {
    const body = {};
    // var even = _.find(this.incdetails.investigators, function (num) { return num.emp_id == sessionStorage.getItem('userid'); });
    body['incident_id'] = this.main_incident.incident_id.toString();
    body['incident_number'] = this.main_incident.incident_number;
    body['details'] = this.recallForm.value.reason_comments;
    if (this.recallForm.valid) {
      this._incidents_list_mr_service
        .add_recall(this.recallForm.value)
        .subscribe(docs => {
          if (!docs.error) {
            this.toastr.successToastr('', 'Reason Submitted successfully');
            this.recallForm.reset();
            this.getIncidents_by_id();
            this.back_page();
          } else {
            this.toastr.errorToastr('', docs.message);
          }
        });
    } else {
      this.toastr.warningToastr('', 'Please enter Reason');
    }
  }

  riskListDet() {
    this.closeForm.patchValue({
      risk_id: []
    });
    const id = this.closeForm.value.risk_threat_id[0].id;
    this._incidents_list_mr_service.riskfull_details().subscribe(docs => {
      this.risk_full_det = [];
      if (docs.success) {
        this.risk_full_det = _.filter(docs.data, function(o) {
          return o.threat_id === id;
        });
      }
    });
  }

  rest_det() {
    this.closeForm.patchValue({
      risk_id: []
    });
  }

  selectionfirstaid1($event) {
    this._incidents_view_service
      .setchangestatus({
        incident_id: JSON.stringify(this.main_incident.incident_id),
        status: $event.target.value
      })
      .subscribe(docs => {
        if (!docs.error) {
          this.toastr.successToastr('', 'Request saved successfully');
        } else {
          this.toastr.errorToastr('', 'Error');
        }
      });
  }

  addinvestigation() {
    const data_in_no = [];
    console.log(this.selectedlist.length);
    if (this.selectedlist.length === 0) {
      return this.toastr.errorToastr(
        'There was a issue in adding investigator, so please add at least 1 investigator',
        'Error..!'
      );
    }

    for (let a = 0; a < this.selectedlist.length; a++) {
      data_in_no.push(this.selectedlist[a].id);
    }
    const body_submit = {
      incident_id: this.InvestigationForm.value.incident_id,
      investigators: data_in_no.toString(),
      type: this.InvestigationForm.value.type
    };
    this._incidents_list_mr_service
      .addinvestigators(body_submit)
      .subscribe(docs => {
        if (!docs.error) {
          this.toastr.successToastr('', 'Investigator Assigned successfully');
          this.InvestigationForm.reset();
          this.getIncidents_by_id();
          // this.back_page();
        } else {
          this.toastr.errorToastr(
            docs.message
            // 'Error..!',
            // 'There was a issue in adding investigator'
          );
        }
      });
  }

  getlocation_name(value) {
    let text = _.filter(this.LocationsListStatic, function(o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function(o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  getlistoflocations() {
    this.locations = [];
    this.locationservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function(o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['lastAdd'] = false;
          }
        });
        this.locations = _.filter(response, function(o) {
          return o.lastAdd === false;
        });

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 9)];
    }
    return '1px solid ' + color;
  }

  async getIncColour(value) {
    const val = await _.filter(this.coloursList, function(o) {
      return parseInt(o.incident_id, 0) === parseInt(value.incident_id, 0);
    });
    return await val[0]['dispColour'];
  }

  getUniqDet(value, codeCheck) {
    value = _.uniq(value, `${codeCheck}`);
    return value ? value : [];
  }

  async getRaisedColour(value, type) {
    value.forEach(async element => {
      const filterDet = await _.filter(value, function(o) {
        return o[`${type}`] === element[`${type}`];
      });
      element['raisedBy'] = [];
      await filterDet.forEach(async response => {
        const a1 = await _.filter(this.coloursList, function(o) {
          return (
            parseInt(o.incident_id, 0) === parseInt(response.incident_id, 0)
          );
        });
        const Iname = await _.filter(this.DispIncident, function(o) {
          return (
            parseInt(o.incident_id, 0) === parseInt(response.incident_id, 0)
          );
        });
        // element.raisedBy.push(a1[0]['dispColour']);
        element.raisedBy.push({
          clr: a1[0]['dispColour'],
          ids: a1[0]['ids'],
          name: Iname[0].created_by_name
        });
      });
      await _.uniq(element.raisedBy);
    });
    return await value;
  }

  async getRaisedColourParts(value) {
    await value.forEach(element => {
      element.raisedBy = [];
      element.getUniqId = '';
      const a1 = _.filter(value, function(o) {
        return o.part === element.part && o.side === element.side;
      });
      a1.forEach(response => {
        const a2 = _.filter(this.coloursList, function(o) {
          return (
            parseInt(o.incident_id, 0) === parseInt(response.incident_id, 0)
          );
        });
        element.getUniqId = response.part + response.side;
        // element.raisedBy.push(a2[0]['dispColour']);
        const Iname = _.filter(this.DispIncident, function(o) {
          return (
            parseInt(o.incident_id, 0) === parseInt(response.incident_id, 0)
          );
        });
        element.raisedBy.push({
          clr: a2[0]['dispColour'],
          ids: a2[0]['ids'],
          name: Iname[0].created_by_name
        });
      });
    });
    this.parts_list = await _.uniq(value, 'getUniqId');
  }

  onItemSelect() {}
  OnItemDeSelect() {}
  close_action() {
    if (this.closeForm.controls.management_comments.valid) {
      let ids = [];
      if (this.closeForm.value.training_ids.length > 0) {
        ids = this.closeForm.value.training_ids[0].id;
      }
      if (this.closeForm.value.incident_risk === 1) {
        const body = {
          incident_id: this.closeForm.value.incident_id,
          plan_imporve: this.closeForm.value.plan_imporve,
          incident_risk: this.closeForm.value.incident_risk,
          management_comments: this.closeForm.value.management_comments,
          risk_id: this.closeForm.value.risk_id[
            this.closeForm.value.risk_id.length - 1
          ].id.toString(),
          training_id: ids
        };
        this._incidents_list_mr_service.close_action(body).subscribe(docs => {
          if (!docs.error) {
            this.toastr.successToastr('', 'Incident Closed successfully');
            this.closeForm.reset();
            // this.getIncidents_list_mr(this.status);
          } else {
            this.toastr.errorToastr('', docs.message);
          }
        });
      } else {
        const body = {
          incident_id: this.closeForm.value.incident_id,
          incident_risk: this.closeForm.value.incident_risk,
          management_comments: this.closeForm.value.management_comments,
          plan_imporve: this.closeForm.value.plan_imporve,
          risk_id: 'null',
          training_id: ids
        };
        this._incidents_list_mr_service.close_action(body).subscribe(docs => {
          if (!docs.error) {
            this.toastr.successToastr('', 'Incident Closed successfully');
            this.closeForm.reset();
            // this.getIncidents_list_mr(this.status);
          } else {
            this.toastr.errorToastr('', docs.message);
          }
        });
      }
    } else {
      this.toastr.warningToastr('', 'Please fill all requirements');
    }
  }

  getname(vsalue) {
    if (vsalue === 'near miss') {
      return 'Near Miss';
    } else {
      if (vsalue === 'Injury to People and damages to Property') {
        return 'Injuries & Damages';
      } else {
        if (vsalue === 'Injury to People') {
          return 'Injuries';
        } else {
          return 'Damages';
        }
      }
    }
  }
}
