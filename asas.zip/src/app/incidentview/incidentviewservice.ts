import { Injectable } from '@angular/core';
import {
  Headers,
  Http,
  RequestOptions,
  Response,
  ResponseContentType
} from '@angular/http';
import { ApiService } from '../common/services/api.service';
import { IncidentSettings } from '../intial_incidents/incidents.settings';

@Injectable()
export class IncidentViewService {
  constructor(private _apiService: ApiService, private http: Http) {}

  // get incidents by id
  getIncidents_by_id(body) {
    return this._apiService.callApi(
      IncidentSettings.API.GET_INCIDENTS_BY_ID,
      'post',
      body
    );
  }
  gethospitalreport(body) {
    return this._apiService.callApi(
      IncidentSettings.API.GET_REPORTS_OF_HOSPITAL,
      'post',
      body
    );
  }
  setchangestatus(body) {
    return this._apiService.callApi(
      IncidentSettings.API.SET_CHANGE_STATUS,
      'post',
      body
    );
  }
  getImagePath(body) {
    return this.http.get(
      IncidentSettings.API.GETIMAGEPATH + '/' + `${body}`,
      new RequestOptions({ responseType: ResponseContentType.Blob })
    );
  }
}
