import { Injectable, Output, EventEmitter } from '@angular/core';

import { AppSettings } from '../app.settings';
import { ApiService } from '../common/services/api.service';

@Injectable()
export class InspectorService {
  constructor(private _apiService: ApiService) { }

  // get inspection Type and its Details
  getInspectionTypeDetails(value, type) {
    return this._apiService.callApi(
      AppSettings.API.GET_INSPECTION_TYPE_DET +
      '/' +
      `${value.fromDate}` +
      '/' +
      `${value.toDate}` + '/' + `${type}`,
      'GET',
      {}
    );
  }

  // Get user list
  getUsersList() {
    const body = {};
    return this._apiService.callApi(
      AppSettings.API.GET_EMPLOYEES_LIST,
      'get',
      body
    );
  }

  // Get with in dates
  getWithInDates(value) {
    const body = {};
    return this._apiService.callApi(
      AppSettings.API.GETWITHINDATES +
      `${value.fromDate}` +
      '/' +
      `${value.endDate}` +
      '/' +
      value.itid,
      'get',
      body
    );
  }

  // Get location details
  getListOfLocat() {
    const body = {};
    return this._apiService.callApi(AppSettings.API.GET_LOCATIONS, 'GET', body);
  }

  // add Inspector
  addInspector(value) {
    return this._apiService.callApi(
      AppSettings.API.ADD_INSPECTOR,
      'post',
      value
    );
  }

  // add Remarks
  addRemarks(value) {
    return this._apiService.callApi(AppSettings.API.ADD_REMARKS, 'post', value);
  }

  // get inspection history
  getInspectionHistory(value) {
    return this._apiService.callApi(AppSettings.API.GET_INSPECTION_HISTORY + value, 'get', value);
  }
}
