import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl,
  FormArray
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Observable } from 'rxjs/Observable';
import * as _ from 'underscore';
import { GenericValidator } from '../common/generic-validator';
import { ApiService } from '../common/services/api.service';
import { InspectorService } from './InspectorService';
import { IMyDpOptions } from 'mydatepicker';
import { IMyDrpOptions } from 'mydaterangepicker';
import * as moment from 'moment';

declare var $;

@Component({
  selector: 'app-inspector',
  templateUrl: './inspector.component.html',
  styleUrls: ['./inspector.component.css']
})
export class InspectorComponent implements OnInit {
  loading: Boolean = true;
  dropdownSettings_list: any = [];
  durationList = [];
  LocationsListDisp = [];

  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  showForm = true;
  showType = false;
  inspectionTypes: any[];
  StaticInspectionTypes: any[];
  InspectionForm: FormGroup;
  RemarksForm: FormGroup;
  inspectionDate = [];
  deadline = [];
  displayType: boolean;

  myDateRangePickerOptions: IMyDrpOptions = {
    dateFormat: 'mmm dd, yyyy',
    firstDayOfWeek: 'mo',
    sunHighlight: true,
    height: '36px',
    width: '260px',
    inline: false,
    alignSelectorRight: false,
    indicateInvalidDateRange: true,
    showSelectDateText: false,
    yearSelector: true,
    monthSelector: true,
    editableDateRangeField: false,
    componentDisabled: false,
    showClearBtn: true,
    minYear: 2016,
    showClearDateRangeBtn: false,
    selectionTxtFontSize: '14px',
    showSelectorArrow: true
  };

  public ToDateOptions: IMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: false,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate()
    }
  };

  public FromOptions: IMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  public ToOptions: IMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth(),
      day: new Date().getDate()
    }
  };

  d = new Date();
  public model: any;
  public withInRange: any;
  UsersList: any[];
  fromDate = { jsdate: new Date(this.d.getFullYear(), this.d.getMonth(), 1) };
  toDate = { jsdate: new Date(this.d.getFullYear(), this.d.getMonth() + 1, 1) };
  userId;
  headerList = { today: [], past: [], future: [] };
  dispType: string;
  LocationsList: any[];
  staffDisplay: any[];
  inspectionHistory: any[];
  tableType = 'records';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _inspectorService: InspectorService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public _route: ActivatedRoute,
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      location_name: {
        required: 'Name is required'
      },
      supervisor: {
        required: 'Supervisors are required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    // const a = _.filter(JSON.parse(sessionStorage.getItem('roles')), function (o) {
    //   return o.module_name === 'Inspection' && (o.role_name === 'Inspection Manager' || o.role_name === 'inspector');
    // });

    this.tableType = 'records';
    const b = _.filter(JSON.parse(sessionStorage.getItem('roles')), function (o) {
      return o.module_name === 'Inspection' && o.role_name === 'Inspection Manager';
    });
    this.displayType = b.length ? true : false;
    this.userId = this.displayType;

    this.dateChanged(this.fromDate, 'fromDate');
    this.showForm = true;
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.dropdownSettings_list = {
      text: 'Select Supervisor',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      singleSelection: false
    };
    this.durationList.push({ id: 7, itemName: 'Weekly' });
    this.durationList.push({ id: 30, itemName: 'Monthly' });
    this.durationList.push({ id: 180, itemName: 'Semiannually' });
    this.durationList.push({ id: 360, itemName: 'Annually' });

    this.InspectionForm = this.fb.group({
      itid: new FormControl(0, [Validators.required]),
      type: new FormControl('', [Validators.required]),
      duration: new FormControl(7, [Validators.required]),
      fromDate: new FormControl('', [Validators.required]),
      toDate: new FormControl('', [Validators.required]),
      // inspectorDates: this.fb.array([this.initItemRows()])
      inspectorDates: this.fb.array([])
    });

    this.RemarksForm = this.fb.group({
      idid: 0,
      type: '',
      inspectionDate: '',
      remarks: new FormControl('', [Validators.required]),
      ncShow: false,
      ncData: this.fb.array([])
    });

    this.getInspectionTypeDetails();
    this.getUsersList();
    this.getListOfLocations();


    if (this._route.snapshot.url[0].path === 'InspectorComponentAdd') {
      this.addform();
    } else {
      this.showForm = true;
      // this.displayType = true;
      // this.tableType = 'records';
    }

  }

  getListOfLocations() {
    this.LocationsListDisp = [];
    this.LocationsList = [];
    this._inspectorService.getListOfLocat().subscribe(async data => {
      if (!data.error) {
        this.LocationsList = data.data;
        const response = data.data;
        await data.data.forEach(async element => {
          element['locDisplay'] = await this.getLocationName(element.loc_id);
          const len = _.filter(response, function (o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['lastAdd'] = false;
          }
        });
        this.LocationsListDisp = _.filter(response, function (o) {
          return o.lastAdd === false;
        });
      }
      this.loading = false;
    });
  }

  getLocationName(value) {
    let text = _.filter(this.LocationsList, function (o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pIds = text.parent_id;
        const withPIds = _.filter(this.LocationsList, function (o) {
          return o.loc_id === parseInt(pIds, 0);
        });
        loc_nam.push(withPIds[0].location_name);
        text = withPIds[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  changeFunction() {
    // this.showForm = true;
    // this.getInspectionTypeDetails();
    // this.getUsersList();
    this.InspectionForm.reset();
    this.InspectionForm.controls.inspectorDates['controls'] = [];
  }

  getDurationName(value) {
    const abc = _.filter(this.durationList, function (o) {
      return o.id === value;
    });
    return abc[0].itemName;
  }

  addNewRow(value) {
    const control = <FormArray>this.InspectionForm.controls['inspectorDates'];
    control.push(this.initItemRows(value));
  }

  initItemRows(value) {
    return this.fb.group({
      itid: new FormControl(value.itid),
      inspectionDate: new FormControl(value.inspectionDate, [
        Validators.required
      ]),
      inspector: new FormControl(value.inspector, [Validators.required])
    });
  }

  getDetails() {
    this.getInspectionTypeDetails();
  }

  dateChanged(date, type) {
    if (type === 'fromDate') {
      this.ToOptions = {
        disableUntil: {
          year: parseInt(moment(date.jsdate).format('YYYY'), 0),
          month: parseInt(moment(date.jsdate).format('MM'), 0),
          day: parseInt(moment(date.jsdate).format('DD'), 0)
        }
      };
    }
  }

  async getInspectionTypeDetails() {
    this.inspectionTypes = [];
    await this._inspectorService
      .getInspectionTypeDetails({
        fromDate: moment(this.fromDate.jsdate).format('YYYY-MM-DD'),
        toDate: moment(this.toDate.jsdate).format('YYYY-MM-DD')
      }, this.displayType)
      .subscribe(async response => {
        if (response.success) {
          this.loading = false;
          this.StaticInspectionTypes = response.data;
          this.inspectionTypes = response.data;
          if (this.displayType) {
            this.inspectionTypes.forEach(element => {
              element['lastInspection'] = element.lastInspection
                ? element.lastInspection.split('##')
                : '';
              element['nextInspection'] = element.nextInspection
                ? element.nextInspection.split('##')
                : '';
            });
          } else {
            this.headerList.today = _.filter(this.inspectionTypes, function (o) {
              return (
                moment().format('YYYY-MM-DD') ===
                moment(o.inspectionDate).format('YYYY-MM-DD')
              );
            });
            this.headerList.past = _.filter(this.inspectionTypes, function (o) {
              return (
                moment().format('YYYY-MM-DD') >
                moment(o.inspectionDate).format('YYYY-MM-DD')
              );
            });
            this.headerList.future = _.filter(this.inspectionTypes, function (
              o
            ) {
              return (
                moment().format('YYYY-MM-DD') <
                moment(o.inspectionDate).format('YYYY-MM-DD')
              );
            });
            this.viewInspectionTypeForUser('today');
          }
        }
      }, error => {
        this.loading = false;
      });
  }

  getUsersList() {
    this._inspectorService.getUsersList().subscribe(docs => {
      if (docs.error) {
        this.UsersList = docs.data;
        this.loading = false;
      } else {
        this.UsersList = [];
      }
    });
  }

  getEmpName(value) {
    const abc = _.filter(this.UsersList, function (o) {
      return o.emp_id === value;
    });
    return abc[0] ? abc[0]['emp_name'] : value;
  }

  async addform() {
    this.showForm = !this.showForm;
  }

  async patchType() {
    if (this.InspectionForm.value.itid !== '0') {
      this.showType = false;
      this.InspectionForm.controls['type'].disable();
      const itid = parseInt(this.InspectionForm.value.itid, 0);
      const abc = _.filter(this.inspectionTypes, function (o) {
        return o.itid === itid;
      });
      this.InspectionForm.patchValue({
        type: abc[0].type,
        duration: abc[0].duration
      });
      if (this.InspectionForm.controls.fromDate.valid) {
        this.onDateRangeChanged(this.InspectionForm.value.fromDate);
      } else if (
        this.InspectionForm.controls.toDate.valid &&
        this.InspectionForm.controls.fromDate.valid
      ) {
        this.fromDateChange(this.InspectionForm.value.toDate);
      }
    } else {
      this.showType = true;
      this.InspectionForm.controls['type'].enable();
      this.InspectionForm.patchValue({
        type: '',
        duration: ''
      });
    }
  }

  onDateRangeChanged($event) {
    this.InspectionForm.patchValue({
      fromDate: $event
    });
    this._inspectorService
      .getWithInDates({
        fromDate: moment($event.beginJsDate).format('YYYY-MM-DD'),
        endDate: moment($event.endJsDate).format('YYYY-MM-DD'),
        itid: this.InspectionForm.value.itid
      })
      .subscribe(response => {
        if (response.success) {
          if (response.data.length) {
            // case to change
            this.InspectionForm.controls.inspectorDates['controls'] = [];
            this.InspectionForm.patchValue({
              toDate: { jsdate: new Date(response.data[0].inspectionDate) }
            });
            response.data.forEach(element => {
              this.addNewRow({
                inspectionDate: moment(element.inspectionDate).format(
                  'YYYY-MM-DD'
                ),
                inspector: element.inspector,
                itid: element.itid
              });
              this.inspectionDate.push({
                jsdate: new Date(element.inspectionDate)
              });
            });
            // -------
          } else if (
            !response.data.length &&
            this.InspectionForm.controls.toDate.valid
          ) {
            this.fromDateChange(this.InspectionForm.controls.toDate.value);
          }
        }
      });
  }

  changeDuration() {
    if (
      this.InspectionForm.controls.toDate.valid &&
      this.InspectionForm.controls.fromDate.valid
    ) {
      this.fromDateChange(this.InspectionForm.value.toDate);
    }
  }

  fromDateChange($event) {
    this.InspectionForm.patchValue({
      toDate: $event
    });
    this.inspectionDate = [];
    this.InspectionForm.controls.inspectorDates['controls'] = [];
    let startDate = moment($event.jsdate).format('YYYY-MM-DD');
    if (!this.InspectionForm.controls.fromDate.valid) {
      return;
    }
    const endDate = moment(this.InspectionForm.value.fromDate.endJsDate).format(
      'YYYY-MM-DD'
    );
    if (!startDate || !endDate || startDate > endDate) {
      return;
    }
    while (startDate <= endDate) {
      startDate = moment(startDate).format('YYYY-MM-DD');
      this.addNewRow({ inspectionDate: startDate, inspector: [], itid: 0 });
      this.inspectionDate.push({ jsdate: new Date(startDate) });
      startDate = moment(
        moment(startDate).add(this.InspectionForm.value.duration, 'days')
      ).format('YYYY-MM-DD');
    }
  }

  changeBetweenDate($event, index) {
    let startDate = moment($event.jsdate).format('YYYY-MM-DD');
    for (
      let i = index;
      i < this.InspectionForm.controls.inspectorDates.value.length;
      i++
    ) {
      this.inspectionDate[i] = { jsdate: new Date(startDate) };
      startDate = moment(
        moment(startDate).add(this.InspectionForm.value.duration, 'days')
      ).format('YYYY-MM-DD');
    }
  }

  addInspector() {
    const inspectionType = [];
    inspectionType.push({
      itid: this.InspectionForm.value.itid,
      type: this.InspectionForm.value.type,
      duration: this.InspectionForm.value.duration
    });
    const inspectionDet = [];
    this.InspectionForm.value.inspectorDates.forEach(element => {
      inspectionDet.push({
        itid: element.itid,
        inspector: element.inspector,
        inspectionDate: moment(element.inspectionDate.jsdate).format(
          'YYYY-MM-DD'
        )
      });
    });
    const body = {
      inspectionType: inspectionType,
      inspectionDet: inspectionDet,
      itid: this.InspectionForm.value.itid
    };
    this._inspectorService.addInspector(body).subscribe(docs => {
      if (docs.success) {
        this.toastr.successToastr('Inspection Details Saved Successfully');
        // this.showForm = true;
        // this.getInspectionTypeDetails();
        // this.getUsersList();
        // this.model = {};
        this.router.navigate(['/InspectorComponent']);
      } else {
        this.toastr.errorToastr('Please try again');
      }
    });
  }

  viewInspectionTypeForUser(type) {
    this.dispType = type;
    this.inspectionTypes = this.headerList[`${type}`];
  }

  patchRemForm(value) {
    // if (this.dispType === 'today' && !value.status) {
    if (this.dispType !== 'future' && !value.status) {
      this.showForm = false;
      this.RemarksForm.patchValue({
        idid: value.idid,
        type: value.type,
        inspectionDate: value.inspectionDate,
        remarks: value.remarks
      });
    }
  }

  resetForKingdomPeople() {
    this.RemarksForm.reset();
    this.showForm = true;
    this.tableType = 'records';
    const b = _.filter(JSON.parse(sessionStorage.getItem('roles')), function (o) {
      return o.module_name === 'Inspection' && o.role_name === 'Inspection Manager';
    });
    this.displayType = b.length ? true : false;
  }

  async submitRemarks() {
    if (!this.RemarksForm.value.remarks.trim()) {
      return this.toastr.warningToastr('Please Select correct data');
    }
    const body = {
      idid: this.RemarksForm.value.idid,
      remarks: this.RemarksForm.value.remarks,
      status: 1,
      ncData: []
    };
    this.RemarksForm.value.ncData.forEach(element => {
      if (!element.details.trim()) {
        return this.toastr.warningToastr('Please Select correct data');
      }
      element.deadline = moment(element.deadline.jsdate).format('YYYY-MM-DD');
      body.ncData.push(element);
    });
    await this._inspectorService.addRemarks(body).subscribe(async response => {
      if (response.success) {
        this.toastr.successToastr('Remarks added Successfully');
        // $('#updateRm').modal('hide');
        // this.showForm = true;
        // this.getInspectionTypeDetails();
        // this.getUsersList();
        // this.RemarksForm.reset();
        // this.RemarksForm.controls.ncData['controls'] = [];
      } else {
        this.toastr.errorToastr('Please try again');
      }
    });
  }

  changeNcStatus($event, value) {
    if (
      $event.target.value === 'true' &&
      !this.RemarksForm.controls.ncData['controls'].length
    ) {
      this.ncAddNewRow();
      this.staffDisplay = [];
    } else {
      this.deadline = [];
      for (let index = 0; index < this.RemarksForm.controls.ncData['controls'].length; index++) {
        this.deleteRow(index);
      }
    }
  }

  ncAddNewRow() {
    const control = <FormArray>this.RemarksForm.controls['ncData'];
    control.push(this.ncInitItemRows());
  }

  ncInitItemRows() {
    return this.fb.group({
      main_id: new FormControl(0),
      location: new FormControl('', [Validators.required]),
      raised_by: new FormControl(`${sessionStorage.getItem('userid')}`), // session storage
      staff: new FormControl(''), // add emp to do
      issue: new FormControl('NC Raised Form Inspection'), // default
      details: new FormControl('', [Validators.required]),
      impact: new FormControl('', [Validators.required]), // low, medium, high
      deadline: new FormControl('', [Validators.required]),
      observe_date_tm: new FormControl(moment().format('YYYY-MM-DD')), // current date
      status: new FormControl(1)
    });
  }

  deleteRow(index) {
    const control = <FormArray>this.RemarksForm.controls['ncData'];
    control.removeAt(index);
  }

  assignCoordinator(index, $event) {
    this.staffDisplay[index] = [];
    const len = _.filter(this.LocationsListDisp, function (o) {
      return o.loc_id === parseInt($event, 0);
    });
    const a = [];
    if (len[0].supervisior !== '-') {
      len[0].supervisior.split(',').forEach(element => {
        const b = {};
        b['empname'] = element.split('(')[0];
        b['empname'] = element.split('(')[0];
        b['itemName'] = element.split('(')[0];
        b['id'] = element.split('(')[1].slice(0, -1);
        a.push(b);
      });
    }
    this.RemarksForm.controls.ncData['controls'][index].patchValue({
      staff: len[0].coordinator,
    });
    this.staffDisplay[index] = a;
  }

  async getInspectionHistory(value) {
    this.tableType = 'history';
    this.inspectionHistory = [];
    await this._inspectorService
      .getInspectionHistory(value)
      .subscribe(async response => {
        if (response.success) {
          this.loading = false;
          this.inspectionHistory = response.data;
        }
      }, error => {
        this.loading = false;
      });
  }

  BackToList() {
    this.tableType = 'records';
  }
}
