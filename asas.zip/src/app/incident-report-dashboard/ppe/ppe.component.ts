import { Component, OnInit, ViewChild, Input } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { DashboardReportsService } from '../dashboard_report_service';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';
// tslint:disable-next-line:prefer-const
declare let require: any;
const Highcharts = require('highcharts');
declare var $;
Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});
@Component({
  selector: 'app-ppe',
  templateUrl: './ppe.component.html',
  styleUrls: ['./ppe.component.css']
})
export class PpeComponent implements OnInit {
  public show_hide = 'incident';
  work_month2;
  value: Date;
  options3: Object;

  dateValue;
  monthPass: Date;
  sentDate;
  incidents_panel = 'main';
  ctlit: any = {};

  incident_details = false;

  accidents_panel = false;
  nc_panel = 'main';
  NC_details = false;
  ptw_details = false;
  ppe_details = false;
  sub_graphs = false;

  PData: any;
  options7: Object;

  ptwList: any = [];
  ppeData: any = [];
  todayDate: any = '';
  popType: any = '';
  acc_categories_panel = false;
  inc_categories_panel = false;
  allDashCounts: any = new Object();
  popDashCount: any = new Object();
  type = 'all';
  displayDate: any = new Date();
  selectedDate: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate_nc: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate2: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate3: any = new Date();
  mini_card = false;
  piechartloading = false;
  statusIds = [1, 6, 3];
  loading = false;
  accCategories: any = [];
  incCategories: any = [];
  accCategories2: any = [];
  incCategories2: any = [];
  kpimonthvalue: any;
  supervisorlist = [];

  line_graph = false;
  bar_graph = false;
  line_graph2 = false;
  bar_graph2 = false;
  costdetails = [];
  listofptws1 = [];

  iData2: any;
  iData: any;
  options: Object;
  options2: Object;
  options4: Object;
  options5: Object;
  options6: Object;
  options8: Object;
  options9: Object;
  bar_type: Object;
  pyramidgraph: Object;
  ptwpiecharts: Object;
  ptwpiechartsforsome: Object;
  ptwpiecharts2: Object;
  status;
  preview = false;

  options_type: Object;
  options_cost: Object;
  options_cost1: Object;
  options_supervisior: Object;
  options_location: Object;
  catetype = [];
  cat_loading4: boolean;

  config = {
    monthFormat: 'YYYY-MM',
    allowMultiSelect: false,
    enableMonthSelector: true,
    format: 'DD-MM-YYYY',
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    isMonthDisabledCallback: false,
    monthBtnFormat: 'MMM',
    max: moment(this.displayDate).format('YYYY-MM-dd')
  };

  public fromDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  public toDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  d = new Date();
  public from_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 1
    }
  };
  public to_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 31
    }
  };
  DatesForm: FormGroup;

  incident_cat_list: any = [];
  cat_loading: boolean;
  nc_list: any = [];
  nc_line_data: boolean;
  pie_graph: boolean;
  incidentGraphData = [];
  btype_graph: boolean;
  loc_graph: boolean;
  sup_graph: boolean;
  cost_graph: boolean;
  inc_table = false;
  listtoshow: any = [];
  locations: any = [];
  listonpop: any = [];
  categorytype: any;
  locationsdata: any = [];
  optionschart1;
  getcostdetailsof: any = [];
  listofinj: any = [];
  kpidtaa: any = [];
  kpichart: Object;
  kpis: any = [];
  safetylist: any = [];
  listofsafety: any = [];
  cat_loading2: boolean;
  safetytext: any;
  listofptws: any = [];
  extensionslist: any = [];
  surrender: any = [];
  approved: any = [];
  table = false;
  ptwpermit: any;
  piegraphshow = false;
  permitdata: any = [];
  questionlist: any = [];
  totaldata: any = [];
  questionlist1: any = [];
  employesslist: any = [];
  extensionlist: any = [];
  employesslist1: any = [];
  saftier_authorizer: any = [];
  ext_from_date: any = [];
  ppesgiven: any = [];
  extn_employesslist: any = [];
  status1: string;
  safetylist1: any = [];
  preview1 = false;

  constructor(
    public dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService
  ) {}

  ngOnInit() {
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    this.sentDate = {
      resp: new Date()
    };
    this.Open_card2();
    this.Open_card3();
    this.dashService
      .get_individual_count({
        date_month:
          this.todayDate.split('-')[0] + '-' + this.todayDate.split('-')[1],
        type: 'all'
      })
      .subscribe(allCounts => {
        console.log(allCounts);
        this.allDashCounts = allCounts.data[0];
        this.allDashCounts['incidents'] =
          this.allDashCounts['inc_severity_normal'] +
          this.allDashCounts['inc_severity_accident'] +
          this.allDashCounts['inc_severity_near_miss'];
        this.allDashCounts['pre_incidents'] =
          this.allDashCounts['pre_inc_severity_normal'] +
          this.allDashCounts['pre_inc_severity_accident'] +
          this.allDashCounts['pre_inc_severity_near_miss'];

        this.kpimonthvalue = allCounts.data2[0] ? allCounts.data2[0].kpi : 0;
        this.cat_loading4 = false;
      });
  }

  onChange(value) {
    this.sentDate = {
      resp: value
    };
  }

  incident_block() {
    this.show_hide = 'incident';
  }

  nc_block() {
    this.show_hide = 'n_conformation';
  }

  ptw_block() {
    this.show_hide = 'permit';
  }

  ppe_block() {
    this.show_hide = 'personal';
  }

  audits_block() {
    this.show_hide = 'audits';
  }

  trining_block() {
    this.show_hide = 'trining';
  }

  ergonomics_block() {
    this.show_hide = 'ergonomics';
  }

  gate_pass_block() {
    this.show_hide = 'gatepSS';
  }

  notifications_block() {
    this.show_hide = 'notifications';
  }

  risk_block() {
    this.show_hide = 'risk';
  }
  inspection_block() {
    this.show_hide = 'inspection';
  }

  Open_card2() {
    this.loading = true;
    // this.sub_graphs = false;
    // const type = typeof this.selectedDate3;

    // let selcdate = '';

    // if (type === 'object') {
    const selcdate = moment(this.selectedDate3).format('YYYY-MM');
    // } else {
    //   selcdate = this.selectedDate3;
    // }
    console.log(selcdate);
    this.dashService
      .get_individual_count({
        date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1],
        type: 'ptw'
      })
      .subscribe(popallCounts => {
        this.popDashCount = popallCounts.data[0];
        this.dashService.getDashReportsBARForPTW().subscribe(ptwBar => {
          this.options3 = {
            chart: {
              type: 'column',
              height: 380,
              // width: 580,
              backgroundColor: 'rgba(255, 255, 255, 0.0)'
            },
            credits: {
              enabled: false
            },
            title: {
              text: 'Work Permits',
              style: {
                color: '#f6a821',
                fontSize: '14px;'
              }
            },
            xAxis: {
              categories: ptwBar['data']['categories'],
              crosshair: true,
              labels: {
                style: {
                  fontSize: '13px',
                  color: '#d7d7d7'
                }
              }
            },
            yAxis: {
              min: 0,
              title: {
                text: 'Number',
                style: {
                  color: '#f6a821',
                  fontSize: '14px;'
                }
              }
            },
            legend: {
              itemStyle: {
                color: '#d7d7d7'
              }
            },
            tooltip: {
              headerFormat:
                '<span style="font-size:10px">{point.key}</span><table>',
              pointFormat:
                '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}</b></td></tr>',
              footerFormat: '</table>',
              shared: true,
              useHTML: true
            },
            exporting: { enabled: false },

            plotOptions: {
              column: {
                pointPadding: 0.2,
                borderWidth: 0
              }
            },
            series: ptwBar['data']['series']
          };
          this.dashService
            .getPtwListByMonth({
              date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1]
            })
            .subscribe(ptwList => {
              this.loading = true;
              if (!popallCounts.error) {
                this.ptwList = ptwList.data;
                this.loading = false;
              } else {
                this.loading = false;
                this.ptwList = [];
              }

              this.popType = 'ptw';
              this.mini_card = false;
              this.dashService.card_show = true;
              this.dashService.card_show_two = false;
              this.dashService.card_show_three = false;
              this.incident_details = false;
              this.dashService.card_show1 = false;
              this.dashService.card_show2 = true;
              this.dashService.card_show3 = false;
              this.dashService.card_show4 = false;
              this.dashService.card_show5 = false;
              this.dashService.card_show6 = false;
              this.dashService.card_show7 = false;
              this.dashService.card_show8 = false;
              this.dashService.card_show9 = false;
              this.dashService.card_show10 = false;
              this.incidents_panel = 'main';
              this.nc_panel = 'main';
              this.accidents_panel = false;
              this.NC_details = false;
              this.ptw_details = true;
              this.ppe_details = false;
              window.scroll(0, 0);
            });
        });
      });
  }

  dates_inc(event) {
    console.log(event.target.value, 'bshdfgjdfgsjdfgsfj');
    const dates = this.selectedDate.split('-');
    this.displayDate = dates[2] + '-' + dates[1];
    this.loading = true;
    if (this.acc_categories_panel) {
      this.dashService
        .getDashReportsForAccidentCategories({
          date_month: this.displayDate
        })
        .subscribe(accData => {
          this.loading = true;
          if (!accData.error) {
            this.accCategories = accData.data;
            this.accCategories = _.sortBy(accData.data, 'actual_val').reverse();
            this.accCategories2 = this.accCategories;
            this.loading = false;
          } else {
            this.accCategories = [];
            this.accCategories2 = [];
            this.loading = false;
          }
        });
    }

    this.dashService
      .getcostlit({
        date_month: this.displayDate
      })
      .subscribe(data => {
        if (data.success) {
          this.ctlit = data.data[0];
        }
      });

    this.incidentsgraphs(this.displayDate);
    this.getraisedgraphs(this.displayDate);

    if (this.inc_categories_panel) {
      this.dashService
        .getDashReportsForIncidentCategories({
          date_month: this.displayDate
        })
        .subscribe(incData => {
          this.loading = true;
          if (!incData.error) {
            this.incCategories = incData.data;
            this.incCategories = _.sortBy(incData.data, 'actual_val').reverse();
            this.incCategories2 = this.incCategories;
            this.loading = false;
          } else {
            this.incCategories = [];
            this.incCategories2 = [];
            this.loading = false;
          }
        });
    }

    const body = {
      date_month: this.displayDate,
      type: this.popType
    };
    this.dashService.get_individual_count(body).subscribe(data => {
      this.popDashCount = data.data[0];
      this.kpimonthvalue = data.data2[0].kpi;
    });

    if (this.popType === 'nc') {
      this.dashService
        .getPpePIEForDashReports({
          date_month: this.displayDate
        })
        .subscribe(iData2 => {
          this.loading = true;
          if (!iData2.error) {
            this.loading = false;
            Highcharts.setOptions({
              colors: [
                '#50B432',
                '#910000',
                '#492970',
                '#0d233a',
                '#058DC7',
                '#8bbc21',
                '#6AF9C4',
                '#1aadce',
                '#2f7ed8',
                '#f28f43',
                '#77a1e5',
                '#c42525',
                '#a6c96a',
                '#ED561B',
                '#DDDF00',
                '#24CBE5',
                '#64E572',
                '#FF9655',
                '#FFF263'
              ]
            });
            this.options7 = {
              colors: [
                '#379a24',
                '#df6810',
                '#FF0000',
                '#2d99b8',
                '#7f6b7e',
                '#2f7ed8',
                '#c42525',
                '#8bbc21',
                '#da4398',
                '#bf7138',
                '#0d9398',
                '#7a36cd',
                '#6784f0'
              ],
              chart: {
                plotBackgroundColor: null,
                plotBorderWidth: null,
                plotShadow: false,
                type: 'pie',
                backgroundColor: 'rgba(255, 255, 255, 0.0)'
              },
              credits: {
                enabled: false
              },
              title: {
                text: 'Nc Impact',
                style: {
                  color: '#fff'
                }
              },
              tooltip: {
                pointFormat: '{series.name}: <b>{point.y}</b>'
              },
              plotOptions: {
                pie: {
                  allowPointSelect: true,
                  cursor: 'pointer',
                  dataLabels: {
                    enabled: true,
                    format: '<b>{point.name}</b>: {point.y}'
                  }
                }
              },
              series: [
                {
                  name: 'Impact',
                  colorByPoint: true,
                  data: iData2.data.series[0]['data']
                }
              ]
            };
          } else {
            this.loading = false;
          }
        });
    } else if (this.popType === 'ptw') {
      this.dashService
        .getPtwListByMonth({
          date_month: this.displayDate
        })
        .subscribe(ptwList => {
          this.ptwList = ptwList.data;
        });
    }
    $('#monthpic').modal('hide');
    this.ptw_details = false;
    this.NC_details = false;
  }

  incidentsgraphs(d) {
    this.dashService
      .getincidentdashboardreport({
        date_month: d
      })
      .subscribe(data => {
        if (data.success) {
          this.sub_graphs = true;
          const names = [];
          const d_i = [];
          this.supervisorlist = data.data.supervisor;
          this.costdetails = data.data.cost;
          data.data.supervisor.forEach(element => {
            names.push(element.supervisor);
            d_i.push(element.incident_count);
          });
          this.incidentGraphData = data.data;
          console.log(this.incidentGraphData);
          const a = [];
          console.log(data.data.cost);
          const cost = [];
          const d_nmaes = [];
          data.data.cost.forEach(element => {
            cost.push(element.amount);
            d_nmaes.push(element.incident_name);
          });
          this.incidentGraphData['cost'] = cost;
          this.incidentGraphData['d_nmaes'] = d_nmaes;
          this.incidentGraphData['names'] = names;
          this.incidentGraphData['d_i'] = d_i;
          const l_names = [];
          const l_count = [];
          this.locationsdata = data.data.location;
          data.data.location.forEach(element => {
            l_names.push(element.location_name);
            l_count.push(element.incident_count);
          });
          this.incidentGraphData['location_names'] = l_names;
          this.incidentGraphData['location_count'] = l_count;
          const names1 = [];
          const values = [];
          this.catetype = data.data.bytype;
          data.data.bytype.forEach(element => {
            names1.push(element.name);
            values.push(element.y);
          });
          this.incidentGraphData['names1'] = names1;
          this.incidentGraphData['val'] = values;

          console.log(this.incidentGraphData);
          this.Graph();
        }
      });
  }

  getraisedgraphs(dt) {
    this.dashService
      .getDashReportsForTypesIncidents({ date_month: dt })
      .subscribe(iData2 => {
        // bar

        if (!iData2.error) {
          this.loading = false;
        } else {
          this.loading = false;
        }
        const t = _.sortBy(iData2['data']['series'], function(num) {
          return num;
        });
        console.log(t);
        this.options2 = {
          chart: {
            type: 'column',
            height: 295,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          credits: {
            enabled: false
          },
          legend: {
            itemStyle: {
              color: '#d7d7d7'
            }
          },
          title: {
            // text: 'Type of Incidents'
            text: 'Incidents Trend',
            style: {
              color: '#f6a821',
              fontSize: '16px;'
            }
          },
          xAxis: {
            categories: iData2['data']['categories'],
            crosshair: true,
            labels: {
              style: {
                fontSize: '13px',
                color: '#d7d7d7'
              }
            }
          },
          yAxis: {
            min: 0,
            title: {
              text: 'Number',
              style: {
                color: '#d7d7d7'
              }
            },
            labels: {
              style: {
                color: '#d7d7d7'
              }
            }
          },

          exporting: { enabled: false },
          tooltip: {
            headerFormat:
              '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat:
              '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
              '<td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
          },
          plotOptions: {
            column: {
              pointPadding: 0.2,
              borderWidth: 0
            }
          },
          series: iData2['data']['series']
        };
      }); // bar api
  
  }
  Graph() {
    console.log(this.incidentGraphData['cost'].length);
    this.incidentGraphData['bytype'] = _.filter(
      this.incidentGraphData['bytype'],
      function(o) {
        return o.y !== 0;
      }
    );
    this.bar_graph2 = true;
    if (this.incidentGraphData['bytype'].length) {
      this.btype_graph = true;
    } else {
      this.btype_graph = false;
    }
    if (this.incidentGraphData['cost'].length) {
      this.cost_graph = true;
    } else {
      this.cost_graph = false;
    }
    if (this.incidentGraphData['d_i'].length) {
      this.sup_graph = true;
    } else {
      this.sup_graph = false;
    }
    if (this.incidentGraphData['location_count'].length) {
      this.loc_graph = true;
    } else {
      this.loc_graph = false;
    }
    this.options_type = {
      chart: {
        type: 'pie',
        renderTo: 'container',
        height: 163,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      // title: {
      //   text: false
      // },
      title: {
        text: false,
        style: {
          color: '#f6a821',
          fontSize: '14px;'
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Type',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        headerFormat: '<span style="font-size: 10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 3,
          borderWidth: 0
        }
      },

      series: [
        {
          name: 'Type',
          data: this.incidentGraphData['bytype']
        }
      ]
    };

    console.log(this.incidentGraphData);
    const a = [];
    let i = 0;
    const clr = ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'];
    this.incidentGraphData['d_i'].forEach(element => {
      a.push({
        y: element,
        color: clr[i++],
        lineColor: '#e3a33f'
      });
    });
    this.incidentGraphData['d_i'] = a;

    this.options_supervisior = {
      colors: ['#058DC7', 'red', 'blue', 'black'],
      chart: {
        type: 'column',
        renderTo: 'supervisior',
        height: 315,
        width: 250,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Supervisior',
        x: -10, // center
        style: {
          color: '#f6a821',
          // fontWeight: 'normal',
          fontSize: '14px;'
        }
        // align: 'center'
      },
      exporting: { enabled: false },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },
      legend: {
        enabled: false,
        color: '#FF0000',
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['d_i'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_cost = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'cost',
        height: 200,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Cost ($)',
        style: {
          color: '#f6a821',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['d_nmaes'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },

      yAxis: {
        min: 0,
        title: {
          text: 'Total Cost',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },
      exporting: { enabled: false },
      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'Total Cost: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['cost'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_location = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'location',
        height: 200,
        width: 239,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      exporting: { enabled: false },
      title: {
        text: 'Incidents by Location',
        style: {
          color: '#f6a821',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['location_names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['location_count'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.bar_type = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        height: 157,
        width: 230,
        renderTo: 'container2',
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
        //   style: {
        //     color: "#b7b7b7"
        // }
      },
      exporting: { enabled: false },
      // title: {
      //   text: false,
      //   style: {
      //     color: '#f6a821',
      //     fontWeight: 'normal',
      //     fontSize: '16px;'
      //   }
      // },
      title: {
        text: false,
        style: {
          color: '#f6a821',
          fontSize: '14px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: this.incidentGraphData['names1'],
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      // tooltip: {
      //   pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      // },
      series: [
        {
          lineColor: '#f00',
          // color: '#d7d7d7',
          // fillOpacity: 0.5,
          name: 'supervisior',
          data: this.incidentGraphData['val'],
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 5, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };
  }

  Open_card3() {
    this.loading = true;
    this.sub_graphs = false;
    const type = typeof this.selectedDate;

    let selcdate = '';

    if (type === 'object') {
      selcdate = this.selectedDate._i;
    } else {
      selcdate = this.selectedDate;
    }
    this.dashService
      .get_individual_count({
        date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1],
        type: 'ppe'
      })
      .subscribe(popallCounts => {
        this.loading = true;
        if (!popallCounts.error) {
          this.popDashCount = popallCounts.data[0];
          this.loading = false;
        } else {
          this.loading = false;
          this.popDashCount = [];
        }

        this.dashService.getDashReportsForPPE().subscribe(ppeData => {
          this.loading = true;
          if (!ppeData.error) {
            this.ppeData = ppeData.data;
            this.loading = false;
          } else {
            this.loading = false;
            this.ppeData = [];
          }

          // var totInStock = 0;
          // var totOutStock = 0;
          // ppeData.data.forEach(row => {
          //   totInStock += row.instock;
          //   totOutStock += row.outstock;
          // });

          this.options4 = {
            chart: {
              type: 'pie',
              // marginRight: 10,
              height: 315,
              backgroundColor: 'rgba(255, 255, 255, 0.0)'

              // width: 730
            },
            credits: {
              enabled: false
            },
            title: {
              text: 'PPE Stores'
            },
            yAxis: {
              title: {
                text: 'Raised',
                style: {
                  color: '#f6a821',
                  fontSize: '14px;'
                }
              },
              plotLines: [
                {
                  value: 0,
                  width: 1,
                  color: '#808080'
                }
              ]
            },
            tooltip: {
              pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
              pie: {
                allowPointSelect: true,
                cursor: 'pointer',
                dataLabels: {
                  enabled: true,
                  format: '<b>{point.name}</b>: {point.y}'
                }
              }
            },
            legend: {
              enabled: false,
              itemStyle: {
                color: '#d7d7d7'
              }
            },
            exporting: {
              enabled: false
            },
            series: [
              {
                name: 'Equipment',
                data: [
                  {
                    name: 'Stores',
                    y: this.allDashCounts.ppe_instock
                  },
                  {
                    name: 'Circulation',
                    y: this.allDashCounts.ppe_outstock
                  }
                ]
              }
            ]
          };

          this.popType = 'ppe';
          this.type = 'ppe';
          this.mini_card = false;
          this.dashService.card_show = true;
          this.dashService.card_show_two = false;
          this.dashService.card_show_three = false;
          this.incident_details = false;
          this.dashService.card_show1 = false;
          this.dashService.card_show2 = false;
          this.dashService.card_show3 = true;
          this.dashService.card_show4 = false;
          this.dashService.card_show5 = false;
          this.dashService.card_show6 = false;
          this.dashService.card_show7 = false;
          this.dashService.card_show8 = false;
          this.dashService.card_show9 = false;
          this.dashService.card_show10 = false;
          this.incidents_panel = 'main';
          this.nc_panel = 'main';
          this.accidents_panel = false;
          this.NC_details = false;
          this.ptw_details = false;
          this.ppe_details = true;
          this.sub_graphs = false;
        }); // ppe data api
      });
    window.scroll(0, 0); // pop counts api
  }
}
