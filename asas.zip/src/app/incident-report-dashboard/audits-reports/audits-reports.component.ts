import { Component, OnInit, ViewChild, Input } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { DashboardReportsService } from '../dashboard_report_service';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';
// tslint:disable-next-line:prefer-const
declare let require: any;
const Highcharts = require('highcharts');
declare var $: any;
Highcharts.setOptions({
  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});
@Component({
  selector: 'app-audits-reports',
  templateUrl: './audits-reports.component.html',
  styleUrls: ['./audits-reports.component.css']
})
export class AuditsReportsComponent implements OnInit {
  @Input()
  PData: any;
  options3: Object;

  ncdata: any[];
  auditdata: any = [];
  audit_report_data: any = [];
  loading = false;
  scheduleData: any[];
  ncMissedData: any[];
  auditsCompleted: any[];
  popUpData = {
    title: '',
    errorMsg: '',
    data: ''
  };

  public filterQuery = '';
  public rowsOnPage = 10;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService
  ) { }

  ngOnInit() {
    this.Open_card4();
    this.getScheduleData();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
    this.Open_card4();
    this.getScheduleData();
  }

  Open_card4() {
    this.loading = true;
    this.audit_report_data = [];
    this.auditdata = [];
    this.ncdata = [];

    this.dashService
      .getAuditReports(moment(this.PData.resp).format('YYYY-MM'))
      .subscribe(auditData => {
        this.loading = true;
        if (auditData.success) {
          this.audit_report_data = auditData.data.auditNc[0];
          // pending details
          this.auditdata = [
            this.audit_report_data['auditsPending'],
            this.audit_report_data['NcRaised'] -
            this.audit_report_data['NcClosed']
          ];
          // Closed details
          this.ncdata = [
            this.audit_report_data['auditCompleted'],
            this.audit_report_data['NcClosed']
          ];
          this.loading = false;
        } else {
          this.loading = false;
          this.audit_report_data = [];
          this.auditdata = [0, 0];
          this.ncdata = [0, 0];
        }

        const a = this;
        this.options3 = {
          chart: {
            type: 'column',
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },

          title: {
            text: 'Audits & Non-Conformance',
            style: {
              color: '#f6a821',
              fontSize: '14px;'
            }
          },

          credits: {
            enabled: false
          },

          plotOptions: {
            series: {
              cursor: 'pointer',
              events: {
                click: function (event) {
                  a.callFunction(event);
                }
              }
            },
            column: {
              stacking: 'normal'
            }
          },

          xAxis: {
            categories: ['Audits', 'Non Conformance', 'Inspection'],
            labels: {
              style: {
                fontSize: '13px',
                color: '#d7d7d7'
              }
            }
          },
          legend: {
            itemStyle: {
              color: '#000000'
            }
          },

          yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
              text: 'Number',
              style: {
                color: '#f6a821',
                fontSize: '14px;'
              }
            }
          },
          exporting: {
            enabled: false
          },

          tooltip: {
            formatter: function () {
              return ('<b>' + this.x + '</b><br/>' + this.series.name + ': ' + this.y + '<br/>' + 'Total: ' + this.point.stackTotal
              );
            }
          },

          series: [
            {
              name: 'Pending',
              data: [
                {
                  y: this.audit_report_data['auditsPending']
                    ? this.audit_report_data['auditsPending']
                    : 0,
                  color: 'orange',
                  lineColor: 'orange'
                },
                {
                  y:
                    this.audit_report_data['NcRaised'] -
                      this.audit_report_data['NcClosed']
                      ? this.audit_report_data['NcRaised'] -
                      this.audit_report_data['NcClosed']
                      : 0,
                  color: 'orange',
                  lineColor: 'orange'
                }
              ],
              stack: 'male',
              color: 'orange'
            },
            {
              name: 'Closed',
              data: [
                {
                  y: this.audit_report_data['auditCompleted']
                    ? this.audit_report_data['auditCompleted']
                    : 0,
                  color: 'green',
                  lineColor: 'green'
                },
                {
                  y: this.audit_report_data['NcClosed']
                    ? this.audit_report_data['NcClosed']
                    : 0,
                  color: 'green',
                  lineColor: 'green'
                }
              ],
              stack: 'male',
              color: 'green'
            }
          ]
        };
      });
  }

  async getScheduleData() {
    this.scheduleData = [];
    this.ncMissedData = [];
    this.auditsCompleted = [];
    const body = {};
    body['startDate'] = moment(
      moment(this.PData.resp).format('YYYY-MM-01')
    ).format('YYYY-MM-DD');
    body['endDate'] = moment(
      new Date(
        parseInt(moment(this.PData.resp).format('YYYY'), 0),
        parseInt(moment(this.PData.resp).format('MM'), 0),
        0
      )
    ).format('YYYY-MM-DD');
    await this.dashService.getScheduleData(body).subscribe(data => {
      if (data.success) {
        this.scheduleData = data.data;
        this.ncMissedData = data.NcMissed;
      }
    });
  }

  callFunction($event) {
    this.openAuditPopUp(
      $event.point.series.name,
      $event.point.category === 'Audits' ? 'Audits' : 'NC'
    );
  }

  openAuditPopUp(status, type) {
    if (status === 'Closed' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function (o) {
        return o.status === 3;
      });
      this.popUpData.title = 'Audits Conducted';
      this.popUpData.errorMsg = 'No Audits Where Closed';
    } else if (status === 'Pending' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function (o) {
        return o.status === 1;
      });
      this.popUpData.title = 'Pending Audits';
      this.popUpData.errorMsg = 'No Audits Found';
    } else if (status === 'Scheduled' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function (o) {
        return o.status > 0;
      });
      this.popUpData.title = 'Scheduled Audits';
      this.popUpData.errorMsg = 'No Audits Found';
    } else if (status === 'Closed' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function (o) {
        return o.status === 2;
      });
      this.popUpData.title = `NC's Closed`;
      this.popUpData.errorMsg = 'No NC Where Closed';
    } else if (status === 'Pending' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function (o) {
        return o.status === 1;
      });
      this.popUpData.title = `NC's closure in progress`;
      this.popUpData.errorMsg = 'No NC Found';
    } else if (status === 'Raised' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function (o) {
        return o.status > 0;
      });
      this.popUpData.title = `NC's Raised`;
      this.popUpData.errorMsg = `No NC's Raised`;
    }

    if (type === 'Audits') {
      $('#auditPopUp').modal('show');
    } else {
      $('#NCPopUp').modal('show');
    }
  }
}
