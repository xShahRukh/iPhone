import {
  Component,
  OnInit,
  ViewChild,
  Input,
  Output,
  EventEmitter
} from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { DashboardReportsService } from '../../incident-report-dashboard/dashboard_report_service';

declare let require: any;
const Highcharts = require('highcharts');
declare var $;

Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});

@Component({
  selector: 'app-inspection-reports',
  templateUrl: './inspection-reports.component.html',
  styleUrls: ['./inspection-reports.component.css']
})
export class InspectionReportsComponent implements OnInit {
  @Input()
  PData: any;
  optionsReport: Object;
  optionsNc: Object;
  ReportsData = [];
  monthPass: Date;

  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = 'color';
  public sortOrder = 'asc';
  tableData: any = {
    data: '',
    type: '',
    error: ''
  };
  ncTableData: any = {
    data: '',
    type: '',
    error: ''
  };
  loading = false;
  dispType = {
    headerMsg: '',
    type: '',
    data: [],
    titleMsg: '',
    errorMsg: ''
  };
  locations = [];
  LocationsListStatic = [];

  constructor(
    public _dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder
  ) { }

  async ngOnInit() {
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    await this.getInspectionReport();
    await this.getListOfLocations();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
    this.getInspectionReport();
  }

  getListOfLocations() {
    this.locations = [];
    this._dashService.getListOfLocations().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function (o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['lastAdd'] = false;
          }
        });
        this.locations = _.filter(response, function (o) {
          return o.lastAdd === false;
        });

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getInspectionReport() {
    this.loading = true;
    const a = this;
    this.ReportsData = [];
    this._dashService
      .getInspectionReport(moment(this.monthPass).format('YYYY-MM'))
      .subscribe(async response => {
        this.ReportsData = response.data;

        const ncAuditPending = _.filter(response.data.NcAudit, function (o) {
          return o.status === 1;
        });
        const ncAuditClosed = _.filter(response.data.NcAudit, function (o) {
          return o.status === 2;
        });
        const ncInsPending = _.filter(response.data.Inspection, function (o) {
          return o.status === 0;
        });
        const ncInsClosed = _.filter(response.data.Inspection, function (o) {
          return o.status === 1;
        });
        const ncInsClosedChart2 = _.filter(response.data.NcInspection, function (o) {
          return o.status === 1;
        });
        const ncInsPendingChart2 = _.filter(response.data.NcInspection, function (o) {
          return o.status !== 1;
        });

        console.log(ncInsPending, ncInsClosed, response.data, 'inspection');


        // First Graph
        this.optionsReport = {
          chart: {
            type: 'column',
            height: 250,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: 'Inspection Details',
            style: {
              color: '#f6a821',
              fontSize: '16px;'
            }
          },
          credits: {
            enabled: false
          },
          exporting: { enabled: false },
          xAxis: {
            categories: ['Inspections Planned', 'Inspections Conducted'],
            crosshair: true,
            labels: {
              style: {
                fontSize: '13px',
                color: '#8d8f94'
              }
            }
          },
          yAxis: {
            min: 0,
            title: {
              text: 'Raised',
              style: {
                color: '#d7d7d7'
              }
            },
            labels: {
              style: {
                color: '#8d8f94'
              }
            }
          },
          legend: {
            itemStyle: {
              color: '#8d8f94'
            }
          },
          tooltip: {
            headerFormat: '<span style="font-size:10px">No. of {point.key} </span><table>',
            pointFormat: '<tr><td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
          },
          plotOptions: {
            series: {
              cursor: 'pointer',
              events: {
                click: function (event) {
                  a.callFunction(event);
                }
              }
            }
          },
          series: [
            {
              type: 'column',
              data: [
                // {
                //   y: response.data.Inspection.length,
                //   color: '#f6a821',
                //   lineColor: '#e3a33f'
                // },
                // {
                //   y: response.data.Audit.length,
                //   color: '#258000',
                //   lineColor: '#e3a33f'
                // }
                {
                  y: ncInsPending.length,
                  color: '#f6a821',
                  lineColor: '#e3a33f'
                },
                {
                  y: ncInsClosed.length,
                  color: '#258000',
                  lineColor: '#e3a33f'
                }
              ],
              showInLegend: false
            }
          ]
        };

        // Second Graph (Raised from Ncs)
        this.optionsNc = {
          chart: {
            type: 'column',
            height: 250,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: 'NC Raised',
            style: {
              color: '#f6a821',
              fontSize: '16px;'
            }
          },
          credits: {
            enabled: false
          },
          exporting: { enabled: false },
          xAxis: {
            categories: ['Inspections', 'Audits'],
            crosshair: false,
            labels: {
              style: {
                fontSize: '13px',
                color: '#8d8f94'
              }
            }
          },
          yAxis: {
            min: 0,
            title: {
              text: 'Raised',
              style: {
                color: '#d7d7d7'
              }
            },
            labels: {
              style: {
                color: '#8d8f94'
              }
            }
          },
          tooltip: {
            formatter: function () {
              return (
                '<b>' +
                this.x +
                '</b><br/>' +
                this.series.name +
                ': ' +
                this.y +
                '<br/>' +
                'Total: ' +
                this.point.stackTotal
              );
            }
          },
          plotOptions: {
            series: {
              cursor: 'pointer',
              events: {
                click: function (event) {
                  a.callFunctionNcReports(event);
                }
              }
            },
            column: {
              stacking: 'normal'
            }
          },
          legend: {
            itemStyle: {
              color: '#8d8f94'
            }
          },
          series: [
            {
              name: 'Pending',
              data: [
                {
                  y: ncInsPendingChart2.length,
                  color: 'orange',
                  lineColor: 'orange'
                },
                {
                  y: ncAuditPending.length,
                  color: 'orange',
                  lineColor: 'orange'
                }
              ],
              stack: 'male',
              color: 'orange'
            },
            {
              name: 'Closed',
              data: [
                {
                  y: ncInsClosedChart2.length,
                  color: 'green',
                  lineColor: 'green'
                },
                {
                  y: ncAuditClosed.length,
                  color: 'green',
                  lineColor: 'green'
                }
              ],
              stack: 'male',
              color: 'green'
            }
          ]
        };
        const ncaa = {};
        ncaa['point'] = {};
        ncaa['point'] = { category: 'Inspections Planned' };
        ncaa['point']['series'] = { name: 'Pending' };
        await this.callFunction(ncaa);
        ncaa['point'] = { category: 'Inspections' };
        ncaa['point']['series'] = { name: 'Pending' };
        await this.callFunctionNcReports(ncaa);

        if (!this.tableData['data'].length) {
          ncaa['point'] = { category: 'Audits' };
          this.callFunction(ncaa);
        }
        this.loading = false;
      });
  }

  callFunction(event) {
    console.log(event.point.category);
    if (event.point.category === 'Inspections Planned') {
      this.tableData['type'] = 'Inspections';
      this.tableData['data'] = _.filter(this.ReportsData['Inspection'], function (o) {
        return o.status === 0;
      });
      this.tableData['error'] = 'No Inspections Planned';
    } else if (event.point.category === 'Inspections Conducted') {
      this.tableData['type'] = 'Inspections';
      this.tableData['data'] = _.filter(this.ReportsData['Inspection'], function (o) {
        return o.status === 1;
      });
      this.tableData['error'] = 'No Inspections Conducted';
    } else if (event.point.category === 'Audits') {
      this.tableData['type'] = event.point.category;
      this.tableData['data'] = this.ReportsData['Audit'];
      this.tableData['error'] = 'No Audits Found';
    }
  }

  callFunctionNcReports(event) {
    console.log(event, this.ReportsData);
    if (event.point.category === 'Inspections') {
      this.ncTableData['type'] = event.point.category;
      if (event.point.series.name === 'Pending') {
        this.ncTableData['data'] = _.filter(this.ReportsData['NcInspection'],
          function (o) {
            return o.status !== 1;
          });
        this.ncTableData['error'] = 'No Pending Inspections Found';
      } else if (event.point.series.name === 'Closed') {
        this.ncTableData['data'] = _.filter(this.ReportsData['NcInspection'],
          function (o) {
            return o.status === 1;
          });
        this.ncTableData['error'] = 'No Closed Inspections Found';
      }
    } else if (event.point.category === 'Audits') {
      this.ncTableData['type'] = event.point.category;
      if (event.point.series.name === 'Pending') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcAudit'],
          function (o) {
            return o.status === 1;
          }
        );
        this.ncTableData['error'] = 'No Pending Audits Found';
      } else if (event.point.series.name === 'Closed') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcAudit'],
          function (o) {
            return o.status === 2;
          }
        );
        this.ncTableData['error'] = 'No Closed Audits Found';
      }
    }
  }

  onenPopup(type, value) {
    this.dispType.type = type;
    this.dispType.data = value;
    this.dispType.headerMsg = '';
    this.dispType.titleMsg = '';
    this.dispType.errorMsg = '';
    if (type === 'Inspections') {
      this.dispType.headerMsg = 'Inspection Details';
      this.dispType.titleMsg = '';
      this.dispType.errorMsg = 'No Inspection Details Found';
    } else if (type === 'Audits') {
      this.dispType.headerMsg = 'Audit Details';
      this.dispType.titleMsg = '';
      this.dispType.errorMsg = 'No Audit Details Found';
    }
  }

  getLocationName(value) {
    let text = _.filter(this.LocationsListStatic, function (o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function (o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  onChange($event) {
    // this.PData = {
    //   resp: $event
    // };
    this.monthPass = $event;
    this.getInspectionReport();
  }
}
