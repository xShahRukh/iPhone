import { environment } from '../../environments/environment';

export class DashboardReportsSettings {
  public static API = {
    DASH_INCIDENT_INCIDENT_CATEGORIES:
      environment.apiUrl + 'dashboard/get/incident/categories/list',
    DASH_INCIDENT_ACCIDENT_CATEGORIES:
      environment.apiUrl + 'dashboard/get/accident/categories/list',
    DASH_INCIDENTS_LIST_12:
      environment.apiUrl + 'dashboard/get/all/list/incidents',
    DASH_INCIDENT_TYPES_LIST_12:
      environment.apiUrl + 'dashboard/get/all/types/incidents',
    DASH_NC_LIST: environment.apiUrl + 'dashboard/get/count/nc',
    DASH_PTW_LIST: environment.apiUrl + 'dashboard/get/count/ptw',
    DASH_PTW_LIST_TABLE: environment.apiUrl + 'dashboard/table/get/list/ptw',
    DASH_PPE_LIST: environment.apiUrl + 'dashboard/get/stock/count/ppe',
    DASH_INCIDENT_SEVERITY_INDIVIDUAL_LIST_12:
      environment.apiUrl + 'dashboard/get/all/severity/individual/incidents',

    //
    // DASH_INDIVIUAL_COUNT:
    //   environment.apiUrl + 'dashboard/get/all/individual/counts',
    DASH_INDIVIUAL_COUNT:
      environment.apiUrl + 'dashboard/get/all/individual/counts1',
    DASH_INDIVIUAL_ALL: environment.apiUrl + 'dashboard/get/all/individual/all',
    DASH_INDIVIUAL_INCIDENTS:
      environment.apiUrl + 'dashboard/get/all/individual/incidents',
    DASH_INDIVIUAL_NC: environment.apiUrl + 'dashboard/get/all/individual/nc',
    DASH_INDIVIUAL_PTW: environment.apiUrl + 'dashboard/get/all/individual/ptw',
    DASH_INDIVIUAL_PPE: environment.apiUrl + 'dashboard/get/all/individual/ppe',
    DASH_STATUS_BAR: environment.apiUrl + 'dashboard/get/nc/all/status/bar',
    DASH_STATUS_STACK:
      environment.apiUrl + 'dashboard/get/nc/individual/status/stack',
    DASH_STATUS_PIE: environment.apiUrl + 'dashboard/get/nc/pie/status',
    DASH_GET_TODAY_DATE: environment.apiUrl + 'get/todaydate',
    // DASH_DEPT_GET_LIST: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    DASH_DEPT_GET_LIST: environment.apiUrl + 'ergonomics/dashboarddata_dept/',
    DASH_GET_ERGONOMICS_DATA: environment.apiUrl + 'ergonomics/dashboarddata/',
    DASH_EROG_LIST: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    DASH_NOTIFICATIONS_LIST: environment.apiUrl + 'notification/dashboarddata/',
    DASH_REPORTS_DASHBOARD: environment.apiUrl + 'risk/reports_dashboard/',
    DASH_REPORTS_CHARTS: environment.apiUrl + 'risk/reports_dashboard_charts',
    DASH_TEMPLATE_COUNT: environment.apiUrl + 'ergonomics/dashboarddataCOUNT',
    DASH_INCIDENT_CAT_LIST:
      environment.apiUrl + 'dashboard/get/incident/categories/list/type',
    DASH_NC_DATA_LIST: environment.apiUrl + 'dashboard/get/nc/diffdates',
    DASH_INCIDENTS_COST_LIT:
      environment.apiUrl + 'dashboard/incident/count_LIT',
    DASH_INCIDENTS_REPORT_DETAILS:
      environment.apiUrl + 'dashboard/incident/getreportsdata',
    GETLIST_OF_INCIDENTS:
      environment.apiUrl + 'getallsupervisors/byIncidentDate',
    GETCOST_DETAILS: environment.apiUrl + 'getdashboard/incident/cost',
    GETINJURIES: environment.apiUrl + 'dashboard/get/all/injuries/list',
    GETKPIDATA: environment.apiUrl + 'incident/dashboard/kpi',
    GETLISTFOR_INJURIES: environment.apiUrl + 'dashboard/get/all/safety/list',
    GETDATA_SAFETY: environment.apiUrl + 'dashboard/get/listfor/safety',
    GETPTWLITS: environment.apiUrl + 'dashboard/get/detailsofptw',
    GETAPISFORPERMITS: environment.apiUrl + 'get/apilist/permits/status',

    GET_SCHEDULE_DATA: environment.apiUrl + 'getScheduleData',

    // Inspection Reports
    GET_INSPECTION_REPORTS: environment.apiUrl + 'get/inspection/Report',
    GET_LOCATIONS: environment.apiUrl + 'get/locations',
    GET_DATA_FOR_SIMILAR:
      environment.apiUrl + 'incident/dashboard/incidents/similar',
    GET_NC_MONTHLY_REPORT: environment.apiUrl + 'nc/getDetailsByMonth/',
  };
}
