import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import { DashboardReportsService } from '../dashboard_report_service';
declare var $: any;
@Component({
  selector: 'app-main-dashboard',
  templateUrl: './main-dashboard.component.html',
  styleUrls: ['./main-dashboard.component.css']
})
export class MainDashboardComponent implements OnInit {
  public show_hide = 'incident';
  work_month2;
  value: Date;
  dateValue;
  monthPass: Date;
  sentDate;

  totincidents;
  pretotincidents: any;
  imageShow = false;
  imageShow1 = false;
  constructor(public dashService: DashboardReportsService) {}

  ngOnInit() {
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    this.sentDate = {
      resp: new Date()
    };
    this.dashService
      .get_individual_count({
        date_month: moment(this.sentDate.resp).format('YYYY-MM'),
        type: 'all'
      })
      .subscribe(allCounts => {
        this.totincidents = parseInt(allCounts.data3[0].current_month, 0);
        this.pretotincidents = parseInt(allCounts.data3[0].z, 0);
        console.log(typeof this.totincidents, typeof this.pretotincidents);
      });
    const body = document.getElementsByTagName('body')[0];
    body.removeAttribute('class');
    body.classList.add('nav-toggle'); // add the class
    console.log(body);
  }

  onChange(value) {
    this.sentDate = {
      resp: value
    };
    this.dashService
      .get_individual_count({
        date_month: moment(this.sentDate.resp).format('YYYY-MM'),
        type: 'all'
      })
      .subscribe(allCounts => {
        this.totincidents = parseInt(allCounts.data3[0].current_month, 0);
        this.pretotincidents = parseInt(allCounts.data3[0].z, 0);
      });
  }

  incident_block() {
    this.show_hide = 'incident';
  }

  nc_block() {
    this.show_hide = 'n_conformation';
  }

  ptw_block() {
    this.show_hide = 'permit';
  }

  ppe_block() {
    this.show_hide = 'personal';
  }

  audits_block() {
    this.show_hide = 'audits';
  }

  trining_block() {
    this.show_hide = 'trining';
  }

  ergonomics_block() {
    this.show_hide = 'ergonomics';
  }

  gate_pass_block() {
    this.show_hide = 'gatepSS';
  }

  notifications_block() {
    this.show_hide = 'notifications';
  }

  risk_block() {
    this.show_hide = 'risk';
  }
  inspection_block() {
    this.show_hide = 'inspection';
  }

  mouseEnter(div: string) {
    this.imageShow = true;
  }

  mouseLeave(div: string) {
    this.imageShow = false;
  }
  mouseEnter1(div: string) {
    this.imageShow1 = true;
  }

  mouseLeave1(div: string) {
    this.imageShow1 = false;
  }
}
