import { Component, OnInit } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { ApiService } from '../../common/services/api.service';
import { DashboardReportsService } from '../dashboard_report_service';
import { FormBuilder } from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';

declare let require: any;
const Highcharts = require('highcharts');
Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});

@Component({
  selector: 'app-non-conformation',
  templateUrl: './non-conformation.component.html',
  styleUrls: ['./non-conformation.component.css']
})
export class NonConformationComponent implements OnInit {
  // ptwList: any = [];
  // ppeData: any = [];
  // todayDate: any = '';
  popType: any = '';
  // acc_categories_panel = false;
  // inc_categories_panel = false;
  // allDashCounts: any = new Object();
  popDashCount: any = new Object();
  // type = 'all';
  displayDate: any = new Date();
  selectedDate: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate_nc: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate2: any = moment(this.displayDate).format('YYYY-MM');
  // selectedDate3: any = new Date();
  mini_card = false;
  piechartloading = false;
  // statusIds = [1, 6, 3];

  incident_details = false;
  options7: Object;
  options8: Object;
  options9: Object;
  ncChart: Object;
  nc_panel = 'main';
  nc_list: any = [];
  nc_line_data: boolean;
  pie_graph: boolean;
  monthPass: Date;
  ncCompleteDetails: any[];

  constructor(
    public dashService: DashboardReportsService,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService
  ) { }

  ngOnInit() {
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    // this.nc_status('Raised');
    this.Open_card1();
    this.getDataFormNewApi();
    this.mini_card = true;
  }

  onChange($event) {
    this.selectedDate = moment($event).format('YYYY-MM-DD');
    // this.nc_status(this.nc_panel);
    this.getDataFormNewApi();
    this.Open_card1();
  }

  nc_status(status) {
    this.dashService
      .getDashStatusStackNC({ status: status })
      .subscribe(ncStack => {
        if (!ncStack.error) {
        } else {
        }
        this.options9 = {
          chart: {
            type: 'column',
            marginRight: 10,
            height: 300,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
            // width: 700
          },
          credits: {
            enabled: false
          },
          title: {
            // tslint:disable-next-line:quotemark
            text: "NC's" + '-' + status,
            style: {
              color: '#f6a821',
              fontSize: '14px;'
            }
          },
          xAxis: {
            categories: ncStack['data']['categories'],
            labels: {
              style: {
                fontSize: '13px',
                color: '#d7d7d7'
              }
            }
          },
          yAxis: {
            title: {
              text: 'Raised',
              style: {
                color: '#d7d7d7'
              }
            },

            plotLines: [
              {
                value: 0,
                width: 1,
                color: '#808080'
              }
            ]
          },
          tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat:
              '{series.name}: {point.y}<br/>Total: {point.stackTotal}'
          },
          plotOptions: {
            column: {
              stacking: 'normal',
              dataLabels: {
                enabled: true,
                color: '#fff'
              }
            }
          },
          legend: {
            enabled: false
          },
          exporting: {
            enabled: false
          },
          series: ncStack['data']['series']
        };

        this.nc_panel = status;
      });
  }

  Open_card1() {
    this.pie_data();
    this.nc_list = [];
    this.pie_graph = true;
    // this.sub_graphs = false;
    const type = typeof this.selectedDate;

    let selcdate = '';

    if (type === 'object') {
      selcdate = this.selectedDate._i;
    } else {
      selcdate = this.selectedDate;
    }
    this.dashService
      .get_individual_count({
        date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1],
        type: 'nc'
      })
      .subscribe(popallCounts => { });
    this.dashService.getDashStatusBarNC().subscribe(ncBarData => {
      if (!ncBarData.error) {
      } else {
      }
      // this.options8 = {
      //   colors: [
      //     '#FF0000',
      //     '#379a24',
      //     '#df6810',
      //     '#2d99b8',
      //     '#7f6b7e',
      //     '#2f7ed8',
      //     '#c42525',
      //     '#8bbc21',
      //     '#da4398',
      //     '#bf7138',
      //     '#0d9398',
      //     '#7a36cd',
      //     '#6784f0'
      //   ],
      //   chart: {
      //     type: 'column',
      //     height: 300,
      //     // width: 710,
      //     backgroundColor: 'rgba(255, 255, 255, 0.0)'
      //   },
      //   credits: {
      //     enabled: false
      //   },
      //   title: {
      //     text: 'At Risk Behaviors (NCs)',
      //     style: {
      //       color: '#f6a821',
      //       fontSize: '14px;'
      //     }
      //   },
      //   xAxis: {
      //     categories: ncBarData['data']['categories'],
      //     crosshair: true
      //   },
      //   yAxis: {
      //     min: 0,
      //     title: {
      //       text: 'Number'
      //     }
      //   },
      //   tooltip: {
      //     headerFormat:
      //       '<span style="font-size:10px">{point.key}</span><table>',
      //     pointFormat:
      //       '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
      //       '<td style="padding:0"><b>{point.y}</b></td></tr>',
      //     footerFormat: '</table>',
      //     shared: true,
      //     useHTML: true
      //   },
      //   plotOptions: {
      //     column: {
      //       pointPadding: 0.2,
      //       borderWidth: 0
      //     }
      //   },
      //   series: ncBarData['data']['series']
      // };
    });
    this.dashService
      .getPpePIEForDashReports({
        date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1]
      })
      .subscribe(iData2 => {
        if (!iData2.error) {
        } else {
        }
        this.options7 = {
          colors: [
            '#379a24',
            '#df6810',
            '#FF0000',
            '#2d99b8',
            '#7f6b7e',
            '#2f7ed8',
            '#c42525',
            '#8bbc21',
            '#da4398',
            '#bf7138',
            '#0d9398',
            '#7a36cd',
            '#6784f0'
          ],
          chart: {
            plotBackgroundColor: null,
            plotBorderWidth: null,
            plotShadow: false,
            type: 'pie',
            // height: 300,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          credits: {
            enabled: false
          },
          title: {
            text: 'Nc Impact',
            style: {
              color: '#f6a821',
              fontSize: '14px;'
            }
          },
          tooltip: {
            pointFormat: '{series.name}: <b>{point.y}</b>'
          },
          exporting: {
            enabled: false
          },
          plotOptions: {
            pie: {
              allowPointSelect: true,
              cursor: 'pointer',
              dataLabels: {
                enabled: true,
                format: '<b>{point.name}</b>: {point.y}'
              }
            }
          },
          series: [
            {
              name: 'Impact',
              colorByPoint: true,
              data: iData2.data.series[0]['data']
            }
          ]
        };
      }); // nc impact pie api

    this.dashService
      .getncdatalist({
        date_month: selcdate.split('-')[0] + '-' + selcdate.split('-')[1]
      })
      .subscribe(data => {
        if (data.success) {
          this.nc_list = data.data;
        } else {
          this.nc_list = [];
        }
      });

    window.scroll(0, 0);
  }

  pie_data() {
    this.pie_graph = true;
    this.nc_line_data = false;
  }

  line_data() {
    this.pie_graph = false;
    this.nc_line_data = true;
  }

  getDataFormNewApi() {
    this.ncCompleteDetails = [];
    this.dashService.getDataFormNewApi(moment(this.monthPass).format('YYYY-MM')).subscribe(response => {
      if (response.success) {
        this.ncCompleteDetails = response.data;
        const raised = this.ncCompleteDetails.length;
        let closed = _.filter(this.ncCompleteDetails, function (o) {
          return o.status === 2;
        });
        closed = closed.length;
        let progress = _.filter(this.ncCompleteDetails, function (o) {
          return o.status === 1;
        });
        progress = progress.length;
        let reassigned = _.uniq(response.data, 'parent_issue_id');
        reassigned = _.filter(reassigned, function (o) {
          return (o.parent_issue_id !== null) && (o.parent_issue_id !== o.main);
        });
        reassigned = reassigned.length;
        let delayed = _.filter(this.ncCompleteDetails, function (o) {
          return moment(o.deadline).format('YYYY-MM-DD') < moment().format('YYYY-MM-DD');
        });
        delayed = delayed.length;



        this.ncChart = {

          title: {
            text: 'Nc Reports',
            style: {
              color: '#f6a821',
              fontSize: '14px;'
            }
          },
          exporting: {
            enabled: false
          },
          credits: {
            enabled: false
          },

          xAxis: {
            categories: ['Raised', 'Closed', 'In-Progress', 'Re-Assigned', 'Delayed']
          },

          tooltip: {
            headerFormat: '<b>{point.x}</b><br/>',
            pointFormat: 'Count: {point.y}'
          },

          series: [{
            type: 'column',
            colorByPoint: true,
            data: [
              { y: raised, color: '#2c99b8' },
              { y: closed, color: '#379a23' },
              { y: progress, color: '#f6a820' },
              { y: reassigned, color: '#df6811' },
              { y: delayed, color: 'red' }
            ],
            showInLegend: false
          }]

        };
      }
    });
  }
}
