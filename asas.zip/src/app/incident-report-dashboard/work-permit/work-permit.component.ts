import { Component, OnInit, ViewChild, Input } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { DashboardReportsService } from '../dashboard_report_service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';
// tslint:disable-next-line:prefer-const
declare let require: any;
const Highcharts = require('highcharts');
declare var $;
Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});
@Component({
  selector: 'app-work-permit',
  templateUrl: './work-permit.component.html',
  styleUrls: ['./work-permit.component.css']
})
export class WorkPermitComponent implements OnInit {
  @Input()
  PData: any;

  public show_hide = 'incident';
  work_month2;
  value: Date;
  options3: Object;
  ptwpiechartsextension: Object;
  ptwpiechartscancel: Object;
  ptwpiechartsuspended: Object;

  ptwpiechartswip: Object;
  dateValue;
  monthPass: Date;
  sentDate;
  incidents_panel = 'main';
  ctlit: any = {};

  incident_details = false;

  accidents_panel = false;
  nc_panel = 'main';
  NC_details = false;
  ptw_details = false;
  ppe_details = false;
  sub_graphs = false;

  options7: Object;

  ptwList: any = [];
  ppeData: any = [];
  todayDate: any = '';
  popType: any = '';
  acc_categories_panel = false;
  inc_categories_panel = false;
  allDashCounts: any = new Object();
  popDashCount: any = new Object();
  type = 'all';
  displayDate: any = new Date();
  selectedDate: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate_nc: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate2: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate3: any = new Date();
  mini_card = false;
  piechartloading = false;
  statusIds = [1, 6, 3];
  loading = false;
  accCategories: any = [];
  incCategories: any = [];
  accCategories2: any = [];
  incCategories2: any = [];
  kpimonthvalue: any;
  supervisorlist = [];

  line_graph = false;
  bar_graph = false;
  line_graph2 = false;
  bar_graph2 = false;
  costdetails = [];
  listofptws1 = [];
  listofptws2 = [];

  iData2: any;
  iData: any;
  options: Object;
  options2: Object;
  options4: Object;
  options5: Object;
  options6: Object;
  options8: Object;
  options9: Object;
  bar_type: Object;
  pyramidgraph: Object;
  ptwpiecharts: Object;
  ptwpiechartsforsome: Object;
  ptwpiecharts2: Object;
  ptwpiechartsraised: Object;
  ptwpiechartsclosed: Object;
  status;
  preview = false;

  options_type: Object;
  options_cost: Object;
  options_cost1: Object;
  options_supervisior: Object;
  options_location: Object;
  catetype = [];
  cat_loading4: boolean;

  config = {
    monthFormat: 'YYYY-MM',
    allowMultiSelect: false,
    enableMonthSelector: true,
    format: 'DD-MM-YYYY',
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    isMonthDisabledCallback: false,
    monthBtnFormat: 'MMM',
    max: moment(this.displayDate).format('YYYY-MM-dd')
  };

  public fromDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  public toDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  d = new Date();
  public from_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 1
    }
  };
  public to_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 31
    }
  };
  DatesForm: FormGroup;

  incident_cat_list: any = [];
  cat_loading: boolean;
  nc_list: any = [];
  nc_line_data: boolean;
  pie_graph: boolean;
  incidentGraphData = [];
  btype_graph: boolean;
  loc_graph: boolean;
  sup_graph: boolean;
  cost_graph: boolean;
  inc_table = false;
  listtoshow: any = [];
  locations: any = [];
  listonpop: any = [];
  categorytype: any;
  locationsdata: any = [];
  optionschart1;
  getcostdetailsof: any = [];
  listofinj: any = [];
  kpidtaa: any = [];
  kpichart: Object;
  kpis: any = [];
  safetylist: any = [];
  listofsafety: any = [];
  cat_loading2: boolean;
  safetytext: any;
  listofptws: any = [];
  extensionslist: any = [];
  surrender: any = [];
  approved: any = [];
  table = false;
  ptwpermit: any;
  piegraphshow = false;
  permitdata: any = [];
  questionlist: any = [];
  totaldata: any = [];
  questionlist1: any = [];
  employesslist: any = [];
  extensionlist: any = [];
  employesslist1: any = [];
  saftier_authorizer: any = [];
  ext_from_date: any = [];
  ppesgiven: any = [];
  extn_employesslist: any = [];
  status1: string;
  safetylist1: any = [];
  preview1 = false;
  ptwpermitnmae: any;
  constructor(
    public dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService
  ) {}

  ngOnInit() {
    console.log(this.PData);
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    this.sentDate = {
      resp: new Date()
    };
    this.Open_card2();
    this.getlistoflocations();
  }

  onChange(value) {
    this.sentDate = {
      resp: value
    };
    this.Open_card2();
    this.displayDate = this.sentDate.resp;
  }

  Open_card2() {
    this.loading = true;
    const selcdate = moment(this.selectedDate3).format('YYYY-MM');
    console.log(selcdate);
    this.dashService
      .get_individual_count({
        date_month: moment(this.sentDate.resp).format('YYYY-MM'),
        type: 'ptw'
      })
      .subscribe(popallCounts => {
        this.popDashCount = popallCounts.data[0];
        this.dashService.getDashReportsBARForPTW().subscribe(ptwBar => {
          this.options3 = {
            chart: {
              type: 'column',
              height: 380,
              // width: 580,
              backgroundColor: 'rgba(255, 255, 255, 0.0)'
            },
            credits: {
              enabled: false
            },
            title: {
              text: 'Work Permits',
              style: {
                color: '#f6a821',
                fontSize: '14px;'
              }
            },
            xAxis: {
              categories: ptwBar['data']['categories'],
              crosshair: true,
              labels: {
                style: {
                  fontSize: '13px',
                  color: '#d7d7d7'
                }
              }
            },
            yAxis: {
              min: 0,
              title: {
                text: 'Number',
                style: {
                  color: '#f6a821',
                  fontSize: '14px;'
                }
              }
            },
            legend: {
              itemStyle: {
                color: '#d7d7d7'
              }
            },
            tooltip: {
              headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
              pointFormat:
                '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}</b></td></tr>',
              footerFormat: '</table>',
              shared: true,
              useHTML: true
            },
            exporting: { enabled: false },

            plotOptions: {
              column: {
                pointPadding: 0.2,
                borderWidth: 0
              }
            },
            series: ptwBar['data']['series']
          };
          this.dashService
            .getPtwListByMonth({
              date_month: moment(this.sentDate.resp).format('YYYY-MM')
            })
            .subscribe(ptwList => {
              this.loading = true;
              if (!popallCounts.error) {
                this.ptwList = ptwList.data;
                console.log(this.ptwList);
                this.getgraphs();
                this.loading = false;
              } else {
                this.loading = false;
                this.ptwList = [];
              }

              this.popType = 'ptw';
              this.mini_card = false;
              this.dashService.card_show = true;
              this.dashService.card_show_two = false;
              this.dashService.card_show_three = false;
              this.incident_details = false;
              this.dashService.card_show1 = false;
              this.dashService.card_show2 = true;
              this.dashService.card_show3 = false;
              this.dashService.card_show4 = false;
              this.dashService.card_show5 = false;
              this.dashService.card_show6 = false;
              this.dashService.card_show7 = false;
              this.dashService.card_show8 = false;
              this.dashService.card_show9 = false;
              this.dashService.card_show10 = false;
              this.incidents_panel = 'main';
              this.nc_panel = 'main';
              this.accidents_panel = false;
              this.NC_details = false;
              this.ptw_details = true;
              this.ppe_details = false;
              window.scroll(0, 0);
            });
        });
      });
  }

  Graph() {
    console.log(this.incidentGraphData['cost'].length);
    this.incidentGraphData['bytype'] = _.filter(this.incidentGraphData['bytype'], function(o) {
      return o.y !== 0;
    });
    this.bar_graph2 = true;
    if (this.incidentGraphData['bytype'].length) {
      this.btype_graph = true;
    } else {
      this.btype_graph = false;
    }
    if (this.incidentGraphData['cost'].length) {
      this.cost_graph = true;
    } else {
      this.cost_graph = false;
    }
    if (this.incidentGraphData['d_i'].length) {
      this.sup_graph = true;
    } else {
      this.sup_graph = false;
    }
    if (this.incidentGraphData['location_count'].length) {
      this.loc_graph = true;
    } else {
      this.loc_graph = false;
    }
    this.options_type = {
      chart: {
        type: 'pie',
        renderTo: 'container',
        height: 163,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      // title: {
      //   text: false
      // },
      title: {
        text: false,
        style: {
          color: '#f6a821',
          fontSize: '14px;'
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Type',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        headerFormat: '<span style="font-size: 10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 3,
          borderWidth: 0
        }
      },

      series: [
        {
          name: 'Type',
          data: this.incidentGraphData['bytype']
        }
      ]
    };

    console.log(this.incidentGraphData);
    const a = [];
    let i = 0;
    const clr = ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'];
    this.incidentGraphData['d_i'].forEach(element => {
      a.push({
        y: element,
        color: clr[i++],
        lineColor: '#e3a33f'
      });
    });
    this.incidentGraphData['d_i'] = a;

    this.options_supervisior = {
      colors: ['#058DC7', 'red', 'blue', 'black'],
      chart: {
        type: 'column',
        renderTo: 'supervisior',
        height: 315,
        width: 250,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Supervisior',
        x: -10, // center
        style: {
          color: '#f6a821',
          // fontWeight: 'normal',
          fontSize: '14px;'
        }
        // align: 'center'
      },
      exporting: { enabled: false },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },
      legend: {
        enabled: false,
        color: '#FF0000',
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['d_i'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_cost = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'cost',
        height: 200,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Cost ($)',
        style: {
          color: '#f6a821',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['d_nmaes'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },

      yAxis: {
        min: 0,
        title: {
          text: 'Total Cost',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },
      exporting: { enabled: false },
      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'Total Cost: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['cost'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_location = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'location',
        height: 200,
        width: 239,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      exporting: { enabled: false },
      title: {
        text: 'Incidents by Location',
        style: {
          color: '#f6a821',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['location_names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['location_count'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.bar_type = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        height: 157,
        width: 230,
        renderTo: 'container2',
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
        //   style: {
        //     color: "#b7b7b7"
        // }
      },
      exporting: { enabled: false },
      // title: {
      //   text: false,
      //   style: {
      //     color: '#f6a821',
      //     fontWeight: 'normal',
      //     fontSize: '16px;'
      //   }
      // },
      title: {
        text: false,
        style: {
          color: '#f6a821',
          fontSize: '14px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: this.incidentGraphData['names1'],
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#d7d7d7'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of incidents',
          style: {
            color: '#d7d7d7'
          }
        },
        labels: {
          style: {
            color: '#d7d7d7'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#d7d7d7'
        }
      },
      // tooltip: {
      //   pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      // },
      series: [
        {
          lineColor: '#f00',
          // color: '#d7d7d7',
          // fillOpacity: 0.5,
          name: 'supervisior',
          data: this.incidentGraphData['val'],
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 5, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };
  }

  getlistofptwsall(event) {
    if (this.ptwList.length > 0) {
      console.log(this.ptwList);
      let raised = 0;
      let approved = 0;
      let closed = 0;
      let extension = 0;
      this.ptwList.forEach(element => {
        if (parseInt(element.raised, 0) !== 0) {
          raised = raised + element.raised;
        }
        if (parseInt(element.approved, 0) !== 0) {
          approved = approved + element.approved;
        }
        if (parseInt(element.closed, 0) !== 0) {
          closed = closed + element.closed;
        }
        if (parseInt(element.extension, 0) !== 0) {
          extension = extension + element.extension;
        }
      });
      console.log(raised, approved, closed, extension);
      this.ptwpiecharts = {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie',
          height: 300
        },
        title: {
          text: 'Work Permits'
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        credits: {
          enabled: false
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false
            },
            showInLegend: true
          }
        },
        series: [
          {
            name: 'Permits',
            data: [
              {
                name: 'Raised',
                y: raised
              },
              {
                name: 'Approved',
                y: approved
              },
              {
                name: 'Surrendered',
                y: closed
              },
              {
                name: 'Extended',
                y: extension
              }
            ],

            point: {
              events: {
                // tslint:disable-next-line:no-shadowed-variable
                click: function(event) {
                  const p = event.point;
                  // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                  this.opengraph(p.name);
                }.bind(this)
              }
            }
          }
        ]
      };
    }
  }

  opengraph(event) {
    console.log(event);
    this.table = false;
    this.status = event;
    this.piegraphshow = true;
    this.piechartloading = true;
    if (this.ptwList.length > 0) {
      const names = [];

      this.ptwList.forEach(element => {
        if (event === 'Raised') {
          console.log(names, 'rasied');
          names.push({
            name: element.work_permit,
            y: element.raised,
            type: element.type
          });
        }
        if (event === 'Approved') {
          names.push({
            name: element.work_permit,
            y: element.approved,
            type: element.type
          });
        }
        if (event === 'Surrendered') {
          names.push({
            name: element.work_permit,
            y: element.closed,
            type: element.type
          });
        }

        if (event === 'Extended') {
          names.push({
            name: element.work_permit,
            y: element.extension,
            type: element.type
          });
        }
      });
      this.ptwpiechartsforsome = {
        chart: {
          type: 'pie',
          height: 300
        },
        title: {
          text: 'Work Permits' + '-' + event
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        credits: {
          enabled: false
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false
            },
            showInLegend: true
          }
        },
        series: [
          {
            name: 'Permits',
            colorByPoint: true,
            data: names,
            point: {
              events: {
                // tslint:disable-next-line:no-shadowed-variable
                click: function(event) {
                  const p = event.point;
                  // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                  this.opemntable(p.type, p.name);
                }.bind(this)
              }
            }
          }
        ]
      };
    }
  }

  opemntable(event, name) {
    this.ptwpermit = name;
    this.listofptws1 = [];
    console.log(event, this.status);
    this.dashService
      .getapilistforpermits({
        date: moment(this.selectedDate3).format('YYYY-MM'),
        type: event,
        status: this.status
      })
      .subscribe(data => {
        console.log(data.data);
        this.listofptws1 = data.data;
        this.table = true;
      });
  }

  getquestionsbyid() {
    const body = {
      id: this.permitdata.wp_id,
      type: this.permitdata.type1
    };
    console.log('questions', body);

    this.permitservice.getQuestionbyid(body).subscribe(data => {
      console.log('Permit Data list', data);
      if (!data.error) {
        this.questionlist = data.data;
        for (let u = 0; u < this.questionlist['questions'].length; u++) {
          this.questionlist['questions'][u]['temp'] = '';
        }
        console.log('Questionlist', this.questionlist);
      } else {
        this.questionlist = [];
      }
    });
  }

  getTotaldatabyid() {
    this.loading = true;
    const body = {
      id: this.permitdata.wp_id,
      type: this.permitdata.type1
    };
    console.log('total data', body);

    this.permitservice.getTotalDatabyid(body).subscribe(data => {
      console.log('Permit Data list', data);
      if (data.error) {
        this.loading = false;
        this.totaldata = data.data;
        this.questionlist1 = data.data[0].ques_ans;
        this.employesslist = data.data[2].latest_emp;
        this.extensionlist = data.data[4].extension[0];
        this.safetylist1 = data.data[5].safety;
        this.employesslist1 = data.data[3].employess_alldata;
        this.saftier_authorizer = data.data[7].saftier_authorizer[0];
        this.ppesgiven = data.data[9].ppes_given;
        this.ext_from_date = data.data;
        for (let index = 0; index < this.ppesgiven.length; index++) {
          if (this.ppesgiven[index].stores_status === 0) {
            this.status1 = 'Requested';
          }
          if (this.ppesgiven[index].stores_status === 1) {
            this.status1 = 'Issued';
          }
          if (this.ppesgiven[index].stores_status === 2) {
            this.status1 = 'Returned';
          }
          if (this.ppesgiven[index].stores_status === 3) {
            this.status1 = 'Received';
          }
        }
        if (this.employesslist1.length > 0) {
          if (this.employesslist[0].id) {
            this.extn_employesslist = this.employesslist1.filter(
              emp => emp.id !== this.employesslist[0].id
            );
            console.log(this.extn_employesslist, 'extension');
            console.log(this.employesslist, 'execution');
          } else {
            this.extn_employesslist = [];
          }
        } else {
          this.extn_employesslist = [];
        }
        // this.surrenderedlist = data.data[4].surrender[0];
      } else {
        this.totaldata = [];
        this.questionlist1 = [];
        this.employesslist = [];
        this.extensionlist = [];
        this.safetylist = [];
        this.ext_from_date = [];
      }
    });
  }
  back() {
    this.preview = false;
  }
  back1() {
    this.preview1 = false;
  }

  gottorespectivepages(data2) {
    this.preview = true;
    this.permitdata = [];
    this.permitdata = data2;
    this.getquestionsbyid();
    this.getTotaldatabyid();
  }

  getlistofptwcategorywise(event) {
    console.log(event);
    this.piechartloading = true;
    if (this.ptwList.length > 0) {
      console.log(this.ptwList);
      const names = [];

      this.ptwList.forEach(element => {
        if (event === 'Raised') {
          names.push({
            name: element.work_permit,
            y: element.raised
          });
        }
        if (event === 'Approved') {
          names.push({
            name: element.work_permit,
            y: element.approved
          });
        }
        if (event === 'Surrendered') {
          names.push({
            name: element.work_permit,
            y: element.closed
          });
        }

        if (event === 'Extended') {
          names.push({
            name: element.work_permit,
            y: element.extension
          });
        }
      });

      this.ptwpiecharts2 = {
        chart: {
          type: 'pie',
          height: 300
        },
        title: {
          text: 'Work Permits' + '-' + event
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.y}</b>'
        },
        credits: {
          enabled: false
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false
            },
            showInLegend: true
          }
        },
        series: [
          {
            name: 'Brands',
            colorByPoint: true,
            data: names
          }
        ]
      };
    }
  }

  getgraphs() {
    const raised = [];
    const completed = [];
    const wip = [];
    const suspended = [];
    const cancel = [];
    const extension = [];
    this.ptwList.forEach(element => {
      raised.push({
        name: element.work_permit,
        y: element.raised,
        type: element.type
      });
      completed.push({
        name: element.work_permit,
        y: element.closed,
        type: element.type
      });
      wip.push({
        name: element.work_permit,
        y: element.wip,
        type: element.type
      });
      suspended.push({
        name: element.work_permit,
        y: element.suspended,
        type: element.type
      });
      cancel.push({
        name: element.work_permit,
        y: element.cancelled,
        type: element.type
      });
      extension.push({
        name: element.work_permit,
        y: element.extension,
        type: element.type
      });
    });
    console.log(raised);
    this.ptwpiechartsraised = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - Raised' + '(' + this.count(raised) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: raised,
          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'Raised');
              }.bind(this)
            }
          }
        }
      ]
    };
    this.ptwpiechartsclosed = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - Closed' + '(' + this.count(completed) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: completed,

          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'Surrendered');
              }.bind(this)
            }
          }
        }
      ]
    };

    this.ptwpiechartswip = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - WIP' + '(' + this.count(wip) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: wip,

          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'WIP');
              }.bind(this)
            }
          }
        }
      ]
    };

    this.ptwpiechartsuspended = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - Suspended' + '(' + this.count(suspended) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: suspended,

          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'Suspended');
              }.bind(this)
            }
          }
        }
      ]
    };
    this.ptwpiechartscancel = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - Cancelled' + '(' + this.count(cancel) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: cancel,

          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'Cancelled');
              }.bind(this)
            }
          }
        }
      ]
    };
    this.ptwpiechartsextension = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie',
        height: 300
      },
      title: {
        text: 'Work Permits - Extension' + '(' + this.count(extension) + ')'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      // plotOptions: {
      //   pie: {
      //     allowPointSelect: true,
      //     cursor: 'pointer',
      //     dataLabels: {
      //       enabled: false
      //     },
      //     showInLegend: true
      //   }
      // },
      series: [
        {
          name: 'Permits',
          data: extension,

          point: {
            events: {
              // tslint:disable-next-line:no-shadowed-variable
              click: function(event) {
                const p = event.point;
                // alert(p.x + " " + p.y + " " + p.company_id + " " + p.name);
                this.opemntable2(p.type, p.name, 'Extended');
              }.bind(this)
            }
          }
        }
      ]
    };
  }

  count(ty) {
    let sum = 0;
    sum = ty.reduce((s, f) => {
      return s + f.y;
    }, 0);
    return sum;
  }

  opemntable2(event2, name, statusPTW) {
    console.log(event2, name, statusPTW);
    this.ptwpermitnmae = statusPTW;
    this.listofptws2 = [];
    this.dashService
      .getapilistforpermits({
        date: moment(this.sentDate.resp).format('YYYY-MM'),
        type: event2,
        status: statusPTW
      })
      .subscribe(data => {
        console.log(data.data);
        this.listofptws2 = data.data;
        $('#popPtws').modal('show');
        this.listofptws2.forEach(element => {
          element['locationDisplay'] = this.getlocation_name(parseInt(element.location, 0));
        });
      });
  }

  getlistoflocations() {
    this.locations = [];
    this._apiService.getlistoflocats().subscribe(data => {
      if (!data.error) {
        this.locations = data.data;
      } else {
        this.locations = [];
      }
    });
  }
  getlistofptws(types) {
    this.listofptws = [];
    this.extensionslist = [];
    this.approved = [];
    this.surrender = [];
    this.preview1 = false;
    this.dashService
      .getptwslist({ type: types.id, date: moment(this.sentDate.resp).format('YYYY-MM') })
      .subscribe(data => {
        console.log(data);
        this.listofptws = data.data;
        this.extensionslist = data.data2;
        this.approved = data.approved;
        this.surrender = data.close;
      });
  }

  getlocation_name(value) {
    const lc1 = _.filter(this.locations, function(o) {
      return o.loc_id === parseInt(value, 0);
    });
    if (lc1.length > 0) {
      let lc = lc1[0];
      let loc_nam = lc.location_name;
      while (true) {
        if (lc.parent_id) {
          const pids = lc.parent_id;
          const withpids = _.filter(this.locations, function(o) {
            return o.loc_id === parseInt(pids, 0);
          });
          loc_nam = loc_nam + ', ' + withpids[0].location_name;
          lc = withpids[0];
        } else {
          loc_nam = loc_nam + '.';
          break;
        }
      }
      return loc_nam;
    }
  }
}
