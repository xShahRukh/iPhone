import { Component, OnInit, ViewChild, Input } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { DashboardReportsService } from '../dashboard_report_service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';
//import { isDate } from 'util';

declare let require: any;
const Highcharts = require('highcharts');
declare var $;
Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});

@Component({
  selector: 'app-incident-dash',
  templateUrl: './incident-dash.component.html',
  styleUrls: ['./incident-dash.component.css']
})
export class IncidentDashComponent implements OnInit {
  @Input()
  PData: any;
  ptwList: any = [];
  ppeData: any = [];
  todayDate: any = '';
  popType: any = '';
  acc_categories_panel = false;
  inc_categories_panel = false;
  allDashCounts: any = new Object();
  popDashCount: any = new Object();
  type = 'all';
  displayDate: any = new Date();
  selectedDate: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate_nc: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate2: any = moment(this.displayDate).format('YYYY-MM');
  selectedDate3: any = new Date();
  mini_card = false;
  piechartloading = false;
  statusIds = [1, 6, 3];

  incident_details = false;
  iData2: any;
  iData: any;
  options: Object;
  options2: Object;
  options3: Object;
  options4: Object;
  options5: Object;
  options6: Object;
  options7: Object;
  options8: Object;
  options9: Object;
  bar_type: Object;
  pyramidgraph: Object;
  ptwpiecharts: Object;
  ptwpiechartsforsome: Object;
  ptwpiecharts2: Object;
  status;
  preview = false;

  options_type: Object;
  options_cost: Object;
  options_cost1: Object;
  options_supervisior: Object;
  options_location: Object;
  catetype = [];
  cat_loading4: boolean;

  supervisorlist = [];

  incidents_panel = 'main';
  accidents_panel = false;
  nc_panel = 'main';
  NC_details = false;
  ptw_details = false;
  ppe_details = false;
  line_graph = false;
  bar_graph = false;
  line_graph2 = false;
  bar_graph2 = false;
  costdetails = [];
  sub_graphs = false;
  listofptws1 = [];

  config = {
    monthFormat: 'YYYY-MM',
    allowMultiSelect: false,
    enableMonthSelector: true,
    format: 'DD-MM-YYYY',
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    isMonthDisabledCallback: false,
    monthBtnFormat: 'MMM',
    max: moment(this.displayDate).format('YYYY-MM-dd')
  };

  public fromDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  public toDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  d = new Date();
  public from_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 1
    }
  };
  public to_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 31
    }
  };
  DatesForm: FormGroup;

  accCategories: any = [];
  incCategories: any = [];
  accCategories2: any = [];
  incCategories2: any = [];
  loading: boolean;
  incident_cat_list: any = [];
  cat_loading: boolean;
  nc_list: any = [];
  nc_line_data: boolean;
  pie_graph: boolean;
  ctlit: any = {};
  incidentGraphData = [];
  btype_graph: boolean;
  loc_graph: boolean;
  sup_graph: boolean;
  cost_graph: boolean;
  inc_table = false;
  listtoshow: any = [];
  locations: any = [];
  listonpop: any = [];
  categorytype: any;
  locationsdata: any = [];
  optionschart1;
  getcostdetailsof: any = [];
  listofinj: any = [];
  kpidtaa: any = [];
  kpichart: Object;
  kpis: any = [];
  kpimonthvalue: any;
  safetylist: any = [];
  listofsafety: any = [];
  cat_loading2: boolean;
  safetytext: any;
  listofptws: any = [];
  extensionslist: any = [];
  surrender: any = [];
  approved: any = [];
  table = false;
  ptwpermit: any;
  piegraphshow = false;
  permitdata: any = [];
  questionlist: any = [];
  totaldata: any = [];
  questionlist1: any = [];
  employesslist: any = [];
  extensionlist: any = [];
  employesslist1: any = [];
  saftier_authorizer: any = [];
  ext_from_date: any = [];
  ppesgiven: any = [];
  extn_employesslist: any = [];
  status1: string;
  safetylist1: any = [];
  preview1 = false;
  LocationsListStatic: any = [];
  totincidents: any;
  text4: any;
  inTrend: boolean;
  constructor(
    public dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService
  ) { }

  ngOnInit() {
    console.log(this.PData, moment(this.PData.resp).format('YYYY-MM'), '123456', 'Inspection');

    this.close_card();
    this.getlistoflocations();
    this.cat_loading4 = true;
    this.dashService.get_today_date().subscribe(todayDate => {
      this.todayDate = todayDate.data;
      // this.selectedDate = todayDate.date;

      this.dashService
        .get_individual_count({
          date_month: moment(this.PData.resp).format('YYYY-MM'),
          // this.todayDate.split('-')[0] + '-' + this.todayDate.split('-')[1],
          type: 'all'
        })
        .subscribe(allCounts => {
          this.allDashCounts = allCounts.data[0];
          this.allDashCounts['incidents'] =
            this.allDashCounts['inc_severity_normal'] +
            this.allDashCounts['inc_severity_accident'] +
            this.allDashCounts['inc_severity_near_miss'];
          this.allDashCounts['pre_incidents'] =
            this.allDashCounts['pre_inc_severity_normal'] +
            this.allDashCounts['pre_inc_severity_accident'] +
            this.allDashCounts['pre_inc_severity_near_miss'];

          this.kpimonthvalue = allCounts.data2[0].kpi;
          this.totincidents = allCounts.data3.length;
          this.cat_loading4 = false;
        });
      // this.dates_inc(this.todayDate);
      // this.incidentsgraphs();
    });
    this.DatesForm = this.fb.group({
      from_date: new FormControl('', Validators.required),
      to_date: new FormControl('', Validators.required)
    });
    const date = new Date();
    this.from_date = {
      jsdate: new Date(date.getFullYear(), date.getMonth(), 1)
    };
    this.to_date = {
      jsdate: new Date(date.getFullYear(), date.getMonth() + 1, 0)
    };
    this.Open_card();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
    console.log('dfsd', this.PData);
    this.ngOnInit();
  }

  onChange() { }

  getDateValue(val) {
    console.log(val, '123456');
  }

  dates_inc(event) {
    console.log(event.target.value, 'bshdfgjdfgsjdfgsfj');
    const dates = this.selectedDate.split('-');
    this.displayDate = dates[2] + '-' + dates[1];
    this.loading = true;

    this.dashService
      .getcostlit({
        date_month: moment(this.PData.resp).format('YYYY-MM')
      })
      .subscribe(data => {
        if (data.success) {
          this.ctlit = data.data[0];
        }
      });

    this.incidentsgraphs(moment(this.PData.resp).format('YYYY-MM'));
    this.getraisedgraphs(moment(this.PData.resp).format('YYYY-MM'));

    if (this.inc_categories_panel) {
      this.dashService
        .getDashReportsForIncidentCategories({
          date_month: this.displayDate
        })
        .subscribe(incData => {
          this.loading = true;
          if (!incData.error) {
            this.incCategories = incData.data;
            this.incCategories = _.sortBy(incData.data, 'actual_val').reverse();
            this.incCategories2 = this.incCategories;
            this.loading = false;
          } else {
            this.incCategories = [];
            this.incCategories2 = [];
            this.loading = false;
          }
        });
    }

    const body = {
      date_month: this.displayDate,
      type: this.popType
    };
    this.dashService.get_individual_count(body).subscribe(data => {
      this.popDashCount = data.data[0];
      this.kpimonthvalue = data.data2[0].kpi;
    });
    $('#monthpic').modal('hide');
    this.ptw_details = false;
    this.NC_details = false;
  }

  Open_card() {
    this.loading = true;
    this.incidents_panel = 'main';
    this.bar_graph = true;
    this.inc_categories_panel = true;
    const type = typeof this.selectedDate;
    let selcdate = '';
    if (type === 'object') {
      selcdate = this.selectedDate._i;
    } else {
      selcdate = this.selectedDate;
    }
    // const d = selcdate.split('-')[0] + '-' + selcdate.split('-')[1];
    const d = moment(this.PData.resp).format('YYYY-MM');
    this.incidentsgraphs(d);
    this.getraisedgraphs(d);
    this.getkpi();
    this.getsafety();
    this.dashService
      .get_individual_count({
        date_month: d,
        type: 'incidents'
      })
      .subscribe(popallCounts => {
        this.popDashCount = popallCounts.data[0];
        this.kpimonthvalue = popallCounts.data2[0].kpi;
        this.popType = 'incidents';
        this.mini_card = false;
        this.incident_details = true;
        this.incidents_panel = 'main';
        this.accidents_panel = false;
        this.NC_details = false;
        this.ptw_details = false;
        this.ppe_details = false;
        this.bar_graph = true;
        this.inc_categories_panel = true;
        this.acc_categories_panel = false;
        this.loading = false;
        this.line_graph = false;

        this.ptw_details = false;
      });

    this.dashService
      .getcostlit({
        date_month: d
      })
      .subscribe(data => {
        if (data.success) {
          this.ctlit = data.data[0];
        }
      });
    window.scroll(0, 0);
  }
  close_card() {
    this.mini_card = true;
    this.dashService.card_show = false;
    this.dashService.card_show_two = false;
    this.dashService.card_show_three = false;
    this.dashService.card_show1 = false;
    this.dashService.card_show2 = false;
    this.dashService.card_show3 = false;
    this.dashService.card_show4 = false;
    this.dashService.card_show5 = false;
    this.dashService.card_show6 = false;
    this.dashService.card_show7 = false;
    this.dashService.card_show8 = false;
    this.dashService.card_show9 = false;
    this.dashService.card_show10 = false;
  }

  incidents_open() {
    this.incidents_panel = 'main';
    this.nc_panel = 'main';
    this.accidents_panel = false;
  }

  accidents_open() {
    this.incidents_panel = 'main';
    this.nc_panel = 'main';
    this.accidents_panel = true;
  }

  nc_open() {
    this.incidents_panel = 'main';
    this.nc_panel = 'main';
    this.accidents_panel = false;
  }

  bar_open() {
    this.line_graph = false;
    this.bar_graph = true;
    this.inc_categories_panel = true;
    this.acc_categories_panel = false;
  }

  line_open() {
    this.incidents_panel = 'main';
    this.nc_panel = 'main';
    this.line_graph = true;
    this.bar_graph = false;
    this.inc_categories_panel = true;
    this.acc_categories_panel = false;
  }

  incident_open() {
    this.inc_categories_panel = true;
    this.acc_categories_panel = false;
  }

  accident_open() {
    this.inc_categories_panel = false;
    this.acc_categories_panel = true;
  }

  getincidentcatlist(list, date) {
    this.cat_loading = true;
    this.incident_cat_list = [];

    const body = {
      type: list.type
    };

    const type = typeof this.selectedDate;

    let selcdate = '';

    if (type === 'object') {
      selcdate = this.selectedDate._i;
      body['date_month'] = selcdate;
    } else {
      selcdate = this.selectedDate;

      body['date_month'] = selcdate.split('-')[2] + '-' + selcdate.split('-')[1];
    }

    this.dashService.getincidentcatlist(body).subscribe(data => {
      this.cat_loading = true;
      if (data.success) {
        this.incident_cat_list = data.data;
        this.cat_loading = false;
      } else {
        this.incident_cat_list = [];
        this.cat_loading = false;
      }
    });
  }

  pie_data() {
    this.pie_graph = true;
    this.nc_line_data = false;
  }

  line_data() {
    this.pie_graph = false;
    this.nc_line_data = true;
  }

  incidentsgraphs(d) {
    this.dashService
      .getincidentdashboardreport({
        date_month: d
      })
      .subscribe(data => {
        if (data.success) {
          this.sub_graphs = true;
          const names = [];
          const d_i = [];
          this.supervisorlist = data.data.supervisor;
          this.costdetails = data.data.cost;
          data.data.supervisor.forEach(element => {
            names.push(element.supervisor);
            d_i.push(element.incident_count);
          });
          this.incidentGraphData = data.data;
          const a = [];
          const cost = [];
          const d_nmaes = [];
          data.data.cost.forEach(element => {
            cost.push(element.amount);
            d_nmaes.push(element.incident_name);
          });
          this.incidentGraphData['cost'] = cost;
          this.incidentGraphData['d_nmaes'] = d_nmaes;
          this.incidentGraphData['names'] = names;
          this.incidentGraphData['d_i'] = d_i;
          const l_names = [];
          const l_count = [];
          this.locationsdata = data.data.location;
          console.log(this.locations);
          for (let index = 0; index < this.locationsdata.length; index++) {
            for (let im = 0; im < this.locations.length; im++) {
              if (this.locationsdata[index].loc_id === this.locations[im].loc_id) {
                l_names.push(this.locations[im].DispData);
                l_count.push(this.locationsdata[index].incident_count);
              }
            }
          }
          this.incidentGraphData['location_names'] = l_names;
          this.incidentGraphData['location_count'] = l_count;
          // data.data.location.forEach(element => {
          // l_names.push(element.location_name);
          // l_count.push(element.incident_count);
          // });

          const names1 = [];
          const values = [];
          this.catetype = data.data.bytype;
          data.data.bytype.forEach(element => {
            names1.push(element.name);
            values.push(element.y);
          });
          this.incidentGraphData['names1'] = names1;
          this.incidentGraphData['val'] = values;
          this.Graph();
        }
      });
  }

  Graph() {
    this.incidentGraphData['bytype'] = _.filter(this.incidentGraphData['bytype'], function (o) {
      return o.y !== 0;
    });
    this.line_graph2 = true;
    if (this.incidentGraphData['bytype'].length) {
      this.btype_graph = true;
    } else {
      this.btype_graph = false;
    }
    if (this.incidentGraphData['cost'].length) {
      this.cost_graph = true;
    } else {
      this.cost_graph = false;
    }
    if (this.incidentGraphData['d_i'].length) {
      this.sup_graph = true;
    } else {
      this.sup_graph = false;
    }
    if (this.incidentGraphData['location_count'].length) {
      this.loc_graph = true;
    } else {
      this.loc_graph = false;
    }
    this.options_type = {
      chart: {
        type: 'pie',
        renderTo: 'container',
        height: 157,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      // title: {
      //   text: false
      // },
      title: {
        text: false,
        style: {
          color: '#000',
          fontSize: '14px;'
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Type',
          style: {
            color: '#000'
          }
        },
        labels: {
          style: {
            color: '#000'
          }
        }
      },

      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      plotOptions: {
        column: {
          pointPadding: 3,
          borderWidth: 0
        }
      },

      series: [
        {
          name: 'Type',
          data: this.incidentGraphData['bytype']
        }
      ]
    };

    const a = [];
    let i = 0;
    const clr = ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'];
    this.incidentGraphData['d_i'].forEach(element => {
      a.push({
        y: element,
        color: clr[i++],
        lineColor: '#e3a33f'
      });
    });
    this.incidentGraphData['d_i'] = a;

    this.options_supervisior = {
      colors: ['#058DC7', 'red', 'blue', 'black'],
      chart: {
        type: 'column',
        renderTo: 'supervisior',
        height: 315,
        // width: 250,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Supervisior',
        x: -10, // center
        style: {
          color: '#000',
          // fontWeight: 'normal',
          fontSize: '14px;'
        }
        // align: 'center'
      },
      exporting: { enabled: false },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#000'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of Incidents',
          style: {
            color: '#000'
          }
        },
        labels: {
          style: {
            color: '#000'
          }
        }
      },
      legend: {
        enabled: false,
        color: '#FF0000',
        itemStyle: {
          color: '#000'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['d_i'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_cost = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'cost',
        height: 200,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      title: {
        text: 'Incidents by Cost (₹)',
        style: {
          color: '#000',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['d_nmaes'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#000'
          }
        }
      },

      yAxis: {
        min: 0,
        title: {
          text: 'Total Cost',
          style: {
            color: '#000'
          }
        },
        labels: {
          style: {
            color: '#000'
          }
        }
      },
      exporting: { enabled: false },
      legend: {
        enabled: false,
        itemStyle: {
          color: '#000'
        }
      },
      tooltip: {
        pointFormat: 'Total Cost: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['cost'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.options_location = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        renderTo: 'location',
        height: 200,
        // width: 239,
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
      },
      exporting: { enabled: false },
      title: {
        text: 'Incidents by Location',
        style: {
          color: '#000',
          fontWeight: 'normal',
          fontSize: '16px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: _.first(this.incidentGraphData['location_names'], 5),
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#000'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of Incidents',
          style: {
            color: '#000'
          }
        },
        labels: {
          style: {
            color: '#000'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#000'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          name: 'supervisior',
          data: _.first(this.incidentGraphData['location_count'], 5),
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 10, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };

    this.bar_type = {
      colors: ['#f6a821', '#d89625', '#c18f38', '#bb944f', '#b58e4a'],
      chart: {
        type: 'column',
        height: 157,
        // width: 230,
        renderTo: 'container2',
        backgroundColor: 'rgba(255, 255, 255, 0.0)'
        //   style: {
        //     color: "#b7b7b7"
        // }
      },
      exporting: { enabled: false },
      title: {
        text: false,
        style: {
          color: '#000',
          fontSize: '14px;'
        }
      },
      credits: {
        enabled: false
      },
      xAxis: {
        type: 'category',
        categories: this.incidentGraphData['names1'],
        labels: {
          rotation: -45,
          style: {
            fontSize: '13px',
            color: '#000'
          }
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'No of Incidents',
          style: {
            color: '#000'
          }
        },
        labels: {
          style: {
            color: '#000'
          }
        }
      },

      legend: {
        enabled: false,
        itemStyle: {
          color: '#000'
        }
      },
      tooltip: {
        pointFormat: 'No. of incidents occured: <b>{point.y}</b>'
      },
      series: [
        {
          lineColor: '#f00',
          // color: '#000',
          // fillOpacity: 0.5,
          name: 'supervisior',
          data: this.incidentGraphData['val'],
          dataLabels: {
            enabled: true,
            rotation: -90,
            color: '#FFFFFF',
            align: 'right',
            format: '{point.y}', // one decimal
            y: 5, // 10 pixels down from the top
            style: {
              fontSize: '13px'
            }
          },
          borderColor: 'transperant'
        }
      ]
    };
  }

  details(type) {
    this.categorytype = type;
    this.listonpop = [];

    if (this.categorytype === 'supervisor') {
      this.inc_table = true;
      this.listonpop = this.supervisorlist;
    }
    if (this.categorytype === 'location') {
      this.inc_table = true;
      // this.listonpop = this.locationsdata;
      this.locationsdata.forEach(element => {
        const len = _.filter(this.listonpop, function (o) {
          return o.parent_id === element.loc_id;
        });
        if (len.length) {
          element['lastAdd'] = true;
        } else {
          element['DispData'] = this.getlocation_name(element.loc_id);
          element['lastAdd'] = false;
        }
      });
      this.listonpop = _.filter(this.locationsdata, function (o) {
        return o.lastAdd === false;
      });
    }
    if (this.categorytype === 'type') {
      this.inc_table = true;
      this.listonpop = this.catetype;
    }
    if (this.categorytype === 'cost') {
      this.inc_table = true;
      this.listonpop = this.costdetails;
    }
  }

  getdartaforsupervisor(item2, type) {
    this.inc_table = false;
    this.cat_loading = true;
    let body = {};
    this.listtoshow = [];
    if (type === 'supervisor') {
      body = {
        date_month: item2.date_month,
        supervisor: item2.supervisor,
        type: type
      };
    }
    if (type === 'location') {
      body = {
        date_month: item2.date_month,
        location: item2.loc_id,
        type: type
      };
    }
    if (type === 'type') {
      body = {
        date_month: item2.date_month,
        Category: item2.name,
        type: 'Category'
      };
    }
    this.dashService.getincidentslist(body).subscribe(datd => {
      this.listtoshow = datd.data;
      this.cat_loading = false;
    });
  }
  getlocation_name(value) {
    let text = _.filter(this.LocationsListStatic, function (o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function (o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }

    return _.chain(loc_nam)
      .reverse()
      .value();
  }

  backtosuplist() {
    this.inc_table = true;
    this.listtoshow = [];
    this.getcostdetailsof = [];
    this.cat_loading = false;
  }

  piegraph(type) {
    if (type === 'pie') {
      this.line_graph2 = true;
      this.bar_graph2 = false;
    } else {
      this.line_graph2 = false;
      this.bar_graph2 = true;
    }
  }

  getcostdetails(item) {
    this.cat_loading = true;
    this.dashService
      .getcostdetails({
        date_month: item.date_month,
        incident_id: item.incident_id
      })
      .subscribe(dat => {
        this.getcostdetailsof = dat.data;
        this.inc_table = false;
        this.cat_loading = false;
        console.log(this.getcostdetailsof);
      });
  }

  getdataforinjury(item) {
    console.log(item);
    this.dashService.getinjurydtaa({ date_month: item.date_month }).subscribe(data => {
      this.listofinj = data.data;
      console.log(this.listofinj);
    });
  }

  getkpi() {
    this.dashService.getkpidata().subscribe(data => {
      this.kpis = data.data;
      console.log(this.kpidtaa);
      const months = [];
      const kpis = [];
      data.data.forEach(element => {
        months.push(element.month_name);
        if (element.kpi > 0.08) {
          kpis.push({ y: element.kpi, color: '#FF0000' });
        } else if (element.kpi === 0.08) {
          kpis.push({ y: element.kpi, color: '#ffc200' });
        } else {
          kpis.push({ y: element.kpi, color: '' });
        }
      });
      this.kpidtaa['mon'] = months;
      this.kpidtaa['kpi'] = kpis;
      console.log(this.kpidtaa['mon'], this.kpidtaa['kpi']);

      if (this.kpidtaa) {
        this.kpichart = {
          chart: {
            zoomType: 'xy',
            renderTo: 'kpicht',
            height: 315,
            backgroundColor: 'rgba(255, 255, 255, 0.0)',
            color: '#000'
          },
          credits: {
            enabled: false
          },
          legend: {
            itemStyle: {
              color: '#000'
            }
          },
          title: {
            text: 'Lost Time Injury(LTI)',
            style: {
              color: '#000',
              fontWeight: 'normal',
              fontSize: '16px;'
            }
          },
          xAxis: [
            {
              categories: this.kpidtaa['mon'],
              crosshair: true,
              labels: {
                style: {
                  fontSize: '13px',
                  color: '#000'
                }
              }
            }
          ],
          yAxis: [
            {
              title: {
                style: {
                  color: '#000'
                }
              },
              labels: {
                style: {
                  color: '#000'
                }
              }
            }
          ],
          exporting: { enabled: false },
          tooltip: {
            shared: true
          },
          series: [
            {
              name: 'LTI Actuals',
              type: 'column',
              yAxis: 0,

              title: {
                text: 'Numbers'
              },
              data: this.kpidtaa['kpi'],
              borderColor: 'transperant'
            },
            {
              name: 'LTI Target',
              type: 'spline',
              // colorByPoint: true,
              data: [0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08, 0.08],
              colors: ['#FF0000'],
              marker: {
                enabled: false
              }
            }
          ]
        };
      }
    });
  }

  getraisedgraphs(dt) {
    this.inTrend = false;
    this.dashService.getDashReportsForTypesIncidents({ date_month: dt }).subscribe(iData2 => {
      // bar

      if (!iData2.error) {
        this.loading = false;
      } else {
        this.loading = false;
      }
      const t = _.sortBy(iData2['data']['series'], function (num) {
        return num;
      });
      if (iData2['data']['series'].length) {
        this.inTrend = true;
      }
      this.options2 = {
        chart: {
          type: 'column',
          height: 295,
          backgroundColor: 'rgba(255, 255, 255, 0.0)'
        },
        credits: {
          enabled: false
        },
        legend: {
          itemStyle: {
            color: '#000'
          }
        },
        title: {
          // text: 'Type of Incidents'
          text: 'Incidents Trend',
          style: {
            color: '#000',
            fontSize: '16px;'
          }
        },
        xAxis: {
          categories: iData2['data']['categories'],
          crosshair: true,
          labels: {
            style: {
              fontSize: '13px',
              color: '#000'
            }
          }
        },
        yAxis: {
          min: 0,
          title: {
            text: 'Number',
            style: {
              color: '#000'
            }
          },
          labels: {
            style: {
              color: '#000'
            }
          }
        },

        exporting: { enabled: false },
        tooltip: {
          headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
          pointFormat:
            '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
            '<td style="padding:0"><b>{point.y}</b></td></tr>',
          footerFormat: '</table>',
          shared: true,
          useHTML: true
        },
        plotOptions: {
          column: {
            pointPadding: 0.2,
            borderWidth: 0
          }
        },
        series: iData2['data']['series']
      };
    }); // bar api
    this.dashService.getDashReportsForIncidents({ date_month: dt }).subscribe(iData => {
      console.log(iData);
      // spline
      if (!iData.error) {
        this.loading = false;
      } else {
        this.loading = false;
      }
      this.options6 = {
        chart: {
          type: 'spline',
          marginRight: 10,
          height: 295,
          backgroundColor: 'rgba(255, 255, 255, 0.0)'
          // width: 730
        },

        credits: {
          enabled: false
        },
        title: {
          text: 'Total Incidents',
          style: {
            color: '#000',
            fontWeight: 'normal',
            fontSize: '16px;'
          }
        },
        xAxis: {
          categories: _.pluck(
            _.map(iData['data'][0]['data'], function (o) {
              return _.pick(o, 'x');
            }),
            'x'
          ),
          labels: {
            style: {
              fontSize: '13px',
              color: '#000'
            }
          }
        },
        yAxis: {
          title: {
            text: 'Incidents',
            style: {
              color: '#000'
            }
          },
          labels: {
            style: {
              color: '#000'
            }
          },
          plotLines: [
            {
              value: 0,
              width: 1,
              color: '#000'
            }
          ]
        },

        exporting: { enabled: false },
        tooltip: {
          formatter: function () {
            return this.x + ' : ' + this.y + ' Total Incidents';
          }
        },

        legend: {
          enabled: false,
          itemStyle: {
            color: '#000'
          }
        },

        series: [
          {
            name: 'Incidents',
            data: _.map(iData['data'][0]['data'], function (o) {
              return _.pick(o, 'y');
            }),
            borderColor: 'transperant'
          }
        ]
      };
    }); // spline api
  }

  getkpichart() {
    console.log(this.kpis);
  }

  all_details(value) {
    console.log(value);
    const ids = [];
    $('#incidentcat2').modal('hide');
    this.dashService
      .getdataforsimilar({
        similarIncident: value.similarIncident,
        inc_id: value.incident_id
      })
      .subscribe(async ohs => {
        const t = ohs.data;
        await t.forEach(element => {
          ids.push(element.incident_id);
        });
        value.incident_id = ids.toString();
        console.log(t);

        this._apiService.incidentObj = await value;
        this._apiService.page = '';
        this.router.navigate(['incidentview']);
      });
    console.log(value);

    // this.router.navigate(['incidentview']);
  }

  getsafety() {
    this.dashService.getInjuryList().subscribe(data => {
      this.safetylist = data.data2;
      const d = data.data;
      console.log(_.pairs(d));
      console.log(_.pairs(this.safetylist), 'hsdifgh;sidlghsuildfhgsfdklguh');

      this.pyramidgraph = {
        chart: {
          type: 'pyramid',
          renderTo: 'pyramidchart',
          height: 342
        },
        title: {
          text: 'Sales pyramid',
          x: -50,
          style: {
            color: '#000',
            fontWeight: 'normal',
            fontSize: '16px;'
          }
        },
        plotOptions: {
          series: {
            dataLabels: {
              enabled: true,
              format: '<b>{point.name}</b> ({point.y:,.0f})',
              color: 'black',
              softConnector: true
            },
            center: ['40%', '50%'],
            width: '80%',
            borderColor: 'transperant'
          }
        },
        legend: {
          enabled: false,
          itemStyle: {
            color: '#000'
          }
        },
        series: [
          {
            name: 'Unique users',
            data: [
              ['Risk_behaviours', 300],
              ['Hospitalization', 2],
              ['First_Aid_Cases', 6],
              ['Fatalities', 16],
              ['near_miss', 15]
            ],
            borderColor: 'transperant'
          }
        ]
      };
    });
  }

  getdataforsafety(type) {
    this.cat_loading2 = true;
    this.safetytext = type;
    this.listofsafety = [];

    if (type === 'near_miss') {
      this.text4 = 'Near Miss';
    } else if (type === 'fatalities') {
      this.text4 = 'Fatalities';
    } else if (type === 'First_Aid_Cases') {
      this.text4 = 'First-Aid';
    } else {
      this.text4 = type;
    }
    this.dashService.getdataforsafety1({ type: type }).subscribe(data => {
      if (data.success) {
        this.cat_loading2 = false;
        this.listofsafety = data.data;
      }
    });
  }

  back() {
    this.preview = false;
  }

  back1() {
    this.preview1 = false;
  }

  ChangeDate($event) {
    console.log($event);
  }

  getlistoflocations() {
    this.locations = [];
    this.dashService.getlistoflocats().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        console.log(this.LocationsListStatic);
        data.data.forEach(element => {
          const len = _.filter(response, function (o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['DispData'] = this.getlocation_name(element.loc_id);
            element['lastAdd'] = false;
          }
        });
        this.locations = _.filter(response, function (o) {
          return o.lastAdd === false;
        });
        console.log(this.locations, 'szfds');

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }
}
