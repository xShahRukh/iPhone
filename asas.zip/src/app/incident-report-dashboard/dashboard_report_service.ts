import { Injectable } from '@angular/core';
import { ApiService } from '../common/services/api.service';
import { DashboardReportsSettings } from './dashboardReports.settings';
import { environment } from '../../environments/environment';
import { IncidentSettings } from '../intial_incidents/incidents.settings';

@Injectable()
export class DashboardReportsService {
  card_show: Boolean = false;
  card_show_two: Boolean = false;
  card_show_three: Boolean = false;

  card_show1: Boolean = false;
  card_show2: Boolean = false;
  card_show3: Boolean = false;
  card_show4: Boolean = false;
  card_show5: Boolean = false;
  card_show6: Boolean = false;
  card_show7: Boolean = false;
  card_show8: Boolean = false;
  card_show9: Boolean = false;
  card_show10: Boolean = false;

  constructor(private _apiService: ApiService) { }

  // get_dash_reports_for_incidents
  getDashReportsForIncidents(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENTS_LIST_12,
      'post',
      body
    );
  }

  // get_dash_reports_for_accident_categories
  getDashReportsForAccidentCategories(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENT_ACCIDENT_CATEGORIES,
      'post',
      body
    );
  }

  // get_dash_reports_for_incident_categories
  getDashReportsForIncidentCategories(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENT_INCIDENT_CATEGORIES,
      'post',
      body
    );
  }

  // get_dash_reports_for_types_of_incidents
  // getDashReportsForTypesIncidents() {
  //   return this._apiService.callApi(
  //     DashboardReportsSettings.API.DASH_INCIDENT_TYPES_LIST_12,
  //     'get',
  //     {}
  //   );
  // }
  getDashReportsForTypesIncidents(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENT_TYPES_LIST_12,
      'post',
      body
    );
  }
  // get_dash_reports_for_types_of_incidents
  getDashReportsForSeverityIndividualIncidents() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENT_SEVERITY_INDIVIDUAL_LIST_12,
      'get',
      {}
    );
  }
  // get_dash_reports_for_nc
  getDashReportsForNC() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_NC_LIST,
      'get',
      {}
    );
  }
  // get_dash_reports_for_ptw
  getDashReportsBARForPTW() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_PTW_LIST,
      'get',
      {}
    );
  }

  // get all list of ptw's in month
  getPtwListByMonth(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_PTW_LIST_TABLE,
      'post',
      body
    );
  }

  // get_dash_reports_for_ppe
  getDashReportsForPPE() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_PPE_LIST,
      'get',
      {}
    );
  }

  get_today_date() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_GET_TODAY_DATE,
      'get',
      {}
    );
  }

  getPpePIEForDashReports(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_STATUS_PIE,
      'post',
      body
    );
  }

  getDashStatusBarNC() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_STATUS_BAR,
      'get',
      {}
    );
  }

  getDashStatusStackNC(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_STATUS_STACK,
      'post',
      body
    );
  }
  // get_individual_count() {
  //   return this._apiService.callApi(
  //     DashboardReportsSettings.API.DASH_INDIVIUAL_COUNT,
  //     "get",
  //     {}
  //   );
  // }
  get_individual_count(value) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INDIVIUAL_COUNT,
      'post',
      value
    );
  }

  getDepartlist(dATE) {
    console.log(dATE);

    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_DEPT_GET_LIST + dATE,
      'get',
      {}
    );
  }

  getErgonomicsData(id, date) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_GET_ERGONOMICS_DATA + id + '/' + date,
      'get',
      {}
    );
  }
  getEroglist() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_EROG_LIST,
      'get',
      {}
    );
  }

  getNotificationlist(id) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_NOTIFICATIONS_LIST + id,
      'get',
      {}
    );
  }

  // rohith
  getdashboardreports(date) {
    console.log(DashboardReportsSettings.API.DASH_REPORTS_DASHBOARD + date);
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_REPORTS_DASHBOARD + date,
      'get',
      {}
    );
  }

  getChartsreports(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_REPORTS_CHARTS,
      'post',
      body
    );
  }

  getAuditReports(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardAuditCount/' + date,
      'get',
      {}
    );
  }

  getGatepass(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardGatepass/' + date,
      'get',
      {}
    );
  }

  getExamList(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardExamList/' + date,
      'get',
      {}
    );
  }

  getTraining(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'getDashboardTraining/' + date,
      'get',
      {}
    );
  }

  getTrainingModule(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardTrainingModule/' + date,
      'get',
      {}
    );
  }

  getdashboardDepartments() {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardDepartments',
      'get',
      {}
    );
  }

  getdashboardcounts(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'getAuditGatepassCount/' + date,
      'get',
      {}
    );
  }

  getdashboardtemplatecounts(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'ergonomics/dashboarddataCOUNT/' + date,
      'get',
      {}
    );
  }

  getdashboardnotificationcounts(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'notification/notificationsCount/' + date,
      'get',
      {}
    );
  }

  getincidentcatlist(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENT_CAT_LIST,
      'post',
      body
    );
  }

  getncdatalist(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_NC_DATA_LIST,
      'post',
      body
    );
  }

  getcostlit(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENTS_COST_LIT,
      'post',
      body
    );
  }

  getincidentdashboardreport(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.DASH_INCIDENTS_REPORT_DETAILS,
      'post',
      body
    );
  }

  getincidentslist(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETLIST_OF_INCIDENTS,
      'post',
      body
    );
  }
  getlistoflocats() {
    return this._apiService.callApi(
      IncidentSettings.API.GET_MAJOR_LOCATIONS,
      'get',
      {}
    );
  }
  getcostdetails(bosy) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETCOST_DETAILS,
      'post',
      bosy
    );
  }

  getinjurydtaa(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETINJURIES,
      'post',
      body
    );
  }
  getkpidata() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETKPIDATA,
      'get',
      {}
    );
  }
  getInjuryList() {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETLISTFOR_INJURIES,
      'get',
      {}
    );
  }
  getdataforsafety1(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETDATA_SAFETY,
      'post',
      body
    );
  }
  getptwslist(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETPTWLITS,
      'post',
      body
    );
  }

  getapilistforpermits(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GETAPISFORPERMITS,
      'post',
      body
    );
  }

  // Inspection Reports APis
  getInspectionReport(value) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GET_INSPECTION_REPORTS + '/' + value,
      'get',
      {}
    );
  }

  // get location details
  getListOfLocations() {
    const body = {};
    return this._apiService.callApi(
      DashboardReportsSettings.API.GET_LOCATIONS,
      'GET',
      body
    );
  }

  getdataforsimilar(body) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GET_DATA_FOR_SIMILAR,
      'POST',
      body
    );
  }

  getScheduleData(values: any) {
    const body = values;
    console.log(body);
    return this._apiService.callApi(
      DashboardReportsSettings.API.GET_SCHEDULE_DATA,
      'POST',
      body
    );
  }

  getDataFormNewApi(value) {
    return this._apiService.callApi(
      DashboardReportsSettings.API.GET_NC_MONTHLY_REPORT + value, 'GET', ''
    );
  }
}
