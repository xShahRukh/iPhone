import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IncidentsService } from './incidents.services';
import { ApiService } from '../../common/services/api.service';

@Component({
  selector: 'app-incidents-causes',
  templateUrl: './incidents-causes.component.html',
  styleUrls: ['./incidents-causes.component.css']
})
export class IncidentsCausesComponent implements OnInit {
  incidentsCause: any = [];
  category_code = '';
  category_name = '';
  type_status: Number = 0;
  loading: Boolean = true;
  dataItem: any = new Object();
  incidentcauseform: FormGroup;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  ic_id;

  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public fb: FormBuilder,
    public incidservice: IncidentsService
  ) {}

  ngOnInit() {
    this.getIncidentsCauses();
    this.incidentcauseform = this.fb.group({
      cause_code: ['', Validators.required],
      cause: ['', Validators.required],
      status: [''],
      ic_id: ['']
    });
  }
  getIncidentsCauses() {
    this.incidservice.getIncidentsCauses().subscribe(data => {
      if (!data.error) {
        this.incidentsCause = data.data;
        this.loading = false;
      } else {
        this.incidentsCause = [];
      }
    });
  }

  addNewIncCau() {
    console.log(this.incidentcauseform.value, this.category_name, 'add');

    const body = {
      cause: this.incidentcauseform.value.cause,
      cause_code: this.incidentcauseform.value.cause_code,
      status: '1',
      ic_id: null
    };
    console.log(body);

    this.incidservice.addNewIncidentCause(body).subscribe(addData => {
      console.log(addData);
      this.loading = true;

      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');
        this.getIncidentsCauses();
        this.incidentcauseform.reset();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editCategory(item) {
    this.incidentcauseform.patchValue(item);
    // this.type_status = item.status;
    this.ic_id = item.ic_id;
  }

  editIncCause() {
    console.log(this.category_code, this.category_name, 'add');

    const body = {
      cause: this.incidentcauseform.value.cause,
      cause_code: this.incidentcauseform.value.cause_code,
      status: this.incidentcauseform.value.status,
      ic_id: this.ic_id
    };

    this.incidservice.addNewIncidentCause(body).subscribe(editData => {
      console.log(editData);
      this.loading = true;
      if (!editData.error) {
        // success toaster
        this.toastr.successToastr(editData.message, 'Success!');
        this.getIncidentsCauses();
        this.incidentcauseform.reset();
      } else {
        // warning toaster
        this.toastr.warningToastr(editData.message, 'Warning!');
      }
    });
  }
}
