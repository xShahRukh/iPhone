import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { AppSettings } from '../../app.settings';
import { IncidentSettings } from '../incidents.settings';

@Injectable()
export class IncidentsService {
  constructor(private _apiService: ApiService) {}

  // ADD_DOCUMENT_DETAI
  addNewIncidentCause(body) {
    return this._apiService.callApi(
      IncidentSettings.API.ADD_INCIDENT_CAUSES,
      'post',
      body
    );
  }

  // GET_INCIDENTS_LIST
  getIncidentsCauses() {
    const body = {};
    return this._apiService.callApi(
      IncidentSettings.API.GET_INCIDENTS_LIST,
      'get',
      body
    );
  }
}
