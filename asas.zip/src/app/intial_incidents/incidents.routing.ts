import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { IncidentsCausesComponent } from './incidents-causes/incidents-causes.component';
import { AuthGuard } from '../common/guards/auth.guard';
import { IncidentsActionsComponent } from './incidents-actions/incidents-actions.component';
import { IncidentsHospitalreportComponent } from './incidents-hospitalreport/incidents-hospitalreport.component';
import { IncidentsFirstaidComponent } from './incidents-firstaid/incidents-firstaid.component';
import { IncidentsViewComponent } from './incidents-view/incidents-view.component';
import { IncidentsAddComponent } from './incidents-add/incidents-add.component';
import { IncidentsInvestigationComponent } from './incidents-investigation/incidents-investigation.component';
import { IncidentsRaisedBymeComponent } from './incidents-raised-byme/incidents-raised-byme.component';
import { WorkHoursComponent } from './work-hours/work-hours.component';
import { GroupingIncidentsComponent } from './grouping-incidents/grouping-incidents.component';
import { IncidentsListManagerComponent } from './incidents-list-manager/incidents-list-manager.component';
import { IncidentsDashboardComponent } from './incidents-dashboard/incidents-dashboard.component';
import { KpiTargetsComponent } from './kpi-targets/kpi-targets.component';
import { RaisedIncidentComponent } from './raised-incident/raised-incident.component';
import { RaiseIncidentsPart2Component } from './raise-incidents-part2/raise-incidents-part2.component';
import { RaisedIncidentPart3Component } from './raised-incident-part3/raised-incident-part3.component';
import { PTWSectionOneComponent } from './PTW-section-one/PTW-section-one.component';
import { IncidentDashboardComponent } from "./incident-dashboard/incident-dashboard.component";

const incidentroutes: Routes = [
  { path: "incidentscauses", component: IncidentsCausesComponent },
  {
    path: "incidentsaction",
    component: IncidentsActionsComponent
  },
  {
    path: "incidentsinvestigation",
    component: IncidentsInvestigationComponent
  },
  {
    path: "incidentsadd",
    component: IncidentsAddComponent
  },
  {
    path: "incidentsview",
    component: IncidentsViewComponent
  },
  {
    path: "incidentsfirstaid",
    component: IncidentsFirstaidComponent
  },
  {
    path: "incidentshospitalreport",
    component: IncidentsHospitalreportComponent
  },
  {
    path: "incidentraisedlistbyme",
    component: IncidentsRaisedBymeComponent
  },
  {
    path: "workhours",
    component: WorkHoursComponent
  },
  {
    path: "groupingIncidents",
    component: GroupingIncidentsComponent
  },
  {
    path: "listpageofmr",
    component: IncidentsListManagerComponent
  },
  {
    path: "incidents_dashboard",
    component: IncidentsDashboardComponent
  },
  {
    path: "kpi_targets",
    component: KpiTargetsComponent
  },
  {
    path: "report_dashboard",
    component: IncidentDashboardComponent
  },
  {
    path: "report_dashboard",
    component: IncidentDashboardComponent
  },
  {
    path: "RIMUK0001V1",
    component: RaisedIncidentComponent
  },
  {
    path: "firstincident/:incident_id",
    component: RaisedIncidentComponent
  },
  {
    path: "RIMUK0002V1",
    component: RaiseIncidentsPart2Component
  },
  {
    path: 'finalincident/:id',
    component: RaiseIncidentsPart2Component
  },
  {
    path: "RIMUK0003V1",
    component: RaisedIncidentPart3Component
  },
  {
    path: 'thirdincident/:id',
    component: RaisedIncidentPart3Component
  },
  {
    path: 'PTW-section-one',
    component: PTWSectionOneComponent
  },

  { path: "", redirectTo: "incidents_dashboard", pathMatch: "full" },
  { path: "**", redirectTo: "incidents_dashboard", pathMatch: "full" }
];

export const incidentRouting: ModuleWithProviders = RouterModule.forChild(
  incidentroutes
);
