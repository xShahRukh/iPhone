import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import {
  DomSanitizer,
  BrowserModule,
  SafeResourceUrl
} from '@angular/platform-browser';
import * as _ from 'underscore';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { GroupIncidentsService } from './grouping-incidents.service';
import { ApiService } from '../../common/services/api.service';
import * as moment from 'moment';

@Component({
  selector: 'app-grouping-incidents',
  templateUrl: './grouping-incidents.component.html',
  styleUrls: ['./grouping-incidents.component.css']
})
export class GroupingIncidentsComponent implements OnInit {
  loading: boolean;
  incidentsList = [];
  incidentsListDisplay = [];
  LocationsListStatic = [];
  underLocationsList = [];

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'created_at';
  public sortOrder = 'desc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public toastr: ToastrManager,
    public _groupService: GroupIncidentsService,
    public _apiService: ApiService
  ) {}

  async ngOnInit() {
    await this.getIncidentDetails();
  }

  async getIncidentDetails() {
    await this._groupService.getIncidents_list().subscribe(async docs => {
      this.loading = false;
      if (!docs.error) {
        this.incidentsList = await docs.data;
        console.log(this.incidentsList);
        await this.getAllLocations();
      } else {
        this.incidentsList = await [];
      }
    });
  }

  getAllLocations() {
    this._groupService.getlistoflocat().subscribe(data => {
      if (!data.error) {
        this.LocationsListStatic = data.data;
        if (
          this._apiService.findIndexInData1({
            data: this._apiService.rolesArray,
            where1: 'module_name',
            where2: 'role_name',
            what1: 'Incidents',
            what2: 'MR'
          }) > -1
        ) {
          this.underLocationsList = data.data;
        } else {
          const ListDisp = _.filter(this.LocationsListStatic, function(o) {
            return o.coordinator === sessionStorage.getItem('userid');
          });
          this.loading = false;
          this.underLocationsList = ListDisp;
          this.UnderLocations(ListDisp);
          this.underLocationsList = _.uniq(this.underLocationsList);
        }

        let z = [];
        this.underLocationsList.forEach(element => {
          const filterInc = _.filter(this.incidentsList, function(o) {
            return parseInt(o.incident_location, 0) === element.loc_id;
          });
          const list = [z, filterInc];
          z = _.reduceRight(
            list,
            function(a, b) {
              return a.concat(b);
            },
            []
          );
        });
        this.incidentsListDisplay = z;
        this.incidentsListDisplay.forEach(element => {
          element['checked'] = 0;
          element['disabled'] = false;
        });
        const withzero = _.filter(this.incidentsListDisplay, function(o) {
          return o.similarIncident === 0;
        });
        const withoutzero = _.filter(this.incidentsListDisplay, function(o) {
          return o.similarIncident !== 0;
        });
        const withUnic = _.uniq(withoutzero, 'similarIncident');
        const list1 = [withzero, withUnic];
        let c = [];
        c = _.reduceRight(
          list1,
          function(a, b) {
            return a.concat(b);
          },
          []
        );
        console.log(c);

        this.incidentsListDisplay = _.filter(c, function(k) {
          return parseInt(k.status, 0) === 1 || parseInt(k.status, 0) === 2;
        });
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  async UnderLocations(value) {
    await value.forEach(async element => {
      const ListAgain = _.filter(this.LocationsListStatic, function(o) {
        return parseInt(o.parent_id, 0) === parseInt(element.loc_id, 0);
      });
      this.UnderLocations(ListAgain);
      this.underLocationsList.push(element);
    });
  }

  getlocation_name(value) {
    let text = _.filter(this.LocationsListStatic, function(o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function(o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  all_details(value) {
    if (value.similarIncident) {
      const check = _.filter(this.incidentsList, function(o) {
        return (
          parseInt(o.similarIncident, 0) === parseInt(value.similarIncident, 0)
        );
      });
      const abc = _.pluck(check, 'incident_id');
      value['incident_id'] = abc.toString();
    }
    this._apiService.incidentObj = value;
    this._apiService.page = 'groupingIncidents';
    this.router.navigate(['intial_incidents/incidentsview']);
  }

  changeVal(value) {
    const id = _.findLastIndex(this.incidentsListDisplay, {
      incident_number: value.incident_number
    });
    this.incidentsListDisplay[id].checked = !this.incidentsListDisplay[id]
      .checked;
    console.log(value);
    if (this.incidentsListDisplay[id].checked) {
      // this.incidentsListDisplay[id].disabled = !this.incidentsListDisplay[id]
      //   .disabled;
      const check = _.filter(this.incidentsListDisplay, function(o) {
        return (
          parseInt(o.incident_location, 0) ===
            parseInt(value.incident_location, 0) &&
          moment(o.incident_time).format('YYYY-MM-DD') ===
            moment(value.incident_time).format('YYYY-MM-DD')
        );
      });
      this.incidentsListDisplay.forEach(element => {
        element.disabled = true;
      });
      check.forEach(element => {
        const idCheck = _.findLastIndex(this.incidentsListDisplay, {
          incident_number: element.incident_number
        });
        this.incidentsListDisplay[idCheck].disabled = false;
      });
      console.log(check, '147852');
    } else {
      const sim = _.filter(this.incidentsListDisplay, function(o) {
        return o.checked === 1 || o.checked === true;
      });
      if (!sim.length) {
        this.incidentsListDisplay.forEach(element => {
          element.disabled = false;
        });
      }
    }
  }

  async LinkSimilar() {
    const sim = await _.filter(this.incidentsListDisplay, function(o) {
      return o.checked === 1 || o.checked === true;
    });
    const highStatus = _.max(sim, function(val) {
      return val.status;
    });
    console.log(highStatus);

    if (sim.length <= 1) {
      return this.toastr.warningToastr('Please select Incidents');
    }
    const body = [];
    const randNo = Math.floor(Math.random() * 999999999);
    await sim.forEach(async element => {
      if (element.similarIncident !== 0) {
        const AllWithIds = await _.filter(this.incidentsList, function(o) {
          return o.similarIncident === element.similarIncident;
        });
        await AllWithIds.forEach(async response => {
          await body.push({
            incident_id: response.incident_id,
            status: highStatus.status,
            similarIncident: randNo
          });
        });
      }
      await body.push({
        incident_id: element.incident_id,
        status: highStatus.status,
        similarIncident: randNo
      });
    });
    await this._groupService
      .groupSimilarIncident({ data: body })
      .subscribe(async data => {
        if (data.success) {
          await this.toastr.successToastr(data.message);
          this.LocationsListStatic = await [];
          this.incidentsList = await [];
          this.incidentsListDisplay = await [];
          await this.getIncidentDetails();
          // await this.getAllLocations();
        } else {
          this.toastr.errorToastr(data.message);
        }
      });
  }
}
