import { Injectable, Output, EventEmitter } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { ApiService } from '../../common/services/api.service';
import { IncidentSettings } from '../incidents.settings';

@Injectable()
export class GroupIncidentsService {
  constructor(private _apiService: ApiService, public _http: Http) { }

  // get location details
  getlistoflocat() {
    const body = {};
    return this._apiService.callApi(
      IncidentSettings.API.GET_MAJOR_LOCATIONS,
      'GET',
      body
    );
  }

  // get incident details
  getIncidents_list() {
    const body = {};
    return this._apiService.callApi(
      IncidentSettings.API.GET_INCIDENTS_LIST_MR,
      'get',
      body
    );
  }

  // Group similar Incidents
  groupSimilarIncident(value) {
    return this._apiService.callApi(
      IncidentSettings.API.GROUP_SIMILAR_INCIDENT,
      'post',
      value
    );
  }
}
