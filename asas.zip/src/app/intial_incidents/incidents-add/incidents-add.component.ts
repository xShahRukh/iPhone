import { IMyDpOptions, IMyDateModel } from "mydatepicker";
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl,
  FormArray
} from "@angular/forms";
import { CustomValidators } from "ng2-validation";
import { ToastrManager } from "ng6-toastr-notifications";
// import { GenericValidator } from "../common/generic-validator";
import { Router, ActivatedRoute } from "@angular/router";
import { ApiService } from "../../common/services/api.service";
import { FileUploader, FileItem } from "ng2-file-upload";
import {
  DomSanitizer,
  BrowserModule,
  SafeResourceUrl
} from "@angular/platform-browser";
import { GenericValidator } from "../../common/generic-validator";
import { IncidentsAddService } from "./incidents-add.service";
import { AppSettings } from "../../app.settings";
import { CalendarModule } from "primeng/calendar";
import * as _ from "underscore";
import * as moment from "moment";
import { environment } from "../../../environments/environment";
import { IncidentSettings } from "../incidents.settings";
import { LoactionService } from "../../locations/locations.service";
import { IncidentsListManagerService } from "../incidents-list-manager/incidents-list-service";
declare var $;

@Component({
  selector: "app-incidents-add",
  templateUrl: "./incidents-add.component.html",
  styleUrls: ["./incidents-add.component.css"]
})
export class IncidentsAddComponent implements OnInit {
  LocationsListStatic: any;
  injureslist1: any = [];
  const_injureslist1: any = [];
  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _incidentaddservice: IncidentsAddService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer,
    public _incidents_list_mr_service: IncidentsListManagerService,
    public locationservice: LoactionService
  ) {
    this.img_url = environment.api_image_url;
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      reg_no: {
        required: "Registration No is required"
      },
      service_code: {
        required: "Service Code is required"
      }
    };
    // let a = new Date(Date.now());
    // this.incident_date = a;
  }
  allcauses: any = [];
  helped_data: any = [];
  helped_date_selected: any = [];
  first_aid_data: any = [];
  value: any = "";
  img_url: string;
  opend_popup_det: any;
  injureslist: any = [];
  const_injureslist: any = [];
  dropdownSettings_inj: any = [];
  dropdownSettings_help: any = [];
  dropdownSettings_Firstaid: any = [];
  dropdownSettings_EMP: any = [];
  selected_parts: any = [];
  dropdownSettingswitness: any = [];
  witness_data: any = [];
  supervisor_List: any = [];
  dropdownSettingssupervisor: any = [];
  supervisordata_form: any = [];
  incident_time: Date;
  injureslist_one: any = [];
  injureslist_two: any = [];
  causesList: any = [];
  causes: any = [];
  firstaidquestion: boolean;
  hospitalquestion: boolean;
  firstaidquestion1: boolean;
  witnessselect: boolean;
  hospitalquestion1: boolean;
  document_id = "";
  doc_category = "";
  doctype = "";
  doc_type = "";
  item: any = {};
  doccatname: any;
  doctypename: any;
  imagePath: any = "";
  binaryString: any;
  ImgCode: any;
  text: string;

  text_to_show: any;
  base64_data: any = "";
  type: any = "";
  type_3: any;
  type_2: any;
  type_1: any;
  proof_1: any = "";
  proof_2: any = "";
  proof_3: any = "";
  base64textString: any;
  severity_type: any = "normal";
  cause_frm_data: any;
  cause_arr: any = [];
  b = [];
  count = 0;
  to_push = [];
  selectedItems = [];
  picName: any = [];
  file_exist: any;
  fileformat;
  file_error = false;

  public step1 = true;
  public step2 = false;
  public step3 = false;
  public step4 = false;
  public step5 = false;
  public step6 = false;
  showDet = {
    det: "show",
    causes: "show",
    inj: "show",
    damage: "show",
    witness: "show",
    first_aid: "show"
  };
  public editsection: boolean;
  public addsection: boolean;
  public showInput: boolean;
  public openoverwritebtn = true;
  public closeoverwritebtn: boolean;
  // date picker options
  d = new Date();
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: "dd mmm yyyy",
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: this.d.getDate() + 1
    }
  };
  public incident_date: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: this.d.getDate()
    }
  };

  @ViewChild("selectedFile", {static:false})
  selectedFile: ElementRef;

  incidentForm: FormGroup;
  cause_form: FormGroup;
  emp_inj_parts: FormGroup;
  showButton = true;
  doctypesList: any;
  categoriesList: any;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  public loading: Boolean = false;
  locations: any = [];
  locationsupervisor: any = [];
  file: File;
  body = {};
  validationCheck = {
    det: true,
    causes: false,
    first_aid: false,
    inj: false,
    damage: false,
    witness: false
  };

  ngOnInit() {
    this.create_form();
    this._apiService.incidentAddFormCheck = true;

    this.emp_inj_parts = this.fb.group({
      Head: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Face: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Neck: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Upper_Back: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Lower_Back: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Chest: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Abdomen: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Pelvis_Groin: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Lips: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Teeth: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Tongue: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Nose: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Fingers: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      Toes: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Shoulder: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Shoulder: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_ArmPit: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_ArmPit: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_UpperArm: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_UpperArm: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_LowerArm: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_LowerArm: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Elbow: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Elbow: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Wrist: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Wrist: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Hand: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Hand: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Buttocks: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Buttocks: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Hip: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Hip: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Thigh: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Thigh: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_LowerLeg: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_LowerLeg: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Knee: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Knee: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Ankle: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Ankle: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Eyes: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Eyes: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      l_Ears: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      r_Ears: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      first_aid_by: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      first_aid: new FormControl({ value: "0", disabled: false }, [
        Validators.required
      ]),
      hospital: new FormControl({ value: "0", disabled: false }, [
        Validators.required
      ]),
      hospital_name: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      doctor_name: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      doctor_specification: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      fatal: new FormControl({ value: "0", disabled: false }, [
        Validators.required
      ])
    });

    this.dropdownSettings_help = {
      singleSelection: false,
      text: "Select Help Provided by",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class",
      badgeShowLimit: 5
    };

    this.dropdownSettingswitness = {
      singleSelection: false,
      text: "Select witness",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class",
      badgeShowLimit: 5
    };

    this.dropdownSettings_inj = {
      text: "Select Employee",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class",
      singleSelection: true
    };

    this.dropdownSettings_Firstaid = {
      text: "Select Employee",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class",
      singleSelection: true
    };
    this.dropdownSettings_EMP = {
      text: "Select Employee",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: true,
      classes: "myclass custom-class",
      singleSelection: true
    };
    this.getIncidentCauses();
    this.getInjuries_witness();
    this.get_supervisor_list();
    this.getlistoflocations();
    this.injureslist_one = AppSettings.Injures_one;
    this.injureslist_two = AppSettings.Injures_two;
    console.log("Doc Form", this.incidentForm);
    this.movetostep1();
    this.getinvestigatorslist();
    this.helped_data = [];
    const help_1 = { id: "Ambulance", itemName: "Ambulance" };
    const help_2 = { id: "Company Vechile", itemName: "Company Vechile" };
    const help_3 = { id: "Private Vechile", itemName: "Private Vechile" };
    const help_4 = { id: "Patrol", itemName: "Patrol" };
    this.helped_data.push(help_1);
    this.helped_data.push(help_2);
    this.helped_data.push(help_3);
    this.helped_data.push(help_4);
    this.changeStatusType("near miss");
    this.incidentForm.patchValue({
      incident_type: "near miss"
    });
    // this.helped_date_selected.push({
    //   id: 'Company Vechile',
    //   itemName: 'Company Vechile'
    // });
  }

  create_form() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const incident_name = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const incident_date = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const incident_time = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const incident_type = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const work_unit = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const incident_location = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const city = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const state = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const pincode = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const supervisor = new FormControl({ value: [], disabled: false });
    const first_aid = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const hospital = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const hospital_name = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const doctor_name = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const doctor_specification = new FormControl(
      { value: "", disabled: false },
      [Validators.required]
    );
    const incident_description = new FormControl(
      { value: "", disabled: false },
      [Validators.required]
    );
    const witness = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const incident_img_type = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const incident_img = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const severity_type = new FormControl(
      { value: "normal", disabled: false },
      [Validators.required]
    );

    // new
    const police_complaint = new FormControl({ value: "No", disabled: false }, [
      Validators.required
    ]);
    const PoliceStationName = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const Fatal = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const FatalCount = new FormControl({ value: "", disabled: false }, [
      Validators.required
    ]);
    const IncidentLevel = new FormControl({ value: "Minor", disabled: false }, [
      Validators.required
    ]);
    const AnimalKilled = new FormControl({ value: "No", disabled: false }, [
      Validators.required
    ]);
    const RepeatedIncident = new FormControl({ value: "No", disabled: false }, [
      Validators.required
    ]);
    const HelpedBy = new FormControl({ value: "", disabled: false });
    const Evacuation = new FormControl({ value: "No", disabled: false }, [
      Validators.required
    ]);

    this.incidentForm = this.fb.group({
      incident_name: incident_name,
      incident_date: incident_date,
      incident_time: incident_time,
      incident_type: incident_type,
      work_unit: work_unit,
      incident_location: incident_location,
      city: city,
      state: state,
      pincode: pincode,
      supervisor: supervisor,
      first_aid: first_aid,
      hospital: hospital,
      hospital_name: hospital_name,
      doctor_name: doctor_name,
      incident_img_type: incident_img_type,
      incident_img: incident_img,
      doctor_specification: doctor_specification,
      incident_description: incident_description,
      itemRows: this.fb.array([this.initItemRows()]),
      itemRows2: this.fb.array([this.initItemRows2()]),
      damagerows: this.fb.array([this.initdamagerows()]),
      witness: witness,
      cause: [],

      police_complaint: police_complaint,
      PoliceStationName: PoliceStationName,
      Fatal: Fatal,
      FatalCount: FatalCount,
      IncidentLevel: IncidentLevel,
      AnimalKilled: AnimalKilled,
      RepeatedIncident: RepeatedIncident,
      HelpedBy: HelpedBy,
      severity_type: severity_type,
      Evacuation: Evacuation
    });
  }

  getinvestigatorslist() {
    this._incidents_list_mr_service
      .getinvestigatorslist({ role_name: "FirstAid" })
      .subscribe(docs => {
        this.first_aid_data = docs.data;
      });
  }

  initItemRows() {
    return this.fb.group({
      emp_id: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      part: new FormControl([], [Validators.required]),
      side: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ])
    });
  }

  initdamagerows() {
    return this.fb.group({
      damage: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      location: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ])
    });
  }

  initItemRows2() {
    return this.fb.group({
      emp_id1: new FormControl({ value: "", disabled: false }, [
        Validators.required
      ]),
      description: new FormControl({ value: "", disabled: false })
    });
  }

  addNewRow() {
    const control = <FormArray>this.incidentForm.controls["itemRows"];
    control.push(this.initItemRows());
  }

  deleteRow(index: number) {
    const control = <FormArray>this.incidentForm.controls["itemRows"];
    control.removeAt(index);
  }

  addNewRow1() {
    const control = <FormArray>this.incidentForm.controls["itemRows2"];
    control.push(this.initItemRows2());
  }

  deleteRow1(index: number) {
    const control = <FormArray>this.incidentForm.controls["itemRows2"];
    control.removeAt(index);
  }

  addNewRow_damage() {
    const control = <FormArray>this.incidentForm.controls["damagerows"];
    control.push(this.initdamagerows());
  }

  deleteRow_damage(index: number) {
    const control = <FormArray>this.incidentForm.controls["damagerows"];
    control.removeAt(index);
  }

  getInjuries_witness() {
    this._incidentaddservice.getInjuries_witness().subscribe(docs => {
      if (!docs.error) {
        this.witness_data = docs.data;
        this.injureslist = docs.data;
        this.const_injureslist = docs.data;
        this.const_injureslist1 = docs.data;
      } else {
        this.witness_data = [];
      }
    });
  }

  get_supervisor_list() {
    this._incidentaddservice.get_locations_supervisors().subscribe(docs => {
      this.supervisor_List = docs.data;
      console.log(this.supervisor_List);
    });
  }
  getlocatuibsup($event) {
    this.locationsupervisor = _.filter(this.supervisor_List, function (km) {
      return km.loc_id.toString() == $event.target.value;
    });
  }

  getIncidentCauses() {
    this._incidentaddservice.getIncidentsCauses().subscribe(docs => {
      if (!docs.error) {
        this.causes = [];
        this.allcauses = [];
        docs.data = _.filter(docs.data, function (o) {
          return o.status == 1;
        });
        for (let v = 0; v < docs.data.length; v++) {
          const a = docs.data[v];
          a["checked"] = 0;
          this.causes.push(a);
        }
        this.allcauses = _.chunk(this.causes, this.causes.length / 3);

        console.log(this.allcauses, "allll", this.causes);
      } else {
        this.causes = [];
      }
    });
  }

  checkbox(event, id, index, firstIndex) {
    console.log(this.allcauses[firstIndex][index].checked);
    if (this.allcauses[firstIndex][index].checked == 1) {
      this.allcauses[firstIndex][index].checked = 0;
    } else if (this.allcauses[firstIndex][index].checked == 0) {
      this.allcauses[firstIndex][index].checked = 1;
    }
  }

  movetostep1() {
    this.checkValidCases();
    this.step1 = true;
    this.step2 = false;
    this.step3 = false;
    this.step4 = false;
    this.step5 = false;
    this.step6 = false;
    this.showDet["det"] = "show";
    this.validationCheck.det = true;
  }

  movetostep2() {
    this.checkValidCases();
    this.step1 = false;
    this.step2 = true;
    this.step3 = false;
    this.step4 = false;
    this.step5 = false;
    this.step6 = false;
    this.showDet["causes"] = "show";
    this.validationCheck.causes = true;
  }

  movetostep3() {
    if (this.showDet["inj"] == "hide") {
      this.movetostep4();
      return;
    }
    this.checkValidCases();
    this.step1 = false;
    this.step2 = false;
    this.step3 = true;
    this.step4 = false;
    this.step5 = false;
    this.step6 = false;
    this.showDet["inj"] = "show";
    this.validationCheck.inj = true;
  }
  movetostep4() {
    if (this.showDet["damage"] == "hide") {
      this.movetostep5();
      return;
    }
    this.checkValidCases();
    this.step1 = false;
    this.step2 = false;
    this.step3 = false;
    this.step4 = true;
    this.step5 = false;
    this.step6 = false;
    this.showDet["damage"] = "show";
    this.validationCheck.damage = true;
  }

  movetostep5() {
    console.log(this.showDet["first_aid"]);
    if (this.showDet["first_aid"] == "hide") {
      this.movetostep6();
      return;
    }
    this.checkValidCases();
    this.step1 = false;
    this.step2 = false;
    this.step3 = false;
    this.step4 = false;
    this.step5 = false;
    this.step6 = true;
    this.showDet["first_aid"] = "show";
    this.validationCheck.first_aid = true;
  }

  movetostep6() {
    this.checkValidCases();
    this.step1 = false;
    this.step2 = false;
    this.step3 = false;
    this.step4 = false;
    this.step5 = true;
    this.step6 = false;
    this.showDet["witness"] = "show";
    this.validationCheck.witness = true;
  }

  geback4() {
    if (this.incidentForm.value.incident_type == "Damage to material") {
      this.movetostep2();
    } else if (
      this.incidentForm.value.incident_type ==
      "Injury to People and damages to Property"
    ) {
      this.checkValidCases();
      this.step1 = false;
      this.step2 = false;
      this.step3 = true;
      this.step4 = false;
      this.step5 = false;
      this.showDet["inj"] = "show";
    }
  }

  geback5() {
    if (this.incidentForm.value.incident_type == "near miss") {
      this.movetostep5();
      // this.movetostep2();
    } else if (this.incidentForm.value.incident_type == "Injury to People") {
      this.movetostep3();
    } else if (
      this.incidentForm.value.incident_type == "Damage to material" ||
      this.incidentForm.value.incident_type ==
      "Injury to People and damages to Property"
    ) {
      this.movetostep4();
    }
  }

  geback6() {
    if (this.incidentForm.value.incident_type == "near miss") {
      this.movetostep2();
    }
  }

  checkValidCases() {
    if (this.step1 == true) {
      if (
        this.incidentForm.controls.incident_name.valid &&
        this.incidentForm.controls.incident_type.valid &&
        this.incidentForm.controls.incident_date.valid &&
        this.incidentForm.controls.incident_time.valid &&
        this.incidentForm.controls.Evacuation.valid &&
        this.incidentForm.controls.Evacuation.valid &&
        this.incidentForm.controls.work_unit.valid &&
        this.incidentForm.controls.incident_location.valid &&
        this.incidentForm.controls.supervisor.valid &&
        this.incidentForm.controls.incident_description.valid &&
        this.file
      ) {
        this.showDet["det"] = "valid";
      } else {
        this.showDet["det"] = "invalid";
      }
    } else if (this.step2 == true) {
      this.allcauses.forEach(element => {
        const filter_det = _.filter(element, function (o) {
          return o.checked == 1;
        });
        if (filter_det.length) {
          this.showDet["causes"] = "valid";
        }
      });
      if (this.showDet["causes"] !== "valid") {
        this.showDet["causes"] = "invalid";
      }
    } else if (this.step3 == true) {
      for (
        let index = 0;
        index < this.incidentForm.controls.itemRows["controls"].length;
        index++
      ) {
        const element = this.incidentForm.controls.itemRows["controls"][index];
        if (!element.value.emp_id.length) {
          this.showDet["inj"] = "invalid";
          break;
        }
        if (element.value.part) {
          const val = _.values(element.value.part[0]);
          const filter_det = _.filter(val, function (o) {
            return o == true;
          });
          if (!filter_det.length) {
            this.showDet["inj"] = "invalid";
            break;
          }
        }
      }
      if (this.showDet["inj"] !== "invalid") {
        this.showDet["inj"] = "valid";
      }
    } else if (this.step4 == true) {
      for (
        let index = 0;
        index < this.incidentForm.controls.damagerows["controls"].length;
        index++
      ) {
        const element = this.incidentForm.controls.damagerows["controls"][
          index
        ];
        if (!element.valid) {
          this.showDet["damage"] = "invalid";
        }
      }
      if (this.showDet["damage"] !== "invalid") {
        this.showDet["damage"] = "valid";
      }
    } else if (this.step5 == true) {
      console.log("text case");
      if (
        this.incidentForm.controls.witness.valid &&
        this.incidentForm.controls.police_complaint.valid &&
        this.incidentForm.controls.IncidentLevel.valid &&
        this.incidentForm.controls.AnimalKilled.valid &&
        this.incidentForm.controls.RepeatedIncident.valid
      ) {
        if (
          this.incidentForm.controls.police_complaint.value == "Yes" &&
          this.incidentForm.controls.PoliceStationName.valid
        ) {
          this.showDet["witness"] = "valid";
        }
        if (this.incidentForm.controls.police_complaint.value == "No") {
          this.showDet["witness"] = "valid";
        }
      } else {
        this.showDet["witness"] = "invalid";
      }
    } else if (this.step6 == true) {
      if (this.incidentForm.controls.itemRows2.valid) {
        this.showDet["first_aid"] = "valid";
      } else {
        this.showDet["first_aid"] = "invalid";
      }
    }
  }

  changeStatusType(value) {
    if (value == "near miss") {
      this.showDet["inj"] = "hide";
      this.showDet["damage"] = "hide";
      this.showDet["first_aid"] = "show";
    } else if (value == "Injury to People") {
      this.showDet["inj"] = "show";
      this.showDet["damage"] = "hide";
      this.showDet["first_aid"] = "hide";
    } else if (value == "Damage to material") {
      this.showDet["inj"] = "hide";
      this.showDet["damage"] = "show";
      this.showDet["first_aid"] = "hide";
    } else if (value == "Injury to People and damages to Property") {
      this.showDet["inj"] = "show";
      this.showDet["damage"] = "show";
      this.showDet["first_aid"] = "hide";
    }
  }

  selectionfirstaid(event, value) {
    if (event.target.value == "1") {
      this.firstaidquestion = true;
    } else {
      this.firstaidquestion = false;
    }
  }

  selectionhospital(event, value) {
    if (event.target.value == "1") {
      this.hospitalquestion = true;
    } else {
      this.hospitalquestion = false;
    }
  }
  selectionhospital1(event, value) {
    if (event.target.value == "1") {
      this.hospitalquestion1 = true;
    } else {
      this.hospitalquestion1 = false;
    }
  }
  selectionfirstaid1(event, value) {
    if (event.target.value == "1") {
      this.firstaidquestion1 = true;
    } else {
      this.firstaidquestion1 = false;
    }
  }

  selectionwitness(event, value) {
    if (event.target.value == "1") {
      this.witnessselect = true;
    } else {
      this.witnessselect = false;
    }
  }

  onDateChanged(event) { }

  onItemSelect(event, a, index) {
    console.log(event, a);
    const filter_det = _.filter(this.const_injureslist, function (o) {
      return o.id !== event.id;
    });
    this.injureslist = filter_det;
  }

  onItemSelect1(event, a, index) {
    console.log(event, a);
    const filter_det = _.filter(this.const_injureslist1, function (o) {
      return o.id !== event.id;
    });
    this.injureslist1 = filter_det;
  }

  OnItemDeSelect(event) {
    console.log(event);
  }
  OnItemDeSelect1(event) {
    console.log(event);
  }

  open_parts_list(value, index) {
    this.firstaidquestion1 = false;
    this.hospitalquestion1 = false;
    console.log(index, "add parts", this.incidentForm.controls.itemRows.value);
    this.opend_popup_det = index;
    console.log(
      value,
      this.incidentForm.controls.itemRows.value[index].part,
      "add parts"
    );
    this.emp_inj_parts.reset();
    console.log(
      this.incidentForm.controls.itemRows["controls"][this.opend_popup_det][
        "controls"
      ].part.value[0],
      "11111"
    );
    if (
      this.incidentForm.controls.itemRows["controls"][this.opend_popup_det][
        "controls"
      ].part.value[0]
    ) {
      this.emp_inj_parts.patchValue(
        this.incidentForm.controls.itemRows["controls"][this.opend_popup_det][
          "controls"
        ].part.value[0]
      );
      console.log(this.emp_inj_parts, "add parts");
    }
    if (this.emp_inj_parts.value.hospital == 1) {
      this.hospitalquestion1 = true;
    }
    if (this.emp_inj_parts.value.first_aid == 1) {
      this.firstaidquestion1 = false;
    }

    this.emp_inj_parts.patchValue({
      fatal: "0",
      first_aid: "0",
      hospital: "0"
    });
  }

  addinj_detials() {
    console.log(
      this.emp_inj_parts.value,
      this.opend_popup_det,
      this.incidentForm.controls.itemRows
    );
    this.incidentForm.controls.itemRows["controls"][this.opend_popup_det][
      "controls"
    ].part.value[0] = this.emp_inj_parts.value;
    console.log(
      this.incidentForm,
      "test",
      this.incidentForm.controls.itemRows.value
    );
    this.emp_inj_parts.reset();
  }
  // Submit Form
  addNewDoc(reqdata) {
    console.log(this.emp_inj_parts.value);
    let submit = true;
    // const body = {};
    this.count = 0;
    this.body["injuries"] = [];
    this.body["first_aid"] = [];
    this.body["incident"] = [];
    this.body["damages"] = [];
    this.body["others"] = [];
    this.body["causes"] = [];
    this.to_push = [];
    this.selected_parts = [];

    console.log("Added Doc Form", this.showDet);

    if (this.showDet["first_aid"] == "valid") {
      console.log("first_aid");
      if (this.incidentForm.controls.itemRows2.value.length > 0) {
        for (
          let yk = 0;
          yk < this.incidentForm.controls.itemRows2.value.length;
          yk++
        ) {
          if (this.incidentForm.controls.itemRows2.value[yk].emp_id1[0]) {
            const fi_aid = {};
            fi_aid["hospital"] = null;
            fi_aid["person_id"] = this.incidentForm.controls.itemRows2.value[
              yk
            ].emp_id1[0].id;

            fi_aid["hosp"] = 0;

            fi_aid["specialisation"] = null;
            fi_aid["doctor"] = null;
            fi_aid["first_aid"] = 1;

            if (this.first_aid_data.length > 0) {
              fi_aid["faid_by"] = this.first_aid_data[0].id;
            } else {
              fi_aid["faid_by"] = null;
            }

            fi_aid["fatal"] = 0;
            fi_aid["description"] = this.incidentForm.controls.itemRows2.value[
              yk
            ].description;
            this.selected_parts.push(fi_aid);
          } else {
            break;
          }
        }
      }
    } else {
      if (this.incidentForm.controls.itemRows.value.length > 0) {
        for (
          let yk = 0;
          yk < this.incidentForm.controls.itemRows.value.length;
          yk++
        ) {
          console.log(
            this.incidentForm.controls.itemRows.value[yk].part,
            "kids"
          );
          if (this.incidentForm.controls.itemRows.value[yk].part.length !== 0) {
            if (this.incidentForm.controls.itemRows.value[yk].emp_id[0]) {
              const fi_aid = {};
              fi_aid["hospital"] = this.incidentForm.controls.itemRows.value[
                yk
              ].part[0]["hospital_name"];
              fi_aid["person_id"] = this.incidentForm.controls.itemRows.value[
                yk
              ].emp_id[0].id;
              if (
                this.incidentForm.controls.itemRows.value[yk].part[0][
                "hospital"
                ] != null
              ) {
                fi_aid["hosp"] = this.incidentForm.controls.itemRows.value[
                  yk
                ].part[0]["hospital"];
              } else {
                fi_aid["hosp"] = 0;
              }
              fi_aid[
                "specialisation"
              ] = this.incidentForm.controls.itemRows.value[yk].part[0][
                "doctor_specification"
                ];
              fi_aid["doctor"] = this.incidentForm.controls.itemRows.value[
                yk
              ].part[0]["doctor_name"];
              fi_aid["first_aid"] = this.incidentForm.controls.itemRows.value[
                yk
              ].part[0]["first_aid"];
              if (
                this.incidentForm.controls.itemRows.value[yk].part[0][
                "first_aid"
                ] == 1
              ) {
                fi_aid["faid_by"] = this.incidentForm.controls.itemRows.value[
                  yk
                ].part[0]["first_aid_by"][0].id;
              } else {
                fi_aid["faid_by"] = null;
              }
              fi_aid["fatal"] = this.incidentForm.controls.itemRows.value[
                yk
              ].part[0]["fatal"];
              this.selected_parts.push(fi_aid);
            } else {
              // submit = false;
              break;
            }
          } else {
            // submit = false;
            break;
          }
        }
      }
    }

    console.log(this.selected_parts);
    console.log(
      this.incidentForm.controls.itemRows.value.length,
      this.incidentForm.controls.itemRows
    );
    // injuries details

    for (let y = 0; y < this.incidentForm.controls.itemRows.value.length; y++) {
      const obj = this.incidentForm.controls.itemRows.value[y].part[0];
      console.log(obj);
      let keys = [];
      if (obj) {
        keys = Object.keys(obj);
      }
      const a = keys.filter(function (key) {
        return obj[key] == true;
      });
      console.log(a);
      let c = {};
      if (this.incidentForm.controls.itemRows.value[y].emp_id[0]) {
        for (let z = 0; z < a.length; z++) {
          c = {};
          const part_one = _.filter(AppSettings.Injures_one, function (o) {
            return o.Parts == a[z];
          });

          if (part_one.length == 0) {
            const part_two = _.filter(AppSettings.Injures_two, function (o) {
              return o.Parts == a[z];
            });
            const abc = a[z].split("_");
            if (abc[0] == "l") {
              c = {
                emp_id: this.incidentForm.controls.itemRows.value[y].emp_id[0]
                  .id,
                part: abc[1],
                side: "left"
              };
            } else {
              c = {
                emp_id: this.incidentForm.controls.itemRows.value[y].emp_id[0]
                  .id,
                part: abc[1],
                side: "right"
              };
            }
          } else {
            c = {
              emp_id: this.incidentForm.controls.itemRows.value[y].emp_id[0].id,
              part: a[z],
              side: ""
            };
          }
          // console.log(c, 'After loop');
          this.to_push.push(c);
          // console.log(to_push, '123');
        }
      } else {
        // submit = false;
        break;
      }
    }
    this.body["injuries"] = this.to_push;
    this.body["first_aid"] = this.selected_parts;
    // incident detials
    if (
      this.incidentForm.controls.incident_name.valid &&
      this.incidentForm.controls.incident_type.valid &&
      this.incidentForm.controls.incident_time.valid &&
      this.incidentForm.controls.work_unit.valid &&
      this.incidentForm.controls.incident_location.valid &&
      this.incidentForm.controls.incident_description.valid &&
      this.incidentForm.controls.Evacuation.valid
    ) {
      this.body["incident"] = {
        incident_name: this.incidentForm.controls.incident_name.value,
        incident_type: this.incidentForm.controls.incident_type.value,
        incident_date:
          moment(this.incidentForm.value["incident_date"].jsdate).format(
            "YYYY-MM-DD"
          ) +
          " " +
          moment(this.incidentForm.value["incident_time"]).format("HH:mm:ss"),
        incident_time: this.incidentForm.controls.incident_time.value, // change format
        work_unit: this.incidentForm.controls.work_unit.value,
        incident_location: this.incidentForm.controls.incident_location.value,
        incident_description: this.incidentForm.controls.incident_description
          .value,
        incident_img: this.incidentForm.controls.incident_img.value,
        incident_img_type: this.incidentForm.controls.incident_img_type.value,
        Evacuation: this.incidentForm.controls.Evacuation.value
      };
      console.log(this.body["incidents"], "sbdfjhsdfjgsdafhgasfh");
      const sup = [];

      for (let km = 0; km < this.locationsupervisor.length; km++) {
        sup[km] = this.locationsupervisor[km].id;
      }
      this.body["incident"]["supervisor"] = sup.toString();

      // if (this.incidentForm.controls.supervisor.valid) {
      //   for (
      //     let q = 0;
      //     q < this.incidentForm.controls.supervisor.value.length;
      //     q++
      //   ) {
      //     sup[q] = this.incidentForm.controls.supervisor.value[q].id;
      //   }
      //   this.body['incident']['supervisor'] = sup.toString();
      // } else {
      //   submit = false;
      // }
    } else {
      submit = false;
    }
    // witness

    const p = [];
    if (this.incidentForm.controls.witness.valid) {
      for (
        let x = 0;
        x < this.incidentForm.controls.witness.value.length;
        x++
      ) {
        p[x] = this.incidentForm.controls.witness.value[x].id;
      }
      this.body["witness"] = p.toString();
    }
    // else
    //   submit = false;
    // damages details
    if (this.incidentForm.controls.damagerows.valid) {
      this.body["damages"] = this.incidentForm.controls.damagerows.value;
    }
    // else
    //   submit = false;
    // causes
    const cause_push = [];
    // for (let b = 0; b < this.causes.length; b++) {
    //   if (this.causes[b].checked == 1) {
    //     cause_push.push(this.causes[b].ic_id);
    //   }
    // }
    this.allcauses.forEach(element => {
      const filter_det = _.filter(element, function (o) {
        return o.checked == 1;
      });
      filter_det.forEach(res => {
        cause_push.push(res.ic_id);
      });
    });

    this.body["causes"] = cause_push.toString();

    // this.body['others'] = [];
    console.log(this.incidentForm.value.AnimalKilled, "fgszgsdfkjsgfhs");
    for (let ko = 0; ko < this.selected_parts.length; ko++) {
      if (this.selected_parts[ko].fatal == 1) {
        this.count += 1;
      }
    }
    let fatalstatus;
    console.log(this.count, "hsdufsduk");
    if (this.count >= 1) {
      fatalstatus = "Yes";
    } else {
      fatalstatus = "No";
    }
    if (
      this.incidentForm.controls.police_complaint.valid &&
      this.incidentForm.controls.IncidentLevel.valid &&
      this.incidentForm.controls.AnimalKilled.valid &&
      this.incidentForm.controls.RepeatedIncident.valid
    ) {
      this.body["others"] = {
        police_complaint: this.incidentForm.value.police_complaint,
        Fatal: fatalstatus,
        IncidentLevel: this.incidentForm.value.IncidentLevel,
        AnimalKilled: this.incidentForm.value.AnimalKilled,
        RepeatedIncident: this.incidentForm.value.RepeatedIncident,
        PoliceStationName: this.incidentForm.value.PoliceStationName,
        FatalCount: this.count
      };

      const pq = [];
      for (
        let x = 0;
        x < this.incidentForm.controls.HelpedBy.value.length;
        x++
      ) {
        pq[x] = this.incidentForm.controls.HelpedBy.value[x].id;
      }
      this.body["others"]["helpedby"] = pq.toString();
      if (!this.body["others"]["helpedby"]) {
        this.body["others"]["helpedby"] = "";
      }
    } else {
      submit = false;
    }
    if (submit) {
      // this.loading = true;
      console.log(this.body);

      const formData = this.prepareSave7();
      console.log(formData);

      this._incidentaddservice
        .addNewIncidentDetails(formData)
        .subscribe(docs => {
          console.log(docs, "response after add");
          if (!docs.error) {
            this.incidentForm.reset();
            this.witness_data = [];
            this.first_aid_data = [];
            this.supervisor_List = [];
            this.toastr.successToastr("", "Incident Added Successfully");
            this.supervisordata_form = [];
            this.hospitalquestion = false;
            this.causes = [];
            this.movetostep1();
            this.getIncidentCauses();
            this.getInjuries_witness();
            this.create_form();
            this.getInjuries_witness();
            this.get_supervisor_list();
            this.getinvestigatorslist();
            this.proof_1 = "";
            this.type_1 = "";
            this.helped_date_selected = [];
            this.severity_type = "normal";
            this.loading = false;
            this.showDet = {
              det: "show",
              causes: "show",
              inj: "hide",
              damage: "hide",
              witness: "show",
              first_aid: "show"
            };
            this.validationCheck = {
              det: true,
              causes: false,
              first_aid: false,
              inj: false,
              damage: false,
              witness: false
            };
            this.changeStatusType("near miss");
          } else {
            this.toastr.errorToastr("", "Error in adding details");
            this.loading = false;
          }
        });
    } else {
      this.toastr.warningToastr("", "Please enter all required details");
    }
  }

  handleFileSelect_proof1($event) {
    const fileSelected: File = $event.target.files[0];
    this.file = fileSelected;
    console.log(this.file);
  }
  private prepareSave7(): any {
    console.log(`in preparesave`);
    const input = new FormData();
    console.log(this.file, input);
    input.append("image", this.file);
    input.append("data", JSON.stringify(this.body));
    return input;
  }
  _handleReaderLoaded_1_pdf(readerEvt) {
    this.binaryString = readerEvt.target.result;
    this.base64textString = btoa(this.binaryString);
    this.proof_1 = this.base64textString;
    this.incidentForm.patchValue({
      incident_img: this.proof_1
    });
  }
  imgURL(id) {
    return "data:image/jpeg;base64," + id;
  }
  photoURL(id) {
    // console.log('format', id)
    return "data:application/pdf;base64," + id;
  }
  injures_emp() {
    this.injureslist = [];
    this.injureslist = this.const_injureslist;
    for (let a = 0; a < this.incidentForm.value.itemRows.length; a++) {
      console.log(this.incidentForm.value.itemRows[a]);
      if (this.incidentForm.value.itemRows[a].emp_id[0]) {
        const b = this.incidentForm.value.itemRows[a].emp_id[0].id;
        const filter_det = _.filter(this.injureslist, function (o) {
          return o.id != b;
        });
        this.injureslist = filter_det;
      }
    }
    return this.injureslist;
  }
  injures_emp1() {
    this.injureslist1 = [];
    this.injureslist1 = this.const_injureslist1;
    for (let a = 0; a < this.incidentForm.value.itemRows2.length; a++) {
      console.log(this.incidentForm.value.itemRows2[a]);
      if (this.incidentForm.value.itemRows2[a].emp_id1[0]) {
        const b = this.incidentForm.value.itemRows2[a].emp_id1[0].id;
        const filter_det = _.filter(this.injureslist1, function (o) {
          return o.id !== b;
        });
        this.injureslist1 = filter_det;
      }
    }
    return this.injureslist1;
  }

  onChange_image(event, type) {
    const files = event.srcElement.files;
    this.picName = files;
    this.file_exist = this.picName.length;
    this.fileformat = files[0].type;
    if (this.fileformat !== "image/png") {
      this.file_error = true;
      this.toastr.warningToastr(
        "error",
        "Invalid File Format --- Please add jpeg/png files"
      );
    }
    // this.upload();
    console.log(
      this.file_exist,
      this.picName[0].size,
      files,
      files.FileList,
      files[0].name,
      files[0].type
    );
  }

  getlistoflocations() {
    this.locations = [];
    this.locationservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function (o) {
            return o.parent_id == element.loc_id;
          });
          if (len.length) {
            element["lastAdd"] = true;
          } else {
            element["DispData"] = this.getlocation_name(element.loc_id);
            element["lastAdd"] = false;
          }
        });
        this.locations = _.filter(response, function (o) {
          return o.lastAdd == false;
        });
        console.log(this.locations);

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getlocation_name(value) {
    let text = _.filter(this.LocationsListStatic, function (o) {
      return o.loc_id == parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function (o) {
          return o.loc_id == parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    console.log(value, loc_nam, "text");
    return _.chain(loc_nam)
      .reverse()
      .value();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    console.log(this.incidentForm.touched);
  }

  checkCaseTabs(value) {
    if (!this.validationCheck[`${value}`]) {
      return;
    }
    if (value == "det") {
      this.checkValidCases();
      this.movetostep1();
    } else if (value == "causes") {
      this.checkValidCases();
      this.movetostep2();
    } else if (value == "first_aid") {
      this.checkValidCases();
      this.movetostep5();
    } else if (value == "inj") {
      this.checkValidCases();
      this.movetostep3();
    } else if (value == "damage") {
      this.checkValidCases();
      this.movetostep4();
    } else if (value == "witness") {
      this.checkValidCases();
      this.movetostep6();
    }
  }
}
