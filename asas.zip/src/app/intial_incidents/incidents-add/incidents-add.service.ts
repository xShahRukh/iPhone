import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { AppSettings } from '../../app.settings';
import { IncidentSettings } from '../incidents.settings';
import { isThisTypeNode } from '../../../../node_modules/typescript/lib/tsserverlibrary';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';

@Injectable()
export class IncidentsAddService {
  constructor(
    private _apiService: ApiService,
    public _http: Http,
    private http: Http
  ) { }

  // ADD_DOCUMENT_DETAI
  addNewIncidentCause(body) {
    return this._apiService.callApi(
      IncidentSettings.API.ADD_INCIDENT_CAUSES,
      'post',
      body
    );
  }

  // GET_INCIDENTS_LIST
  getIncidentsCauses() {
    const body = {};
    return this._apiService.callApi(
      IncidentSettings.API.GET_INCIDENTS_LIST,
      'get',
      body
    );
  }

  // get injuries and witness
  getInjuries_witness() {
    const body = {};
    return this._apiService.callApi(
      IncidentSettings.API.GET_INJURIES_WITNESS,
      'get',
      body
    );
  }

  // get supervisor list
  get_supervisor_list() {
    return this._apiService.callApi(
      IncidentSettings.API.GET_SUPERVISOR_LIST,
      'get',
      {}
    );
  }

  // add new incident
  // addNewIncidentDetails(body) {
  //   // const data = {
  //   //   data: body
  //   // };
  //   return this._apiService.callApi(
  //     IncidentSettings.API.ADD_NEW_INCIDENT_DETAILS,
  //     'FILE_UPLOAD',
  //     body
  //   );
  // }

  addNewIncidentDetails(body) {
    return this.http
      .post(IncidentSettings.API.ADD_NEW_INCIDENT_DETAILS, body, this.token())
      .pipe(map((response: Response) => response.json()));
  }
  getlistoflocats() {
    return this._apiService.callApi(
      IncidentSettings.API.GET_MAJOR_LOCATIONS,
      'get',
      {}
    );
  }

  get_locations_supervisors() {
    return this._apiService.callApi(
      IncidentSettings.API.GET_LOCATIONS_SUPERVISORS,
      'get',
      {}
    );
  }

  token() {
    return new RequestOptions({
      headers: new Headers({
        // 'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
