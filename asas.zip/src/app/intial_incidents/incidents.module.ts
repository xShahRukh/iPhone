import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { SharedModule } from "../common/shareds.module";
import { ApiService } from "../common/services/api.service";
import { incidentRouting } from "./incidents.routing";

// 3rd party
import { ToastrModule } from "ng6-toastr-notifications";
import { ModalModule } from "ngx-modal";
import { DataTableModule } from "angular-6-datatable";
// import { Ng2UploaderModule } from 'ng2-uploader';
// import { FileUploadModule } from 'ng2-file-upload';
// import { FileSelectDirective } from 'ng2-file-upload';
import { CalendarModule } from "primeng/primeng";
import { MyDatePickerModule } from "mydatepicker";
import { CustomFormsModule } from "ng2-validation";
import { EditorModule } from "primeng/editor";
import { CKEditorModule } from "ng2-ckeditor";
import { MultiSelectModule } from "primeng/primeng";
import { DropdownModule } from "primeng/primeng";
import { AutoCompleteModule } from "primeng/primeng";
import { MyDateRangePickerModule } from "mydaterangepicker";
// import { DpDatePickerModule } from 'ng2-date-picker';
import { HttpClientModule } from "@angular/common/http";
// Components
import { IncidentsCausesComponent } from "./incidents-causes/incidents-causes.component";
import { IncidentsService } from "./incidents-causes/incidents.services";
import { IncidentsInvestigationComponent } from "./incidents-investigation/incidents-investigation.component";
import { IncidentInvestigationService } from "./incidents-investigation/incideinvest.service";
import { IncidentsAddComponent } from "./incidents-add/incidents-add.component";
import { IncidentsAddService } from "./incidents-add/incidents-add.service";
import { IncidentsViewService } from "./incidents-view/incidents-view.service";
import { IncidentsViewComponent } from "./incidents-view/incidents-view.component";
import { IncidentsActionsComponent } from "./incidents-actions/incidents-actions.component";
import { IncidentActionService } from "./incidents-actions/incidents-actions.service";
import { IncidentsFirstaidComponent } from "./incidents-firstaid/incidents-firstaid.component";
import { IncidentsHospitalreportComponent } from "./incidents-hospitalreport/incidents-hospitalreport.component";
import { IncidentFirstaidService } from "./incidents-firstaid/incidents-firstaidservice";
import { IncidentHospitalService } from "./incidents-hospitalreport/incidents-hospitalservice";
import { IncidentsRaisedBymeComponent } from "./incidents-raised-byme/incidents-raised-byme.component";
import { WorkHoursComponent } from "./work-hours/work-hours.component";
import { WorkHoursService } from "./work-hours/work-hours.services";
import { GroupingIncidentsComponent } from "./grouping-incidents/grouping-incidents.component";
import { GroupIncidentsService } from "./grouping-incidents/grouping-incidents.service";
import { IncidentsListManagerComponent } from "./incidents-list-manager/incidents-list-manager.component";
import { IncidentsListManagerService } from "./incidents-list-manager/incidents-list-service";

import { TooltipModule } from 'ng2-tooltip-directive';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { ChartModule } from 'angular2-highcharts';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { IncidentsDashboardComponent } from './incidents-dashboard/incidents-dashboard.component';
import { KpiTargetsComponent } from './kpi-targets/kpi-targets.component';
import { IncidentsTopMenuComponent } from './incidents-top-menu/incidents-top-menu.component';
import { RaisedIncidentComponent } from './raised-incident/raised-incident.component';
import { RaiseIncidentsPart2Component } from './raise-incidents-part2/raise-incidents-part2.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { RaisedIncidentPart3Component } from './raised-incident-part3/raised-incident-part3.component';
import { PTWSectionOneComponent } from './PTW-section-one/PTW-section-one.component';
import { IncidentDashboardService } from "./incident-dashboard/incident-dashboard.service";
import { IncidentDashboardComponent } from "./incident-dashboard/incident-dashboard.component";

declare let require: any;
export function highchartsFactory() {
  const Highcharts = require("highcharts");
  const Exporting = require("highcharts/modules/exporting");
  const More = require("highcharts/highcharts-more");
  const Solid = require("highcharts/modules/solid-gauge");
  const Heatmap = require("highcharts/modules/heatmap");
  const Pointline = require("highcharts/modules/export-data");
  Heatmap(Highcharts);
  Exporting(Highcharts);
  More(Highcharts);
  Solid(Highcharts);
  Pointline(Highcharts);
  return Highcharts;
}

@NgModule({
  declarations: [
    IncidentsCausesComponent,
    IncidentsInvestigationComponent,
    IncidentsAddComponent,
    IncidentsViewComponent,
    IncidentsActionsComponent,
    IncidentsFirstaidComponent,
    IncidentsHospitalreportComponent,
    IncidentsRaisedBymeComponent,
    WorkHoursComponent,
    GroupingIncidentsComponent,
    IncidentsListManagerComponent,
    IncidentsDashboardComponent,
    KpiTargetsComponent,
    IncidentsTopMenuComponent,
    RaisedIncidentComponent,
    RaiseIncidentsPart2Component,
    RaisedIncidentPart3Component,
    PTWSectionOneComponent,
    IncidentDashboardComponent
  ],
  imports: [
    incidentRouting,
    CommonModule,
    FormsModule,
    EditorModule,
    CKEditorModule,
    ReactiveFormsModule,
    CustomFormsModule,
    DataTableModule,
    AutoCompleteModule,
    ModalModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    CKEditorModule,
    CalendarModule,
    ToastrModule.forRoot(),
    EditorModule,
    SharedModule,
    MyDateRangePickerModule,
    TooltipModule,
    ChartModule,
    NgbModule,
    HttpClientModule
  ],

  providers: [
    ApiService,
    IncidentsService,
    IncidentInvestigationService,
    IncidentsAddService,
    IncidentsViewService,
    IncidentActionService,
    IncidentFirstaidService,
    IncidentHospitalService,
    WorkHoursService,
    GroupIncidentsService,
    IncidentsListManagerService,
    IncidentDashboardService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    }
  ]
})
export class InitialincidentModule { }
