import { ApiService } from '../../common/services/api.service';

import { Injectable, Output, EventEmitter } from '@angular/core';
import { IncidentSettings } from '../incidents.settings';
import {
  Headers,
  Http,
  RequestOptions,
  Response,
  ResponseContentType
} from '@angular/http';

@Injectable()
export class IncidentActionService {
  constructor(private _apiService: ApiService, private http: Http) {}

  // ADD_DOCUMENT_DETAI
  getIncidentsalldetails(body) {
    return this._apiService.callApi(
      IncidentSettings.API.GET_INCIDENT_DETAILS,
      'post',
      body
    );
  }

  // GET_INCIDENTS_LIST
  getIncidentsalllist(body) {
    return this._apiService.callApi(
      IncidentSettings.API.GET_ALL_INCIDENTS_LIST,
      'post',
      body
    );
  }
  saveactionlist(body) {
    return this._apiService.callApi(
      IncidentSettings.API.SAVE_ACTIONS_TAKEN,
      'post',
      body
    );
  }
  incidentsinvestclose(body) {
    return this._apiService.callApi(
      IncidentSettings.API.CLOSE_INCIDENT_LIST,
      'post',
      body
    );
  }

  getImagePath(body) {
    return this.http.get(
      IncidentSettings.API.GETIMAGEPATH + '/' + `${body}`,
      new RequestOptions({ responseType: ResponseContentType.Blob })
    );
  }
  gethospitalreport(body) {
    return this._apiService.callApi(
      IncidentSettings.API.GET_REPORTS_OF_HOSPITAL,
      'post',
      body
    );
  }
}
