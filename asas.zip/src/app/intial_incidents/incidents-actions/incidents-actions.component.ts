import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild,
  Pipe,
  PipeTransform
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl,
  FormArray
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import * as _ from 'underscore';
import * as moment from 'moment';
import { IncidentActionService } from './incidents-actions.service';
import { IncidentsAddService } from '../incidents-add/incidents-add.service';
import { LoactionService } from '../../locations/locations.service';
import { IncidentSettings } from '../incidents.settings';
import { AppSettings } from '../../app.settings';
import { environment } from '../../../environments/environment';

@Component({
  selector: 'app-incidents-actions',
  templateUrl: './incidents-actions.component.html',
  styleUrls: ['./incidents-actions.component.css']
})
export class IncidentsActionsComponent implements OnInit {
  showlist = false;
  opend_popup_det: any;
  incident_id: any;
  dropdownSettings_inj: any = [];
  incdetails: any = [];
  loading: Boolean = true;
  viewdata = [];
  causeform: FormGroup;
  addmore_length;
  rem_length;
  listtoshow = [];
  img_url: string;
  employee_id: any = '';
  typesList = [];
  incidentactionForm: FormGroup;
  item: any;
  main_incident: any = [];
  type: any = '';
  base64_data: any = '';
  coloursList = [];

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';
  locations: any = [];
  LocationsListStatic = [];
  incidentsListStatic: any = [];
  typesList1: any = [];
  parts_list: any = [];
  hospitaldetails = [];
  inc_ids: any = [];
  DispIncident: any = [];
  image_dataDisp = [];
  typesList10: any;
  status_name: string;
  countdata: any = {};
  startDate = moment().format('YYYY-MM-01');
  startDt;
  today = moment().format('YYYY-MM-DD');
  endDt;
  status = 1;
  endDate = moment().format('YYYY-MM-31');

  public startDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableSince: {
    //   year: new Date().getFullYear(),
    //   month: new Date().getUTCMonth() + 1, day: new Date().getDate() + 1
    // }
  };
  d = new Date();
  public endDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 31
    },
    disableUntil: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 1
    }
  };
  id: any;
  damages_parts_emp: any = [];
  first_aids: any = [];
  report_name = false;
  piechartsforsome: Object;

  constructor(
    public fb: FormBuilder,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer,
    public incactionservice: IncidentActionService,
    public _incidentaddservice: IncidentsAddService,
    public locationservice: LoactionService
  ) {}

  ngOnInit() {
    this.startDt = { jsdate: new Date(this.startDate) };
    this.endDt = { jsdate: new Date(this.endDate) };
    this.getallincidentslist();

    // this.getDocumentTypes();
    this.causeform = this.fb.group({
      activeList: this.fb.array([])
    });
    this.incidentactionForm = this.fb.group({
      incidents_action_comments: new FormControl('', [Validators.required])
    });

    this.img_url = environment.api_image_url;
  }

  getallincidentslist() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    body['type'] = 'action';
    this.incactionservice.getIncidentsalllist(body).subscribe(async docs => {
      if (!docs.error) {
        this.typesList = docs.data;
        this.typesList1 = docs.data2;
        this.getddata_statuswise(4);
        setTimeout(() => {
          this.getgraph();
        }, 2000);
        this.getCountByStatus(4, 'pending');
        this.getCountByStatus(5, 'Completed');
        this.getCountByStatus3(4, 'total');
        //   this.incidentsListStatic = this.typesList;

        //   // Not Similar
        //   const withzero = await _.filter(this.typesList, function(o) {
        //     return o.similarIncident == 0;
        //   });
        //   // Smiler Incidents
        //   const withoutzero = await _.filter(this.typesList, function(o) {
        //     return o.similarIncident !== 0;
        //   });
        //   // Make uniq similar incidents
        //   const withUnic = await _.uniq(withoutzero, 'similarIncident');
        //   // Placing all of them in one variable
        //   const list1 = [withzero, withUnic];
        //   this.typesList1 = _.reduceRight(
        //     list1,
        //     function(a, b) {
        //       return a.concat(b);
        //     },
        //     []
        //   );

        //   this.typesList1.forEach(async element => {
        //     let sCount = [];
        //     if (element.similarIncident) {
        //       sCount = await _.filter(docs.data, function(o) {
        //         return o.similarIncident == element.similarIncident;
        //       });
        //     }
        //     element['similar'] = sCount.length;
        //   });
        this.loading = false;
        this.getlistoflocations();
        // } else {
        // this.typesList = [];
      }
    });
  }

  editDoc(item) {
    let i = 0;
    this.status = null;
    this._apiService.docobject = item;
    this.viewdata = item;
    this.incident_id = item.incident_id;
    this.status = item.status;
    let ids = [];
    if (item.similarIncident) {
      const ListToShow = _.filter(this.incidentsListStatic, function(o) {
        return o.similarIncident == item.similarIncident;
      });
      ListToShow.forEach(element => {
        ids.push(element.incident_id);
      });
    } else {
      ids = item.incident_id;
    }
    const t = ids.toString();
    this.inc_ids = ids;
    item.incident_id = ids.toString();
    if (typeof item.incident_id == 'number') {
      const a = [];
      a.push(item.incident_id);
      a.forEach(element => {
        this.coloursList.push({
          incident_id: element,
          // dispColour: this.getRandomColor()
          dispColour: IncidentSettings.BasicColors[i++],
          ids: i
        });
      });
    } else {
      item.incident_id.split(',').forEach(element => {
        this.coloursList.push({
          incident_id: element,
          // dispColour: this.getRandomColor()
          dispColour: IncidentSettings.BasicColors[i++],
          ids: i
        });
      });
    }
    this.incactionservice.getIncidentsalldetails({ incident_id: `'` + t + `'` }).subscribe(docs => {
      if (!docs.error) {
        this.DispIncident = docs.data.incident;
        this.DispIncident.forEach(element => {
          const val = _.filter(this.coloursList, function(o) {
            return parseInt(o.incident_id, 0) == parseInt(element.incident_id, 0);
          });

          element['dispColour'] = this.getIncColour(element);
          element['ids'] = val[0]['ids'];
        });
        docs.data.damages.forEach(async element => {
          const a = [];
          const itemName = this.getlocation_name(element.location);
          let itemNameList = itemName ? itemName.toString() : '';
          itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
          // element['locHistory'] = itemNameList;
          a.push({
            id: element,
            locHistory: itemNameList
          });
          element = a;
        });

        this.getRaisedColour(docs.data.causes, 'cause_code');
        this.getRaisedColour(docs.data.damages, 'damage');
        this.getRaisedColour(docs.data.injured_emps, 'name');
        this.getRaisedColour(docs.data.investigators, 'name');
        this.getRaisedColour(docs.data.witness, 'name');
        this.getRaisedColour(docs.data.actions, 'name');

        this.incdetails['causes'] = _.uniq(docs.data.causes, `cause_code`);
        this.incdetails['damages'] = _.uniq(docs.data.damages, `damage`);
        this.incdetails = docs.data;
        this.main_incident = docs.data.incident;
        this.damages_parts_emp = docs.data.injuries;
        this.first_aids = docs.data.first_aid;

        const IDS = [];
        this.main_incident.forEach(element => {
          IDS.push(element.incident_id);
        });
        this.image_dataDisp = [];
        IDS.forEach(element => {
          this.incactionservice.getImagePath(element).subscribe(data => {
            const check = data['_body'].type.split('/');
            if (check[0] == 'image') {
              this.image_dataDisp.push(data.url);
            }
          });
        });

        this.showlist = true;
      } else {
        this.incdetails = [];
      }
    });
  }

  addactiveList() {
    const control = <FormArray>this.causeform.controls['activeList'];
    const addrCtrl = this.initLink();
    control.push(addrCtrl);
    this.addmore_length = control.length;
  }

  removeList(i: any) {
    const control = <FormArray>this.causeform.controls['activeList'];
    this.rem_length = (<FormArray>this.causeform.controls['activeList']).length;
    control.removeAt(i);
    this.addmore_length = this.rem_length - 1;
  }

  initLink() {
    return this.fb.group({
      action_taken: new FormControl('', [Validators.required])
    });
  }

  submitactions() {
    if (this.causeform.value.activeList.length > 0) {
      const body = {};
      body['incident_id'] = this.inc_ids.toString();
      body['data'] = JSON.stringify(this.causeform.value.activeList);
      this.incactionservice.saveactionlist(body).subscribe(data => {
        if (!data.error) {
          this.toastr.successToastr('', 'Actions Added successfully');
          this.causeform.reset();
          this.causeform.controls.activeList['controls'] = [];
          this.incactionservice
            .getIncidentsalldetails({
              incident_id: `'` + this.inc_ids.toString() + `'`
            })
            .subscribe(docs => {
              if (!docs.error) {
                this.incdetails = docs.data;
                this.showlist = true;
              } else {
                this.incdetails = [];
              }
            });
        }
      });
    } else {
      this.toastr.warningToastr('Please Enter Text');
    }
  }
  details() {
    // this.incident_id = item.incident_id;
    this.incactionservice
      .getIncidentsalldetails({ incident_id: this.incident_id.toString() })
      .subscribe(docs => {
        this.incdetails = docs.data;
      });
  }
  Closeinvesti(even1) {
    const body = {};
    const even = _.find(this.incdetails.investigators, function(num) {
      return num.emp_id == sessionStorage.getItem('userid');
    });
    const element2 = [];
    this.incdetails.actions.forEach(element => {
      element2.push(element.inv_id);
    });
    body['incident_id'] = this.inc_ids.toString();
    body['inv_id'] = element2.toString();
    body['type'] = 'action';
    body['details'] = this.incidentactionForm.value.incidents_action_comments;
    body['standards'] = 0;

    this.incactionservice.incidentsinvestclose(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr('', 'Actioner Report submitted sucessfully');
        this.showlist = false;
        this.getallincidentslist();
        this.incident_id = '';
      }
    });
  }
  back() {
    this.showlist = false;
    this.ngOnInit();
  }
  view_img() {
    this.type = this.main_incident.image_type;
    this.base64_data = this.main_incident.image_data;
  }
  imgURL(type, id) {
    return 'data:' + type + ';base64,' + id;
  }

  getlocation_name(value) {
    let text = _.filter(this.LocationsListStatic, function(o) {
      return o.loc_id == parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function(o) {
          return o.loc_id == parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  async getlistoflocations() {
    this.locations = [];
    await this.locationservice.getlistoflocat().subscribe(async data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function(o) {
            return o.parent_id == element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['lastAdd'] = false;
          }
        });
        this.locations = _.filter(response, function(o) {
          return o.lastAdd == false;
        });

        await this.typesList1.forEach(async element => {
          const itemName = await this.getlocation_name(element.incident_location);
          let itemNameList = await itemName.toString();
          itemNameList = await itemNameList.replace(/,/g, ' ⇨ ');
          // element['locHistory'] = await itemNameList;
          const a = [];
          a.push({
            id: element,
            locHistory: itemNameList
          });
          element = a;
        });

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    return '1px solid ' + color;
  }

  async getIncColour(value) {
    const val = await _.filter(this.coloursList, function(o) {
      return parseInt(o.incident_id, 0) == parseInt(value.incident_id, 0);
    });
    return await val[0]['dispColour'];
  }

  getUniqDet(value, codeCheck) {
    value = _.uniq(value, `${codeCheck}`);
    return value ? value : [];
  }
  actionUniq(value) {
    const value1 = _.uniq(value, 'action_taken');
    return value1 ? value1 : [];
  }

  async getRaisedColour(value, type) {
    value.forEach(async element => {
      const filterDet = await _.filter(value, function(o) {
        return o[`${type}`] == element[`${type}`];
      });
      element['raisedBy'] = [];
      await filterDet.forEach(async response => {
        const a1 = await _.filter(this.coloursList, function(o) {
          return parseInt(o.incident_id, 0) == parseInt(response.incident_id, 0);
        });
        const Iname = await _.filter(this.DispIncident, function(o) {
          return parseInt(o.incident_id, 0) == parseInt(response.incident_id, 0);
        });
        // element.raisedBy.push(a1[0]['dispColour']);
        element.raisedBy.push({
          clr: a1[0]['dispColour'],
          ids: a1[0]['ids'],
          name: Iname[0].created_by_name
        });
      });
    });
    return await value;
  }

  async getRaisedColourParts(value) {
    await value.forEach(element => {
      element.raisedBy = [];
      element.getUniqId = '';
      const a1 = _.filter(value, function(o) {
        return o.part == element.part && o.side == element.side;
      });
      a1.forEach(response => {
        const a2 = _.filter(this.coloursList, function(o) {
          return parseInt(o.incident_id, 0) == parseInt(response.incident_id, 0);
        });
        element.getUniqId = response.part + response.side;
        element.raisedBy.push(a2[0]['dispColour']);
      });
    });
    this.parts_list = await _.uniq(value, 'getUniqId');
  }

  getLocationName(value) {
    const lc1 = _.filter(this.locations, function(o) {
      return o.loc_id.toString() == value.toString();
    });
    if (lc1.length) {
      return lc1[0].location_name;
    } else {
      return '-';
    }
  }

  ChangeDate(dt) {
    this.startDate = moment(dt).format('YYYY-MM-DD');
    this.endDateOptions.disableUntil.year = dt.date.year;
    this.endDateOptions.disableUntil.month = dt.date.month;
    this.endDateOptions.disableUntil.day = dt.date.day - 1;
  }

  ChangeEndDate(dt) {
    this.endDate = moment(dt).format('YYYY-MM-DD');
  }
  async getCountByStatus(status, value) {
    let incidentslist = [];
    this.status = status;
    if (status == 4) {
      incidentslist = await _.filter(this.typesList1, function(o) {
        return o.status == 4;
      });
    } else {
      incidentslist = await _.filter(this.typesList1, function(o) {
        return o.status != 4;
      });
    }

    // Not Similar
    const withzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident == 0;
    });
    // Smiler Incidents
    const withoutzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident !== 0;
    });
    const withUnic = await _.uniq(withoutzero, 'similarIncident');
    const list1 = [withzero, withUnic];
    incidentslist = await _.reduceRight(
      list1,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    this.countdata[`${value}`] = await incidentslist.length;
  }

  async getddata_statuswise(status) {
    this.status = status;
    let incidentslist = [];
    if (this.status == 4) {
      this.status_name = 'Pending';
    }
    if (this.status == 5) {
      this.status_name = 'Completed';
    }
    if (status == 4) {
      incidentslist = await _.filter(this.typesList1, function(o) {
        return o.status == status;
      });
    } else {
      incidentslist = await _.filter(this.typesList1, function(o) {
        return o.status !== 4;
      });
    }
    console.log(incidentslist, this.typesList1);
    this.incidentsListStatic = incidentslist;

    // Not Similar
    const withzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident == 0;
    });
    // Smiler Incidents
    const withoutzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident !== 0;
    });
    // Make uniq similar incidents
    const withUnic = await _.uniq(withoutzero, 'similarIncident');
    // Placing all of them in one variable
    const list1 = [withzero, withUnic];
    this.typesList10 = _.reduceRight(
      list1,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    await this.typesList10.forEach(async element => {
      let sCount = [];
      if (element.similarIncident) {
        sCount = await _.filter(this.incidentsListStatic, function(o) {
          return o.similarIncident == element.similarIncident;
        });
      }
      element['similar'] = sCount.length;
      const itemName = await this.getlocation_name(element.incident_location);
      console.log(this.typesList10);
      let itemNameList = (await itemName) ? itemName.toString() : '';
      itemNameList = await itemNameList.replace(/,/g, ' ⇨ ');
      element['locHistory'] = await itemNameList;
    });
  }

  async getCountByStatus3(status, value) {
    let incidentslist = [];
    this.status = status;
    incidentslist = await _.filter(this.typesList, function(o) {
      return o.status == status;
    });

    // Not Similar
    const withzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident == 0;
    });
    // Smiler Incidents
    const withoutzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident !== 0;
    });
    const withUnic = await _.uniq(withoutzero, 'similarIncident');
    const list1 = [withzero, withUnic];
    incidentslist = await _.reduceRight(
      list1,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    this.countdata[`${value}`] = await incidentslist.length;
  }

  async getddata_statuswise1(status) {
    this.status = status;
    let incidentslist = [];
    if (this.status == 10) {
      this.status_name = ' Total Pending';
    }
    if (this.status == 3) {
      this.status_name = 'Completed';
    }
    if (status == 10) {
      incidentslist = await _.filter(this.typesList, function(o) {
        return o.status == 4;
      });
    }

    console.log(incidentslist, this.typesList);
    this.incidentsListStatic = incidentslist;

    // Not Similar
    const withzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident == 0;
    });
    // Smiler Incidents
    const withoutzero = await _.filter(incidentslist, function(o) {
      return o.similarIncident !== 0;
    });
    // Make uniq similar incidents
    const withUnic = await _.uniq(withoutzero, 'similarIncident');
    // Placing all of them in one variable
    const list1 = [withzero, withUnic];
    this.typesList10 = _.reduceRight(
      list1,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    await this.typesList10.forEach(async element => {
      let sCount = [];
      if (element.similarIncident) {
        sCount = await _.filter(this.incidentsListStatic, function(o) {
          return o.similarIncident == element.similarIncident;
        });
      }
      element['similar'] = sCount.length;
      const itemName = await this.getlocation_name(element.incident_location);
      console.log(this.typesList10);
      let itemNameList = (await itemName) ? itemName.toString() : '';
      itemNameList = await itemNameList.replace(/,/g, ' ⇨ ');
      element['locHistory'] = await itemNameList;
    });
  }

  open_image_popup(value) {
    this.loading = true;
    this.id = value;
    this.report_name = true;
    const part_one = _.filter(this.damages_parts_emp, function(o) {
      return o.emp_id == value.emp_id;
    });

    const part_two = _.filter(this.first_aids, function(d) {
      return d.person_id == value.emp_id && d.incident_id == value.incident_id;
    });
    this.getRaisedColourParts(part_one);
    if (part_two[0]) {
      this.incactionservice.gethospitalreport({ ifh_id: part_two[0].ifh_id }).subscribe(docs => {
        if (!docs.error) {
          this.loading = false;
          this.hospitaldetails = docs.data;
          for (let z = 0; z < docs.data.length; z++) {
            if (docs.data[z].img) {
              let a = [];
              a = docs.data[z].img.split('@@');
              const p = [];
              for (let y = 0; y < a.length; y++) {
                let b = [];
                b = a[y].split('$$');
                const c = [];
                if (y == 0) {
                  c['type'] = b[0];
                } else {
                  c['type'] = b[0].substr(1);
                }
                c['text'] = b[1];
                p.push(c);
              }
              this.hospitaldetails[z]['image_data'] = p;
            }
          }
        } else {
          this.hospitaldetails = [];
        }
        if (this.hospitaldetails[0].image_data != null) {
          this.hospitaldetails[0].image_data = this.hospitaldetails[0].image_data.filter(
            item => item.type !== ''
          );
        }
      });
    } else {
      this.hospitaldetails = [];
      this.loading = false;
    }
  }
  get_image(value) {
    if (value.side !== 'right' && value.side !== 'left') {
      const part_one = _.filter(AppSettings.Injures_one, function(o) {
        return o.Parts == value.part;
      });
      return part_one[0].img;
    } else {
      const part_one = _.filter(AppSettings.Injures_two, function(o) {
        return o.Parts == value.part;
      });
      if (part_one[0]) {
        if (value.side == 'right') {
          return part_one[0].left_img;
        } else {
          return part_one[0].right_img;
        }
      } else {
        return '';
      }
    }
  }

  getname(vsalue) {
    if (vsalue == 'near miss') {
      return 'Near Miss';
    } else {
      if (vsalue == 'Injury to People and damages to Property') {
        return 'Injuries & Damages';
      } else {
        if (vsalue == 'Injury to People') {
          return 'Injuries';
        } else {
          return 'Damages';
        }
      }
    }
  }

  getgraph() {
    this.piechartsforsome = {
      chart: {
        type: 'pie',
        height: 105,
        backgroundColor: 'rgba(255, 255, 255, 0.0)',
        marginTop: 0,
        marginBottom: 0
      },
      colors: ['#db524b', '#0f83c9', '#1bbf89', '#f7af3e', '#6b6c73'],
      title: {
        text: null
      },
      credits: {
        enabled: false
      },
      exporting: { enabled: false },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.y}</b>'
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: false
        }
      },
      series: [
        {
          name: 'Incidents',
          colorByPoint: true,
          data: [
            {
              name: 'Pending',
              y: this.countdata['pending']
            },
            {
              name: 'Completed',
              y: this.countdata['Completed']
            },
            {
              name: 'Total Pending',
              y: this.countdata['total']
            }
          ]
        }
      ]
    };
  }
}
