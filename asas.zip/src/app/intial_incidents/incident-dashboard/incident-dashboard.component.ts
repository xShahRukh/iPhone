import { Component, OnInit } from '@angular/core';
import { IncidentDashboardService } from "../../intial_incidents/incident-dashboard/incident-dashboard.service";
import { Router } from '@angular/router';
@Component({
  selector: 'app-incident-dashboard',
  templateUrl: './incident-dashboard.component.html',
  styleUrls: ['./incident-dashboard.component.styl']
})
export class IncidentDashboardComponent implements OnInit {

  public filterQuery = '';
  public rowsOnPage = 10;
  public sortBy = '';
  public sortOrder = 'asc';
  loading: Boolean = true;
  dataItem: any = {
    id: null
  };

  firstFormData: any = [];
  secondFormData: any = [];
  reflectFormData: any = [];
  rmSkills: any = [];
  listofequipments: any = [];
  title: any = "";
  pageOneData: any = {};
  incident_time: any = "";
  dataStatus: any;
  step: number;
  user_id: string;
  listofincidents: any = [];
  isHidden: boolean = false;
  incident_id: any;
  incidentsData: any = [];
  constructor(private _incidentDashboardService: IncidentDashboardService,
    private _router: Router) {

  }

  ngOnInit() {
    this.fetchIncidentData();
  }

  fetchIncidentData() {

    this._incidentDashboardService.getIncidentsData().subscribe(data => {
      console.log(data, "nsdfghfghsdfhsfsjfhhsgiuwre");
      this.firstFormData = data.response.data;
      this.loading = false;
      console.log(this.firstFormData, "dataaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
    })
  }

  showData(item: any) {
    let data: any;
    if (item.form == 1) {
      this._router.navigate(['/intial_incidents/firstincident', item.incident_id]);
      console.log("form one")
    }
    else if (item.form == 2) {
      this._router.navigate(['/intial_incidents/finalincident', item.incident_id]);
      console.log("form second")
    } else if (item.form == 3) {
      this._router.navigate(['/intial_incidents/thirdincident', item.incident_id]);
      console.log("form third")
    }
  }
}
