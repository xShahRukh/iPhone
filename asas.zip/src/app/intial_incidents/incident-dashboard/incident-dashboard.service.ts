import { Injectable } from "@angular/core";
import { IncidentSettings } from "../incidents.settings";
import {
    Headers,
    Http,
    RequestOptions,
    Response,
    ResponseContentType
} from "@angular/http";
import { Observable } from "rxjs";

@Injectable()
export class IncidentDashboardService {
    constructor(private http: Http) { }
    //getForm
    token() {
        return new RequestOptions({
            headers: new Headers({
                "Content-Type": "application/json",
                Authorization: "BEARER " + sessionStorage.getItem("token")
            })
        });
    }

    getDraftData(body: any) {
        return this.http
            .get(IncidentSettings.API.GET_DRAFT + "/" + body, this.token())
            .map((response: Response) => response.json());
    }


    fetchDataFromFormOne(incident_id: any) {
        return this.http
            .get(IncidentSettings.API.GET_TITLE_FORM_DATA1 + `/${incident_id}`, this.token())
            .map((response: Response) => response.json());
    }


    getIncidentsData() {
        return this.http
            .get(IncidentSettings.API.GET_INCIDENTS_ONE, this.token())
            .map((response: Response) => response.json());
    }
}
