import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disaster-recovery',
  templateUrl: './disaster-recovery.component.html',
  styleUrls: ['./disaster-recovery.component.css']
})
export class DisasterRecoveryComponent implements OnInit {
  businessList = [];
  constructor() {}

  ngOnInit() {
    this.businessList = [
      {
        project_name: 'Virtualized Disaster ',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'Cloud Disaster',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'Network Disaster',
        link: '../../assets/business continuity/Business Continuity.pdf'
      }
    ];
  }
}
