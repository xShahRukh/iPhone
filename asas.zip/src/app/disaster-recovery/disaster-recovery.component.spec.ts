import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisasterRecoveryComponent } from './disaster-recovery.component';

describe('DisasterRecoveryComponent', () => {
  let component: DisasterRecoveryComponent;
  let fixture: ComponentFixture<DisasterRecoveryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisasterRecoveryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisasterRecoveryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
