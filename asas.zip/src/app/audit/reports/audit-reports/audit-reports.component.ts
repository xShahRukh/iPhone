import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { AuditapiService } from '../../common/auditapi.service';
import { AuditReportService } from './audit-reports.service';
import { SharedService } from '../../common/shared.service';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-audit-reports',
  templateUrl: './audit-reports.component.html',
  styleUrls: ['./audit-reports.component.css']
})
export class AuditReportsComponent implements OnInit {
  kaizenCount = 0;
  totalResponses = 0;
  kaizen: any;
  newListbyId: any = [];
  options3: Object;
  options: Object;
  options1: Object;
  options6: Object;
  Submit = false;
  showCharts = true;
  showScheduleTable = false;
  showAuditCompleteTable = false;
  showMissedAuditTable = false;
  showNCListTable = false;
  redAudit = false;
  yellowAudit = false;
  greenAudit = false;
  showKaizen = false;
  showAllDataTable = false;
  showNcClosed = false;
  deprtmentList = [];
  showListbyId = false;
  scheduleData = [];
  ncMissedData = [];
  ncMissedList = [];
  ncMissedCount = 0;
  auditsCompleted = [];
  missedAudits = [];
  redAuditList = [];
  greenAuditList = [];
  yellowAuditList = [];
  auditCatagory = [];
  finalScheduleList = [];
  finalAuditCompletedList = [];
  finalMissedAuditList = [];
  showAllNCData = [];
  showAllOKData = [];
  deptList = [];
  NcClosed = [];
  ncClosedCount = 0;
  deptData = [];
  deptDataList = [];
  deptListById = [];
  showAllSixtyData = [];
  categoryList = [];
  mainCategoryList = [];
  categories = [];
  monthsList = [];
  showCategoryList = false;
  missedAuditsCount = 0;
  auditCompletedCount = 0;
  scheduleDataCount = 0;
  redAuditCount = 0;
  greenAuditCount = 0;
  yellowAuditCount = 0;
  NcClosedListCount = 0;
  NcList = [];
  NcListCount = 0;
  allReportsData = [];
  showNc = false;
  showAudit = false;
  months = [];
  jan = [];
  OK;
  NC;
  belowSixty;
  startDate = moment().format('YYYY-MM-01');
  startDt;
  today = moment().format('YYYY-MM-DD');
  endDt;
  endDate = moment().format('YYYY-MM-31');
  spinner = false;

  public startDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableSince: {
    //   year: new Date().getFullYear(),
    //   month: new Date().getUTCMonth() + 1, day: new Date().getDate() + 1
    // }
  };
  constructor(
    public router: Router,
    public _auditService: AuditapiService,
    public _auditReportService: AuditReportService,
    public sharedService: SharedService
  ) { }

  async ngOnInit() {
    this.spinner = false;
    this.startDt = { jsdate: new Date(this.startDate) };
    this.endDt = { jsdate: new Date(this.endDate) };
    this.getKaizenData();
    // this.getNcClosed();
    this.getCategory();
    this.getScheduleData();
    this.getNCList();
    this.getAllDataList();
    this.getCategoryListData();
    // this.getDeptData();
    this.Graph();
  }

  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }

  goBak() {
    this.showScheduleTable = false;
    this.showAuditCompleteTable = false;
    this.showCharts = true;
    this.showMissedAuditTable = false;
    this.showNCListTable = false;
    this.greenAudit = false;
    this.redAudit = false;
    this.yellowAudit = false;
    this.showAllDataTable = false;
    this.showListbyId = false;
    this.showKaizen = false;
    this.showNcClosed = false;
    this.showAudit = false;
    this.showNc = false;
  }

  ChangeDate(dt) {
    this.startDate = moment(dt).format('YYYY-MM-DD');
  }

  goToSchedulePage() {
    this.router.navigate(['audit/manager/schedule']);
  }

  ChangeEndDate(dt) {
    this.endDate = moment(dt).format('YYYY-MM-DD');
  }

  getNcClosed() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this._auditReportService.getNcClosedData(body).subscribe(data => {
      if (data.success) {
        this.NcClosed = data.data;
        this.NcClosedListCount = 0;
        this.NcClosed.forEach(item => (this.NcClosedListCount += item.count));
      } else {
      }
    });
  }

  async getScheduleData() {
    this.spinner = false;
    await this.getKaizenData();

    await this.getCategory();
    await this.getAllDataList();
    await this.getNcClosed();
    await this.getNCList();
    const body = {};
    this.reset();
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this.startDate = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    this.endDate = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this.Submit = true;
    await this._auditReportService.getScheduleData(body).subscribe(data => {
      if (data.success) {
        this.deptData = [];
        this.deptDataList = [];
        this.getDeptData();
        this.scheduleData = data.data;
        this.ncMissedData = data.NcMissed;
        this.scheduleDataCount = this.scheduleData.length;
        this.scheduleData.forEach(item => {
          if (item.status === 3) {
            this.auditsCompleted.push({
              audit_category_id: item.audit_category_id,
              audit_id: item.audit_id,
              audit_name: item.audit_name,
              audit_type: item.audit_type,
              auditor: item.auditor,
              score: item.score,
              stage: item.stage,
              start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
              end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
              status: item.status
            });
          }
        });
        for (let i = 0; i < this.auditCatagory.length; i++) {
          for (let j = 0; j < this.scheduleData.length; j++) {
            if (
              this.scheduleData[j].audit_category_id ===
              this.auditCatagory[i].audit_category_id
            ) {
              this.finalScheduleList.push({
                audit_category_id: this.auditCatagory[i].audit_category,
                audit_id: this.scheduleData[j].audit_id,
                audit_name: this.scheduleData[j].audit_name,
                audit_type: this.scheduleData[j].audit_type,
                auditor: this.scheduleData[j].auditor,
                end_dt: moment(this.scheduleData[j].end_dt).format(
                  'YYYY-MM-DD'
                ),
                start_dt: moment(this.scheduleData[j].start_dt).format(
                  'YYYY-MM-DD'
                ),
                status: this.scheduleData[j].status,
                score:
                  this.scheduleData[j].score == null
                    ? '-'
                    : this.scheduleData[j].score,
                stage: this.scheduleData[j].stage
              });
            }
          }
        }
        this.finalScheduleList.forEach(item => {
          if (item.score >= '80' && item.status === 3) {
            this.yellowAuditList.push({
              audit_category_id: item.audit_category_id,
              audit_id: item.audit_id,
              audit_name: item.audit_name,
              audit_type: item.audit_type,
              auditor: item.auditor,
              score: item.score,
              stage: item.stage,
              start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
              end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
              status: item.status
            });
          } else if (
            item.score < '80' &&
            item.score >= '60' &&
            item.status === 3
          ) {
            this.greenAuditList.push({
              audit_category_id: item.audit_category_id,
              audit_id: item.audit_id,
              audit_name: item.audit_name,
              audit_type: item.audit_type,
              auditor: item.auditor,
              score: item.score,
              stage: item.stage,
              start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
              end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
              status: item.status
            });
          } else {
            if (item.status === 3) {
              this.redAuditList.push({
                audit_category_id: item.audit_category_id,
                audit_id: item.audit_id,
                audit_name: item.audit_name,
                audit_type: item.audit_type,
                auditor: item.auditor,
                score: item.score,
                stage: item.stage,
                start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
                end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
                status: item.status
              });
            }
          }
        });
        this.redAuditCount = this.redAuditList.length;
        this.greenAuditCount = this.greenAuditList.length;
        this.yellowAuditCount = this.yellowAuditList.length;
        for (let i = 0; i < this.auditCatagory.length; i++) {
          for (let j = 0; j < this.auditsCompleted.length; j++) {
            if (
              this.auditsCompleted[j].audit_category_id ===
              this.auditCatagory[i].audit_category_id
            ) {
              this.finalAuditCompletedList.push({
                audit_category_id: this.auditCatagory[i].audit_category,
                audit_id: this.auditsCompleted[j].audit_id,
                audit_name: this.auditsCompleted[j].audit_name,
                audit_type: this.auditsCompleted[j].audit_type,
                auditor: this.auditsCompleted[j].auditor,
                end_dt: moment(this.auditsCompleted[j].end_dt).format(
                  'YYYY-MM-DD'
                ),
                start_dt: moment(this.auditsCompleted[j].start_dt).format(
                  'YYYY-MM-DD'
                ),
                status: this.auditsCompleted[j].status,
                score:
                  this.auditsCompleted[j].score == null
                    ? '-'
                    : this.auditsCompleted[j].score,
                stage: this.auditsCompleted[j].stage
              });
            }
          }
        }
        this.ncMissedList = [];
        if (this.ncMissedData.length) {
          this.ncMissedData.forEach(item => {
            this.ncMissedList.push({
              audit_name: item.auditname,
              catagory: item.audit_category,
              audit_category_id: item.audit_category_id,
              audit_id: item.audit_id,
              audit_type: item.audit_type,
              auditor: item.auditor,
              start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
              end_dt: moment(item.deadline).format('YYYY-MM-DD'),
              response_id: item.audit_response_id
            });
          });
        }
        this.ncMissedCount = this.ncMissedList.length;

        this.scheduleData.forEach(item => {
          if (item.closed_dt > item.end_dt && item.status === 3) {
            this.missedAudits.push({
              audit_category_id: item.audit_category_id,
              audit_id: item.audit_id,
              audit_name: item.audit_name,
              audit_type: item.audit_type,
              auditor: item.auditor,
              score: item.score,
              stage: item.stage,
              start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
              end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
              status: item.status,
              closed_dt: moment(item.closed_dt).format('YYYY-MM-DD')
            });
          }
        });

        for (let i = 0; i < this.auditCatagory.length; i++) {
          for (let j = 0; j < this.missedAudits.length; j++) {
            if (
              this.missedAudits[j].audit_category_id ===
              this.auditCatagory[i].audit_category_id
            ) {
              this.finalMissedAuditList.push({
                audit_category_id: this.auditCatagory[i].audit_category,
                audit_id: this.missedAudits[j].audit_id,
                audit_name: this.missedAudits[j].audit_name,
                audit_type: this.missedAudits[j].audit_type,
                auditor: this.missedAudits[j].auditor,
                end_dt: moment(this.missedAudits[j].end_dt).format(
                  'YYYY-MM-DD'
                ),
                start_dt: moment(this.missedAudits[j].start_dt).format(
                  'YYYY-MM-DD'
                ),
                status: this.missedAudits[j].status,
                score:
                  this.missedAudits[j].score == null
                    ? '-'
                    : this.missedAudits[j].score,
                stage: this.missedAudits[j].stage,
                closed_dt: this.missedAudits[j].closed_dt
              });
            }
          }
        }
        this.missedAuditsCount = this.missedAudits.length;
        this.auditCompletedCount = this.auditsCompleted.length;
        this.spinner = true;
      } else {
        this.spinner = true;
      }
    });
  }

  reset() {
    this.scheduleData = [];
    this.auditsCompleted = [];
    this.missedAudits = [];
    this.redAuditList = [];
    this.yellowAuditList = [];
    this.auditCatagory = [];
    this.finalScheduleList = [];
    this.greenAuditList = [];
    this.finalAuditCompletedList = [];
    this.finalMissedAuditList = [];
  }

  async getCategory() {
    await this.sharedService.getAuditCategory().subscribe(data => {
      if (data.success) {
        this.auditCatagory = data.data;
      }
    });
  }

  getNCList() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this._auditReportService.getNCReports(body).subscribe(data => {
      if (data.success) {
        this.NcList = data.data;
        this.NcListCount = this.NcList.length;
      }
    });
  }

  getCategoryListData() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this._auditReportService.getCategoryList(body).subscribe(data => {
      if (data.success) {
        this.categoryList = data.data;
        this.categoryList.forEach(item => {
          this.mainCategoryList.push({
            name: item.audit_category,
            y: item.categoryScore
          });
        });
        this.categories = _.pluck(this.categoryList, 'audit_category');
        this.Graph();
      }
    });
  }

  ScheduleDataForm() {
    this.showScheduleTable = true;
    this.showCharts = false;
  }

  AuditCompleteDataForm() {
    this.showAuditCompleteTable = true;
    this.showCharts = false;
  }

  MissedAuditDataForm() {
    this.showMissedAuditTable = true;
    this.showNc = true;
    this.showAudit = false;
    this.showCharts = false;
  }

  showNCList() {
    this.showNCListTable = true;
    this.showCharts = false;
  }

  RedAudit() {
    this.redAudit = true;
    this.showCharts = false;
  }

  YellowAudit() {
    this.yellowAudit = true;
    this.showCharts = false;
  }

  GreenAudit() {
    this.greenAudit = true;
    this.showCharts = false;
  }
  ShowKaizenList() {
    this.showKaizen = true;
    this.showCharts = false;
  }

  gotoback() {
    this.showScheduleTable = false;
    this.showCharts = true;
    this.redAudit = false;
    this.yellowAudit = false;
    this.showAllDataTable = false;
    this.showScheduleTable = false;
  }

  gotoback_Kaizen() {
    this.showKaizen = false;
    this.showCharts = true;
  }
  gotoback_auditsCompleted() {
    this.showAuditCompleteTable = false;
    this.showCharts = true;
  }
  gotoback_missed() {
    this.showMissedAuditTable = false;
    this.showCharts = true;
  }
  gotoback_ncclosed() {
    this.showNcClosed = false;
    this.showCharts = true;
  }
  gotoback_rised() {
    this.showNCListTable = false;
    this.showCharts = true;
  }
  gotoback_audits() {
    this.greenAudit = false;
    this.showCharts = true;
    this.greenAudit = false;
  }

  getData(value) {
    this.showAllNCData = [];
    this.showAllOKData = [];
    this.showAllSixtyData = [];
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    this._auditReportService.getTableData(body).subscribe(data => {
      if (data.success) {
        this.totalResponses = 0;
        this.showAllNCData = data.NC;
        this.showAllOKData = data.OK;
        this.showAllSixtyData = data.Sixty;
        this.showAllNCData.forEach(item => {
          if (this.showAllOKData.length > 0) {
            this.showAllOKData.forEach(ele => {
              if (item.audit_category === ele.audit_category) {
                item['OK'] = ele.OK;
              } else {
                item['OK'] = item.OK != null ? item.OK : 0;
              }
            });
          } else {
            item['OK'] = 0;
          }
        });
        this.showAllNCData.forEach(item => {
          if (this.showAllSixtyData.length > 0) {
            this.showAllSixtyData.forEach(ele => {
              if (item.audit_category === ele.audit_category) {
                item['Sixty'] = ele.Sixty;
              } else {
                item['Sixty'] = item.Sixty != null ? item.Sixty : 0;
              }
            });
          } else {
            item['Sixty'] = 0;
          }
        });

        this.showCharts = false;
        this.showAllDataTable = true;
      }
    });
  }

  NcClosedData() {
    this.showNcClosed = true;
    this.showCharts = false;
  }

  async getDeptData() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    await this._auditReportService.getDeptData(body).subscribe(data => {
      if (data.success) {
        this.deptData = [];
        // this.deptData = data.data;
        data.data.forEach(item => {
          this.deptData.push({
            audit_category: item.audit_category,
            score: item.score,
            startDate: moment(item.start_dt).format('YYYY-MM-DD'),
            closedDate: moment(item.closed_dt).format('YYYY-MM-DD')
          });
        });
        for (let i = 0; i < this.deptData.length; i++) {
          this.deptDataList.push({
            name: this.deptData[i].audit_category,
            y: this.deptData[i].score
          });
        }
        this.deptList = _.pluck(this.deptData, 'audit_category');
        this.Graph();
      }
    });
  }

  getDeptById(value) {
    this._auditReportService.getDeptById(value).subscribe(data => {
      this.Graph();
      this.months = [
        { id: '1', month: 'Jan' },
        { id: '2', month: 'Feb' },
        { id: '3', month: 'Mar' },
        { id: '4', month: 'Apr' },
        { id: '5', month: 'May' },
        { id: '6', month: 'Jun' },
        { id: '7', month: 'Jul' },
        { id: '8', month: 'Aug' },
        { id: '9', month: 'Sep' },
        { id: '10', month: 'Oct' },
        { id: '11', month: 'Nov' },
        { id: '12', month: 'Dec' }
      ];

      if (data.success) {
        this.newListbyId = [];
        this.deptListById = data.data;
        this.showCharts = false;
        this.showListbyId = true;

        this.deprtmentList = Object.keys(this.deptListById).map(item => {
          return {
            id: item,
            name: this.deptListById[item]['category_name']
          };
        });
      }
    });
  }

  async getAllDataList() {
    const body = {};
    body['startDate'] = moment(this.startDt.jsdate).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt.jsdate).format('YYYY-MM-DD');
    await this._auditReportService.getAllScoreData(body).subscribe(data => {
      if (data.success) {
        this.allReportsData = data.data;
        this.OK = this.allReportsData[0].OK;
        this.NC = this.allReportsData[0].NC;
        this.belowSixty = this.allReportsData[0].belowSixty;
        this.Graph();
      }
    });
  }
  async getKaizenData() {
    const body = {};
    body['startDate'] = moment(this.startDt).format('YYYY-MM-DD');
    body['endDate'] = moment(this.endDt).format('YYYY-MM-DD');
    await this._auditReportService.getKaizenData(body).subscribe(data => {
      if (data.success) {
        this.kaizen = data.data;
        this.kaizenCount = 0;
        if (this.kaizen.length) {
          this.kaizen.forEach(item => {
            this.kaizenCount += item.kaizenCount;
          });
        }
      }
    });
  }

  async Graph() {
    this.options = {
      chart: {
        type: 'pie',
        renderTo: 'container'
      },
      title: {
        text: 'Audit Responses'
      },
      xAxis: {
        categories: 'this.dateList',
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          name: 'Count',
          data: [
            {
              name: 'OK',
              y: this.OK,
              sliced: true,
              selected: true
            },
            {
              name: 'NC',
              y: this.NC
            },
            {
              name: '< 60%',
              y: this.belowSixty
            }
          ],
          point: {
            events: {
              click: function (event) {
                this.getData(event.point.name);
              }.bind(this)
            }
          }
        }
      ]
    };
    this.options1 = {
      chart: {
        type: 'column',
        renderTo: 'contain'
      },
      title: {
        text: 'Audit Scores by Category'
      },
      xAxis: {
        categories: this.deptList,
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          name: 'Score',
          data: this.deptDataList,
          point: {
            events: {
              click: function (event) {
                this.getDeptById(event.point.name);
              }.bind(this)
            }
          }
        }
      ]
    };

    this.options6 = {
      chart: {
        type: 'column',
        renderTo: 'co'
      },
      title: {
        text: 'Audit Scores'
      },
      xAxis: {
        categories: this.deptList,
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          name: 'Score',
          data: this.deptDataList,
          point: {
            events: {
              click: function (event) {
                this.getDeptById(event.point.name);
              }.bind(this)
            }
          }
        }
      ]
    };

    this.options3 = {
      chart: {
        type: 'pie',
        renderTo: 'con'
      },
      title: {
        text: 'Audit Score'
      },
      xAxis: {
        categories: 'this.dateList',
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },

      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0,
          colors: ['red', 'yellow', 'green'],
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: true
        }
      },
      series: [
        {
          name: 'Count',
          colorByPoint: true,
          data: [
            {
              name: 'RED',
              y: this.redAuditCount,
              sliced: true,
              selected: true,
              color: 'red'
            },
            {
              name: 'YELLOW',
              y: this.greenAuditCount,
              color: 'yellow'
            },
            {
              name: 'GREEN',
              y: this.yellowAuditCount,
              color: 'green'
            }
          ],
          point: {
            events: {
              click: function (event) {
                if (event.point.name === 'RED') {
                  this.showCharts = false;
                  this.redAudit = true;
                } else if (event.point.name === 'YELLOW') {
                  this.greenAudit = true;
                  this.showCharts = false;
                } else {
                  this.showCharts = false;
                  this.yellowAudit = true;
                }
              }.bind(this)
            }
          }
        }
      ]
    };
  }

  selectMissed(value) {
    if (value === 'nc') {
      this.showNc = true;
      this.showAudit = false;
    } else {
      this.showNc = false;
      this.showAudit = true;
    }
  }
}
