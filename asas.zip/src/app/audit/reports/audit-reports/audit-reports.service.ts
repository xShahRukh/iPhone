import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';
import { AppSettings } from '../../../app.settings';

@Injectable()
export class AuditReportService {
    constructor(private _auditapiService: AuditapiService) {}

    getScheduleData(values: any) {
        const body = values;
        console.log(body);
        const url = AuditSettings.API.GET_SCHEDULE_DATA;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getNCReports(values: any) {
        const body = values;
        const url = AuditSettings.API.GET_NC_LIST;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getAllScoreData(values: any) {
        const body = values;
        const url = AuditSettings.API.GEt_ALL_DATA_LIST;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getTableData(values: any) {
        const body = values;
        const url = AuditSettings.API.GET_NC_DATA ;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getDeptData(values: any) {
        const body = values;
        const url = AuditSettings.API.GET_DEPT_DATA;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getDeptById(id) {
        const url = AuditSettings.API.GET_DEPT_BY_ID ;
        return this._auditapiService.callApi(url, 'GET', null);
    }

    getCategoryList(values: any) {
        const body = values;
        const url = AuditSettings.API.GET_CATEGORY_LIST;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getKaizenData(values: any) {
        const body = values;
        console.log(body);
        const url = AuditSettings.API.GET_KAIZEN_DATA;
        return this._auditapiService.callApi(url, 'POST', body);
    }

    getNcClosedData(values: any) {
        const body = values;
        const url = AuditSettings.API.GET_NC_CLOSED_COUNT;
        return this._auditapiService.callApi(url, 'POST', body);
    }
}
