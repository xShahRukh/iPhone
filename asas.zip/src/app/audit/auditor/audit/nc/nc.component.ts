import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { NcService } from './nc.service';
import { AuditquestionnaireService } from '../../questionnaire/questionnaire.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { IMyDpOptions } from 'mydatepicker';

@Component({
  selector: 'app-nc',
  templateUrl: './nc.component.html',
  styleUrls: ['./nc.component.css']
})
export class NcComponent implements OnInit {
  auditorList = [];
  auditCatagory = [];
  audit_id;
  deptid;
  lid;
  filterData = [];
  auditQuestion = [];
  ncData = [];
  usersArray = [];
  ScoreArray = [];
  supervisorsList = [];
  okArray = [];
  nc_type = {};
  nc_user = {};
  totalData = [];
  auditName = '';
  deptName = '';
  location_name = '';
  selectedArray = [];
  dueDt: any = [];
  spinner = false;
  public startDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableSince: {
    //   year: new Date().getFullYear(),
    //   month: new Date().getUTCMonth() + 1, day: new Date().getDate() + 1
    // }
  };
  constructor(
    public router: Router,
    private _route: ActivatedRoute,
    private _ncService: NcService,
    public auditquestionnaireService: AuditquestionnaireService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  async ngOnInit() {
    this.spinner = false;
    this.auditName = sessionStorage.getItem('audit_name');
    this.deptName = sessionStorage.getItem('deptname');
    this.location_name = sessionStorage.getItem('locationName');

    await this._route.params.subscribe(data => {
      this.audit_id = data.id;
      this.deptid = data.dept;
      this.lid = data.location;
    });
    await this.getSupervisors();
    await this.getAllUsers();
    await this.auditQuestions();
    const id = +this.lid;
    await this._ncService.getlocationWise(this.audit_id, this.lid).subscribe(
      data => {
        console.log(data);
        this.ncData = [];
        this.totalData = [];
        this.ScoreArray = [];
        if (data.success) {
          this.spinner = true;

          this.totalData = data.data[0];
          console.log('this total data', this.totalData);
          this.filterData = _.filter(data.data[0], function(item) {
            return item.nc === 1;
          });

          let dataArray = [];
          dataArray = _.filter(data.data[0], function(item) {
            return item.score <= 60 && item.nc !== 1;
          });

          dataArray.forEach(item => {
            this.ScoreArray.push({
              response_id: item.response_id,
              question_id: item.question_id,
              nc: item.nc,
              kaizan: item.kaizan,
              location: item.location,
              score: item.score,
              ncUser: item.nc_user
            });
            // this.nc_type[item.response_id] = 'na';
            // this.nc_user[item.response_id] = 'all';

            if (item.nc_user) {
              this.nc_user[item.response_id] = item.nc_user;
            } else {
              this.nc_user[item.response_id] = 'all';
            }

            if (item.nc || item.kaizen) {
              this.nc_type[item.response_id] = item.nc !== 0 ? 'nc' : 'kaizen';
            } else {
              this.nc_type[item.response_id] = 'na';
            }
          });

          this.okArray = _.filter(data.data[0], function(item) {
            return item.score >= 60;
          });

          // nc
          let a = 0;
          this.ncData = [];
          this.filterData.forEach(item => {
            this.ncData.push({
              response_id: item.response_id,
              question_id: item.question_id,
              nc: item.nc,
              kaizan: item.kaizan,
              location: item.location,
              score: item.score,
              ncUser: item.nc_user,
              nc_duedate: moment(item.nc_duedate).format('DD/MM/YYYY')
            });
            this.dueDt[a] = { jsdate: new Date(item.nc_duedate) };

            a++;
            // this.nc_type[item.response_id] = 'na';
            if (item.nc_user) {
              this.nc_user[item.response_id] = item.nc_user;
            } else {
              this.nc_user[item.response_id] = 'all';
            }

            if (item.nc || item.kaizen) {
              this.nc_type[item.response_id] = item.nc !== 0 ? 'nc' : 'kaizen';
            } else {
              this.nc_type[item.response_id] = 'na';
            }
          });
        } else {
          this.spinner = true;
        }
      },
      error => {
        this.spinner = true;
      }
    );
  }

  //   audit qestion
  async auditQuestions() {
    await this.auditquestionnaireService
      .getauditorQuestionnaire(this.audit_id)
      .subscribe(data => {
        this.auditQuestion = [];
        if (data.success) {
          this.auditQuestion = data.data;
        }
      });
  }

  ChangeDate($event, i, value) {
    this.dueDt = $event.jsdate;
    const eq = _.filter(this.totalData, function(item) {
      return item.response_id === value.response_id;
    });
    const noteq = _.filter(this.totalData, function(item) {
      return item.response_id !== value.response_id;
    });
    eq[0].nc_duedate = moment(this.dueDt).format('YYYY-MM-DD');
    const list = [eq, noteq];
    this.totalData = _.reduceRight(
      list,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    // this.totalData[i].nc_duedate = moment(this.dueDt).format('YYYY-MM-DD');
    // this.dueDt = moment(this.dueDt).format('YYYY-MM-DD');
  }
  //   filter question
  filterQuestion(id) {
    const question = _.filter(this.auditQuestion, function(item) {
      // console.log(id, item.question_id)
      return item.question_id === id;
    })[0];
    return question;
  }

  //   get all users
  getAllUsers() {
    this._ncService.get_auditors().subscribe(data => {
      if (!data.success) {
        this.usersArray = [];
        data.data.forEach(item => {
          this.usersArray.push({
            id: item.emp_id,
            name: item.emp_name
          });
        });
      }
    });
  }

  filterUsers(eid) {
    const tempEmp = _.filter(this.usersArray, function(item) {
      return item.id === eid;
    })[0];
    return tempEmp;
  }
  selected(e) {
    if (e.target.value !== 'na') {
      this.selectedArray.push(e.target.value);
    }
  }

  submit() {
    this.spinner = false;

    const body = {};
    this.totalData.forEach(item => {
      if (this.nc_type[item.response_id]) {
        switch (this.nc_type[item.response_id]) {
          case 'nc':
            body[item.response_id] = {
              nc: 1,
              kaizen: 0,
              nc_user: this.nc_user[item.response_id]
            };
            break;
          case 'kaizen':
            body[item.response_id] = {
              nc: 0,
              kaizen: 1,
              nc_user: this.nc_user[item.response_id]
            };
            break;
        }
      }

      if (this.nc_type[item.response_id] && item.nc_duedate) {
        switch (this.nc_type[item.response_id]) {
          case 'nc':
            body[item.response_id] = {
              nc: 1,
              kaizen: 0,
              nc_user: this.nc_user[item.response_id],
              dueDt: moment(item.nc_duedate).format('YYYY-MM-DD')
            };
            break;
          case 'kaizen':
            body[item.response_id] = {
              nc: 0,
              kaizen: 1,
              nc_user: this.nc_user[item.response_id]
            };
            break;
        }
      }
    });
    if ((this.selectedArray.length = Object.keys(this.nc_user).length)) {
      this._ncService.saveNc({ responses: body }).subscribe(
        data => {
          if (data.success) {
            this.spinner = true;

            this.toastr.successToastr('Nc Assigned successfully');
            this.router.navigate(['/audit/manager/schedule']);
          } else {
            this.spinner = true;

            this.toastr.errorToastr('Error  while assiging the NC');
          }
        },
        error => {
          this.spinner = true;
        }
      );
    } else {
      this.toastr.errorToastr('Please select employee');
    }
  }

  deptPage() {
    this.router.navigate([`/audit/auditor/${this.audit_id}/departments`]);
  }

  // get Supervisors
  getSupervisors() {
    this._ncService.getSuprvisorsList().subscribe(data => {
      if (data.success) {
        console.log(data.data);
        this.supervisorsList = data.data;
      }
    });
  }
}
