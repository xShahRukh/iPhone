import {
  Component,
  OnInit,
  EventEmitter,
  ViewContainerRef
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  FormArray,
  Validator,
  Validators
} from '@angular/forms';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';
import {
  UploadOutput,
  UploadInput,
  UploadFile,
  humanizeBytes,
  UploaderOptions
} from 'ngx-uploader';
import * as saveAs from 'file-saver';
import { NcService } from './nc/nc.service';
import * as moment from 'moment';
import { SharedService } from '../../common/shared.service';
import { AuditquestionnaireService } from '../questionnaire/questionnaire.service';
import { AuditService } from './audit.service';
import { AuditSettings } from '../../audit.setting';
import { LoactionService } from 'src/app/locations/locations.service';

@Component({
  selector: 'app-audit',
  templateUrl: './audit.component.html',
  styleUrls: ['./audit.component.css']
})
export class AuditComponent implements OnInit {
  step1 = true;
  step2 = false;
  deptname = '';
  audit_id = '';
  auditQuestion = [];
  response = {};
  questionId = '';
  audit = '';
  userid = '';
  sum = 0;
  audit_name;
  deptid = '';
  locationName = '';
  lid = '';
  filterData = [];
  supervisorList = [];
  supervisorName = '';
  public myForm: FormGroup;
  options: UploaderOptions;
  formData: FormData;
  files: UploadFile[];
  uploadInput: EventEmitter<UploadInput>;
  humanizeBytes: Function;
  dragOver: boolean;
  role = '';
  ncData = [];
  filterQuestion = [];
  fileNames = {};
  fileIds = {};
  questionFiles = [];
  questionAttachments = {};
  modelQid = '';
  score_percent = 0;
  questionWeightages = {};
  status: any = '';
  usersArray = [];
  dueDt = moment().format('YYYY-MM-DD');
  spinner = false;
  LocationsListDisp: any[];
  LocationsList: any[];
  supervisorLocation: any;
  locationId;

  constructor(
    private _fb: FormBuilder,
    public router: Router,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    public auditquestionnaireService: AuditquestionnaireService,
    private _auditService: AuditService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public _ncService: NcService,
    public locationService: LoactionService
  ) {
    this.files = []; // local uploading files array
    this.uploadInput = new EventEmitter<UploadInput>(); // input events, we use this to emit data to ngx-uploader
    this.humanizeBytes = humanizeBytes;
  }

  async ngOnInit() {
    this.spinner = false;
    await this.getLocations();
    this.role = sessionStorage.getItem('role');
    this.status = sessionStorage.getItem('status');
    this.deptname = sessionStorage.getItem('deptname');
    this.audit_name = sessionStorage.getItem('audit_name');
    this.audit = sessionStorage.getItem('name');
    this.userid = sessionStorage.getItem('userid');
    await this._route.params.subscribe(data => {
      this.audit_id = data.id;
      this.deptid = data.dept;
      this.lid = data.location;
    });
    this.myForm = this._fb.group({
      audit: this.audit,
      supervisor: [''],
      location: [''],
      score: this.sum,
      checklist: this._fb.array([])
      // weightage: [''],
      // id: this.qid
    });
    await this.auditquestionnaireService
      .getauditorQuestionnaire(this.audit_id)
      .subscribe(data => {
        this.spinner = false;

        this.auditQuestion = [];
        if (data.success) {
          this.spinner = true;

          this.auditQuestion = data.data;
          data.data.forEach(item => {
            this.questionId = item.question_id;

            this.questionWeightages[item.question_id] = item.weightage;
            if (!this.lid) {
              const control = <FormArray>this.myForm.controls['checklist'];
              control.push(this.initAddress());
            } else {
              this.myForm.controls['location'].disable();
              this.myForm.controls['supervisor'].disable();
            }
          });
        } else {
          this.spinner = true;
        }
      });
    if (this.lid) {
      this.ncData = [];
      const id = +this.lid;

      await this._auditService
        .getlocationWise(this.audit_id, this.lid)
        .subscribe(async data => {
          if (data.success) {
            this.spinner = true;

            this.filterData = _.filter(data.data[0], function (item) {
              return item.location_id === id;
            });
            this.filterData.forEach(item => {
              if (item.attachments) {
                if (!this.questionAttachments[item.question_id]) {
                  this.questionAttachments[item.question_id] = [];
                }
                this.questionAttachments[
                  item.question_id
                ] = item.attachments.split(',');
              }
            });

            this.locationName = this.filterData[0].location;
            this.supervisorName = this.filterData[0].supervisor;
            await this.splitEmpName({ target: { value: parseInt(this.filterData[0].new_location_id, 0) } });

            this.myForm.patchValue({
              location: this.filterData[0].new_location_id,
              supervisor: this.supervisorName
            });
            const arr = [];
            this.filterData.forEach(item => {
              arr.push(
                this._fb.group({
                  qid: item.question_id,
                  nc: item.nc.toString(),
                  score: item.score,
                  response_id: item.response_id,
                  remarks: item.remarks,
                  nc_duedate: moment(this.filterData[0].nc_duedate).format(
                    'YYYY-MM-DD'
                  )
                  // score_percent: item.score_percent
                })
              );
              this.sum += parseInt(item.score, 10);
            });
            this.myForm.setControl('checklist', this._fb.array(arr));
          } else {
            this.spinner = true;
          }
        });
    }
    this.getAllUsers();
  }

  //   get all users
  getAllUsers() {
    this.spinner = false;

    this._ncService.get_auditors().subscribe(data => {
      if (!data.success) {
        this.spinner = true;

        this.usersArray = [];
        data.data.forEach(item => {
          this.usersArray.push({
            id: item.emp_id,
            name: item.emp_name
          });
        });
      }
    });
  }

  //  question filter

  questionFilter(id) {
    this.filterData = _.filter(this.auditQuestion, function (item) {
      return item.question_id === id;
    });
  }

  initAddress() {
    if (!this.lid) {
      return this._fb.group({
        qid: this.questionId,
        nc: ['', Validators.required],
        score: ['', Validators.required],
        remarks: ['']
        // nc_duedate: ['']
        // score_percent: ['']
      });
    } else {
      return this._fb.group({
        qid: this.questionId,
        nc: ['', Validators.required],
        score: ['', Validators.required],
        response_id: [''],
        remarks: [''],
        nc_duedate: ['']
        // score_percent: ['']
      });
    }
  }

  score(weightage) {
    const wt = parseInt(weightage, 10);
    this.sum = 0;
    this.score_percent = 0;
    this.myForm.value.checklist.forEach(item => {
      if (item.score) {
        this.sum += parseInt(item.score, 10);
      }
    });
  }

  // upload multiple images
  onUploadOutput(output: UploadOutput, qid): void {
    if (output.type === 'allAddedToQueue') {
      // when all files added in queue
    } else if (
      output.type === 'addedToQueue' &&
      typeof output.file !== 'undefined'
    ) {
      // add file to array when added
      output.file['qid'] = qid;
      this.fileNames[output.file.name.toLowerCase()] = qid;
      if (!this.fileIds[qid] || !this.fileIds[qid].length) {
        this.fileIds[qid] = [];
        this.questionFiles[qid] = [];
      }
      this.fileIds[qid].push(output.file.id);

      this.questionFiles[qid].push({
        id: output.file.id,
        name: output.file.name
      });

      // this.files.push(output.file);
      // this.fileNames = [];
      // this.files.forEach(item => {
      //   this.fileNames.push({
      //     qid: qid
      //   });
      // });
    } else if (
      output.type === 'uploading' &&
      typeof output.file !== 'undefined'
    ) {
      // update current data in files array for uploading file
      const index = this.files.findIndex(
        file => typeof output.file !== 'undefined' && file.id === output.file.id
      );
      this.files[index] = output.file;
    } else if (output.type === 'removed') {
      // remove file from array when removed
      this.files = this.files.filter(
        (file: UploadFile) => file !== output.file
      );
    } else if (output.type === 'dragOver') {
      this.dragOver = true;
    } else if (output.type === 'dragOut') {
      this.dragOver = false;
    } else if (output.type === 'drop') {
      this.dragOver = false;
    } else if (output.type === `done`) {
      this.router.navigate([`/audit/auditor/${this.audit_id}/departments`]);

      // this.myForm.reset();
      // this.toastr.successToastr('Submit successfully');
      return;
    }
  }

  clear(qid) {
    this.fileIds[qid].forEach(item => {
      this.removeFile(item);
      this.questionFiles[qid] = [];
    });
  }

  deleteSelected(qid, name) {
    this.questionFiles[qid] = this.questionFiles[qid].filter(function (item) {
      return item.name !== name;
    });
  }
  deleteAttachment(qid, id, name) {
    this.spinner = false;

    if (confirm('Are you sure, you want to delete this attachment?') === true) {
      this.questionAttachments[qid] = this.questionAttachments[qid].filter(
        function (item) {
          return item !== name;
        }
      );
      const body = {};
      body['response_id'] = id;

      body['filename'] = name;

      this._auditService.deleteAttachment(body).subscribe(data => {
        if (data.success) {
          this.spinner = true;
          this.toastr.successToastr('Attachment deleted successfully');
        } else {
          this.spinner = true;
          this.toastr.errorToastr(' Error while deleting the Attachement');
        }
      });
    }
  }

  DownloadAttachment(id, name) {
    this.spinner = false;

    this._auditService.downloadAttachment(id, name).subscribe(res => {
      this.spinner = true;

      this.saveFile(res.blob(), name);
      // if (data.success) {
      //   // this.toastr.successToastr('Attachement deleted successfully');
      // } else {
      //    this.toastr.errorToastr(' Error while deleting the Attachement');
      // }
    });
  }

  saveFile = (blobContent: Blob, fileName: string) => {
    const blob = new Blob([blobContent], { type: 'application/octet-stream' });
    saveAs(blob, fileName);
    // tslint:disable-next-line:semicolon
  };

  startUpload(): void {
    let body = {};
    body = Object.assign({}, this.myForm.value);
    body['checklist'] = JSON.stringify(body['checklist']);
    body['fileNames'] = JSON.stringify(this.fileNames);
    body['questionWeightages'] = JSON.stringify(this.questionWeightages);
    body['score'] = this.sum;
    body['location'] = this.supervisorLocation;
    body['new_location_id'] = this.locationId;
    if (this.lid) {
      body['location_id'] = this.lid;
    }

    if (this.questionFiles.length > 0) {
      const event: UploadInput = {
        type: 'uploadAll',
        url:
          AuditSettings.API.AUDIT +
          `/${this.audit_id}` +
          '/departments' +
          `/${this.deptid}` +
          '/audit',
        method: 'POST',
        data: body
      };
      this.uploadInput.emit(event);
      // this.router.navigate([`/audit/auditor/${this.audit_id}/departments`]);
      this.lid = '';
    } else {
      this._auditService
        .auditor(body, this.audit_id, this.deptid)
        .subscribe(data => {
          if (data.success) {
            this.toastr.successToastr('Audit report submitted successfully');
            this.router.navigate([
              `/audit/auditor/${this.audit_id}/departments`
            ]);
          }
        });
    }
  }

  modelpop(id) {
    this.modelQid = id;
  }

  cancelUpload(id: string): void {
    this.uploadInput.emit({ type: 'cancel', id: id });
  }

  removeFile(id: string): void {
    this.uploadInput.emit({ type: 'remove', id: id });
  }

  removeAllFiles(): void {
    this.uploadInput.emit({ type: 'removeAll' });
  }

  // save audit review
  submit() {
    this.startUpload();
    // const body = this.myForm.value;
    // body['score'] = this.sum;
    // if (this.lid) {
    //   body['location_id'] = this.lid;
    // }
    // this._auditService
    //   .auditor(body, this.audit_id, this.deptid)
    //   .subscribe(data => {
    //     if (data.success) {
    //       this.router.navigate([`/audit/auditor/${this.audit_id}/departments`]);
    //     }
    //   });
  }

  movetostep2() {
    this.step2 = true;
    this.step1 = false;
  }

  movetostep1() {
    this.step1 = true;
    this.step2 = false;
  }

  delete(id) {
    if (confirm('Are you sure, you want to delete this audit?') === true) {
      this._auditService.deleteAudit(this.audit_id, id).subscribe(data => {
        if (data.success) {
          this.toastr.successToastr('Your Question is deleted successfully');
          this.router.navigate([`/audit/auditor/${this.audit_id}/departments`]);
        } else {
        }
      });
    }
  }

  deptPage() {
    this.router.navigate(['/audit/auditor/', this.audit_id, 'departments']);
  }

  // get Locations
  getLocations() {
    this.LocationsListDisp = [];
    this.LocationsList = [];
    this.locationService.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListDisp = data.data;
      } else {
        this.LocationsList = [];
      }
    });
  }

  splitEmpName(value) {
    const location = _.filter(this.LocationsListDisp, (item) => {
      if (item.loc_id === parseInt(value.target.value, 0)) {
        return item.loc_id;
      }
    });
    if (!location.length) {
      return;
    }
    this.supervisorLocation = location[0].location_name;
    this.locationId = location[0].loc_id;
    this.supervisorList = [];
    const a = [];
    if (location[0].supervisior !== '-') {
      location[0].supervisior.split(',').forEach(element => {
        const b = {};
        b['empname'] = element.split('(')[0];
        b['empId'] = element.split('(')[1].slice(0, -1);
        a.push(b);
      });
    }
    // return a;
    this.supervisorList = a;
  }

  getDisplayCase(weg, item) {
    if (item.value.nc === '1' && item.value) {
      const a = (item.value.score / weg) * 100;
      return a > 85 ? 1 : 0;
    } else {
      return 0;
    }
  }

  changeValidations($event, i) {
    if (parseInt($event, 0) === 1) {
      this.myForm.controls['checklist']['controls'][i]['controls']['remarks'].setValidators(Validators.required);
      this.myForm.controls['checklist']['controls'][i]['controls']['remarks'].updateValueAndValidity();
    } else {
      this.myForm.controls['checklist']['controls'][i]['controls']['remarks'].setValidators();
      this.myForm.controls['checklist']['controls'][i]['controls']['remarks'].updateValueAndValidity();
    }
  }
}
