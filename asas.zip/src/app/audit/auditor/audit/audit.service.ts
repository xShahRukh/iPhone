import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';
import { Jsonp } from '@angular/http';
import { AppSettings } from '../../../app.settings';
import {
  Headers,
  Http,
  RequestOptions,
  Response,
  ResponseContentType
} from '@angular/http';
import * as FileSaver from 'file-saver';
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
@Injectable()
export class AuditService {
  constructor(private _auditapiService: AuditapiService, private http: Http) {}

  auditor(values: any, auditid, deptid) {
    console.log('sercer', auditid, deptid);
    const body = JSON.stringify(values);
    const url =
      AuditSettings.API.AUDIT +
      `/${auditid}` +
      '/departments' +
      `/${deptid}` +
      '/audit_without_upload';
    return this._auditapiService.callApi(url, 'post', body);
  }

  getlocationWise(auditid, location_id) {
    const url = AuditSettings.API.AUDIT + `/${auditid}` + `/${location_id}`;

    return this._auditapiService.callApi(url, 'get', null);
  }
  deleteAudit(auditid, location_id) {
    const url = AuditSettings.API.AUDIT + `/${auditid}` + `/${location_id}`;

    return this._auditapiService.callApi(url, 'delete', null);
  }
  deleteAttachment(values: any) {
    const body = JSON.stringify(values);
    const url = AuditSettings.API.AUDIT_ATTACHMENT_DELETE;
    return this._auditapiService.callApi(url, 'post', body);
  }

  downloadAttachment(id, name) {
    // console.log('savers', id, name);
    // const url = AuditSettings.API.AUDIT_ATTACHMENT + `/${id}` + `/${name}`;
    // return this._auditapiService.callApi(url, 'get', null);
    return this.http.get(
      AuditSettings.API.AUDIT_ATTACHMENT + `/${id}` + `/${name}`,
      new RequestOptions({ responseType: ResponseContentType.Blob })
    );
  }
}
