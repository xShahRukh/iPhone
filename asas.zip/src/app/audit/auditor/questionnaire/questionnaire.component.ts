import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';

import { AuditquestionnaireService } from './questionnaire.service';

@Component({
  selector: 'app-questionnaire',
  templateUrl: './questionnaire.component.html',
  styleUrls: ['./questionnaire.component.css']
})
export class QuestionnaireComponent implements OnInit {
  status = '';
  code: any;
  public myForm: FormGroup;
  normal = true;
  paramid;
  audit_type;
  questionnaire = [];
  auditorForm = false;
  audit_name = '';
  spinner = false;
  totalSum: any = 0;

  constructor(
    public router: Router,
    private _route: ActivatedRoute,
    private _fb: FormBuilder,
    private _auditorQuestionnaireService: AuditquestionnaireService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) { }

  ngOnInit() {
    this.spinner = false;
    this.audit_name = sessionStorage.getItem('audit_name');
    this.status = sessionStorage.getItem('status');
    this._route.params.subscribe(data => {
      this.paramid = data.id;
    });
    this.audit_type = sessionStorage.getItem('audit_type');

    if (this.audit_type === '1') {
      this.normal = false;
    }
    this.getAuditQuestions();

    this.myForm = this._fb.group({
      questions: this._fb.array([])
    });
  }

  initAddress() {
    return this._fb.group({
      question: ['', Validators.required],
      weightage: ['']
    });
  }
  addAddress() {
    const control = <FormArray>this.myForm.controls['questions'];
    control.push(this.initAddress());

    // let control = <FormArray>this.myForm.controls['addresses'];

    // if (qid) {
    //   this.auditorForm = true;
    //   const item = this.questionnaire.filter(
    //     items => items.question_id === qid
    //   )[0];
    //   control.push(
    //     this._fb.group({
    //       question: item['question'],
    //       weightage: item['weightage'],
    //       question_id: item['question_id']
    //     })
    //   );
    // } else {
    //   // this.auditorForm = false;
    //   control.push(this.initAddress());
    // }
  }
  removeAddress(i: number) {
    const control = <FormArray>this.myForm.controls['questions'];
    control.removeAt(i);
  }

  // get auditor question
  getAuditQuestions() {
    this.spinner = false;
    this.questionnaire = [];
    this._auditorQuestionnaireService
      .getauditorQuestionnaire(this.paramid)
      .subscribe(data => {
        if (data.success) {
          this.spinner = true;
          this.questionnaire = data.data;
        } else {
          this.spinner = true;
        }
      });
  }

  // show auditor form
  addQueastions() {
    this.auditorForm = true;
    this.myForm = this._fb.group({
      questions: this._fb.array([this.initAddress()])
    });
  }
  // save questions
  auditorQuestionnaire() {
    const body = this.myForm.value.questions;
    this._auditorQuestionnaireService
      .auditorQuestionnaire({ questions: body }, this.paramid)
      .subscribe(data => {
        this.getAuditQuestions();
        this.auditorForm = false;
        this.myForm = this._fb.group({
          questions: this._fb.array([])
        });
        // this.router.navigate(['/audit', this.paramid, 'departments']);
        // this.router.navigate(['/audit/auditor/', this.paramid, 'departments']);
      });
  }

  // edit audit questions
  editAuditQuestion(qid) {
    this.auditorForm = true;
    const control = <FormArray>this.myForm.controls['questions'];

    const qitem = this.questionnaire.filter(
      item => item.question_id === qid
    )[0];
    control.push(
      this._fb.group({
        question: qitem['question'],
        weightage: qitem['weightage'],
        question_id: qitem['question_id']
      })
    );
    this.totalSum = control.value[0].weightage;
  }

  // delete questionnaire
  deleteAuditQuestion(id) {
    if (confirm('Are you sure you want to delete this question?') === true) {
      this._auditorQuestionnaireService
        .deleteAuditQuestionnaire(id)
        .subscribe(data => {
          if (data.success) {
            this.toastr.successToastr('Your Question is deleted successfully');
            this.getAuditQuestions();
          } else {
          }
        });
    }
  }

  // back to auditor dashboard
  auditorDashboard() {
    this.router.navigate(['/audit/pending/auditor/dashboard']);
  }

  // go to departments
  next() {
    this.router.navigate(['/audit/auditor/', this.paramid, 'departments']);
  }
  onChange(e, i) {
    this.code = e.target.value;
    this.totalSum = 0;
    this.myForm.value['questions'].forEach(element => {
      this.totalSum += parseInt(element.weightage, 10);
    });
    // this.fianlCount = this.fianlCount + parseInt(e.target.value, 10);
  }
  omit_special_number(event) {
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
}
