import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class AuditquestionnaireService {
  constructor(private _auditapiService: AuditapiService) {}

  auditorQuestionnaire(values: any, id) {
    const body = JSON.stringify(values);
    const url =
      AuditSettings.API.AUDITOR_QUESTIONNAIRES + `${id}` + '/questionnaire';
    return this._auditapiService.callApi(url, 'post', body);
  }
  getauditorQuestionnaire(id) {
    const url =
      AuditSettings.API.AUDITOR_QUESTIONNAIRES + `${id}` + '/questionnaire';
    return this._auditapiService.callApi(url, 'get', null);
  }
  deleteAuditQuestionnaire(id) {
    const url =
      AuditSettings.API.AUDITOR_QUESTIONNAIRES + 'question/' + `${id}`;
    return this._auditapiService.callApi(url, 'DELETE', null);
  }
}
