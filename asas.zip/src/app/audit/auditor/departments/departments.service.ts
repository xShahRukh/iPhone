import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class DepartmentsService {
  constructor(private _auditapiService: AuditapiService) {}

  //   auditorQuestionnaire(values: any, id) {
  //     const body = JSON.stringify(values);
  //     const url =
  //       AuditSettings.API.AUDITOR_QUESTIONNAIRES + `${id}` + '/questionnaire';
  //     return this._auditapiService.callApi(url, 'post', body);
  //   }

  AuditDepartments(id) {
    const url =
      AuditSettings.API.AUDITOR_DEPARTMENTS + `/${id}` + '/departments';
    return this._auditapiService.callApi(url, 'get', null);
  }

  getDeptLocation(id) {
    const url = AuditSettings.API.AUDITOR_DEPARTMENTS + `/${id}`;
    return this._auditapiService.callApi(url, 'get', null);
  }

  //   deleteAuditQuestionnaire(id) {
  //     const url =
  //       AuditSettings.API.AUDITOR_QUESTIONNAIRES + 'question/' + `${id}`;
  //     return this._auditapiService.callApi(url, 'DELETE', null);
  //   }
  closeAudit(values: any, id) {
    const body = JSON.stringify(values);
    const url = AuditSettings.API.CLOSED_AUDIT + `${id}`;
    return this._auditapiService.callApi(url, 'post', body);
  }
}
