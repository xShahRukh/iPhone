import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';

import { SharedService } from '../../common/shared.service';
import { DepartmentsService } from './departments.service';
import { ApiService } from '../../../common/services/api.service';
import { textChangeRangeIsUnchanged } from 'typescript/lib/tsserverlibrary';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {
  departments = [];
  auditDepartment = [];
  audit_id = '';
  deptLocations = [];
  auditDepts = [];
  sum = 0;
  depts = [];
  location = [];
  role;
  status = '';
  rolesData = [];
  spinner = false;
  locationArray = [];
  closeAudit = [];
  iconChange = false;
  constructor(
    public router: Router,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    private _departmentsService: DepartmentsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public apiService: ApiService
  ) { }

  async ngOnInit() {
    this.rolesData = this.apiService.rolesArray;

    await this._route.params.subscribe(data => {
      this.spinner = false;
      this.audit_id = data.id;
    });
    this.role = sessionStorage.getItem('auditRole');
    this.status = sessionStorage.getItem('status');

    // if (this.rolesData[0].role_name !== 'Auditor') {
    //   this.location.push(1);
    // }
    this.getDeptLocation();
    // await this.sharedService.getdepartments().subscribe(data => {
    //   if (!data.success) {
    //     this.departments = data.data;

    //     // this.getAuitDepts();
    //   }
    // });
  }

  //  dept locations

  getDeptLocation() {
    this.spinner = false;

    this.locationArray = [];
    this._departmentsService.getDeptLocation(this.audit_id).subscribe(data => {
      if (data.success) {
        this.spinner = false;

        // this.deptLocations = data.data[0];
        this.auditDepts = [];
        const deptname = [];
        this.depts = [];
        this.locationArray = _.filter(
          _.pluck(data.data[0], 'location'),
          item => item != null
        );

        this.closeAudit = _.filter(data.data[0], function (item) {
          return item.location_id == null;
        });
        // this.deptLocations = {};

        // this.auditDepts = _.uniq(_.pluck(this.deptLocations, 'fullname'));
        data.data[0].forEach(item => {
          if (deptname.indexOf(item.fullname) === -1) {
            deptname.push(item.fullname);
            this.auditDepts.push({
              deptid: item.department_id,
              fullname: item.fullname,
              deptScore: item.deptscore
            });
            this.deptLocations[item.department_id] = [];
          }
          this.deptLocations[item.department_id].push({
            location: item.location,
            location_id: item.location_id,
            score: item.score,
            deptname: item.fullname
          });

          // depts score
          if (item.department_id) {
            this.depts.push({
              deptid: item.department_id,
              score:
                parseInt(this.deptLocations[item.department_id][0].score, 10) /
                this.auditDepts.length
            });
          }

          if (item.score) {
            this.sum += parseInt(item.score, 10) / data.data[0].length;
          }
        });
        // this.deptLocations = _.uniq(data.data, function(item) {
        //   return item.department_id;pa
        // });
      } else {
        this.spinner = true;
      }
    });
  }
  locationWise(location_id, dept_id, lname, deptname) {
    if (this.role === 'manager') {
      sessionStorage.setItem('locationName', lname);
      sessionStorage.setItem('deptname', deptname);

      this.router.navigate([
        '/audit/auditor/' +
        this.audit_id +
        '/' +
        location_id +
        '/' +
        dept_id +
        '/nc'
      ]);
    } else {
      if (location_id) {
        this.router.navigate([
          '/audit/auditor/' + this.audit_id + '/' + location_id + '/' + dept_id
        ]);
      } else {
        this.toastr.errorToastr('Not authorized');
      }
    }

    // this.router.navigate(['/audit/auditor/' + this.audit_id + id]);
  }
  // back to questionnaire
  auditPage(id, deptname) {
    if (this.role === 'auditor') {
      if (this.status !== '3') {
        sessionStorage.setItem('deptname', deptname);
        this.router.navigate([
          '/audit/auditor/' + this.audit_id + '/departments/' + id + '/audit'
        ]);
      } else {
        this.toastr.errorToastr('Audit report already closed');
      }
    } else {
      this.toastr.errorToastr('You are not authorized to view this page');
    }
  }

  totalScore() {
    const id = this.audit_id;
    const body = { score: this.sum, departments: this.depts };
    this._departmentsService.closeAudit(body, id).subscribe(data => {
      if (data.success) {
        this.toastr.successToastr('Audit report submitted successfully');
        // this.router.navigate(['/audit/auditor/dashboard']);
        this.router.navigate(['/audit/pending/auditor/dashboard']);
      } else {
        this.toastr.errorToastr('Error while completing the audit');
      }
    });
  }

  homePage() {
    if (this.role === 'auditor') {
      this.router.navigate(['/audit/pending/auditor/dashboard']);
    } else {
      this.router.navigate(['/audit/manager/schedule']);
    }
  }

  showLocation(deptId, name) {
    sessionStorage.setItem('deptname', name);
    this.iconChange = !this.iconChange;
    if (this.location.indexOf(deptId) === -1) {
      this.location.push(deptId);
    } else {
      this.location = _.without(this.location, deptId);
    }
  }
}
