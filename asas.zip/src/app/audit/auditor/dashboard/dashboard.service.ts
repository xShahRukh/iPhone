import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class DashboardService {
  constructor(private _auditapiService: AuditapiService) {}

  getAuditor() {
    const url = AuditSettings.API.GET_AUDIT_LIST;
    return this._auditapiService.callApi(url, 'get', null);
  }
  getAuditCategory() {
    const url = AuditSettings.API.AUDIT_CATEGORY;
    return this._auditapiService.callApi(url, 'get', null);
    // return this._http
    //   .get(AuditSettings.API.AUDIT_CATEGORY, this.token())
    //   .map((response: Response) => response.json());
  }
}
