import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';

import { DashboardService } from './dashboard.service';
import { SharedService } from '../../common/shared.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  auditorList = [];
  auditCatagory = [];
  spinner = false;
  now = moment().format('YYYY-MM-DD');
  pageType = '';

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public router: Router,
    private _route: ActivatedRoute,
    private _dashboardService: DashboardService,
    public sharedService: SharedService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) { }

  async ngOnInit() {
    this.now = moment().format('YYYY-MM-DD');
    this.spinner = false;
    await this.sharedService.getcategory();
    await this.sharedService.categoryList.forEach(item => {
      this.auditCatagory.push({
        audit_category_id: item.audit_category_id,
        audit_category: item.audit_category
      });
    });
    // await this.sharedService.getAuditCategory().subscribe(data => {
    //   if (data.success) {
    //     this.auditCatagory = data.data;
    //   }
    // });
    this.getAuditor();

    this.pageType = this._route.snapshot.url[0].path;
  }

  // get Auditor data

  getAuditor() {
    this.spinner = false;
    this._dashboardService.getAuditor().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.auditorList = [];
        data.data.forEach(item => {
          this.auditorList.push({
            audit_category_id: _.filter(this.auditCatagory, function (dd) {
              return dd.audit_category_id === item.audit_category_id;
            }),
            audit_id: item.audit_id,
            audit_name: item.audit_name,
            audit_type: item.audit_type,
            auditor: item.auditor,
            end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
            start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
            status: item.status
          });
        });
      } else {
        this.spinner = true;
      }
    });
  }

  homePage() {
    this.router.navigate(['/dashboard']);
  }
  questionnaire(id, audit_type, audit_name, status_id, dt) {
    if (dt <= this.now) {
      sessionStorage.setItem('audit_type', audit_type);
      sessionStorage.setItem('audit_name', audit_name);
      sessionStorage.setItem('status', status_id);
      this.router.navigate(['/audit/auditor/', id, 'questionnaire']);
    } else {
      this.toastr.errorToastr('Audit is scheduled at a later date');
    }
  }
}
