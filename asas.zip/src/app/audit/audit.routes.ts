import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';

import { DashboardComponent } from './auditor/dashboard/dashboard.component';
import { QuestionnaireComponent } from './auditor/questionnaire/questionnaire.component';
import { ManagerdashboardComponent } from './manager/managerdashboard/managerdashboard.component';
import { AddScheduleComponent } from './manager/add-schedule/add-schedule.component';
import { ScheduleComponent } from './manager/schedule/schedule.component';
import { DepartmentComponent } from './auditor/departments/department.component';
import { AuditComponent } from './auditor/audit/audit.component';
import { CategoriesQuestionsComponent } from './manager/categories-questions/categories-questions.component';
import { NcComponent } from './auditor/audit/nc/nc.component';
import { AuditReportsComponent } from './reports/audit-reports/audit-reports.component';
import { ScheduleMeetingsComponent } from './safety_system/schedule-meetings/schedule-meetings.component';
import { MomPreparationComponent } from './safety_system/mom-preparation/mom-preparation.component';
import { ActionItemsComponent } from './safety_system/action-items/action-items.component';
import { MomReportsComponent } from './safety_system/reports/mom-reports/mom-reports.component';
import { AuditDashboardComponent } from './audit-dashboard/audit-dashboard.component';
// import { AuditorComponent } from './audits/auditor.component';
const routes: Routes = [
  {
    path: 'audit-dashboard',
    component: AuditDashboardComponent
  },
  {
    path: 'auditor/dashboard',
    component: DashboardComponent
  },
  {
    path: 'pending/auditor/dashboard',
    component: DashboardComponent
  },
  {
    path: 'manager/managerdashboard',
    component: ManagerdashboardComponent
  },
  {
    path: 'manager/addSchedule/:id',
    component: AddScheduleComponent
  },
  {
    path: 'manager/schedule',
    component: ScheduleComponent
  },
  {
    path: 'pending/manager/schedule',
    component: ScheduleComponent
  },
  {
    path: 'auditor/:id/questionnaire',
    component: QuestionnaireComponent
  },

  {
    path: 'auditor/:id/departments',
    component: DepartmentComponent
  },
  {
    path: 'manager/categoriesQuestions',
    component: CategoriesQuestionsComponent
  },

  {
    path: 'auditor/:id/departments/:dept/audit',
    component: AuditComponent
  },

  {
    path: 'auditor/:id/:location/:dept',
    component: AuditComponent
  },
  {
    path: 'auditor/:id/:location/:dept/nc',
    component: NcComponent
  },
  // {
  //   path: 'manager/categoriesQuestions',
  //   component: CategoriesQuestionsComponent
  // },

  {
    path: 'reports/auditReports',
    component: AuditReportsComponent
  },

  {
    path: 'safety_system/schedule',
    component: ScheduleMeetingsComponent
  },
  {
    path: 'safety_system/preparation',
    component: MomPreparationComponent
  },
  {
    path: 'safety_system/actionItems',
    component: ActionItemsComponent
  },
  {
    path: 'safety_system/reports',
    component: MomReportsComponent
  },

  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];

// export const routing = RouterModule.forChild(routes);
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
