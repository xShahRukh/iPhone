import {
  Component,
  OnInit,
  EventEmitter,
  ViewContainerRef
} from '@angular/core';
import { CategoriesquestionsService } from './categories-questions.service';
import { SharedService } from '../../common/shared.service';
import {
  UploadOutput,
  UploadInput,
  UploadFile,
  humanizeBytes,
  UploaderOptions
} from 'ngx-uploader';
import { AuditSettings } from '../../audit.setting';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import * as _ from 'underscore';
import { XlsxToJsonService } from '../../../common/services/xlsx-to-json-service';
@Component({
  selector: 'app-categories-questions',
  templateUrl: './categories-questions.component.html',
  styleUrls: ['./categories-questions.component.css']
})
export class CategoriesQuestionsComponent implements OnInit {
  catename: any;
  deleteButton = false;
  queree: boolean;
  totalSum: any = 0;
  fianlCount = 0;
  totalTargets = 0;
  greater = false;
  code;
  categoty_id: any;
  questionsData = [];
  questionsEntry = false;
  addNew = false;
  auditCatagory: any;
  options: UploaderOptions;
  formData: FormData;
  files: UploadFile[];
  uploadInput: EventEmitter<UploadInput>;
  humanizeBytes: Function;
  dragOver: boolean;
  imagePreview: {};
  image: any;
  imageUpload: any;
  extension: any;
  imagedone: boolean;
  categoryName;
  count = 0;
  lesser = false;
  spinner = false;
  image_path = AuditSettings.image_path;
  private fieldArray: Array<any> = [];
  private newAttribute: any = {};
  public myForm: FormGroup;
  public result: any;
  public excelupload: boolean;
  result1;
  form = true;
  finaldata;
  categoryname;
  private xlsxToJsonService: XlsxToJsonService = new XlsxToJsonService();
  constructor(
    private fb: FormBuilder,
    public vcr: ViewContainerRef,
    private _QuestionCategoryService: CategoriesquestionsService,
    public sharedService: SharedService,
    public _categoryService: CategoriesquestionsService,
    public router: Router,
    public toastr: ToastrManager
  ) {
    this.files = [];
    this.uploadInput = new EventEmitter<UploadInput>();
  }

  async ngOnInit() {
    this.spinner = false;
    this.myForm = this.fb.group({
      myGroup: this.fb.array([])
    });

    await this.sharedService.getAuditCategory().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.auditCatagory = data.data;
      } else {
        this.spinner = true;
      }
    });
  }
  initAddress() {
    return this.fb.group({
      id: [],
      question: ['', Validators.required],
      weightage: ['', Validators.required],
      status: 1,
      category_id: this.categoty_id
    });
  }

  addAddress() {
    const control = <FormArray>this.myForm.controls['myGroup'];

    control.push(this.initAddress());
  }

  removeAddress(i: number) {
    this.totalSum -= this.myForm.controls.myGroup['controls'][
      i
    ].value.weightage;
    const control = <FormArray>this.myForm.controls['myGroup'];
    control.removeAt(i);
  }
  add() {
    this.addNew = true;
  }

  onUploadOutput(output: UploadOutput): void {
    if (output.type === 'allAddedToQueue') {
      this.startUpload();
    }
    if (output.type === 'addedToQueue' && typeof output.file !== 'undefined') {
      this.previewImagem(output.file.nativeFile).then(response => {
        this.imagePreview = response; // The image preview
      });
      this.files.push(output.file);
      this.imageUpload = this.files[0].name;
      this.extension = this.files[0].type.slice(6);
      this.image =
        Math.random()
          .toString(36)
          .slice(-5) +
        `.` +
        this.extension;
    }
    if (output.type !== `done`) {
      return;
    }
    if (output.type === `done`) {
      this.imagedone = true;
      // this.toastr.successToastr(`Image uploaded successfully`);
      this.startUpload();
      return;
    }
  }

  startUpload(): void {
    const event: UploadInput = {
      type: 'uploadAll',
      url: AuditSettings.API.uploadFile,
      method: 'POST',
      data: {
        image: this.image
      }
    };
    this.uploadInput.emit(event);
    this.files = [];
  }

  previewImagem(files: any) {
    const fileReader = new FileReader();
    return new Promise(resolve => {
      fileReader.readAsDataURL(files);
      fileReader.onload = function (e: any) {
        resolve(e.target.result);
      };
    });
  }

  save() {
    const body = {
      audit_category: this.categoryName,
      image: this.image
    };
    this._categoryService.addCategory(body).subscribe(data => {
      if (data.success) {
        this.addNew = false;
        this.ngOnInit();
        this.image = '';
        this.categoryName = '';
      } else {
      }
    });
  }
  addQuestions(item) {
    this.catename = item.audit_category;
    const id = item.audit_category_id;
    this.categoty_id = item.audit_category_id;
    this._categoryService.getQuestionsById(id).subscribe(data => {
      this.myForm.controls.myGroup['controls'] = [];
      this.totalSum = 0;
      this.questionsData = [];
      this.questionsData = data.data;
      this.questionsEntry = true;

      for (let i = 0; i < this.questionsData.length; i++) {
        this.addAddress();
      }
      for (let i = 0; i < this.questionsData.length; i++) {
        this.myForm.controls.myGroup['controls'][i].patchValue({
          id: this.questionsData[i].question_id,
          question: this.questionsData[i].question,
          weightage: this.questionsData[i].weightage,
          category_id: this.questionsData[i].category_id,
          status: this.questionsData[i].status
        });
        if (this.questionsData[i].status) {
          this.totalSum += this.questionsData[i].weightage;
        }
      }
    });
  }

  EnableData(i) {
    this.myForm.controls.myGroup['controls'][i].value['status'] = 1;
    this.questionsData[i].status = 1;
    this.checkCount();
  }

  DisableData(i) {
    this.myForm.controls.myGroup['controls'][i].value['status'] = 0;
    this.questionsData[i].status = 0;
    this.checkCount();
  }

  checkCount() {
    this.totalSum = 0;
    this.myForm.value.myGroup.forEach(element => {
      if (element.status === 1) {
        this.totalSum += parseInt(element.weightage, 10);
      }
    });
  }

  submit() {
    if (this.totalSum < 100) {
      this.greater = true;
      this.toastr.warningToastr(
        `Sum of all weight ages is Less than 100 please update total to 100`
      );
    } else if (this.totalSum > 100) {
      this.lesser = true;
      this.toastr.warningToastr(
        `Sum of all weight ages is More than 100 please update total to 100`
      );
    } else {
      for (let i = 0; i < this.myForm.controls.myGroup.value.length; i++) {
        if (!this.myForm.controls.myGroup.value[i].question) {
          this.queree = true;
        } else {
          this.queree = false;
        }
      }
      if (this.queree) {
        this.toastr.errorToastr(`Please fill all required fields`);
      } else {
        let body = {};
        body = this.myForm.controls.myGroup.value;
        this._categoryService.PostQuestions(body).subscribe(data => {
          if (data.success) {
            this.toastr.successToastr(`Successfully added`);
            this.questionsEntry = false;
            this.questionsData = [];
            this.myForm.controls.myGroup['controls'] = [];
            this.totalSum = 0;
          }
        });
      }
    }
  }
  gotodashboard() {
    this.router.navigate(['/dashboard']);
    this.totalSum = 0;

    this.questionsEntry = false;
    this.questionsData = [];
    this.myForm.controls.myGroup['controls'] = [];
  }

  back() {
    this.totalSum = 0;

    this.questionsEntry = false;
    this.questionsData = [];
    this.myForm.controls.myGroup['controls'] = [];
  }

  onChange(e, i) {
    this.code = e.target.value;
    this.totalSum = 0;
    this.myForm.value.myGroup.forEach(element => {
      if (element.status === 1) {
        this.totalSum += parseInt(element.weightage, 10);
      }
    });
    // this.fianlCount = this.fianlCount + parseInt(e.target.value, 10);
  }

  omit_special_number(event) {
    let k;
    k = event.charCode; //         k = event.keyCode;  (Both can be used)
    return k >= 48 && k <= 57;
  }
  closeNew() {
    this.addNew = false;
    this.categoryName = '';
  }
  GoBack() {
    this.questionsEntry = false;
  }

  openExcelform() {
    this.excelupload = true;
    this.form = false;
    // this.Submit();
  }
  handleFile(event) {
    const file = event.target.files[0];
    if (
      file.type === '.xlsx' ||
      file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      file.type === '.xls'
    ) {
      this.xlsxToJsonService.processFileToJson({}, file).subscribe(data => {
        this.result = data['sheets'].Sheet1;
        this.result1 = _.toArray(this.result);

        _.object(_.map(this.result1.slice(0, 1), _.values));
        const d = Object.keys(_.object(_.map(this.result1.slice(0, 1), _.keys)));

        const dd = d.toString();
        this.categoryname = dd;
        this.finaldata = Object.values(this.result1.slice(1, this.result1.length))
          .map(x => ({ question: x[dd], weightage: x['weightage'], checked: 1, a: x[0], b: x[1] }));

        document.getElementById('openModalButton').click();
      });
    } else {
      this.toastr.warningToastr('Invalid file format must be only MS-Excel');
    }
  }

  SubmitExcel() {
    let total = 0;
    const checkedvalues = _.filter(this.finaldata, function (oh) {
      return oh.checked === 1;
    });

    for (let km = 0; km < checkedvalues.length; km++) {
      if (checkedvalues[km].weightage) {
        total += parseInt(checkedvalues[km].weightage, 0);
      }
    }

    if (total < 100) {
      this.greater = true;
      this.toastr.warningToastr(
        `Sum of all weight ages is Less than 100 please update total to 100`
      );
    } else if (total > 100) {
      this.lesser = true;
      this.toastr.warningToastr(
        `Sum of all weight ages is More than 100 please update total to 100`
      );
    } else {
      this._categoryService
        .categoriesupload({
          questions: checkedvalues,
          category: this.categoryname
        })
        .subscribe(res => {
          if (res.success) {
            this.toastr.successToastr(`Successfully added`);
            this.excelupload = false;
            this.form = true;
            this.ngOnInit();
          } else {
            this.excelupload = true;
            this.form = false;
          }
        });
    }
  }

  save2($event, item) {
    if ($event.target.checked === true) {
      this.finaldata[this.finaldata.indexOf(item)]['checked'] = 1;
    } else {
      this.finaldata[this.finaldata.indexOf(item)]['checked'] = 0;
    }
  }
}
