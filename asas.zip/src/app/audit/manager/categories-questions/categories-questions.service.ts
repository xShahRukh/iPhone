import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';
import { ScheduleService } from '../schedule/schedule.service';

@Injectable()
export class CategoriesquestionsService {
  constructor(private _auditapiService: AuditapiService) {}

  get_dept() {
    const url = AuditSettings.API.GET_DEPT;
    return this._auditapiService.callApi(url, 'get', null);
  }

  get_auditors() {
    const url = AuditSettings.API.GET_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }

  post_auditors(values: any) {
    const body = JSON.stringify(values);
    console.log(body);

    const url = AuditSettings.API.POST_AUDITS;
    return this._auditapiService.callApi(url, 'post', body);
  }
  addCategory(values: any) {
    const body = JSON.stringify(values);
    console.log(body);

    const url = AuditSettings.API.POST_CATE;
    return this._auditapiService.callApi(url, 'post', body);
  }
  getManagerdata() {
    const url = AuditSettings.API.GET_MANAGER;
    return this._auditapiService.callApi(url, 'get', null);
  }
  getQuestionsById(id) {
    const url = AuditSettings.API.GET_CATEGORY_BY_ID + `/${id}`;
    return this._auditapiService.callApi(url, 'get', null);
  }

  PostQuestions(values: any = []) {
    const body = values;
    const url = AuditSettings.API.POST_QUESTIONS;
    return this._auditapiService.callApi(url, 'POST', body);
  }

  categoriesupload(body) {
    const url = AuditSettings.API.CATEGORIES_UPLOAD;
    return this._auditapiService.callApi(url, 'POST', body);
  }
}
