import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-managerdashboard',
  templateUrl: './managerdashboard.component.html',
  styleUrls: ['./managerdashboard.component.css']
})
export class ManagerdashboardComponent implements OnInit {
  constructor(public router: Router, private _route: ActivatedRoute) {}

  ngOnInit() {}
  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
  add() {
    const id = 'add';
    this.router.navigate(['audit/manager/addSchedule/', id]);
  }
}
