import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';
import { ScheduleService } from '../schedule/schedule.service';

@Injectable()
export class AddscheduleService {
  constructor(private _auditapiService: AuditapiService) {}

  get_dept() {
    const url = AuditSettings.API.GET_DEPT;
    return this._auditapiService.callApi(url, 'get', null);
  }

  get_auditors() {
    const url = AuditSettings.API.GET_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }

  // get Audit Users
  auditUsers() {
    const url = AuditSettings.API.GET_AUDIT_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }

  post_auditors(values: any) {
    const body = JSON.stringify(values);
    console.log(body);

    const url = AuditSettings.API.POST_AUDITS;
    return this._auditapiService.callApi(url, 'post', body);
  }

  getManagerdata() {
    const url = AuditSettings.API.GET_MANAGER;
    return this._auditapiService.callApi(url, 'get', null);
  }

  deleteManager(id) {
    const url = AuditSettings.API.DELETE_AUIDT + `/${id}`;
    return this._auditapiService.callApi(url, 'delete', null);
  }

  addauditexcel(body) {
    const url = AuditSettings.API.POST_AUDITS_EXCEL;
    return this._auditapiService.callApi(url, 'post', body);
  }
}
