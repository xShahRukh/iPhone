import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, FormArray } from '@angular/forms';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../../common/shared.service';
import { AuditapiService } from '../../common/auditapi.service';
import { AddscheduleService } from './add-schedule.service';
import * as _ from 'underscore';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { ApiService } from '../../../common/services/api.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { XlsxToJsonService } from '../../../common/services/xlsx-to-json-service';

@Component({
  selector: 'app-add-schedule',
  templateUrl: './add-schedule.component.html',
  styleUrls: ['./add-schedule.component.css']
})
export class AddScheduleComponent implements OnInit {
  enddateSel: boolean;
  startdateSel: boolean;
  auditId: any;
  dept = [];
  deptFilter = [];
  managerList = [];
  selectedItemsList = [];
  user: any;
  audi_list = [];
  auditCatagory: any;
  typeValue: any;
  questiontab = false;
  cateValue: any;
  private fieldArray: Array<any> = [];
  private newAttribute: any = {};
  question;
  public myForm: FormGroup;
  finalList = [];
  itemList = [];
  selectedItems = [];
  selectedItems1 = [];
  settings = {};
  auditor = '';
  auditUsers = [];
  auditorName;
  startDt;
  endDt;
  dept_list = [];
  paramid;
  deleteButton = false;
  spinner = false;
  rolesData = [];
  public result: any;
  public excelupload: boolean;
  result1;
  form = true;
  private xlsxToJsonService: XlsxToJsonService = new XlsxToJsonService();
  a = new Date();
  public startDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: this.a.getFullYear(),
      month: this.a.getMonth() + 1,
      day: this.a.getDate() - 1
    }
  };
  public endDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: this.a.getFullYear(),
      month: this.a.getMonth() + 1,
      day: this.a.getDate() - 1
    }
  };
  constructor(
    public router: Router,
    private fb: FormBuilder,
    public vcr: ViewContainerRef,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    private _AddscheduleService: AddscheduleService,
    public apiService: ApiService,
    public toastr: ToastrManager
  ) { }
  async ngOnInit() {
    this.rolesData = this.apiService.rolesArray;
    this.spinner = false;
    this._route.params.subscribe(data => {
      this.paramid = data.id;
    });
    this.get_dept();
    this.get_auditors();
    await this.sharedService.getAuditCategory().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.auditCatagory = data.data;
      } else {
        this.spinner = true;
      }
    });
    this.myForm = this.fb.group({
      myGroup: this.fb.array([])
    });

    this.selectedItems = [];
    this.selectedItems1 = [];
    this.settings = {
      text: 'Select department',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class'
    };
    this.getAuditUsers();
  }

  users(e) {
    this.user = e.target.value;
  }

  getAuditUsers() {
    this._AddscheduleService.auditUsers().subscribe(data => {
      if (data.success) {
        this.auditUsers = data.data;
      }
    });
  }

  get_dept() {
    this._AddscheduleService.get_dept().subscribe(data => {
      data.data.forEach(item => {
        this.dept_list.push({
          id: item.id,
          itemName: item.fullname
        });
      });
      this.getAuditor();
    });
  }
  get_auditors() {
    this._AddscheduleService.get_auditors().subscribe(data => {
      this.audi_list = [];
      data.data.forEach(item => {
        this.audi_list.push({
          id: item.emp_id,
          itemName: item.emp_name
        });
      });
    });
  }
  initAddress() {
    return this.fb.group({
      question: [''],
      waitage: ['']
    });
  }

  save() {
    this.selectedItemsList = [];
    this.selectedItems.forEach(ele => {
      this.selectedItemsList.push(ele.id);
    });

    const body = {
      audit_name: this.auditor,
      start_dt: moment(this.startDt.jsdate).format('YYYY-MM-DD'),
      end_dt: moment(this.endDt.jsdate).format('YYYY-MM-DD'),
      auditor: this.user,
      audit_type: this.typeValue,
      audit_category_id: this.cateValue,
      departments: this.selectedItemsList,
      audit_id: this.auditId
    };
    if (!body['auditor']) {
      body['auditor'] = this.finalList[0].auditor;
    }

    this._AddscheduleService.post_auditors(body).subscribe(data => {
      this.reset();
      this.router.navigate(['/audit/manager/schedule']);
    });
  }

  reset() {
    this.auditor = '';
    this.auditorName = '';
    this.startDt = '';
    this.endDt = '';
    this.cateValue = '';
    this.typeValue = '';
    this.selectedItems = [];
    this.selectedItems1 = [];
  }

  onItemSelect(item: any) { }
  OnItemDeSelect(item: any) { }
  onSelectAll(items: any) { }
  onDeSelectAll(items: any) { }
  categories(e) {
    this.cateValue = e.target.value;
    if (this.cateValue === 'regular') {
      this.questiontab = true;
    } else {
      this.questiontab = false;
    }
  }
  type(e) {
    this.typeValue = e.target.value;
  }
  ChangeDate($event) {
    this.startdateSel = true;
    this.startDt = $event.jsdate;
    this.startDt = moment(this.startDt).format('YYYY-MM-DD');
    this.endDateOptions = {
      disableUntil: {
        year: parseInt(moment($event.jsdate).format('YYYY'), 0),
        month: parseInt(moment($event.jsdate).format('MM'), 0),
        day: parseInt(moment($event.jsdate).format('DD'), 0) - 1
      }
    };
  }
  ChangeDate2($event) {
    this.enddateSel = true;
    this.endDt = $event.jsdate;
    this.endDt = moment(this.endDt).format('YYYY-MM-DD');
  }

  gotodashboard() {
    // this.router.navigate(['/dashboard']);
    const role_name = sessionStorage.getItem('auditRole');
    if (role_name === 'Auditor') {
      this.router.navigate(['/audit/auditor/dashboard']);
    } else {
      this.router.navigate(['/audit/manager/schedule']);
    }
  }

  gobacklist() {
    this.excelupload = false;
    this.form = true;
  }

  getAuditor() {
    this.spinner = false;
    this.reset();
    this._AddscheduleService.getManagerdata().subscribe(data => {
      if (data.success) {
        this.finalList = [];
        this.managerList = [];
        data.data.forEach(item => {
          this.spinner = true;
          this.managerList.push({
            audit_category_id: item.audit_category_id,
            audit_id: item.audit_id,
            audit_name: item.audit_name,
            audit_type: item.audit_type,
            auditor: item.auditor,
            end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
            start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
            status: item.status,
            score: item.score == null ? 0 : item.score,
            stage: item.stage,
            department: item.departments
          });
        });
        if (this.paramid !== 'new') {
          this.finalList = _.filter(this.managerList, item => {
            this.startdateSel = true;
            this.enddateSel = true;
            return item.audit_id === parseInt(this.paramid, 10);
          });
          this.auditor = this.finalList[0].audit_name;
          this.auditorName = this.finalList[0].auditor;
          this.startDt = { jsdate: new Date(this.finalList[0].start_dt) };
          this.endDt = { jsdate: new Date(this.finalList[0].end_dt) };
          this.cateValue = this.finalList[0].audit_category_id;
          this.typeValue = this.finalList[0].audit_type;
          this.deptFilter = this.finalList[0].department.split(',');
          this.auditId = this.finalList[0].audit_id;
          //   `Filter`,
          //   this.deptFilter,
          //   this.dept,
          //   this.dept_list.length
          // );
          this.dept = [];
          for (let i = 0; i < this.dept_list.length; i++) {
            for (let j = 0; j < this.deptFilter.length; j++) {
              if (this.dept_list[i].id === parseInt(this.deptFilter[j], 10)) {
                this.dept.push(this.dept_list[i]);
              }
            }
          }

          this.selectedItems = this.dept;
        } else {
          this.deleteButton = true;
        }
      } else {
        this.spinner = true;
      }
    });
  }

  delete() {
    // if (window.confirm('Are you sure, you want to delete this audit?')) {
    const id = this.auditId;
    this._AddscheduleService.deleteManager(id).subscribe(data => {
      this.reset();
      this.router.navigate(['/audit/manager/schedule']);
    });
    // }
  }

  openExcelform() {
    this.excelupload = true;
    this.form = false;
    // this.Submit();
  }
  handleFile(event) {
    const file = event.target.files[0];
    if (
      file.type === '.xlsx' ||
      file.type ===
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
      file.type === '.xls'
    ) {
      this.xlsxToJsonService.processFileToJson({}, file).subscribe(data => {
        this.result = data['sheets'].Sheet1;
        this.result1 = _.toArray(this.result);

        this.result1 = this.result1.map(x => ({ ...x, checked: 1 }));
        document.getElementById('openModalButton').click();
        this.reset();
      });
    } else {
      this.toastr.warningToastr('Invalid file format must be only MS-Excel');
    }
  }

  Submit() {
    for (let km = 0; km < this.result1.length; km++) {
      if (this.result1[km].audit_type === 'Open') {
        this.result1[km].audit_type = '2';
      } else {
        this.result1[km].audit_type = '1';
      }
    }
    const checkedvalues = _.filter(this.result1, function (oh) {
      return oh.checked === 1;
    });
    if (checkedvalues.length > 0) {
      this._AddscheduleService.addauditexcel(checkedvalues).subscribe(res => {
        if (res.success) {
          this.router.navigate(['/audit/manager/schedule']);
          this.excelupload = false;
          this.form = true;
        } else {
          this.excelupload = true;
          this.form = false;
        }
      });
    } else {
      this.toastr.warningToastr('Atleast one must be selected');
      this.excelupload = false;
      this.form = true;
    }
  }

  save2($event, item) {
    if ($event.target.checked === true) {
      this.result1[this.result1.indexOf(item)]['checked'] = 1;
    } else {
      this.result1[this.result1.indexOf(item)]['checked'] = 0;
    }
  }
}
