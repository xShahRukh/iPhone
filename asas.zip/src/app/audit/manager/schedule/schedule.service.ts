import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class ScheduleService {
  constructor(private _auditapiService: AuditapiService) {}

  getManagerdata() {
    const url = AuditSettings.API.GET_MANAGER;
    return this._auditapiService.callApi(url, 'get', null);
  }

  deleteManager(id) {
    const url = AuditSettings.API.DELETE_AUIDT + `/${id}`;
    return this._auditapiService.callApi(url, 'delete', null);
  }
}
