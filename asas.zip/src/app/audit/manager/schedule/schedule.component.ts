import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder } from '@angular/forms';
import { ScheduleService } from './schedule.service';
import * as moment from 'moment';
import { SharedService } from '../../common/shared.service';
import { Pipe, PipeTransform } from '@angular/core';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  managerList = [];
  auditCatagory = [];
  finalmanagerList = [];
  public filterQuery = '';
  public filterQuery1 = '';
  public rowsOnPage = 20;
  public sortBy = 'start_dt';
  public sortOrder = 'desc';
  spinner = false;
  now = moment().format('YYYY-MM-DD');
  disPageType = '';

  constructor(
    public router: Router,
    private fb: FormBuilder,
    private _route: ActivatedRoute,
    private _scheduleService: ScheduleService,
    public sharedService: SharedService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) { }
  async ngOnInit() {
    this.disPageType = this._route.snapshot.url[0].path;
    this.spinner = false;
    await this.sharedService.getAuditCategory().subscribe(data => {
      if (data.success) {
        this.auditCatagory = data.data;
        this.getAuditor();
      }
    });
  }

  homePage() {
    this.router.navigate(['/dashboard']);
  }
  getAuditor() {
    this.spinner = false;
    this._scheduleService.getManagerdata().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        data.data.forEach(item => {
          this.managerList.push({
            audit_category_id: _.filter(this.auditCatagory, function (dd) {
              return dd.audit_category_id === item.audit_category_id;
            }),
            audit_id: item.audit_id,
            audit_name: item.audit_name,
            audit_type: item.audit_type,
            auditor: item.auditor,
            auditor_name: item.auditor_name,
            end_dt: moment(item.end_dt).format('YYYY-MM-DD'),
            start_dt: moment(item.start_dt).format('YYYY-MM-DD'),
            status: item.status,
            score: item.score == null ? '-' : item.score,
            stage: item.stage
          });
        });
      } else {
        this.spinner = true;
      }
    });
  }

  editForm(item) {
    const id = item.audit_id;
    if (item.stage === 1) {
      this.router.navigate(['audit/manager/addSchedule/', id]);
    } else if (item.status === 3) {
      sessionStorage.setItem('audit_name', item.audit_name);
      this.router.navigate(['/audit/auditor/', id, 'departments']);
    } else {
      this.toastr.errorToastr('Audit is not closed');
    }
  }
  addNew() {
    const id = 'new';
    this.router.navigate(['audit/manager/addSchedule/', id]);
  }

  delete(item) {
    if (window.confirm('Are sure you want to delete this item ?')) {
      const id = item.audit_id;
      this._scheduleService.deleteManager(id).subscribe(data => {
        this.getAuditor();
      });
    }
  }
}
