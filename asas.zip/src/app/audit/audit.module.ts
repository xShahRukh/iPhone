import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';

import { routing } from './audit.routes';
import { DashboardComponent } from './auditor/dashboard/dashboard.component';
import { SharedModule } from '../common/shareds.module';
import { QuestionnaireComponent } from './auditor/questionnaire/questionnaire.component';
import { AuditapiService } from './common/auditapi.service';
import { AddScheduleComponent } from './manager/add-schedule/add-schedule.component';
import { ScheduleComponent } from './manager/schedule/schedule.component';
import { ManagerdashboardComponent } from './manager/managerdashboard/managerdashboard.component';
import { MyDatePickerModule } from 'mydatepicker';

import { DashboardService } from './auditor/dashboard/dashboard.service';
import { AuditquestionnaireService } from './auditor/questionnaire/questionnaire.service';
import { ScheduleService } from './manager/schedule/schedule.service';
import { DepartmentComponent } from './auditor/departments/department.component';
import { SharedService } from './common/shared.service';
import { DepartmentsService } from './auditor/departments/departments.service';
import { AuditComponent } from './auditor/audit/audit.component';
import { AuditService } from './auditor/audit/audit.service';
import { AddscheduleService } from './manager/add-schedule/add-schedule.service';
import { CategoriesQuestionsComponent } from './manager/categories-questions/categories-questions.component';
import { CategoriesquestionsService } from './manager/categories-questions/categories-questions.service';
import { FileUploadModule } from 'ng2-file-upload';
import { NgxUploaderModule } from 'ngx-uploader';
import { DataTableModule } from 'angular-6-datatable';
import { NcComponent } from './auditor/audit/nc/nc.component';
import { NcService } from './auditor/audit/nc/nc.service';
import { AuditReportsComponent } from './reports/audit-reports/audit-reports.component';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import * as highcharts from 'highcharts';
import { AuditReportService } from './reports/audit-reports/audit-reports.service';
import { SpinnerModule } from 'angular2-spinner/dist';
import { ScheduleMeetingsComponent } from './safety_system/schedule-meetings/schedule-meetings.component';
import { MomPreparationComponent } from './safety_system/mom-preparation/mom-preparation.component';
import { ActionItemsComponent } from './safety_system/action-items/action-items.component';
import { MomReportsComponent } from './safety_system/reports/mom-reports/mom-reports.component';
import { MomPreparationService } from './safety_system/mom-preparation/mom-preparation.service';
import { SchedulemeetingService } from './safety_system/schedule-meetings/schedule-meetings.service';
import { ActionItemsService } from './safety_system/action-items/action-items.service';
import { MomReportsService } from './safety_system/reports/mom-reports/mom-reports.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { AuditDashboardComponent } from './audit-dashboard/audit-dashboard.component';
import { CalendarModule } from 'primeng/primeng';
import { TopMenuComponent } from './common/top-menu/top-menu.component';

declare var require;

export function highchartsFactory() {
  const hc = require('highcharts');
  const hcm = require('highcharts/highcharts-more');
  const exp = require('highcharts/modules/drilldown');
  const sg = require('highcharts/modules/solid-gauge');
  hcm(hc);
  exp(hc);
  sg(hc);
  return hc;
}

@NgModule({
  declarations: [
    DashboardComponent,
    QuestionnaireComponent,
    DepartmentComponent,
    AuditComponent,
    AddScheduleComponent,
    ScheduleComponent,
    ManagerdashboardComponent,
    DepartmentComponent,
    CategoriesQuestionsComponent,
    NcComponent,
    AuditReportsComponent,
    ScheduleMeetingsComponent,
    MomPreparationComponent,
    ActionItemsComponent,
    MomReportsComponent,
    AuditDashboardComponent,
    TopMenuComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    routing,
    FormsModule,
    ReactiveFormsModule,
    MyDatePickerModule,
    AngularMultiSelectModule,
    FileUploadModule,
    NgxUploaderModule,
    DataTableModule,
    ChartModule,
    SpinnerModule,
    CalendarModule
  ],
  providers: [
    AuditapiService,
    DashboardService,
    AuditquestionnaireService,
    SharedService,
    DepartmentsService,
    AuditService,
    ScheduleService,
    SharedService,
    AddscheduleService,
    CategoriesquestionsService,
    NcService,
    AuditReportService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    },
    MomPreparationService,
    SchedulemeetingService,
    ActionItemsService,
    MomReportsService
  ]
})
export class AuditModule { }
