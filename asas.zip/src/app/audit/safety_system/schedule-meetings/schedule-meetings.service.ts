import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class SchedulemeetingService {
  constructor(private _auditapiService: AuditapiService) {}

  get_dept() {
    const url = AuditSettings.API.GET_DEPT;
    return this._auditapiService.callApi(url, 'get', null);
  }

  get_employees() {
    const url = AuditSettings.API.GET_USERS_ROLES;
    return this._auditapiService.callApi(url, 'get', null);
  }

  getmeetingdet() {
    const url = AuditSettings.API.GET_MEETING_DET;
    return this._auditapiService.callApi(url, 'get', null);
  }

  addnewschedule(value) {
    const url = AuditSettings.API.ADDNEWSCHEDULE;
    return this._auditapiService.callApi(url, 'post', value);
  }
}
