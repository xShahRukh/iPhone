import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { FormGroup, FormBuilder, FormArray, Validators } from '@angular/forms';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../../common/shared.service';
import { AuditapiService } from '../../common/auditapi.service';
import * as _ from 'underscore';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { ApiService } from '../../../common/services/api.service';
import { SchedulemeetingService } from './schedule-meetings.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-schedule-meetings',
  templateUrl: './schedule-meetings.component.html',
  styleUrls: ['./schedule-meetings.component.css']
})
export class ScheduleMeetingsComponent implements OnInit {
  const_emp_data: any = [];
  spinner = false;
  AddScheduleForm: FormGroup;
  department_ids: any = [];
  department_data: any = [];
  departmentSettings: any = {
    text: 'Select Departments',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    classes: 'myclass custom-class',
    singleSelection: false,
    badgeShowLimit: 5
  };

  employees_data: any = [];
  emp_ids: any = [];
  empSettings: any = {
    text: 'Select Employees',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    // enableSearchFilter: true,
    classes: 'myclass custom-class',
    singleSelection: false,
    badgeShowLimit: 5
  };

  public meetingdateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getUTCMonth() + 1,
      day: new Date().getDate()
    }
  };
  meetingDate: any = [];

  constructor(
    public router: Router,
    private fb: FormBuilder,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    private _scheduleMeetingService: SchedulemeetingService,
    public apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.spinner = true;
    this.AddScheduleForm = this.fb.group({
      agenda: ['', Validators.required],
      location: ['', Validators.required],
      meeting_date: ['', Validators.required],
      department_id: [[], Validators.required],
      emp_id: [[], Validators.required]
    });
    this.get_dept();
    this.get_employees();
  }

  get_dept() {
    this.department_data = [];
    this._scheduleMeetingService.get_dept().subscribe(data => {
      data.data.forEach(item => {
        this.department_data.push({
          id: item.id,
          itemName: item.fullname
        });
      });
    });
  }

  get_employees() {
    this._scheduleMeetingService.get_employees().subscribe(data => {
      this.employees_data = [];
      data.data.forEach(item => {
        let dept = item.department;
        if (!dept) {
          dept = '';
        }
        this.employees_data.push({
          id: item.emp_id,
          itemName: item.emp_name,
          department: dept,
          display_name: item.display_name
        });
      });
      this.const_emp_data = this.employees_data;
      this.employees_data = _.sortBy(this.employees_data, 'itemName');
      console.log(this.employees_data);
    });
  }

  onselect(event) {
    console.log('selecetd', event);
    this.employees_data = _.filter(this.employees_data, function(item) {
      console.log(item);
      return (
        item.department.toUpperCase() !== event.itemName.toUpperCase() &&
        item.display_name !== 'Safety Officer'
      );
    });
    this.employees_data = _.sortBy(this.employees_data, 'itemName');
  }

  ondeselect(event) {
    const dep_d = _.filter(this.const_emp_data, function(item) {
      return item.department.toUpperCase() === event.itemName.toUpperCase();
    });
    const list = [this.employees_data, dep_d];
    this.employees_data = _.reduceRight(
      list,
      function(a, b) {
        return a.concat(b);
      },
      []
    );
    this.employees_data = _.sortBy(this.employees_data, 'itemName');
  }

  onSelectAll(event) {
    console.log(event);
    event.forEach(element => {
      this.employees_data = _.filter(this.employees_data, function(item) {
        return item.department.toUpperCase() !== element.itemName.toUpperCase();
      });
    });
    this.employees_data = _.sortBy(this.employees_data, 'itemName');
  }
  onDeSelectAll(data) {
    console.log(data);
    this.department_data.forEach(element => {
      const dep_d = _.filter(this.const_emp_data, function(item) {
        return item.department.toUpperCase() === element.itemName.toUpperCase();
      });
      const list = [this.employees_data, dep_d];
      this.employees_data = _.reduceRight(
        list,
        function(a, b) {
          return a.concat(b);
        },
        []
      );
    });
    this.employees_data = _.sortBy(this.employees_data, 'itemName');
  }

  save() {
    console.log(this.AddScheduleForm);
    const department_id = [];
    this.AddScheduleForm.value.department_id.forEach(element => {
      department_id.push(element.id);
    });
    const emp_id = [];
    this.AddScheduleForm.value.emp_id.forEach(element => {
      emp_id.push(element.id);
    });
    const body = {
      agenda: this.AddScheduleForm.controls.agenda.value,
      location: this.AddScheduleForm.controls.location.value,
      meeting_date: moment(
        this.AddScheduleForm.value.meeting_date.jsdate
      ).format('YYYY-MM-DD'),
      department_id: department_id.toString(),
      emp_id: emp_id.toString()
    };
    console.log(body);
    this._scheduleMeetingService.addnewschedule(body).subscribe(res => {
      console.log(res);
      if (res.success) {
        this.toastr.successToastr('New Schedlue added successfully');
        this.AddScheduleForm.reset();
        this.router.navigate(['/audit/safety_system/preparation']);
      } else {
        this.toastr.warningToastr(res.message);
      }
    });
  }

  reset() {
    this.AddScheduleForm.reset();
  }
}
