import { Component, OnInit, ViewContainerRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  FormArray,
  Validators,
  FormControl
} from '@angular/forms';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import * as _ from 'underscore';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { ToastrManager } from 'ng6-toastr-notifications';
import { CustomValidators } from 'ng2-validation';
import { MomReportsService } from './mom-reports.service';

@Component({
  selector: 'app-mom-reports',
  templateUrl: './mom-reports.component.html',
  styleUrls: ['./mom-reports.component.css']
})
export class MomReportsComponent implements OnInit {
  users_det: any = [];
  mom_data: any = [];
  mom_report: any = [];
  pop_data: any = [];
  table_data: any = [];
  show_type: string;
  meetings_data: any = [];
  Meeting_dept_data: any = [];
  sentItems_data: any = [];
  report_data: any = [];
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';
  options_act: Object;
  options_dept: Object;
  spinner = false;

  d = new Date();
  public startDt: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 1
    }
  };
  public endDt: Object = {
    date: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: 0
    }
  };

  public startDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableSince: {
    //   year: new Date().getFullYear(),
    //   month: new Date().getUTCMonth() + 1, day: new Date().getDate() + 1
    // }
  };

  public endDateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
  };

  constructor(
    public _momreportsService: MomReportsService,
    public router: Router,
    private _route: ActivatedRoute,
    public fb: FormBuilder,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.spinner = false;
    this.show_type = 'SAFETY MEETINGS REPORTS';
    const date = new Date();
    this.startDt = { jsdate: new Date(date.getFullYear(), date.getMonth(), 1) };
    this.endDt = {
      jsdate: new Date(date.getFullYear(), date.getMonth() + 1, 0)
    };
    this.getreports_data();
    // this.getdata_by_dept();
    this.get_users();
  }

  gotodashboard(value) {
    if (value === 'dashboard') {
      this.router.navigate(['/dashboard']);
    } else {
      this.show_type = 'SAFETY MEETINGS REPORTS';
      this.getreports_data();
      // this.getdata_by_dept();
      this.get_users();
    }
  }

  testValueShow(value) {
    if (value) {
      return value;
    } else {
      return '--';
    }
  }

  getreports_data() {
    if (this.startDt && this.endDt) {
      this.spinner = false;
      const body = {
        start_date: moment(this.startDt['jsdate']).format('YYYY-MM-DD'),
        end_date: moment(this.endDt['jsdate']).format('YYYY-MM-DD')
      };
      this._momreportsService.getmomreports(body).subscribe(
        docs => {
          this.spinner = true;
          console.log(docs);
          this.report_data = [];
          if (docs.success) {
            this.report_data = docs.data;
            this.meetings_data = docs.data.meetings_data;
            this.Meeting_dept_data = docs.data.Meeting_dept_data;
            this.sentItems_data = docs.data.sentItems_data;
          }
          this.Graph();
        },
        error => {
          this.spinner = true;
        }
      );
    }
  }

  get_users() {
    this.spinner = false;
    this.users_det = [];
    this._momreportsService.get_users().subscribe(
      res => {
        this.spinner = true;
        if (res.error) {
          this.users_det = res.data;
        }
      },
      error => {
        this.spinner = true;
      }
    );
  }

  getValue(type) {
    if (type === 'act_sent') {
      return this.sentItems_data.length;
    } else if (type === 'act_completd') {
      let act_cmp_data = [];
      act_cmp_data = _.filter(this.sentItems_data, function(item) {
        return item.item_status === 1;
      });
      return act_cmp_data.length;
    } else if (type === 'dept_mom') {
      return this.Meeting_dept_data.length;
    } else {
      return 0;
    }
  }

  Graph() {
    const chart_data_1 = [
      { name: 'Action Items Sent', y: this.getValue('act_sent') },
      { name: 'Action Items Completed', y: this.getValue('act_completd') }
    ];
    console.log(chart_data_1);
    this.options_act = {
      chart: {
        type: 'pie',
        renderTo: 'container_act'
      },
      title: {
        text: 'Action Items'
      },
      xAxis: {
        categories: 'this.dateList',
        crosshair: true
      },
      yAxis: {
        min: 0
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size: 10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          data: chart_data_1
        }
      ]
    };
    this.options_dept = {
      chart: {
        type: 'pie',
        renderTo: 'container_dept'
      },
      title: {
        text: 'Department wise meetings'
      },
      xAxis: {
        categories: 'this.dateList',
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Risks'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size: 10px">{point.key}</span><table>',
        pointFormat: '<tr><td style="padding:0"><b>{point.y} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          data: this.Meeting_dept_data,
          point: {
            events: {
              click: function(event) {
                const p = event.point;
                this.getmeetings_data(p);
              }.bind(this)
            }
          }
        }
      ]
      // [
      //   {
      //     name: 'Risks',
      //     data: this.Meeting_dept_data
      //   }
      // ]
    };
    console.log(this.Meeting_dept_data);
  }

  change_graph(type) {
    this.table_data = [];
    if (type === 'meeting_scheduled') {
      this.show_type = 'Meeting Scheduled';
      this.table_data = this.meetings_data;
      this.spinner = true;
    } else if (type === 'act_sent') {
      console.log(this.sentItems_data);
      this.show_type = 'Actions Sent';
      this.table_data = this.sentItems_data;
      this.spinner = true;
    } else if (type === 'act_completed') {
      this.show_type = 'Actions Completed';
      let act_cmp_data = [];
      act_cmp_data = _.filter(this.sentItems_data, function(item) {
        return item.item_status === 1;
      });
      this.table_data = act_cmp_data;
      this.spinner = true;
    } else if (type === 'dept_report') {
      this.show_type = 'Department wise – meetings history';
      this.spinner = true;
    }
  }

  openpopupdate(item) {
    console.log(item);
    if (this.show_type !== 'Meeting Scheduled') {
      this.pop_data = item;
    } else {
      this.mom_data = [];
      this.spinner = false;
      this._momreportsService.getmomdet(item.meeting_id).subscribe(
        res => {
          this.spinner = true;
          console.log(res.data);
          if (res.success) {
            this.pop_data = item;
            this.mom_data = res.data;
            if (res.data.mom_det.length) {
              this.mom_data['mom_det'] = res.data.mom_det[0].mom_desc;
            } else {
              this.mom_data['mom_det'] = '';
            }
          }
        },
        error => {
          this.spinner = true;
        }
      );
    }
  }

  getmeetings_data(value) {
    this.getdata_by_dept(value.id);
    // console.log(value, value.id, value.name, this.mom_report);
    // let act_dept_data = [];
    // act_dept_data = _.filter(this.mom_report, function (item) {
    //   return item.department_id === value.id;
    // });
    // this.table_data = act_dept_data;
    // console.log(this.table_data, this.mom_report, value);
  }

  getdata_by_dept(value) {
    this.spinner = false;
    this.mom_report = [];
    this._momreportsService.getmeetingsbydept({ dept_id: value }).subscribe(
      res => {
        this.spinner = true;
        if (res.success) {
          this.change_graph('dept_report');
          this.mom_report = res.data;
          this.table_data = res.data;
        }
      },
      error => {
        this.spinner = true;
      }
    );
  }

  get_assign_det(value) {
    let assign_det = [];
    assign_det = _.filter(this.mom_data.assign_det, function(item) {
      return item.action_id === value;
    });
    return assign_det;
  }

  getname(value) {
    console.log(value, this.users_det);
    let user = [];
    user = _.filter(this.users_det, function(item) {
      return item.emp_id === value;
    });
    console.log(user);
    if (user.length) {
      return user[0].emp_name;
    } else {
      return value;
    }
  }
}
