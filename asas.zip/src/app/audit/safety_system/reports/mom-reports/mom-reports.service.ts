import { Injectable } from '@angular/core';

import { AuditapiService } from '../../../common/auditapi.service';
import { AuditSettings } from '../../../audit.setting';

@Injectable()
export class MomReportsService {
  constructor(private _auditapiService: AuditapiService) {}

  getmomreports(value) {
    const url = AuditSettings.API.GET_MOMREPORTS;
    return this._auditapiService.callApi(url, 'post', value);
  }

  getmeetingsbydept(value) {
    const url = AuditSettings.API.GET_MEETING_DEPT;
    return this._auditapiService.callApi(url, 'post', value);
  }

  get_users() {
    const url = AuditSettings.API.GET_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }

  getmomdet(value) {
    const role = sessionStorage.getItem('SafetySystem');
    let role_send = '';
    if (role) {
      role_send = 'SafetyOfficer';
    } else {
      role_send = 'User';
    }
    const url = AuditSettings.API.GETMOMDET + `/${role_send}` + `/${value}`;
    return this._auditapiService.callApi(url, 'get', null);
  }
}
