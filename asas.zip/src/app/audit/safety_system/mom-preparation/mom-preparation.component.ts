import { Component, OnInit, ViewContainerRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  FormArray,
  Validators,
  FormControl
} from '@angular/forms';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { SharedService } from '../../common/shared.service';
import { AuditapiService } from '../../common/auditapi.service';
import * as _ from 'underscore';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { ApiService } from '../../../common/services/api.service';
import { MomPreparationService } from './mom-preparation.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-mom-preparation',
  templateUrl: './mom-preparation.component.html',
  styleUrls: ['./mom-preparation.component.css']
})
export class MomPreparationComponent implements OnInit {
  show_data: any = [];
  mom_det: any = [];
  spinner = false;
  meetingform: FormGroup;

  public meetingdateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getUTCMonth() + 1,
      day: new Date().getDate()
    }
  };
  meetingDate: any = [];

  public deadLineOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getUTCMonth() + 1,
      day: new Date().getDate()
    }
  };

  employees_data: any = [];
  employees_ids: any = [];
  assigntoSettings: any = {
    text: 'Select Employee',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    classes: 'myclass custom-class',
    singleSelection: false,
    badgeShowLimit: 3
  };

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';

  constructor(
    public router: Router,
    private fb: FormBuilder,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    private _preparationService: MomPreparationService,
    public apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.spinner = false;
    this.getMeetingDetails();
    // this.get_employees();
  }

  getMeetingDetails() {
    this.spinner = false;
    this._preparationService.getmeetingdet().subscribe(
      response => {
        console.log(response);
        this.spinner = true;
        this.mom_det = [];
        if (response.success) {
          this.mom_det = response.data;
        }
        this.spinner = true;
      },
      error => {
        this.spinner = true;
        this.mom_det = [];
      }
    );
  }

  change_page(value) {
    console.log(value);
    if (value === 'addsafety') {
      this.router.navigate(['/audit/safety_system/schedule']);
    } else if (value === 'dashboard') {
      this.router.navigate(['/dashboard']);
    } else if (value === 'list') {
      this.getMeetingDetails();
      this.show_data = [];
    }
  }

  openattendes(value) {
    console.log(value);
    this.spinner = false;
    this._preparationService.getmomdet(value.meeting_id).subscribe(
      response => {
        this.spinner = true;
        this.employees_data = [];
        if (response.success) {
          value.attendence_det.split(',').forEach(item => {
            const a = item.split('$');
            this.employees_data.push({
              id: a[1],
              itemName: a[2]
            });
          });

          this.employees_ids = [];
          const emp_data = value.attendence_det.split(',');
          this.show_data = value;
          this.meetingDate = { jsdate: new Date(value.meeting_date) };
          this.meetingform = this.fb.group({
            meeting_id: [value.meeting_id, Validators.required],
            meeting_date: [
              { jsdate: new Date(value.meeting_date) },
              Validators.required
            ],
            mom_description: ['', Validators.required],
            mom_id: [0],
            attendence_det: this.fb.array([]),
            action_items: this.fb.array([])
          });

          if (response.data.mom_det.length !== 0) {
            this.meetingform.patchValue({
              mom_description: response.data.mom_det[0].mom_desc,
              mom_id: response.data.mom_det[0].mom_id
            });
          }

          value.attendence_det.split(',').forEach(element => {
            this.addNewRow(element.split('$'), response.data.attendees_det);
          });
          if (response.data.action_item.length !== 0) {
            let i = 0;
            response.data.action_item.forEach(element => {
              console.log(element);
              const asin_d = _.filter(response.data.assign_det, function(item) {
                return item.action_id === element.action_id;
              });
              const b = [];
              if (asin_d.length) {
                asin_d.forEach(data => {
                  const a = _.filter(this.employees_data, function(item) {
                    return item.id === data.emp_id;
                  });
                  if (a.length) {
                    b.push(a[0]);
                  }
                });
              }
              this.employees_ids[i] = b;
              this.addNewRowActionItem(
                element.action_item,
                { jsdate: new Date(element.deadline) },
                element.action_id,
                this.employees_data[i]
              );
              i++;
            });
          } else {
            this.addNewRowActionItem('', '', '', []);
          }
        }
      },
      error => {
        this.spinner = true;
      }
    );
  }

  addNewRow(id, atnd) {
    const pres = _.filter(atnd, function(item) {
      return item.scheduled_id.toString() === id[0];
    });
    let pre_s = 0;
    if (pres.length !== 0) {
      pre_s = pres[0]['present'];
    }
    const control = <FormArray>this.meetingform.controls['attendence_det'];
    control.push(this.initItemRows(id[0], id[1], id[2], pre_s));
  }

  initItemRows(id, emp_id, emp_name, pre) {
    return this.fb.group({
      scheduled_id: new FormControl(id, [Validators.required]),
      emp_id: new FormControl(emp_id),
      emp_name: new FormControl(emp_name),
      present: new FormControl(pre, [Validators.required])
    });
  }

  initItemRowsActionItems(action_item, deadline, action_id, selected) {
    return this.fb.group({
      action_det: new FormControl(action_item, [Validators.required]),
      assign_to: new FormControl(selected, [Validators.required]),
      deadline: new FormControl(deadline, [Validators.required]),
      action_id: new FormControl(action_id)
    });
  }

  addNewRowActionItem(action_item, deadline, action_id, selected) {
    const control = <FormArray>this.meetingform.controls['action_items'];
    control.push(
      this.initItemRowsActionItems(action_item, deadline, action_id, selected)
    );
  }

  deleteRowAction(index) {
    const control = <FormArray>this.meetingform.controls['action_items'];
    control.removeAt(index);
  }

  statusChange(index, value) {
    console.log(index, value);
    let atd_data = this.meetingform.value.attendence_det[index].present;
    console.log(atd_data, '123456', value);
    if (atd_data === 0 || atd_data === '0') {
      atd_data = 1;
    } else {
      atd_data = 0;
    }
    this.meetingform.controls.attendence_det['controls'][index].patchValue({
      present: atd_data
    });
    console.log(this.meetingform.value);
  }

  submitactiondetails() {
    console.log(this.meetingform);
    const attendence_det = [];
    this.meetingform.controls.attendence_det.value.forEach(element => {
      attendence_det.push({
        scheduled_id: element.scheduled_id,
        present: element.present
      });
    });
    const action_items = [];
    this.meetingform.controls.action_items.value.forEach(element => {
      console.log(element);
      action_items.push({
        action_det: element.action_det,
        assign_to: JSON.stringify(element.assign_to),
        deadline: moment(element.deadline.jsdate).format('YYYY-MM-DD'),
        action_id: element.action_id
      });
    });
    const body = {
      mom_id: this.meetingform.value.mom_id,
      meeting_id: this.meetingform.value.meeting_id,
      mom_description: this.meetingform.value.mom_description,
      meeting_date: moment(this.meetingform.value.meeting_date.jsdate).format(
        'YYYY-MM-DD'
      ),
      action_items: action_items,
      attendence_det: attendence_det
    };
    console.log(body);
    this._preparationService.addmomdetails(body).subscribe(docs => {
      console.log(docs);
      if (docs.success) {
        this.toastr.successToastr('Deatiles saved successfully');
        this.meetingform.reset();
        this.employees_ids = [];
        const emp_data = [];
        this.show_data = [];
      } else {
        this.toastr.warningToastr('Error in saving details');
      }
    });
  }

  closeform() {
    this.getMeetingDetails();
    this.show_data = [];
  }
}
