import { Injectable } from '@angular/core';

import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class MomPreparationService {
  constructor(private _auditapiService: AuditapiService) {}

  get_dept() {
    const url = AuditSettings.API.GET_DEPT;
    return this._auditapiService.callApi(url, 'get', null);
  }

  getmeetingdet() {
    const url = AuditSettings.API.GET_MEETING_DET;
    return this._auditapiService.callApi(url, 'get', null);
  }

  get_employees() {
    const url = AuditSettings.API.GET_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }

  addmomdetails(value) {
    const url = AuditSettings.API.ADDMOMDETAILS;
    return this._auditapiService.callApi(url, 'post', value);
  }

  getmomdet(value) {
    const role = sessionStorage.getItem('SafetySystem');
    let role_send = '';
    if (role) {
      role_send = 'SafetyOfficer';
    } else {
      role_send = 'User';
    }
    const url = AuditSettings.API.GETMOMDET + `/${role_send}` + `/${value}`;
    return this._auditapiService.callApi(url, 'get', null);
  }
}
