import { Injectable } from '@angular/core';
import {
  Headers,
  Http,
  RequestOptions,
  Response,
  ResponseContentType
} from '@angular/http';
import { AuditapiService } from '../../common/auditapi.service';
import { AuditSettings } from '../../audit.setting';

@Injectable()
export class ActionItemsService {
  constructor(private _auditapiService: AuditapiService, private http: Http) {}

  getActionItemsList() {
    const role = sessionStorage.getItem('SafetySystem');
    let role_send = '';
    if (role) {
      role_send = 'SafetyOfficer';
    } else {
      role_send = 'User';
    }
    const url =
      AuditSettings.API.GET_ACTIONITEMS +
      `/${role_send}` +
      `/${sessionStorage.getItem('userid')}`;
    console.log(url);
    return this._auditapiService.callApi(url, 'get', null);
  }

  addactiontaken(imagedata) {
    const url = AuditSettings.API.ADDACTIONTAKEN;
    return this._auditapiService.callApi(url, 'FILE_UPLOAD', imagedata);
  }

  closeaction(value) {
    const url = AuditSettings.API.CLOSEACTION;
    return this._auditapiService.callApi(url, 'post', value);
  }

  downloadAttachment(name) {
    return this.http.get(
      AuditSettings.API.DOWNLOAD_FILE + `${name}`,
      new RequestOptions({ responseType: ResponseContentType.Blob })
    );
  }

  getallemp_det() {
    const url = AuditSettings.API.GET_USERS;
    return this._auditapiService.callApi(url, 'get', null);
  }
}
