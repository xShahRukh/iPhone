import { Component, OnInit, ViewContainerRef } from "@angular/core";
import { FormGroup, FormBuilder, FormArray, Validators } from "@angular/forms";
import * as moment from "moment";
import { Router, ActivatedRoute } from "@angular/router";
import { SharedService } from "../../common/shared.service";
import { AuditapiService } from "../../common/auditapi.service";
import * as _ from "underscore";
import { IMyDate, IMyDpOptions } from "mydatepicker";
import { ApiService } from "../../../common/services/api.service";
import { ActionItemsService } from "./action-items.service";
import { ToastrManager } from "ng6-toastr-notifications";
import { ViewChild, ElementRef } from "@angular/core";
import * as saveAs from "file-saver";

@Component({
  selector: "app-action-items",
  templateUrl: "./action-items.component.html",
  styleUrls: ["./action-items.component.css"]
})
export class ActionItemsComponent implements OnInit {
  emp_det: any[];
  @ViewChild("openactionshow", {static:false})
  openactionshow: ElementRef;

  openactionDet: any = [];
  role: string;
  remove_det: any = [];
  show_data: any = [];
  actionItemForm: FormGroup;
  action_det: any = [];
  spinner = false;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "";
  public sortOrder = "desc";

  constructor(
    public router: Router,
    private fb: FormBuilder,
    private _route: ActivatedRoute,
    public sharedService: SharedService,
    public apiService: ApiService,
    public _actionItemService: ActionItemsService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) { }

  ngOnInit() {
    this.role = sessionStorage.getItem("SafetySystem");
    this.spinner = false;
    this.getActionItemsList();
    this.getallemp();
    this.actionItemForm = this.fb.group({
      action_assigned_id: ["", Validators.required],
      remark: ["", Validators.required],
      attachment: [[], Validators.required]
    });
  }

  testValueShow(value) {
    if (value) {
      return value;
    } else {
      return "--";
    }
  }

  getallemp() {
    this._actionItemService.getallemp_det().subscribe(
      data => {
        console.log(data.data);
        this.emp_det = [];
        if (data.error) {
          this.emp_det = data.data;
        }
      },
      error => {
        this.emp_det = [];
      }
    );
  }

  getActionItemsList() {
    this.spinner = false;
    console.log("function called");
    this._actionItemService.getActionItemsList().subscribe(
      data => {
        console.log(data.data);
        this.spinner = true;
        this.action_det = [];
        if (data.success) {
          this.action_det = data.data;
        }
      },
      error => {
        this.spinner = true;
        this.action_det = [];
      }
    );
  }

  openattendes(value) {
    console.log(value);
    this.show_data = value;
    let files = [];
    console.log(value.files);
    if (value.files) {
      files = value.files.split(",");
    }
    this.remove_det = [];
    this.actionItemForm.patchValue({
      action_assigned_id: value.action_assigned_id,
      remark: value.remark,
      attachment: files
    });
  }

  openactionAdmin(value) {
    console.log(value);
    this.spinner = false;
    this.show_data = value;
    if (value.attachments) {
      this.show_data["attachments_files"] = value.attachments.split(",");
    } else {
      this.show_data["attachments_files"] = [];
    }
    this.openactionDet = value;
    this.spinner = true;
    // document.getElementById('openactionshow').click();
  }

  onFileChange(event) {
    console.log(event);
    if (event.target.files.length > 0) {
      const file = this.actionItemForm.value.attachment;
      for (let i = 0; i < event.target.files.length; i++) {
        file.push(event.target.files[i]);
      }
      this.actionItemForm.patchValue({
        attachment: file
      });
    }
  }

  type_att(value) {
    if (typeof value === "string") {
      const a = value.split("$");
      return a[1];
    } else if (value === null) {
      return null;
    } else if (typeof value === "object") {
      return value.name;
    }
  }

  private prepareSave(): any {
    const input = new FormData();
    const actioniten_det = [];
    const arr = this.actionItemForm.get("attachment").value;
    let i = 0;
    let image_length = 0;
    arr.forEach(element => {
      if (element) {
        input.append(`image${i}`, element);
        image_length++;
      }
      ++i;
    });

    const action_data = {
      action_assigned_id: this.actionItemForm.value.action_assigned_id,
      remark: this.actionItemForm.value.remark
    };

    input.append("actioniten_det", JSON.stringify(action_data));
    input.append("image_length", JSON.stringify(image_length));
    input.append("remove_files", JSON.stringify(this.remove_det));

    return input;
  }

  submitactionitems() {
    console.log(this.actionItemForm);
    if (this.actionItemForm.valid) {
      const formModel = this.prepareSave();
      this._actionItemService.addactiontaken(formModel).subscribe(data => {
        if (data.success) {
          this.toastr.successToastr(data.message);
          // this.ngOnInit();
          this.getActionItemsList();
          this.actionItemForm = this.fb.group({
            action_assigned_id: ["", Validators.required],
            remark: ["", Validators.required],
            attachment: [[], Validators.required]
          });
          this.actionItemForm.reset();
          this.remove_det = [];
          // this.showVenderName = false;
        } else {
          this.toastr.errorToastr(data.message);
        }
      });
    } else {
      // if (!this.venderQuestionForm.controls.email.valid)
      //   this.toastr.warningToastr('Please enter email in valid format');
      // else
      this.toastr.warningToastr("Please fill all required details");
    }
  }

  deleteImage_confo(value, index) {
    console.log(index);
    console.log(value, this.actionItemForm.value.attachment);
    const file_det = this.actionItemForm.value.attachment;
    console.log(this.remove_det);
    if (typeof file_det[index] === "string") {
      const a = file_det[index].split("$");
      this.remove_det.push({
        action_assigned_id: a[0],
        file_name: a[1]
      });
      file_det[index] = null;
    } else {
      console.log("else loop");
      // const det = _.indexOf(file_det, value);
      // console.log(det);
      // if (det !== -1) {
      file_det[index] = null;
      // }
    }

    // let j = 0;
    // file_det.forEach(element => {
    //   console.log(typeof (element), element, value, file_det);
    //   if (typeof (element) === 'string' && element === value) {
    //     console.log('if loop');
    //     const a = element.split('$');
    //     this.remove_det[j++] = { action_assigned_id: a[0], file_name: a[1] };
    //   } else {
    //     console.log('else loop');
    //     const det = _.indexOf(file_det, value);
    //     console.log(det);
    //     if (det !== -1) {
    //       file_det[det] = null;
    //     }
    //   }
    // });

    const b = _.filter(file_det, function (item) {
      return item !== null;
    });
    console.log(b, file_det);
    if (b.length) {
      console.log("if");
      this.actionItemForm.patchValue({
        attachment: file_det
      });
    } else {
      console.log("else");
      this.actionItemForm.patchValue({
        attachment: []
      });
      this.actionItemForm.value.attachment = [];
    }
    console.log(
      "after remove",
      this.actionItemForm,
      this.remove_det,
      file_det,
      file_det.length
    );
  }

  close_action_user() {
    console.log(this.show_data);
    this._actionItemService
      .closeaction({
        action_assigned_id: this.show_data.action_assigned_id,
        action_id: this.show_data.action_id
      })
      .subscribe(res => {
        console.log(res);
        if (res.success) {
          this.toastr.successToastr("Action Item Closed successfully");
          this.show_data = [];
          this.getActionItemsList();
          // return 'data-dismiss="modal"';
        } else {
          this.toastr.warningToastr(res.message);
        }
      });
  }

  DownloadAttachment(value) {
    let data = "";
    if (
      sessionStorage.getItem("SafetySystem") !== "Safety Officer" &&
      typeof value === "string"
    ) {
      const a = value.split("$");
      data = a[0] + "-" + a[1];
      this._actionItemService.downloadAttachment(data).subscribe(res => {
        this.saveFile(res.blob(), data);
      });
    } else if (sessionStorage.getItem("SafetySystem") === "Safety Officer") {
      data = this.show_data.action_assigned_id + "-" + value;
      this._actionItemService.downloadAttachment(data).subscribe(res => {
        this.saveFile(res.blob(), data);
      });
    }
  }

  saveFile = (blobContent: Blob, fileName: string) => {
    const blob = new Blob([blobContent], { type: "application/octet-stream" });
    saveAs(blob, fileName);
    // tslint:disable-next-line:semicolon
  };

  getemp_name(value) {
    console.log(value);
    const det = _.filter(this.emp_det, function (item) {
      return item.emp_id.toUpperCase() === value.toUpperCase();
    });
    if (det.length) {
      return det[0].emp_name;
    } else {
      return value;
    }
  }
}
