import { Component, OnInit, ViewChild, Input } from '@angular/core';
import * as _ from 'underscore';
import * as moment from 'moment';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { DashboardReportsService } from '../../incident-report-dashboard/dashboard_report_service';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from '@angular/forms';
import { PermitService } from '../../permit_to_work/permit-types/permitservice';
// tslint:disable-next-line:prefer-const
declare let require: any;
const Highcharts = require('highcharts');
declare var $: any;
Highcharts.setOptions({
  global: {
    useUTC: false
  },
  colors: ['#7ACC86', '#F9E570', '#60A6C1', '#FF887F', '#F0B67F'],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});
@Component({
  selector: 'app-audit-dashboard',
  templateUrl: './audit-dashboard.component.html',
  styleUrls: ['./audit-dashboard.component.css']
})
export class AuditDashboardComponent implements OnInit {
  options3: Object;

  ncdata: any[];
  auditdata: any = [];
  audit_report_data: any = [];
  loading = false;
  scheduleData: any[];
  ncMissedData: any[];
  auditsCompleted: any[];
  inspectionPlanned: any;
  inspectionConducted: any;
  inspectionNcRaised: any;
  inspectionNcClosed: any;
  popUpData = {
    title: '',
    errorMsg: '',
    data: ''
  };

  public filterQuery = '';
  public rowsOnPage = 10;
  public sortBy = 'color';
  public sortOrder = 'asc';

  monthPass: Date;

  // inspection
  PData: any;
  optionsReport: Object;
  options1Report: Object;
  optionsNc: Object;
  ReportsData = [];

  tableData: any = {
    data: '',
    type: '',
    error: ''
  };
  ncTableData: any = {
    data: '',
    type: '',
    error: ''
  };
  dispType = {
    headerMsg: '',
    type: '',
    data: [],
    titleMsg: '',
    errorMsg: ''
  };
  locations = [];
  LocationsListStatic = [];
  // end of inspection

  constructor(
    public dashService: DashboardReportsService,
    private router: Router,
    public _apiService: ApiService,
    public fb: FormBuilder,
    public permitservice: PermitService,
    public _dashService: DashboardReportsService
  ) {}

  async ngOnInit() {
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    await this.Open_card4();
    await this.getScheduleData();

    // inspection
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    this.getInspectionReport();
    this.getListOfLocations();
    // end of inspection
  }

  onChange() {
    this.Open_card4();
    this.getScheduleData();
    // this.monthPass = $event;
    this.getInspectionReport();
    $('#myModal').modal('hide');
  }

  Open_card4() {
    this.loading = true;
    this.audit_report_data = [];
    this.auditdata = [];
    this.ncdata = [];

    this.dashService
      .getAuditReports(moment(this.monthPass).format('YYYY-MM'))
      .subscribe(auditData => {
        this.loading = true;
        if (auditData.success) {
          this.audit_report_data = auditData.data.auditNc[0];
          // pending details
          this.auditdata = [
            this.audit_report_data['auditsPending'],
            this.audit_report_data['NcRaised'] -
              this.audit_report_data['NcClosed']
          ];
          // Closed details
          this.ncdata = [
            this.audit_report_data['auditCompleted'],
            this.audit_report_data['NcClosed']
          ];
          this.loading = false;
        } else {
          this.loading = false;
          this.audit_report_data = [];
          this.auditdata = [0, 0];
          this.ncdata = [0, 0];
        }

        const a = this;
        this.options3 = {
          chart: {
            type: 'column',
            height: 230,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },

          title: {
            text: 'Audits',
            align: 'center',
            style: {
              font: 'bold 16px "Trebuchet MS", Verdana, sans-serif',
              color: '#000'
            }
          },

          exporting: { enabled: false },
          credits: { enabled: false },
          legend: {
            enabled: false,
            align: 'center',
            itemDistance: 5,
            itemMarginTop: 0,
            itemMarginBottom: 3,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            },
            itemHoverStyle: {
              color: 'gray'
            }
          },

          xAxis: {
            type: 'category',
            categories: ['Audit Compliance', 'NC Progress', 'Inspection'],
            labels: {
              rotation: 0,
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            }
          },

          yAxis: {
            min: 0,
            title: {
              text: 'Raised',
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            },
            labels: {
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            }
          },
          tooltip: {
            formatter: function() {
              return (
                '<b>' +
                this.x +
                '</b><br/>' +
                this.series.name +
                ': ' +
                this.y +
                '<br/>' +
                'Total: ' +
                this.point.stackTotal
              );
            }
          },

          plotOptions: {
            column: {
              stacking: 'normal'
            }
          },

          series: [
            {
              name: 'Pending',
              data: [
                {
                  y: this.audit_report_data['auditsPending']
                    ? this.audit_report_data['auditsPending']
                    : 0,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                },
                {
                  y:
                    this.audit_report_data['NcRaised'] -
                    this.audit_report_data['NcClosed']
                      ? this.audit_report_data['NcRaised'] -
                        this.audit_report_data['NcClosed']
                      : 0,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                }
              ],

              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#F0B67F'
            },
            {
              name: 'Closed',
              data: [
                {
                  y: this.audit_report_data['auditCompleted']
                    ? this.audit_report_data['auditCompleted']
                    : 0,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                },
                {
                  y: this.audit_report_data['NcClosed']
                    ? this.audit_report_data['NcClosed']
                    : 0,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                }
              ],
              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#7ACC86'
            }
          ]
        };
      });
  }

  async getScheduleData() {
    this.scheduleData = [];
    this.ncMissedData = [];
    this.auditsCompleted = [];
    const body = {};
    body['startDate'] = moment(
      moment(this.monthPass).format('YYYY-MM-01')
    ).format('YYYY-MM-DD');
    body['endDate'] = moment(
      new Date(
        parseInt(moment(this.monthPass).format('YYYY'), 0),
        parseInt(moment(this.monthPass).format('MM'), 0),
        0
      )
    ).format('YYYY-MM-DD');
    await this.dashService.getScheduleData(body).subscribe(data => {
      if (data.success) {
        this.scheduleData = data.data;
        this.ncMissedData = data.NcMissed;
      }
    });
  }

  callFunction($event) {
    this.openAuditPopUp(
      $event.point.series.name,
      $event.point.category === 'Audits' ? 'Audits' : 'NC'
    );
  }

  openAuditPopUp(status, type) {
    if (status === 'Closed' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function(o) {
        return o.status === 3;
      });
      this.popUpData.title = 'Audits Conducted';
      this.popUpData.errorMsg = 'No Audits Where Closed';
    } else if (status === 'Pending' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function(o) {
        return o.status === 1;
      });
      this.popUpData.title = 'Pending Audits';
      this.popUpData.errorMsg = 'No Audits Found';
    } else if (status === 'Scheduled' && type === 'Audits') {
      this.popUpData.data = _.filter(this.scheduleData, function(o) {
        return o.status > 0;
      });
      this.popUpData.title = 'Scheduled Audits';
      this.popUpData.errorMsg = 'No Audits Found';
    } else if (status === 'Closed' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function(o) {
        return o.status === 2;
      });
      this.popUpData.title = `NC's Closed`;
      this.popUpData.errorMsg = 'No NC Where Closed';
    } else if (status === 'Pending' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function(o) {
        return o.status === 1;
      });
      this.popUpData.title = `NC's closure in progress`;
      this.popUpData.errorMsg = 'No NC Found';
    } else if (status === 'Raised' && type === 'NC') {
      this.popUpData.data = _.filter(this.ncMissedData, function(o) {
        return o.status > 0;
      });
      this.popUpData.title = `NC's Raised`;
      this.popUpData.errorMsg = `No NC's Raised`;
    }

    if (type === 'Audits') {
      $('#auditPopUp').modal('show');
    } else {
      $('#NCPopUp').modal('show');
    }
  }

  // inspection code in audit
  // tslint:disable-next-line:use-life-cycle-interface
  ngOnChanges() {
    this.getInspectionReport();
  }

  getListOfLocations() {
    this.locations = [];
    this._dashService.getListOfLocations().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function(o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element['lastAdd'] = true;
          } else {
            element['lastAdd'] = false;
          }
        });
        this.locations = _.filter(response, function(o) {
          return o.lastAdd === false;
        });

        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getInspectionReport() {
    this.loading = true;
    const a = this;
    this.ReportsData = [];
    this._dashService
      .getInspectionReport(moment(this.monthPass).format('YYYY-MM'))
      .subscribe(async response => {
        this.ReportsData = response.data;

        console.log('reports data', this.ReportsData);

        const ncAuditPending = _.filter(response.data.NcAudit, function(o) {
          return o.status === 1;
        });
        const ncAuditClosed = _.filter(response.data.NcAudit, function(o) {
          return o.status === 2;
        });
        const ncInsPending = _.filter(response.data.Inspection, function(o) {
          return o.status === 0;
        });
        const ncInsClosed = _.filter(response.data.Inspection, function(o) {
          return o.status === 1;
        });
        const ncInsClosedChart2 = _.filter(response.data.NcInspection, function(
          o
        ) {
          return o.status === 1;
        });
        const ncInsPendingChart2 = _.filter(
          response.data.NcInspection,
          function(o) {
            return o.status !== 1;
          }
        );

        console.log(ncInsPending, ncInsClosed, response.data, 'inspection');

        this.inspectionPlanned = ncInsPending.length;
        this.inspectionConducted = ncInsClosed.length;
        // First Graph
        this.optionsReport = {
          chart: {
            type: 'column',
            height: 250,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: 'Inspections',
            style: {
              color: '#f6a821',
              fontSize: '16px;'
            }
          },
          credits: {
            enabled: false
          },
          exporting: { enabled: false },
          xAxis: {
            categories: ['Inspections Planned', 'Inspections Conducted'],
            crosshair: true,
            labels: {
              style: {
                fontSize: '13px',
                color: '#8d8f94'
              }
            }
          },
          yAxis: {
            min: 0,
            title: {
              text: 'Raised',
              style: {
                color: '#d7d7d7'
              }
            },
            labels: {
              style: {
                color: '#8d8f94'
              }
            }
          },
          legend: {
            itemStyle: {
              color: '#8d8f94'
            },
            enabled: false
          },
          tooltip: {
            headerFormat:
              '<span style="font-size:10px">No. of {point.key} </span><table>',
            pointFormat: '<tr><td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
          },
          plotOptions: {
            // series: {
            //   cursor: 'pointer',
            //   events: {
            //     click: function (event) {
            //       a.callFunction(event);
            //     }
            //   }
            // }
          },
          series: [
            {
              name: 'pending',
              data: [
                // {
                //   y: response.data.Inspection.length,
                //   color: '#f6a821',
                //   lineColor: '#e3a33f'
                // },
                // {
                //   y: response.data.Audit.length,
                //   color: '#258000',
                //   lineColor: '#e3a33f'
                // },
                {
                  y: ncInsPending.length,
                  color: '#f6a821',
                  lineColor: '#e3a33f'
                },
                {
                  y: ncInsClosed.length,
                  color: '#258000',
                  lineColor: '#e3a33f'
                }
              ],
              showInLegend: false
            },
            {
              name: 'closed',
              data: [
                {
                  y: ncInsClosedChart2.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                },
                {
                  y: ncAuditPending.length - ncAuditClosed.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                }
              ]
            }
          ]
        };

        this.options1Report = {
          chart: {
            type: 'column',
            height: 250,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: 'Inspections',
            align: 'center',
            style: {
              font: 'bold 16px "Trebuchet MS", Verdana, sans-serif',
              color: '#000'
            }
          },

          exporting: { enabled: false },
          credits: { enabled: false },
          xAxis: {
            categories: ['Inspection Compliance', 'NC Progress'],
            crosshair: false,
            labels: {
              rotation: 0,
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            }
          },
          yAxis: {
            min: 0,
            title: {
              text: 'Raised',
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            },
            labels: {
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            }
          },
          tooltip: {
            formatter: function() {
              return (
                '<b>' +
                this.x +
                '</b><br/>' +
                this.series.name +
                ': ' +
                this.y +
                '<br/>' +
                'Total: ' +
                this.point.stackTotal
              );
            }
          },
          plotOptions: {
            column: {
              stacking: 'normal'
            }
          },
          legend: {
            enabled: false,
            align: 'center',
            itemDistance: 5,
            itemMarginTop: 0,
            itemMarginBottom: 3,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            },
            itemHoverStyle: {
              color: 'gray'
            }
          },
          series: [
            {
              name: 'Pending',
              data: [
                {
                  y: ncInsPending.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                },
                {
                  y: ncInsClosedChart2.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                }
              ],
              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#F0B67F'
            },
            {
              name: 'Closed',
              data: [
                {
                  y: ncInsClosed.length,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                },
                {
                  y: ncInsPendingChart2.length,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                }
              ],
              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#7ACC86'
            }
          ]
        };

        // Second Graph (Raised from Ncs)
        this.inspectionNcRaised = ncInsPendingChart2.length;
        this.inspectionNcClosed = ncInsClosedChart2.length;
        this.optionsNc = {
          chart: {
            type: 'column',
            height: 250,
            backgroundColor: 'rgba(255, 255, 255, 0.0)'
          },
          title: {
            text: 'Overall NC Progress',
            align: 'center',
            style: {
              font: 'bold 16px "Trebuchet MS", Verdana, sans-serif',
              color: '#000'
            }
          },
          credits: {
            enabled: false
          },
          exporting: { enabled: false },
          xAxis: {
            categories: ['Inspections', 'Audits'],
            crosshair: false,
            labels: {
              rotation: 0,
              style: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              }
            }
          },
          tooltip: {
            formatter: function() {
              return (
                '<b>' +
                this.x +
                '</b><br/>' +
                this.series.name +
                ': ' +
                this.y +
                '<br/>' +
                'Total: ' +
                this.point.stackTotal
              );
            }
          },
          plotOptions: {
            // series: {
            //   cursor: 'pointer',
            //   events: {
            //     click: function (event) {
            //       a.callFunctionNcReports(event);
            //     }
            //   }
            // },
            column: {
              stacking: 'normal'
            }
          },
          legend: {
            enabled: false,
            align: 'center',
            itemDistance: 5,
            itemMarginTop: 0,
            itemMarginBottom: 3,
            itemStyle: {
              font: '8pt Trebuchet MS, Verdana, sans-serif',
              color: '#000'
            },
            itemHoverStyle: {
              color: 'gray'
            }
          },
          series: [
            {
              name: 'Pending',
              data: [
                {
                  y: ncInsClosedChart2.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                },
                {
                  y: ncAuditPending.length - ncAuditClosed.length,
                  color: '#F0B67F',
                  lineColor: '#F0B67F'
                }
              ],
              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#F0B67F'
            },
            {
              name: 'Closed',
              data: [
                {
                  y: ncInsPendingChart2.length,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                },
                {
                  y: ncAuditClosed.length,
                  color: '#7ACC86',
                  lineColor: '#7ACC86'
                }
              ],
              dataLabels: {
                enabled: false,
                rotation: -90,
                color: '#FFFFFF',
                align: 'center',
                format: '{point.y}', // one decimal
                style: {
                  font: '8pt Trebuchet MS, Verdana, sans-serif',
                  color: '#000'
                }
              },
              borderColor: 'transperant',
              stack: 'male',
              color: '#7ACC86'
            }
          ]
        };
        const ncaa = {};
        ncaa['point'] = {};
        ncaa['point'] = { category: 'Inspections Planned' };
        ncaa['point']['series'] = { name: 'Pending' };
        await this.callFunction1(ncaa);
        ncaa['point'] = { category: 'Inspections' };
        ncaa['point']['series'] = { name: 'Pending' };
        await this.callFunctionNcReports(ncaa);

        if (!this.tableData['data'].length) {
          ncaa['point'] = { category: 'Audits' };
          this.callFunction1(ncaa);
        }
        this.loading = false;
      });
  }

  callFunction1(event) {
    console.log(event.point.category);
    if (event.point.category === 'Inspections Planned') {
      this.tableData['type'] = 'Inspections';
      this.tableData['data'] = _.filter(
        this.ReportsData['Inspection'],
        function(o) {
          return o.status === 0;
        }
      );
      this.tableData['error'] = 'No Inspections Planned';
    } else if (event.point.category === 'Inspections Conducted') {
      this.tableData['type'] = 'Inspections';
      this.tableData['data'] = _.filter(
        this.ReportsData['Inspection'],
        function(o) {
          return o.status === 1;
        }
      );
      this.tableData['error'] = 'No Inspections Conducted';
    } else if (event.point.category === 'Audits') {
      this.tableData['type'] = event.point.category;
      this.tableData['data'] = this.ReportsData['Audit'];
      this.tableData['error'] = 'No Audits Found';
    }
  }

  callFunctionNcReports(event) {
    console.log(event, this.ReportsData);
    if (event.point.category === 'Inspections') {
      this.ncTableData['type'] = event.point.category;
      if (event.point.series.name === 'Pending') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcInspection'],
          function(o) {
            return o.status !== 1;
          }
        );
        this.ncTableData['error'] = 'No Pending Inspections Found';
      } else if (event.point.series.name === 'Closed') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcInspection'],
          function(o) {
            return o.status === 1;
          }
        );
        this.ncTableData['error'] = 'No Closed Inspections Found';
      }
    } else if (event.point.category === 'Audits') {
      this.ncTableData['type'] = event.point.category;
      if (event.point.series.name === 'Pending') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcAudit'],
          function(o) {
            return o.status === 1;
          }
        );
        this.ncTableData['error'] = 'No Pending Audits Found';
      } else if (event.point.series.name === 'Closed') {
        this.ncTableData['data'] = _.filter(
          this.ReportsData['NcAudit'],
          function(o) {
            return o.status === 2;
          }
        );
        this.ncTableData['error'] = 'No Closed Audits Found';
      }
    }
  }

  onenPopup(type, value) {
    this.dispType.type = type;
    this.dispType.data = value;
    this.dispType.headerMsg = '';
    this.dispType.titleMsg = '';
    this.dispType.errorMsg = '';
    if (type === 'Inspections') {
      this.dispType.headerMsg = 'Inspection Details';
      this.dispType.titleMsg = '';
      this.dispType.errorMsg = 'No Inspection Details Found';
    } else if (type === 'Audits') {
      this.dispType.headerMsg = 'Audit Details';
      this.dispType.titleMsg = '';
      this.dispType.errorMsg = 'No Audit Details Found';
    }
  }

  getLocationName(value) {
    let text = _.filter(this.LocationsListStatic, function(o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function(o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    let itemNameList = _.chain(loc_nam)
      .reverse()
      .value();
    itemNameList = itemNameList.toString();
    itemNameList = itemNameList.replace(/,/g, ' ⇨ ');
    return itemNameList;
  }

  onChange1($event) {
    // this.PData = {
    //   resp: $event
    // };
    this.monthPass = $event;
    this.getInspectionReport();
  }
  // end of inspections
}
