import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';
import { AuditSettings } from '../audit.setting';
import { DashboardService } from '../auditor/dashboard/dashboard.service';
@Injectable()
export class SharedService {
  public categoryList = [];
  constructor(
    private _http: Http,
    public _dashboardService: DashboardService
  ) {}

  getAuditCategory() {
    return this._http
      .get(AuditSettings.API.AUDIT_CATEGORY, this.token())
      .map((response: Response) => response.json());
  }

  getcategory() {
    return new Promise((resolve, reject) => {
      this._dashboardService.getAuditCategory().subscribe(data => {
        if (data.success) {
          this.categoryList = data.data;
          resolve();
        }
      });
    });
  }

  getdepartments() {
    return this._http
      .get(AuditSettings.API.DEPARTMENTS, this.token())
      .map((response: Response) => response.json());
  }

  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
