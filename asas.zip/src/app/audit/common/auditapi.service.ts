import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/timeout';

import {
  Http,
  Headers,
  Response,
  RequestOptions,
  ResponseContentType
} from '@angular/http';
import { AppSettings } from '../../app.settings';
import 'rxjs/add/operator/map';

@Injectable()
export class AuditapiService {
  headers = { headers: new Headers({ 'content-type': 'application/Json' }) };
  options = new RequestOptions();

  constructor(private _http: Http) { }
  callApi(url, method, body = null): Observable<any> {
    if (sessionStorage.getItem('token')) {
      this.token();
    }

    switch (method.toUpperCase()) {
      case 'LOGIN':
        return this._http
          .post(url, body, this.options)
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);
      case 'POST':
        return this._http
          .post(url, body, this.token())
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);

      case 'PATCH':
        return this._http
          .patch(url, body, this.token())
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);

      case 'DELETE':
        return this._http
          .delete(url, this.token())
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);

      case 'GET':
        return this._http
          .get(url, this.token())
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);

      case 'FILE_UPLOAD':
        return this._http
          .post(url, body, this.token_withoutheaders())
          .timeout(30000)
          .map(this.extraData)
          .do((response: Response) => response);
    }
  }
  extraData(response: Response): Response {
    return response.json();
  }
  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }

  token_withoutheaders() {
    return new RequestOptions({
      headers: new Headers({
        // 'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
