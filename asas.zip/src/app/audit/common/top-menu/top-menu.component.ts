import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'underscore';
import { SharedService } from 'src/app/common/services/shared.service';
import { ApiService } from 'src/app/common/services/api.service';
declare var $;
declare var $this;


@Component({
  selector: 'app-top-menu-audit',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css']
})
export class TopMenuComponent implements OnInit {
  // page = this.service.page;
  pageType = '';
  name;
  role;
  role_display: any;
  rolesData: any[];
  pageNavValue = '';
  designation = sessionStorage.getItem('designation');
  pageTypeLength = 0;

  constructor(
    public router: Router,
    public service: ApiService,
    public _route: ActivatedRoute,
    public _apiService: ApiService,
    public _sharedService: SharedService
  ) { }

  ngOnInit() {
    this.pageTypeLength = 0;
    console.log(JSON.parse(sessionStorage.roles));
    this.pageType = this._route.snapshot.url[0].path;
    this.pageTypeLength = this._route.snapshot.url.length;
    this.pageTypeLength =
      this._route.snapshot.url[this._route.snapshot.url.length - 1].path === 'new' ? 1 : this._route.snapshot.url.length;
    // tslint:disable-next-line:max-line-length
    console.log(this._route.snapshot.url, this._route.snapshot.url.length, 'topMenu', this.pageTypeLength, this._route.snapshot.url[this._route.snapshot.url.length - 1].path);
    this.role = sessionStorage.getItem('role');
    this.role_display = sessionStorage.getItem('display_role');
    this.name = sessionStorage.getItem('name');
    this.getRoles();
  }

  getRoles() {
    this.rolesData = [];
    this.service.getRoles1({ emp_id: sessionStorage.getItem('userid') }).subscribe(datas => {
      console.log(datas);
      if (!datas.success) {
        this.service.rolesArray = datas.data;
        this.rolesData = this.service.rolesArray;
        console.log(this.rolesData);
      }
    });
  }

  auditReport() {
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/schedule']);
    }
    if (this.checkRole('Auditor')) {
      sessionStorage.setItem('auditRole', 'auditor');
      this.router.navigate(['/audit/auditor/dashboard']);
    }
  }

  auditReportPending() {
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/pending/manager/schedule']);
    }
    if (this.checkRole('Auditor')) {
      sessionStorage.setItem('auditRole', 'auditor');
      this.router.navigate(['/audit/pending/auditor/dashboard']);
    }
  }

  categories() {
    this.pageType = 'categoriesQuestions';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/categoriesQuestions']);
    }
  }

  audit_reports() {
    this.pageType = 'auditReports';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/reports/auditReports']);
    }
  }

  checkRole(role) {
    const tempRoles = _.pluck(this.rolesData, 'role_name');
    if (tempRoles.indexOf(role) > -1) {
      return true;
    } else {
      return false;
    }
  }

  getPageValue(value) {
    this.pageNavValue = value;
    // if (!this._apiService.incidentAddFormCheck) {
    //   $('#navigateConformation').modal('hide');
    this.router.navigate([this.pageNavValue]);

    // }
  }

}
