import { environment } from '../../environments/environment';
export class AuditSettings {
  public static API = {
    GET_AUDIT_LIST: environment.apiUrl + 'audit/auditor',
    AUDITOR_QUESTIONNAIRES: environment.apiUrl + 'audit/auditor/',
    AUDIT_CATEGORY: environment.apiUrl + 'audit/audit_categories',
    DEPARTMENTS: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    AUDITOR_DEPARTMENTS: environment.apiUrl + 'audit/auditor',
    AUDIT: environment.apiUrl + 'audit/auditor',
    DEPARTMENTSLOCATION: environment.apiUrl + 'audit/auditor/dept_location',
    CLOSED_AUDIT: environment.apiUrl + 'audit/auditor/close_audit/',
    GET_MANAGER: environment.apiUrl + 'audit/manager',
    DELETE_AUIDT: environment.apiUrl + 'audit/manager',
    UPLOAD: environment.apiUrl + 'audit/auditor/',
    AUDIT_ATTACHMENT_DELETE: environment.apiUrl + 'audit/delete_attachment',
    AUDIT_ATTACHMENT: environment.apiUrl + 'audit/attachment',
    SAVE_NC: environment.apiUrl + 'audit/assign_nc_kaizen',
    POST_AUDITS_EXCEL: environment.apiUrl + 'audit/auditspostexcel',

    // AUDITOR_QUESTIONNAIRES:
    //   'http://172.16.16.23:2255/audit/aduitorQuestionnaire',

    GET_DEPT: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    GET_USERS: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',
    POST_AUDITS: environment.apiUrl + 'audit/manager',
    uploadFile: environment.apiUrl + 'audit/upload',
    POST_CATE: environment.apiUrl + 'audit/category',
    GET_CATEGORY_BY_ID: environment.apiUrl + 'audit/getcategorybyId',
    POST_QUESTIONS: environment.apiUrl + 'category_questions',
    CATEGORIES_UPLOAD: environment.apiUrl + 'audit/categoryupload',

    GET_SCHEDULE_DATA: environment.apiUrl + 'getScheduleData',
    GET_NC_LIST: environment.apiUrl + 'getNCList',
    GEt_ALL_DATA_LIST: environment.apiUrl + 'getAllScoreData',
    GET_NC_DATA: environment.apiUrl + 'getDataList',
    GET_DEPT_DATA: environment.apiUrl + 'getDeptData',
    GET_DEPT_BY_ID: environment.apiUrl + 'getDeptById',
    GET_CATEGORY_LIST: environment.apiUrl + 'getCategoryList',
    GET_KAIZEN_DATA: environment.apiUrl + 'getKaizens',
    GET_NC_CLOSED_COUNT: environment.apiUrl + 'getNcClosed',

    // safety system
    GET_MEETING_DET: environment.apiUrl + 'safety/getmomdet',
    ADDNEWSCHEDULE: environment.apiUrl + 'safety/addnewschedule',
    ADDMOMDETAILS: environment.apiUrl + 'safety/addmomdetails',
    GET_ACTIONITEMS: environment.apiUrl + 'safety/getActionItemsList',
    ADDACTIONTAKEN: environment.apiUrl + 'safety/addactiontaken',
    GETMOMDET: environment.apiUrl + 'safety/getmomdet',
    CLOSEACTION: environment.apiUrl + 'safety/closeaction',
    GET_USERS_ROLES: environment.apiUrl + 'safety/emp_with_role_name',
    GET_MOMREPORTS: environment.apiUrl + 'safety/getmomreports',
    GET_MEETING_DEPT: environment.apiUrl + 'safety/getmeetingsbydept',
    DOWNLOAD_FILE: environment.apiUrl + 'safety/downloadimage/',

    // get audit users list
    GET_AUDIT_USERS: environment.apiUrl + 'audit/getAuditUsers',
    // get supervisors list
    GET_SUPERVISORS: environment.apiUrl + 'audit/getSupervisors'
  };
  public static image_path = environment.apiUrl + 'audit/image/';
}
