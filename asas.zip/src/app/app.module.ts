import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { RouterModule } from "@angular/router";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpModule } from "@angular/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { NoopAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";

// Third Party
import { DatePipe } from "@angular/common";
import { ToastrModule } from "ng6-toastr-notifications";
import { CalendarModule } from "primeng/calendar";
import { CommonModule } from "@angular/common";
import { DataTableModule } from "angular-6-datatable";
import { MyDatePickerModule } from "mydatepicker";
import { ChartModule } from "angular2-highcharts";
import { HighchartsStatic } from "angular2-highcharts/dist/HighchartsService";
import { HotTableModule } from "ng2-handsontable";
import { FileUploadModule } from "ng2-file-upload";
import { MyDateRangePickerModule } from "mydaterangepicker";
// import { ImageCropperModule } from 'ngx-image-cropper';
import { NgxMyDatePickerModule } from "ngx-mydatepicker";
import { NgxUploaderModule } from "ngx-uploader";
import { ModalModule } from "ngx-modal";
import { CustomFormsModule } from "ng2-validation";
import { EditorModule } from "primeng/editor";
import { CKEditorModule } from "ng2-ckeditor";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";

// Common Modules
import { AuthGuard } from "./common/guards/auth.guard";
import { ApiService } from "./common/services/api.service";
import { AuthenticationService } from "./common/services/authentication.service";
import { HeaderService } from "./common/header/header.service";
import { SharedService } from "./common/services/shared.service";
import { UploadService } from "./common/services/upload.service";
import { XlsxToJsonService } from "./common/services/xlsx-to-json-service";
import { MultiSelectModule } from "primeng/primeng";
// Components
import { DashboardComponent } from "./dashboard/dashboard.component";
import { SharedModule } from "./common/shareds.module";
import { LocationsComponent } from "./locations/locations.component";
import { LoactionService } from "./locations/locations.service";
import { LoginComponent } from "./login/login.component";
import { AddassestsComponent } from "./addassests/addassests.component";
import { AddAssetService } from "./addassests/assetsservice";
import { SuppliersComponent } from "./suppliers/suppliers.component";
import { PermitsViewComponent } from "./permits-view/permits-view.component";
import { HseStaffComponent } from "./hse-staff/hse-staff.component";
import { HseStaffService } from "./hse-staff/hse-staff.service";
import { NonConformanceModule } from "./regular_audit/regular_audit.module";
import { DropdownModule } from "primeng/primeng";
import { TooltipModule } from "ng2-tooltip-directive";
import { InspectorComponent } from "./inspector/inspector.component";
import { InspectorService } from "./inspector/InspectorService";
import { MainDashboardComponent } from "./incident-report-dashboard/main-dashboard/main-dashboard.component";
import { IncidentDashComponent } from "./incident-report-dashboard/incident-dash/incident-dash.component";
import { DashboardReportsService } from "./incident-report-dashboard/dashboard_report_service";
import { PermitService } from "./permit_to_work/permit-types/permitservice";
import { InspectionReportsComponent } from "./incident-report-dashboard/inspection-reports/inspection-reports.component";
import { NonConformationComponent } from "./incident-report-dashboard/non-conformation/non-conformation.component";
import { WorkPermitComponent } from "./incident-report-dashboard/work-permit/work-permit.component";
import { PpeComponent } from "./incident-report-dashboard/ppe/ppe.component";
import { AuditsReportsComponent } from "./incident-report-dashboard/audits-reports/audits-reports.component";
import { IncidentviewComponent } from "./incidentview/incidentview.component";
import { IncidentViewService } from "./incidentview/incidentviewservice";
import { IncidentsListManagerService } from "./intial_incidents/incidents-list-manager/incidents-list-service";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import { DocumentWritingComponent } from "./documents_module/document-writing/document-writing.component";
import { LicenseReportsComponent } from "./hse_license/licenses_reports/license_reports.component";
import { LicenseReportsPTWComponent } from "./hse_license/licenses_reports_ptw/license_reports_ptw.component";
import { LicenseReportsClientComponent } from "./hse_license/licenses_reports_client/license_reports_client.component";
import { FieldPassComponent } from "./field-pass/field-pass.component";
import { SafetyDrillsComponent } from "./safety-drills/safety-drills.component";
import { OngoingProjectsComponent } from "./ongoing_projects/ongoing_projects.component";
import { BusinessContinuityComponent } from "./business_continuity/business_continuity.component";
import { LicenseService } from "./hse_license/licenses.service";
import { OnGoingProjectsService } from "./ongoing_projects/ongoing_projects.service";
import { EmergencyResponseComponent } from "./emergency-response/emergency-response.component";
import { EmergencyService } from "./emergency-response/emergency.service";
import { DashboardRightMenuComponent } from "./dashboard-right-menu/dashboard-right-menu.component";
import { VendorManagementComponent } from "./vendor-management/vendor-management.component";
import { SafetyMeetingsComponent } from "./safety-meetings/safety-meetings.component";
import { NotificationsComponent } from "./notifications/notifications.component";
import { CardComponent } from "./notifications/card/card.component";
import { NotificationsService } from "./notifications/notifications.service";
import { EmergencyResponsedashboardComponent } from "./emergency-responsedashboard/emergency-responsedashboard.component";
import { DisasterRecoveryComponent } from "./disaster-recovery/disaster-recovery.component";
import { TestComponentComponent } from "./test-component/test-component.component";
import { RiskAssessmentComponent } from './risk-assessment/risk-assessment.component';
import { GenericRiskAssessmentComponent } from './risk-assessment/generic-risk-assessment/generic-risk-assessment.component';

import { UiSwitchModule } from 'ngx-toggle-switch';


import { ChartsModule } from 'ng2-charts';
declare var require;

export function highchartsFactory() {
  const Highcharts = require("highcharts");
  const Exporting = require("highcharts/modules/exporting");
  const More = require("highcharts/highcharts-more");
  const Solid = require("highcharts/modules/solid-gauge");
  const Heatmap = require("highcharts/modules/heatmap");
  const Pointline = require("highcharts/modules/export-data");
  const threeD = require("highcharts/highcharts-3d");
  const Funnel = require("highcharts/modules/funnel");
  Heatmap(Highcharts);
  Exporting(Highcharts);
  threeD(Highcharts);
  More(Highcharts);
  Solid(Highcharts);
  Pointline(Highcharts);
  threeD(Highcharts);
  Funnel(Highcharts);
  return Highcharts;
}

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LocationsComponent,
    LoginComponent,
    AddassestsComponent,
    SuppliersComponent,
    PermitsViewComponent,
    HseStaffComponent,
    InspectorComponent,
    MainDashboardComponent,
    IncidentDashComponent,
    InspectionReportsComponent,
    NonConformationComponent,
    WorkPermitComponent,
    PpeComponent,
    AuditsReportsComponent,
    IncidentviewComponent,
    DocumentWritingComponent,
    LicenseReportsComponent,
    LicenseReportsPTWComponent,
    LicenseReportsClientComponent,
    OngoingProjectsComponent,
    BusinessContinuityComponent,
    FieldPassComponent,
    SafetyDrillsComponent,
    EmergencyResponseComponent,
    DashboardRightMenuComponent,
    VendorManagementComponent,
    SafetyMeetingsComponent,
    NotificationsComponent,
    CardComponent,
    EmergencyResponsedashboardComponent,
    DisasterRecoveryComponent,
    TestComponentComponent,
    RiskAssessmentComponent,
    GenericRiskAssessmentComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserModule,
    HttpModule,
    ReactiveFormsModule,
    MultiSelectModule,
    FormsModule,
    BrowserAnimationsModule, // required animations module
    RouterModule,
    NoopAnimationsModule,
    CommonModule,
    HttpClientModule,
    DataTableModule,
    CalendarModule,
    MyDatePickerModule,
    NgxMyDatePickerModule,
    ChartModule,
    AngularMultiSelectModule,
    MyDateRangePickerModule,
    NgxUploaderModule,
    FileUploadModule,
    HotTableModule,
    SharedModule,
    NonConformanceModule,
    ToastrModule.forRoot(),
    TooltipModule,
    NgbModule,
    ChartsModule,
    UiSwitchModule
  ],
  providers: [
    AuthGuard,
    ApiService,
    AuthenticationService,
    HeaderService,

    SharedService,
    UploadService,
    XlsxToJsonService,
    AddAssetService,
    DashboardReportsService,
    PermitService,
    DatePipe,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    },
    LoactionService,
    HseStaffService,
    InspectorService,
    IncidentViewService,
    IncidentsListManagerService,
    LicenseService,
    OnGoingProjectsService,
    EmergencyService,
    NotificationsService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
