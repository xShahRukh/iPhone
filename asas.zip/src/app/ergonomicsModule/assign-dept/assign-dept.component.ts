import { Component, OnInit } from '@angular/core';
import { TempletService } from '../templates/templates.service';
import { AssignService } from './assign-dept.service';
import * as _ from 'underscore';
import { Router } from '@angular/router';

@Component({
  selector: 'app-assign-dept',
  templateUrl: './assign-dept.component.html',
  styleUrls: ['./assign-dept.component.css']
})
export class AssignDeptComponent implements OnInit {
  deptListData: any;
  checkedData: any = [];
  checked = [];
  ergonomicsDeptTemplate: any = [];
  itemById: any;
  deptName: any = [];
  templetsData = [];
  ItemByname = '';
  mappingList = [];
  questionsEntry = true;
  spinner = false;
  currentModal: any;
  constructor(private _assignService: AssignService, public router: Router) { }

  ngOnInit() {
    this.spinner = false;
    this.get_ergonomics_dept();
    this.get_templets();
    this.get_dept();
  }
  get_templets() {
    this.spinner = false;
    this._assignService.get_templets().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.templetsData = data.data;
        console.log(this.templetsData);
      } else {
        this.spinner = true;
      }
    });
  }

  get_ergonomics_dept() {
    this.spinner = false;
    this._assignService.get_ergonomics_dept().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.ergonomicsDeptTemplate = data.data;
      } else {
        this.spinner = true;
      }
    });
  }

  getRandomColor2() {
    const array = ['#d6d6d6'];

    const rand = Math.floor(Math.random() * array.length);

    // var color = Math.floor(0x1000000 * Math.random()).toString(16);
    // return '#' + ('000000' + color).slice(-6);
    return array[rand];
  }

  getRandomColor1() {
    const color = ['#000'];

    const rand = Math.floor(Math.random() * color.length);

    // var color = Math.floor(0x1000000 * Math.random()).toString(16);
    // return '#' + ('000000' + color).slice(-6);
    return color[rand];
  }
  get_dept() {
    this.spinner = false;
    this._assignService.get_dept().subscribe(data => {
      this.spinner = true;
      this.deptName = data.data;
    });
  }

  ModelbyId(item) {
    this.ItemByname = item.fullname;
    this.currentModal = item.fullname;
    console.log(this.ItemByname);
    this.itemById = item.id;
    this.mappingList = [];
    this.checkedData = [];

    const evens = _.filter(this.ergonomicsDeptTemplate, function (num) {
      return num.department_id === item.id;
    });
    evens.forEach(element => {
      // this.checkedData.push({
      //   id: element.template_id
      // });
      this.mappingList.push(element.template_id);
      this.checkedData.push(element.template_id);
    });
    console.log(`deptList`, this.ergonomicsDeptTemplate);
    console.log(`mappinglist`, this.mappingList);
    console.log(`checkdata`, this.checkedData);
  }
  mapbox(e, i) {
    if (e.target.checked === true) {
      this.mappingList.push(i);
    } else {
      for (let jk = 0; jk < this.mappingList.length; jk++) {
        if (this.mappingList[jk] === i) {
          this.mappingList.splice(jk, 1);
        }
      }
    }
  }

  mappingDept() {
    this.spinner = false;
    const body = {
      templates: this.mappingList
    };

    this._assignService.mapdeptBytemplet(body, this.itemById).subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.ngOnInit();
      } else {
        this.spinner = true;
      }
    });
  }
  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
}
