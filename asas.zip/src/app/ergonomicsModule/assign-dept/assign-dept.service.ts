import { Injectable } from '@angular/core';

import { ErgonomicsSettings } from '../ergonomics.setting';
import { ErgonomicsService } from '../common/ergonomics.service';

@Injectable()
export class AssignService {
  constructor(private _ergonomicsService: ErgonomicsService) {}

  // templateQuestions(values: any, templateId) {
  //   console.log(`values are`, values);
  //   const url = ErgonomicsSettings.API.templateQuestions + '/' + templateId;
  //   return this._ergonomicsService.callApi(url, 'FILE_UPLOAD', values);
  // }

  get_templets() {
    const url = ErgonomicsSettings.API.GETTEMPLETS;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_dept() {
    const url = ErgonomicsSettings.API.DEPARTMENTS;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_ergonomics_dept() {
    const url = ErgonomicsSettings.API.GET_ERDEPT;
    return this._ergonomicsService.callApi(url, 'get', null);
  }

  mapdeptBytemplet(values, id) {
    console.log(`values are`, values, `id is`, id);
     const url = ErgonomicsSettings.API.MAP_DEPT_TO_TEMPLATE + '/' + id;
    return this._ergonomicsService.callApi(url, 'POST', values);
  }
}
