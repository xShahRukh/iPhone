import { Injectable } from '@angular/core';

import { ErgonomicsSettings } from '../ergonomics.setting';
import { ErgonomicsService } from '../common/ergonomics.service';
import { ApiService } from 'src/app/common/services/api.service';

@Injectable()
export class TempletService {
  constructor(private _ergonomicsService: ErgonomicsService, private _apiService: ApiService) {}

  uploadFile(values: any) {
    const url = ErgonomicsSettings.API.uploadFile;
    return this._ergonomicsService.callApi(url, 'FILE_UPLOAD', values);
  }

  templateQuestions(values: any, templateId) {
    console.log(`values are`, values);
    const url = ErgonomicsSettings.API.templateQuestions + '/' + templateId;
    return this._ergonomicsService.callApi(url, 'FILE_UPLOAD', values);
  }

  get_templets() {
    const url = ErgonomicsSettings.API.GETTEMPLETS;
    return this._ergonomicsService.callApi(url, 'get', null);
  }

  get_templets_questions(id) {
    const url = ErgonomicsSettings.API.GET_QUESTIONS_BY_ID + '/' + id;
    return this._apiService.callApi(url, 'get', null);
    // return this._apiService.callApi(PermitWorkSettings.API.GET_TRAINING_IDS, 'get', {});
  }
}
