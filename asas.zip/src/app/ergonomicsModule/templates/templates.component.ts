import { Component, OnInit } from '@angular/core';
import {
  UploadOutput,
  UploadInput,
  UploadFile,
  humanizeBytes,
  UploaderOptions
} from 'ngx-uploader';
import { ErgonomicsSettings } from '../ergonomics.setting';
import { EventEmitter, ViewContainerRef } from '@angular/core';
import { TempletService } from './templates.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-templates',
  templateUrl: './templates.component.html',
  styleUrls: ['./templates.component.css']
})
export class TemplatesComponent implements OnInit {
  templetName_add: any;
  questionsData: any = [];
  selectedTemplate;
  templetsData: any = [];
  imagepath: any;
  addNew = false;
  options: UploaderOptions;
  formData: FormData;
  files: UploadFile[];
  uploadInput: EventEmitter<UploadInput>;
  humanizeBytes: Function;
  dragOver: boolean;
  imagePreview: {};
  image: any;
  imageUpload: any;
  extension: any;
  imagedone: boolean;
  templetName;
  form: FormGroup;
  public myForm: FormGroup;
  questionsEntry = false;
  image_path_template = ErgonomicsSettings.image_path + '/templates/';
  image_path_question = ErgonomicsSettings.image_path + '/question/';
  spinner = false;
  paramsList;
  paramsList_bool: boolean;

  constructor(
    private _templetService: TempletService,
    private fb: FormBuilder,
    public route: ActivatedRoute,
    public router: Router
  ) {
    this.createForm();
    this.files = [];
    this.uploadInput = new EventEmitter<UploadInput>();
  }

  ngOnInit() {
    console.log(this.route.snapshot.queryParams.title);
    this.paramsList = this.route.snapshot.queryParams.title;
    if (this.paramsList === 'new') {
      this.paramsList_bool = true;
    } else {
      this.paramsList_bool = false;
    }

    console.log(`in`);
    this.spinner = false;

    this.get_templets();
    this.myForm = this.fb.group({
      myGroup: this.fb.array([])
    });
  }

  initAddress() {
    return this.fb.group({
      id: null,
      question: [null, Validators.required],
      image: [null, Validators.required]
    });
  }

  addAddress() {
    const control = <FormArray>this.myForm.controls['myGroup'];

    control.push(this.initAddress());
  }

  removeAddress(i: number) {
    const control = <FormArray>this.myForm.controls['myGroup'];
    control.removeAt(i);
  }

  createForm() {
    this.form = this.fb.group({
      templetName: ['', Validators.required],
      image: ['', Validators.required]
    });
  }

  add() {
    this.addNew = true;
  }
  closeNew() {
    this.addNew = false;
  }

  onFileChange2(event, i) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];

      (<FormArray>this.myForm.controls.myGroup).controls[i].get('image').setValue(file);
    }
  }

  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.form.get('image').setValue(file);
    }
  }

  private prepareSave(): any {
    const input = new FormData();
    input.append('template_name', this.form.get('templetName').value);
    input.append('image', this.form.get('image').value);
    return input;
  }

  private prepareSave2(): any {
    const input = new FormData();
    const questions = [];
    const arr = this.myForm.get('myGroup').value;
    let i = 0;
    arr.forEach(element => {
      questions.push({
        question_id: element.id,
        question: element.question
      });
      if (element.image) {
        input.append(`image${i}`, element.image);
      }
      ++i;
    });

    input.append('questions', JSON.stringify(questions));

    return input;
  }

  onSubmit() {
    this.spinner = false;
    const formModel = this.prepareSave();
    this._templetService.uploadFile(formModel).subscribe(data => {
      if (data.success) {
        this.get_templets();
        this.addNew = false;
      } else {
      }
    });
  }

  get_templets() {
    this.spinner = false;

    this._templetService.get_templets().subscribe(data => {
      if (data.success) {
        this.spinner = true;

        this.templetsData = data.data;
      } else {
        this.spinner = true;
      }
    });
  }

  addQuestions(item, i) {
    console.log(item);
    this.templetName_add = item.template_name;
    this.spinner = false;

    this.selectedTemplate = item.template_id;
    this.questionsEntry = true;
    this._templetService.get_templets_questions(item.template_id).subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.questionsData = data.data;
        // tslint:disable-next-line:no-shadowed-variable
        for (let i = 0; i < this.questionsData.length; i++) {
          this.addAddress();
        }
        // tslint:disable-next-line:no-shadowed-variable
        for (let i = 0; i < this.questionsData.length; i++) {
          this.myForm.controls.myGroup['controls'][i].patchValue({
            id: this.questionsData[i].question_id,
            question: this.questionsData[i].question,
            image: this.questionsData[i].image
          });
        }
      } else {
        this.spinner = true;
      }
    });
  }

  submit() {
    const formModel = this.prepareSave2();

    this._templetService.templateQuestions(formModel, this.selectedTemplate).subscribe(data => {
      // data = JSON.parse(data)
      if (data.success) {
        this.questionsEntry = false;
        this.questionsData = [];
        this.myForm.controls.myGroup['controls'] = [];
      } else {
      }
    });

    // this._templetService.uploadFile(formModel).subscribe(data => {
    //   if (data.success) {
    //   } else {
    //   }
    // });
    // this.get_templets();
    // this.addNew = false;
  }
  deleteImage(item) {
    if (confirm('Do you want to delete the image!')) {
      this.myForm.controls.myGroup['controls'][item].value['image'] = null;
    } else {
    }
  }
  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
  GoBack() {
    this.questionsEntry = false;
    this.myForm.controls.myGroup['controls'] = [];
  }
}
