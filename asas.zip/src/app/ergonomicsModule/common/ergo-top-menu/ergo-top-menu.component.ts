import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import _ from 'underscore';
import { ApiService } from 'src/app/common/services/api.service';
declare var $;
declare var $this;
@Component({
  selector: 'app-ergo-top-menu',
  templateUrl: './ergo-top-menu.component.html',
  styleUrls: ['./ergo-top-menu.component.css']
})
export class ErgoTopMenuComponent implements OnInit {
  // page = this.service.page;
  pageType = '';
  name;
  role;
  role_display: any;
  rolesData: any[];
  designation = sessionStorage.getItem('designation');
  constructor(
    public router: Router,
    public _route: ActivatedRoute,
    public _apiService: ApiService
  ) {}

  ngOnInit() {
    console.log(JSON.parse(sessionStorage.roles));
    this.pageType = this._route.snapshot.url[0].path;
    this.role = sessionStorage.getItem('role');
    this.role_display = sessionStorage.getItem('display_role');
    this.name = sessionStorage.getItem('name');
    this.getRoles();
  }

  getRoles() {
    this.rolesData = [];
    this._apiService.getRoles1({ emp_id: sessionStorage.getItem('userid') }).subscribe(datas => {
      console.log(datas);
      if (!datas.success) {
        this._apiService.rolesArray = datas.data;
        this.rolesData = this._apiService.rolesArray;
        console.log(this.rolesData);
      }
    });
  }

  auditReport() {
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/schedule']);
    }
    if (this.checkRole('Auditor')) {
      sessionStorage.setItem('auditRole', 'auditor');
      this.router.navigate(['/audit/auditor/dashboard']);
    }
  }

  categories() {
    this.pageType = 'categoriesQuestions';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/categoriesQuestions']);
    }
  }

  audit_reports() {
    this.pageType = 'auditReports';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/reports/auditReports']);
    }
  }

  checkRole(role) {
    const tempRoles = _.pluck(this.rolesData, 'role_name');
    if (tempRoles.indexOf(role) > -1) {
      return true;
    } else {
      return false;
    }
  }

  ergonomics(item, param) {
    if (item === 'templates') {
      this.router.navigate(['/ergonomicsModule/template']);
    } else if (item === 'add') {
      this.router.navigate(['/ergonomicsModule/addNew']);
    } else if (item === 'assign') {
      this.router.navigate(['/ergonomicsModule/assignDept']);
    } else if (item === 'check') {
      this.router.navigate(['/ergonomicsModule/checkErgonomics']);
    } else if (item === 'reports') {
      this.router.navigate(['/ergonomicsModule/reports']);
    }
  }
}
