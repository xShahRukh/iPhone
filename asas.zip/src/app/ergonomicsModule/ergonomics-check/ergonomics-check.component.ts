import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ErgonomicscheckService } from './ergonomics-check.service';
import * as _ from 'underscore';
import { ErgonomicsSettings } from '../ergonomics.setting';
import { Router } from '@angular/router';
// import { ToastsManager } from 'ng2-toastr';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-ergonomics-check',
  templateUrl: './ergonomics-check.component.html',
  styleUrls: ['./ergonomics-check.component.css']
})
export class ErgonomicsCheckComponent implements OnInit {
  cateName: any;
  leftArrow = false;
  rightArrow = true;
  ergonomics_id: any;
  totalCount = 0;
  check: any;
  responseValue;
  totalpercentage: any;
  questionResponceData: any = {};
  departmentcards = true;
  questionsPage = false;
  deptListData: any;
  checkedData: any = [];
  checked = [];
  ergonomicsDeptTemplate: any = [];
  itemById: any;
  deptName: any = [];
  templetsData = [];
  ItemByname = '';
  mappingList = [];
  questions_data = [];
  image_path_template = ErgonomicsSettings.image_path + '/templates/';
  image_path_question = ErgonomicsSettings.image_path + '/question/';
  countOfRes = 0;
  imageI = 0;
  questionsEntry = true;
  spinner = false;
  yes: number;
  no: number;
  deptId: number;
  evens = [];
  constructor(
    private _checkService: ErgonomicscheckService,
    public router: Router,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.deptId = parseInt(sessionStorage.getItem('departmentId'), 10);
    console.log(typeof this.deptId);
    this.spinner = false;
    this.get_ergonomics_dept();
    this.get_templets();
    this.get_dept();
  }
  get_templets() {
    this.spinner = false;
    this._checkService.get_templets().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.templetsData = data.data;
      } else {
        this.spinner = true;
      }
    });
  }

  get_ergonomics_dept() {
    this.spinner = false;
    this._checkService.get_ergonomics_dept().subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.ergonomicsDeptTemplate = data.data;
      } else {
        this.spinner = true;
      }
    });
  }

  getRandomColor2() {
    const array = ['#23867a'];
    const rand = Math.floor(Math.random() * array.length);

    // var color = Math.floor(0x1000000 * Math.random()).toString(16);
    // return '#' + ('000000' + color).slice(-6);
    return array[rand];
  }

  getRandomColor1() {
    const color = ['white'];
    const rand = Math.floor(Math.random() * color.length);

    // var color = Math.floor(0x1000000 * Math.random()).toString(16);
    // return '#' + ('000000' + color).slice(-6);
    return color[rand];
  }
  get_dept() {
    console.log(this.deptId);
    this.spinner = false;
    this._checkService.get_dept().subscribe(data => {
      this.spinner = true;
      this.deptName = data.data;
      console.log(this.deptName);
      this.evens = _.filter(this.deptName, function(num) {
        console.log(typeof num.id);
        return num.id === parseInt(sessionStorage.getItem('departmentId'), 10);
      });
      if (this.evens.length === 0) {
        this.toastr.errorToastr(` No department assigned to you, Please contact HR `);
      } else {
        console.log(this.evens.length);
        this.ModelbyId(this.evens[0]);
      }
    });
  }

  ModelbyId(item) {
    console.log(item);

    this.departmentcards = false;
    this.ItemByname = item.fullname;
    this.itemById = item.id;
    this.mappingList = [];
    this.checkedData = [];

    const evens = _.filter(this.ergonomicsDeptTemplate, function(num) {
      return num.department_id === item.id;
    });
    console.log(evens);
    if (evens.length === 0) {
      this.ItemByname = '';
      this.departmentcards = true;
      this.toastr.errorToastr(` No templates assigned to ${this.ItemByname} department `);
    }

    evens.forEach(element => {
      const tempData = _.filter(this.templetsData, function(dd) {
        return dd.template_id === element.template_id;
      });
      // tslint:disable-next-line:no-shadowed-variable
      tempData.forEach(element => {
        this.checkedData.push({
          id: element.template_id,
          name: element.template_name,
          image: element.image
        });
      });
      console.log(this.checkedData);
    });
  }
  mapbox(e, i) {
    if (e.target.checked === true) {
      this.mappingList.push(i);
    } else {
      for (let jk = 0; jk < this.mappingList.length; jk++) {
        if (this.mappingList[jk] === i) {
          this.mappingList.splice(jk, 1);
        }
      }
    }
  }

  mappingDept() {
    const body = {
      templates: this.mappingList
    };

    this._checkService.mapdeptBytemplet(body, this.itemById).subscribe(data => {
      if (data.success) {
        this.ngOnInit();
      } else {
      }
    });
  }

  questionsTemplete(item) {
    console.log(`here`);
    this.imageI = 0;
    this.questions_data = [];
    this.questionResponceData = [];
    this.totalCount = 0;
    this.ergonomics_id = '';
    this.leftArrow = false;
    this.rightArrow = true;
    this.spinner = false;
    console.log(item);
    this.cateName = item.name;

    const id = item.id;

    this._checkService.questionsBytemplet(id).subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.questions_data = data.data;
        console.log(`questions`, this.questions_data);
        if (this.questions_data.length) {
          console.log(`true`);
          this.questionsPage = true;
        } else {
          this.toastr.errorToastr(` No Check found `);
          console.log(`false`);
        }
        this.get_ergonomics_By_id(this.itemById, id);
      } else {
        this.spinner = true;
      }
    });
  }

  get_ergonomics_By_id(d_id, t_id) {
    console.log(`dept`, d_id, `temp`, t_id);
    this._checkService.get_ergonomics_by_id(t_id, d_id).subscribe(data => {
      if (data.success) {
        console.log(`success`, data.data[0].ergonomics_departments_id);
        this.ergonomics_id = data.data[0].ergonomics_departments_id;
      } else {
      }
    });
  }

  imageSlider(type) {
    console.log(`sad`, this.questions_data.length);

    if (type === 'prev') {
      if (this.imageI === 0) {
        this.imageI = this.questions_data.length - 1;
      } else {
        this.imageI -= 1;
        // this.leftArrow = false;
      }
    } else {
      if (this.imageI === this.questions_data.length - 1) {
        this.imageI = 0;
      } else {
        // this.rightArrow = false;
        this.imageI += 1;
      }
    }
    if (this.imageI === 0) {
      this.leftArrow = false;
      this.rightArrow = true;
    }
    if (this.imageI + 1 === this.questions_data.length) {
      this.rightArrow = false;
      this.leftArrow = true;
    }

    console.log(`position`, this.imageI);
  }

  response(res, id) {
    console.log(res, id);

    this.totalpercentage = 0;

    if (res.target.value === '1') {
      this.countOfRes++;

      this.totalCount++;
    } else {
      this.totalCount++;
      this.countOfRes--;
      console.log(this.countOfRes);
    }
    // this.totalpercentage = (
    //   this.countOfRes /
    //   this.questions_data.length *
    //   100
    // ).toFixed(2);
    // this.questionResponceData.push({
    //   question: id,
    //   response: res.target.value
    // });
    this.questionResponceData[id] = res.target.value;
    console.log(this.questionResponceData);
  }

  save() {
    let sumVal = 0;

    // tslint:disable-next-line:forin
    for (const prop in this.questionResponceData) {
      sumVal += JSON.parse(this.questionResponceData[prop]);
    }
    console.log(sumVal);

    this.spinner = false;
    const body = {};
    body['question_response'] = this.questionResponceData;
    body['score'] = ((sumVal / this.questions_data.length) * 100).toFixed(2);
    console.log(body, `body`);

    this._checkService.questionResponse_dept(body, this.ergonomics_id).subscribe(data => {
      if (data.success) {
        this.spinner = true;
        this.questionsPage = false;
        this.questions_data = [];
        this.questionResponceData = [];
        this.totalCount = 0;
        this.ergonomics_id = '';
      } else {
        this.spinner = true;
      }
    });
  }

  gotodashboard(stage) {
    // console.log(stage);
    if (stage === '1') {
      this.router.navigate(['/dashboard']);
    }
    if (stage === '2') {
      this.departmentcards = true;
      this.questionsPage = false;
      this.ItemByname = '';
    }
    if (stage === '3') {
      // console.log(`before`, this.yes);
      this.questionsPage = false;
      this.questions_data = [];
      this.questionResponceData = [];
      this.totalCount = 0;
      this.ergonomics_id = '';
      // console.log(`after`, this.yes);
    }
  }
}
