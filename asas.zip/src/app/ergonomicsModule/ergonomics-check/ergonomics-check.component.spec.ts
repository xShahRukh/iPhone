import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErgonomicsCheckComponent } from './ergonomics-check.component';

describe('ErgonomicsCheckComponent', () => {
  let component: ErgonomicsCheckComponent;
  let fixture: ComponentFixture<ErgonomicsCheckComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErgonomicsCheckComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErgonomicsCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
