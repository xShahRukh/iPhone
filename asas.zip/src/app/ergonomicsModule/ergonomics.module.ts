import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { TemplatesComponent } from './templates/templates.component';
import { routing } from '././ergonomics.routes';
import { FileUploadModule } from 'ng2-file-upload';
import { NgxUploaderModule } from 'ngx-uploader';

import { SharedModule } from '../common/shareds.module';
import { TempletService } from './templates/templates.service';
import { ErgonomicsService } from './common/ergonomics.service';
import { AssignDeptComponent } from './assign-dept/assign-dept.component';
import { PopoverModule } from 'ng2-popover';
import { AssignService } from './assign-dept/assign-dept.service';
import { ErgonomicsCheckComponent } from './ergonomics-check/ergonomics-check.component';
import { ErgonomicscheckService } from './ergonomics-check/ergonomics-check.service';
import { ReportsComponent } from './reports/reports.component';
import { ReportsService } from './reports/reports.service';
import { SpinnerModule } from 'angular2-spinner/dist';
import { AddTemplateComponent } from './add-template/add-template.component';
import { ErgoTopMenuComponent } from './common/ergo-top-menu/ergo-top-menu.component';

@NgModule({
  declarations: [
    TemplatesComponent,
    AssignDeptComponent,
    ErgonomicsCheckComponent,
    ReportsComponent,
    AddTemplateComponent,
    ErgoTopMenuComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    routing,
    SharedModule,
    FileUploadModule,
    NgxUploaderModule,
    PopoverModule,
    SpinnerModule
  ],
  providers: [
    TempletService,
    ErgonomicsService,
    AssignService,
    ErgonomicscheckService,
    ReportsService
  ]
})
export class ErgonomicsModule {}
