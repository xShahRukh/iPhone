import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ReportsService } from './reports.service';
import { ErgonomicsSettings } from '../ergonomics.setting';
import * as _ from 'underscore';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {
  template_name_report: any;
  tempBydeptId: any = [];
  down = true;
  up = false;
  score: any;
  step2_item: any;
  created_at: any;
  template_name: any;
  responesbyDept: any = [];
  dept_id: any;
  scoresData: any = [];
  deptName: any;
  step3 = false;
  step1 = true;
  step2 = false;
  tempBydept: any = [];
  constructor(
    private _reportService: ReportsService,
    public router: Router,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) { }
  templetsData = [];
  location = [];
  spinner = false;

  image_path_template = ErgonomicsSettings.image_path + '/templates/';
  ngOnInit() {
    this.spinner = false;
    this.get_templets();
  }
  get_templets() {
    this.spinner = false;

    this._reportService.get_templets().subscribe(data => {
      if (data.success) {
        this.spinner = true;

        this.templetsData = data.data;
      } else {
        this.spinner = true;
      }
    });
  }

  showDetails(item, action) {
    console.log(`item`, item);
    this.template_name_report = item.template_name;
    this.spinner = false;
    this.step1 = false;
    this.step2 = true;
    this.step3 = false;

    if (action === 'up') {
      this.tempBydept = [];
      this.up = false;
      this.down = true;
    } else {
      this.up = false;
      this.down = true;
      console.log(item);
      this._reportService.get_temp_dept(item.template_id).subscribe(data => {
        if (data.success) {
          this.spinner = true;

          this.location = [];
          console.log(data.data);
          if (data.data.length) {
            this.tempBydept = data.data;
          } else {
            this.step1 = true;
            this.step2 = false;
            this.step3 = false;
            this.toastr.errorToastr(' No data found');
          }
          if (this.location.indexOf(item.template_id) === -1) {
            this.location.push(item.template_id);
          } else {
            this.location = _.without(this.location, item.template_id);
          }
          console.log(this.location);
        } else {
          this.spinner = true;
        }
      });
    }
  }
  deptPage(item) {
    this.spinner = false;
    console.log(item);

    this.deptName = item.dept_name;
    if (item.dept_score) {
      // this.dept_id = item.ergonomics_departments_id;
      this.dept_id = item.dept_id;
      this._reportService.get_temp_by_deptId(this.dept_id).subscribe(data => {
        if (data.success) {
          this.spinner = true;
          this.step1 = false;
          this.step3 = true;
          this.step2 = false;
          console.log(`templates data`, data.data);
          this.tempBydeptId = data.data;
        } else {
          this.spinner = true;
        }
      });
    } else {
      this.step2 = true;
      this.spinner = true;
      this.toastr.errorToastr('No data found');
    }
  }

  deptbytempSocre(item) {

    this.spinner = false;

    this.scoresData = [];
    console.log(item);
    this._reportService.get_temp_dept_score(this.dept_id, item.template_id).subscribe(data => {
      if (data.success) {
        this.spinner = true;
        console.log(data.data);
        if (data.data.length) {
          this.scoresData = data.data;
          this.step2_item = item.template_name;
        } else {
          this.toastr.errorToastr(' No data found');
        }
      } else {
        this.spinner = true;
      }
    });
  }

  questionsbyScore(item) {
    this.spinner = false;

    console.log(item.template_name, item.created_at, item.dept_score);

    this.template_name = item.template_name;
    this.created_at = item.created_at;
    this.score = item.dept_score;
    console.log(item.eds_id);
    this._reportService.get_dept_questions(item.eds_id).subscribe(data => {
      if (data.success) {
        this.spinner = true;

        console.log(data.data);
        // this.scoresData = data.data;
        this.responesbyDept = data.data;
      } else {
        this.spinner = true;
      }
    });
  }
  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
  GoBack() {
    this.step3 = false;
    this.step2 = false;
    this.step1 = true;
    this.ngOnInit();
    this.tempBydept = [];
    this.up = false;
    this.down = true;
    this.scoresData.length = [];
    this.deptName = '';
  }
}
