import { Injectable } from '@angular/core';

import { ErgonomicsSettings } from '../ergonomics.setting';
import { ErgonomicsService } from '../common/ergonomics.service';

@Injectable()
export class ReportsService {
  constructor(private _ergonomicsService: ErgonomicsService) {}

  uploadFile(values: any) {
    const url = ErgonomicsSettings.API.uploadFile;
    return this._ergonomicsService.callApi(url, 'FILE_UPLOAD', values);
  }

  templateQuestions(values: any, templateId) {
    console.log(`values are`, values);
    const url = ErgonomicsSettings.API.templateQuestions + '/' + templateId;
    return this._ergonomicsService.callApi(url, 'FILE_UPLOAD', values);
  }

  get_templets() {
    const url = ErgonomicsSettings.API.GETTEMPLETS;
    return this._ergonomicsService.callApi(url, 'get', null);
  }

  get_templets_questions(id) {
    const url = ErgonomicsSettings.API.GET_QUESTIONS_BY_ID + '/' + id;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_temp_dept(id) {
    const url = ErgonomicsSettings.API.GET_TEMP_DEPT_ID + '/' + id;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_temp_by_deptId(id) {
    const url = ErgonomicsSettings.API.GET_TEMP_BY_DEPT_ID + '/' + id;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_dept_questions(id) {
    const url = ErgonomicsSettings.API.GET_DEPT_QUESTIONS + '/' + id;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
  get_temp_dept_score(id, id1) {
    const url =
      ErgonomicsSettings.API.GET_TEMP_DEPT_ID_SCORE + '/' + id + '/' + id1;
    return this._ergonomicsService.callApi(url, 'get', null);
  }
}
