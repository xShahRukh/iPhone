import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { TemplatesComponent } from './templates/templates.component';
import { AssignDeptComponent } from './assign-dept/assign-dept.component';
import { ErgonomicsCheckComponent } from './ergonomics-check/ergonomics-check.component';
import { ReportsComponent } from './reports/reports.component';
import { AddTemplateComponent } from './add-template/add-template.component';
const routes: Routes = [
  {
    path: 'template',
    component: TemplatesComponent
  },
  {
    path: 'assignDept',
    component: AssignDeptComponent
  },
  {
    path: 'checkErgonomics',
    component: ErgonomicsCheckComponent
  },
  {
    path: 'addNew',
    component: AddTemplateComponent
  },
  {
    path: 'reports',
    component: ReportsComponent
  },
  { path: '', redirectTo: 'template', pathMatch: 'full' },
  { path: '**', redirectTo: 'template' }
];

// export const routing = RouterModule.forChild(routes);
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
