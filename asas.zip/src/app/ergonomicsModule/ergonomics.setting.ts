import { environment } from '../../environments/environment';

export class ErgonomicsSettings {
  public static API = {
    uploadFile: environment.apiUrl + 'ergonomics/template',
    templateQuestions: environment.apiUrl + 'ergonomics/template',
    GETTEMPLETS: environment.apiUrl + 'ergonomics/templates',
    GET_QUESTIONS_BY_ID: environment.apiUrl + 'ergonomics/template',
    DEPARTMENTS: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    MAP_DEPT_TO_TEMPLATE: environment.apiUrl + 'ergonomics/departments',
    // GET_ERDEPT: environment.apiUrl + 'ergonomics/departments',
    QUESTIONS_TEMPLATE: environment.apiUrl + 'ergonomics/check',
    GET_ERDEPT: environment.apiUrl + 'ergonomics/departments',
    RESPONSE_BY_QUESTION: environment.apiUrl + 'ergonomics/checkbyquestions',
    GET_TEMP_DEPT_ID: environment.apiUrl + 'ergonomics/templatesdept',
    GET_TEMP_DEPT_ID_SCORE: environment.apiUrl + 'ergonomics/templatesdeptScore',
    GET_TEMP_BY_DEPT_ID: environment.apiUrl + 'ergonomics/templatesbydeptId',
    GET_DEPT_QUESTIONS: environment.apiUrl + 'ergonomics/get_dept_questions',
    GETERDEPT_ID_BY_ID: environment.apiUrl + 'ergonomics/ergonomicsDept'
  };
  public static image_path = environment.apiUrl + 'ergonomics/image';
}
