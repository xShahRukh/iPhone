import { environment } from '../../environments/environment';

export class EmergencySettings {
  public static API = {
    uploadFile: environment.apiUrl + 'ergonomics/template'
  };
  public static image_path = environment.apiUrl + 'ergonomics/image';
}
