import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-emerg-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.styl']
})
export class DashboardComponent implements OnInit {
  fieldpass: any = [];

  constructor(
    public _apiService: ApiService,
    public _route: ActivatedRoute,
    public router: Router
  ) {}

  ngOnInit() {
    // this._apiService.pageType
    console.log('Entered into evacuation Dashboard');
    this.getFieldPassData();
  }

  getFieldPassData() {
    this.fieldpass = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
      },
      title: {
        text: ''
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          showInLegend: true
        }
      },
      series: [
        {
          name: 'Incident',
          colorByPoint: true,
          data: [
            {
              name: 'Fire Accident in Canteen',
              y: 61.41,
              sliced: true,
              selected: true
            },
            {
              name: 'Fire Blow',
              y: 11.84
            },
            {
              name: 'Smoke release',
              y: 10.85
            },
            {
              name: 'Fire Blow',
              y: 4.67
            },
            {
              name: 'Gas Leak	',
              y: 4.18
            },
            {
              name: 'Fire Accident near Substation	',
              y: 7.05
            }
          ]
        }
      ]
    };
  }
}
