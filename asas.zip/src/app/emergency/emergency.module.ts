import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Third Party Plugins
import { ModalModule } from 'ngx-modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { DataTableModule } from 'angular-6-datatable';
import { CalendarModule } from 'primeng/primeng';
import { MyDatePickerModule } from 'mydatepicker';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import { CustomFormsModule } from 'ng2-validation';
import { EditorModule } from 'primeng/editor';
import { CKEditorModule } from 'ng2-ckeditor';
import { AutoCompleteModule } from 'primeng/primeng';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SlideshowModule } from 'ng-simple-slideshow';
import { LightboxModule } from 'ngx-lightbox';

import { ApiService } from '../common/services/api.service';
import { SharedModule } from '../common/shareds.module';

import { EmergencyResponseComponent } from './emergency-response/emergency-response.component';
import { ImportantSignsComponent } from './important-signs/important-signs.component';
import { FactoryLayoutsComponent } from './factory-layouts/factory-layouts.component';
import { ReportEvacuationComponent } from './report-evacuation/report-evacuation.component';
import { BusinessContinuityComponent } from './business-continuity/business-continuity.component';
import { DisasterRecoveryComponent } from './disaster-recovery/disaster-recovery.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TopMenuComponent } from './top-menu/top-menu.component';

import { emergencyRouting } from './emergency.routing';
import { EmergencyService } from './emergency.service';

declare var require;

export function highchartsFactory() {
  const Highcharts = require('highcharts');
  const Exporting = require('highcharts/modules/exporting');
  const More = require('highcharts/highcharts-more');
  const Solid = require('highcharts/modules/solid-gauge');
  const Heatmap = require('highcharts/modules/heatmap');
  const Pointline = require('highcharts/modules/export-data');
  const threeD = require('highcharts/highcharts-3d');
  const Funnel = require('highcharts/modules/funnel');
  Heatmap(Highcharts);
  Exporting(Highcharts);
  threeD(Highcharts);
  More(Highcharts);
  Solid(Highcharts);
  Pointline(Highcharts);
  threeD(Highcharts);
  Funnel(Highcharts);
  return Highcharts;
}

@NgModule({
  declarations: [
    EmergencyResponseComponent,
    ImportantSignsComponent,
    FactoryLayoutsComponent,
    ReportEvacuationComponent,
    BusinessContinuityComponent,
    DisasterRecoveryComponent,
    DashboardComponent,
    TopMenuComponent
  ],
  imports: [
    CommonModule,
    emergencyRouting,
    FormsModule,
    ReactiveFormsModule,
    ModalModule,
    ToastrModule,
    DataTableModule,
    CalendarModule,
    MyDatePickerModule,
    ChartModule,
    CustomFormsModule,
    EditorModule,
    CKEditorModule,
    AutoCompleteModule,
    AngularMultiSelectModule,
    SharedModule,
    SlideshowModule,
    LightboxModule
  ],
  providers: [
    ApiService,
    EmergencyService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    }
  ]
})
export class EmergencyModule {}
