import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { SharedService } from '../../common/services/shared.service';
import _ from 'underscore';
declare var $;
declare var $this;

@Component({
  selector: 'app-emergency-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.css']
})
export class TopMenuComponent implements OnInit {
  pageType = '';
  name;
  role;
  role_display: any;
  constructor(
    public router: Router,
    public service: ApiService,
    public _route: ActivatedRoute,
    public _sharedService: SharedService
  ) {}

  ngOnInit() {
    console.log(this._route.snapshot.url);
    this.pageType = this._route.snapshot.url[0].path;
    this.role = sessionStorage.getItem('role');
    this.role_display = sessionStorage.getItem('display_role');
    this.name = sessionStorage.getItem('name');
  }
}
