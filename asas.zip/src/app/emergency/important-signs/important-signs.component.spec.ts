import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportantSignsComponent } from './important-signs.component';

describe('ImportantSignsComponent', () => {
  let component: ImportantSignsComponent;
  let fixture: ComponentFixture<ImportantSignsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImportantSignsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportantSignsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
