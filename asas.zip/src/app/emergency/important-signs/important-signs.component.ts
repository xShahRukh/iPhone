import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-important-signs',
  templateUrl: './important-signs.component.html',
  styleUrls: ['./important-signs.component.styl']
})
export class ImportantSignsComponent implements OnInit {
  currentSign = {};
  sign_title: any;
  impSigns: any = [
    { name: 'Acite Toxicity', image: 'acite_toxicity.jpg' },
    { name: 'Biological Risk', image: 'biological_risk.jpg' },
    { name: 'Bo Smoking', image: 'bo_smoking.jpg' },
    { name: 'Corrosive', image: 'corrosive.jpg' },
    { name: 'Corrosive Material', image: 'corrosive_material.jpg' },
    { name: 'Danger Electricity', image: 'danger_electricity.jpg' },
    { name: 'Do Not Extinguish with Water', image: 'do_not_extinguish_with_water.jpg' },
    { name: 'Do Not Touch', image: 'do_not_touch.jpg' },
    { name: 'Drop', image: 'drop.jpg' },
    { name: 'Ear Protection Must be Work', image: 'ear_protection_must_be_work.jpg' },
    { name: 'Emergency Escape', image: 'emergency_escape.jpg' },
    { name: 'Emergency Fire Telephone', image: 'emergency_fire_telephone.jpg' },
    { name: 'Emergency Telephone', image: 'emergency_telephone.jpg' },
    { name: 'Emplosive', image: 'emplosive.jpg' },
    { name: 'Explosive Material', image: 'explosive_material.jpg' },
    { name: 'Eye Protection Must be Worn', image: 'eye_protection_must_be_worn.jpg' },
    { name: 'Eyewash', image: 'eyewash.jpg' },
    { name: 'Face Protection_must_be_worn', image: 'face_protection_must_be_worn.jpg' },
    { name: 'Fire Alaram', image: 'fire_alaram.jpg' },
    { name: 'Fire Extinguisher', image: 'fire_extinguisher.jpg' },
    { name: 'Fire Hose', image: 'fire_hose.jpg' },
    { name: 'First Aid', image: 'first_aid.jpg' },
    { name: 'First Aid Poster', image: 'first_aid_poster.jpg' },
    { name: 'Flammable', image: 'flammable.jpg' },
    { name: 'Flamming Material', image: 'flamming_material_or_high_temperature.jpg' },
    { name: 'Gas Under Pressure', image: 'gas_under_pressure.jpg' },
    { name: 'General Danger', image: 'general_danger.jpg' },
    { name: 'General Mandatory Sign', image: 'general_mandatory_sign.jpg' },
    { name: 'Hazardous to the Environment', image: 'hazardous_to_the_environment.jpg' },
    { name: 'Health Hazard', image: 'health_hazard.jpg' },
    { name: 'Industrial Vehicles', image: 'industrial_vehicles.jpg' },
    { name: 'Ladder', image: 'ladder.jpg' },
    { name: 'Laser Beam', image: 'laser_beam.jpg' },
    { name: 'Low Tempeture', image: 'low_tempeture.jpg' },
    { name: 'Mandatory Sign', image: 'mandatory_sign.jpg' },
    { name: 'No Access for Indutrial Vehicles', image: 'no_access_for_indutrial_vehicles.jpg' },
    { name: 'No Access for Pedestrains', image: 'no_access_for_pedestrains.jpg' },
    { name: 'No Access for Unauthorised Persons', image: 'no_access_for_unauthorised_persons.jpg' },
    { name: 'Non Ionising Radiation', image: 'non_ionising_radiation.jpg' },
    { name: 'Not Drinkable', image: 'not_drinkable.jpg' },
    { name: 'Obstacles', image: 'obstacles.jpg' },
    { name: 'Overhead Load', image: 'overhead_load.jpg' },
    { name: 'Oxidant Material', image: 'oxidant_material.jpg' },
    { name: 'Oxidising', image: 'oxidising.jpg' },
    { name: 'Pedestrain Must Use This Route', image: 'pedestrain_must_use_this_route.jpg' },
    { name: 'Prohibition Sign', image: 'prohibition_sign.jpg' },
    { name: 'Radioactive Material', image: 'radioactive_material.jpg' },
    { name: 'Respiratory Equipment Must be Worn', image: 'respiratory_equipment_must_be_worn.jpg' },
    { name: 'Safety Boots Must be Worn', image: 'safety_boots_must_be_worn.jpg' },
    { name: 'Safety Gloves Must Be Worn', image: 'safety_gloves_must_be_worn.jpg' },
    { name: 'Safety Harness Must be Born', image: 'safety_harness_must_be_born.jpg' },
    { name: 'Safety Helmet Must be Work', image: 'safety_helmet_must_be_work.jpg' },
    { name: 'Safety Overalls Must be Worn', image: 'safety_overalls_must_be_worn.jpg' },
    { name: 'Safety Shower', image: 'safety_shower.jpg' },
    { name: 'Serious Health Hazaed', image: 'serious_health_hazaed.jpg' },
    { name: 'Smoking & Naked Flames Forbidden', image: 'smoking_and_naked_flames_forbidden.jpg' },
    { name: 'Stretcher', image: 'stretcher.jpg' },
    { name: 'Strong Magnetic Field', image: 'strong_magnetic_field.jpg' },
    { name: 'Toxic Material', image: 'toxic_material.jpg' },
    { name: 'Warning Sign', image: 'warning_sign.jpg' }
  ];
  constructor(
    public _apiService: ApiService,
    public _route: ActivatedRoute,
    public router: Router
  ) {}

  ngOnInit() {}
}
