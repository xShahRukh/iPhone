import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { AppSettings } from '../app.settings';
import 'rxjs/add/operator/map';
import { ApiService } from '../common/services/api.service';

@Injectable()
export class EmergencyService {
  headers = new Headers({ 'Content-Type': 'application/json' });
  options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http, private _apiService: ApiService) {}

  // login api
  getDepartments() {
    const url = AppSettings.API.DEPARTMENTS;
    return this._apiService.callApi(url, 'get', null);
  }
  sentNotification(values: any = '') {
    const body = JSON.stringify(values);
    const url = AppSettings.API.SENT_NOTIFICATION;
    return this._apiService.callApi(url, 'post', body);
  }

  extraData(response: Response): Response {
    return response.json();
  }

  token1() {
    return new RequestOptions({
      headers: new Headers({
        // 'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
