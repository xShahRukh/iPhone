import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard/dashboard.component';
import { EmergencyResponseComponent } from './emergency-response/emergency-response.component';
import { ImportantSignsComponent } from './important-signs/important-signs.component';
import { FactoryLayoutsComponent } from './factory-layouts/factory-layouts.component';
import { ReportEvacuationComponent } from './report-evacuation/report-evacuation.component';
import { BusinessContinuityComponent } from './business-continuity/business-continuity.component';
import { DisasterRecoveryComponent } from './disaster-recovery/disaster-recovery.component';

const emergencyRoutes: Routes = [
  {
    path: 'edashboard',
    component: DashboardComponent
  },
  {
    path: 'emergencyResponce',
    component: EmergencyResponseComponent
  },
  {
    path: 'importantSigns',
    component: ImportantSignsComponent
  },
  {
    path: 'factoryLayouts',
    component: FactoryLayoutsComponent
  },
  {
    path: 'reportEvacuation',
    component: ReportEvacuationComponent
  },
  {
    path: 'businessContinuity',
    component: BusinessContinuityComponent
  },
  {
    path: 'disasterRecovery',
    component: DisasterRecoveryComponent
  },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];

export const emergencyRouting: ModuleWithProviders = RouterModule.forChild(emergencyRoutes);
