import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { EmergencyService } from '../emergency.service';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-emergency-response',
  templateUrl: './emergency-response.component.html',
  styleUrls: ['./emergency-response.component.styl']
})
export class EmergencyResponseComponent implements OnInit {
  deptList = [];
  sum = 0;
  deptArray = [];
  selectedItems = [];
  dropdownSettings = {};
  message = '';
  constructor(
    public vcr: ViewContainerRef,
    public toastr: ToastrManager,
    private _emergencyService: EmergencyService
  ) {}

  ngOnInit() {
    this.getDeptList();
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Locations',
      selectAllText: 'Select All'
      // unSelectAllText: 'UnSelect All',
      // enableSearchFilter: true,
      // classes: 'myclass custom-class'
    };
  }
  getDeptList() {
    console.log('f');
    this._emergencyService.getDepartments().subscribe(data => {
      if (!data.success) {
        let s: number;
        this.sum = 0;
        this.deptArray = [];
        // this.deptList = data.data;
        data.data.forEach(item => {
          console.log('d', item.short_name.toUpperCase());
          switch (item.short_name.toUpperCase()) {
            case 'CONTROL':
              s = _.random(0, 20);
              break;
            case 'PLANNING':
              s = _.random(0, 20);
              break;
            case 'AUDIT':
              s = _.random(0, 20);
              break;
            case 'SAFETY':
              s = _.random(0, 20);
              break;
            default:
              s = _.random(20, 50);
          }
          const ps = _.random(0, 5);
          this.sum += s;
          this.deptList.push({
            name: item.short_name,
            score: s,
            pcscore: ps
          });
        });

        data.data.forEach(item => {
          this.deptArray.push({
            id: item.id,
            itemName: item.short_name
          });
        });
        console.log('fafa', this.deptList);
      }
    });
  }

  onItemSelect(item: any) {}
  OnItemDeSelect(item: any) {}
  onSelectAll(items: any) {}
  onDeSelectAll(items: any) {}
  // generte random function

  sentNotification() {
    console.log('ff', this.selectedItems);
    const body = { message: this.message, dept: this.selectedItems };
    this._emergencyService.sentNotification(body).subscribe(data => {
      if (data.success) {
        this.toastr.successToastr(data.message);
        this.selectedItems = [];
        this.message = '';
        console.log('success');
      }
    });
  }
}
