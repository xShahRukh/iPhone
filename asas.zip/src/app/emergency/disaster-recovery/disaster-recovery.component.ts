import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-disaster-recovery',
  templateUrl: './disaster-recovery.component.html',
  styleUrls: ['./disaster-recovery.component.styl']
})
export class DisasterRecoveryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
