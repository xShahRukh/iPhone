import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-business-continuity',
  templateUrl: './business-continuity.component.html',
  styleUrls: ['./business-continuity.component.styl']
})
export class BusinessContinuityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
