import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-evacuation',
  templateUrl: './report-evacuation.component.html',
  styleUrls: ['./report-evacuation.component.styl']
})
export class ReportEvacuationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
