import { Component, OnInit } from '@angular/core';
import { Lightbox } from 'ngx-lightbox';

@Component({
  selector: 'app-factory-layouts',
  templateUrl: './factory-layouts.component.html',
  styleUrls: ['./factory-layouts.component.styl']
})
export class FactoryLayoutsComponent implements OnInit {
  imageUrlArray = [
    'assets/img/evacuation_plans/plan_01.png',
    'assets/img/evacuation_plans/plan_02.jpg',
    'assets/img/evacuation_plans/plan_03.png',
    'assets/img/evacuation_plans/building_01.jpg',
    'assets/img/evacuation_plans/building_02.jpg'
  ];
  currentImage: any = {};
  plan_title;
  lightImgs = [
    {
      src: 'assets/img/evacuation_plans/plan_01.png',
      caption: 'Layout 1',
      thumb: 'assets/img/evacuation_plans/thumbs/plan_01.png'
    },
    {
      src: 'assets/img/evacuation_plans/plan_02.jpg',
      caption: 'Layout 2',
      thumb: 'assets/img/evacuation_plans/thumbs/plan_02.jpg'
    },
    {
      src: 'assets/img/evacuation_plans/plan_03.png',
      caption: 'Layout 3',
      thumb: 'assets/img/evacuation_plans/thumbs/plan_03.png'
    },
    {
      src: 'assets/img/evacuation_plans/building_01.jpg',
      caption: 'Layout 4',
      thumb: 'assets/img/evacuation_plans/thumbs/building_01.jpg'
    },
    {
      src: 'assets/img/evacuation_plans/building_02.jpg',
      caption: 'Layout 5',
      thumb: 'assets/img/evacuation_plans/thumbs/building_02.jpg'
    }
  ];
  constructor(public _lightbox: Lightbox) {}

  ngOnInit() {}

  open(index: number): void {
    console.log('open called ' + index);
    // open lightbox
    // this._lightbox.open(this.lightImgs, index);
    this._lightbox.open(this.lightImgs, index, { wrapAround: true, showImageNumberLabel: true });
  }

  close(): void {
    // close lightbox programmatically
    this._lightbox.close();
  }

  uploadLayout() {
    console.log('upload Layout function called');
  }

  selectImage(image) {
    this.currentImage = image;
    this.plan_title = image.caption;
  }

  clearModel() {
    this.currentImage = {};
    this.plan_title = '';
  }
}
