import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BusinessContinuityComponent } from './business_continuity.component';

describe('LicenseReportsComponent', () => {
  let component: BusinessContinuityComponent;
  let fixture: ComponentFixture<BusinessContinuityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BusinessContinuityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BusinessContinuityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
