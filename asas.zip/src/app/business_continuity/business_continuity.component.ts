import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { DomSanitizer } from '@angular/platform-browser';

import { ToastrManager } from 'ng6-toastr-notifications';
import { ApiService } from '../common/services/api.service';

@Component({
  selector: 'app-business-continuity',
  templateUrl: './business_continuity.component.html',
  styleUrls: ['./business_continuity.component.css']
})
export class BusinessContinuityComponent implements OnInit {
  loading: Boolean = true;

  businessList: any = [];

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {}
  ngOnInit() {
    this.businessList = [
      {
        project_name: 'Director general',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'National directors',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'Hospital Group Managers',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'Integrated Service Area Managers',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      {
        project_name: 'General Managers',
        link: '../../assets/business continuity/Business Continuity.pdf'
      },

      { project_name: 'Staff', link: '../../assets/business continuity/Business Continuity.pdf' }
    ];
  }
}
