import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { AuthGuard } from "./common/guards/auth.guard";
import { LocationsComponent } from "./locations/locations.component";
import { LoginComponent } from "./login/login.component";
import { AddassestsComponent } from "./addassests/addassests.component";
import { PermitsViewComponent } from "./permits-view/permits-view.component";
import { HseStaffComponent } from "./hse-staff/hse-staff.component";
import { NcDashboardComponent } from "./regular_audit/nc-dashboard/nc-dashboard.component";
import { NcIncidenAddComponent } from "./regular_audit/nc-inciden-add/nc-inciden-add.component";
import { NcIncidenViewComponent } from "./regular_audit/nc-inciden-view/nc-inciden-view.component";
import { NcReportsComponent } from "./regular_audit/nc-reports/nc-reports.component";
import { NcIssuesSupviewComponent } from "./regular_audit/nc-issues-supview/nc-issues-supview.component";
import { NcDetailsSupComponent } from "./regular_audit/nc-details-sup/nc-details-sup.component";
import { InspectorComponent } from "./inspector/inspector.component";
import { MainDashboardComponent } from "./incident-report-dashboard/main-dashboard/main-dashboard.component";
import { IncidentDashComponent } from "./incident-report-dashboard/incident-dash/incident-dash.component";
import { IncidentviewComponent } from "./incidentview/incidentview.component";
import { LicenseReportsComponent } from "./hse_license/licenses_reports/license_reports.component";
import { FieldPassComponent } from "./field-pass/field-pass.component";
import { BusinessContinuityComponent } from "./business_continuity/business_continuity.component";
import { OngoingProjectsComponent } from "./ongoing_projects/ongoing_projects.component";
import { EmergencyResponseComponent } from "./emergency-response/emergency-response.component";
import { VendorManagementComponent } from "./vendor-management/vendor-management.component";
import { NotificationsComponent } from "./notifications/notifications.component";
import { SafetyMeetingsComponent } from "./safety-meetings/safety-meetings.component";
import { SafetyDrillsComponent } from "./safety-drills/safety-drills.component";
import { EmergencyResponsedashboardComponent } from "./emergency-responsedashboard/emergency-responsedashboard.component";
import { DisasterRecoveryComponent } from "./disaster-recovery/disaster-recovery.component";
import { InspectionReportsComponent } from "./incident-report-dashboard/inspection-reports/inspection-reports.component";
import { TestComponentComponent } from "./test-component/test-component.component";
import { RiskAssessmentComponent } from "./risk-assessment/risk-assessment.component";
import { GenericRiskAssessmentComponent } from "./risk-assessment/generic-risk-assessment/generic-risk-assessment.component";
const routes: Routes = [
  { path: "login", component: LoginComponent },
  {
    path: "dashboard",
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  { path: "Location", component: LocationsComponent, canActivate: [AuthGuard] },
  { path: "assets", component: AddassestsComponent, canActivate: [AuthGuard] },

  // Permit to work new module
  {
    path: "PTW",
    loadChildren: () => import("./ptw/ptw.module").then(m => m.PTWeModule),
    canActivate: [AuthGuard]
  },

  // HR module
  {
    path: "hse_hr",
    loadChildren: () =>
      import("./hse_hr/hse_hr.module").then(m => m.HseHrModule),
    canActivate: [AuthGuard]
  },

  // Employee Management module
  {
    path: "employee",
    loadChildren: () =>
      import("./employee/employee.module").then(m => m.EmployeeModule),
    canActivate: [AuthGuard]
  },

  // Ergonomics
  {
    path: "ergonomicsModule",
    loadChildren: () =>
      import("./ergonomicsModule/ergonomics.module").then(
        m => m.ErgonomicsModule
      )
  },

  // Incident Module
  {
    path: "intial_incidents",
    loadChildren: () =>
      import("./intial_incidents/incidents.module").then(
        m => m.InitialincidentModule
      )
    // canActivate: [AuthGuard]
  },

  // Stores module
  {
    path: "stores",
    loadChildren: () =>
      import("./stores/stores.module").then(m => m.StoresModule)
  },

  // Permit Work Module
  {
    path: "permit_to_work",
    loadChildren: () =>
      import("./permit_to_work/permit_work.module").then(
        m => m.PermitToWorkModule
      ),
    canActivate: [AuthGuard]
  },

  {
    path: "permits-view",
    component: PermitsViewComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "hseStaff",
    component: HseStaffComponent,
    canActivate: [AuthGuard]
  },

  // Non Conformence
  {
    path: "regular_audit/non-conformence",
    component: NcDashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "regular_audit/nc-incident-form",
    component: NcIncidenAddComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "regular_audit/ncincidentview",
    component: NcIncidenViewComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "regular_audit/ncreports",
    component: NcReportsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "regular_audit/ncpreviousissues",
    component: NcIssuesSupviewComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "regular_audit/ncfulldetails",
    component: NcDetailsSupComponent,
    canActivate: [AuthGuard]
  },

  // Auditor module
  {
    path: "audit",
    loadChildren: () => import("./audit/audit.module").then(m => m.AuditModule)
    // canActivate: [AuthGuard]
  },

  // employee training module
  {
    path: "employee_training",
    loadChildren: () =>
      import("./employee_training/employee_training.module").then(
        m => m.EmployeeTrainingModule
      ),
    canActivate: [AuthGuard]
  },

  // Document Module
  {
    path: "document",
    loadChildren: () =>
      import("./documents_module/documents.module").then(
        m => m.DocumentsModule
      ),
    canActivate: [AuthGuard]
  },

  // Emergenbcy response
  {
    path: "emergency",
    loadChildren: () =>
      import("./emergency/emergency.module").then(m => m.EmergencyModule),
    canActivate: [AuthGuard]
  },

  // Report Dashboard module
  // {
  //   path: 'dashboard_reports',
  //   loadChildren:
  //     './dashboard_reports/dashboardReports.module#DashboardReportingModule'
  // },

  // incident main Report Dashboard module
  {
    path: "incident_report_dashboard",
    component: MainDashboardComponent
    // path: 'incident_report_dashboard',
    // loadChildren:
    //   './incident-report-dashboard/main-dashboard/main-dashboard.component#main-dashboard',
    // component: MainDashboardComponent
  },

  // Inspector Component
  {
    path: "InspectorComponent",
    component: InspectorComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "InspectorComponentPending",
    component: InspectorComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "InspectorComponentAdd",
    component: InspectorComponent,
    canActivate: [AuthGuard]
  },

  {
    path: "incidentview",
    component: IncidentviewComponent,
    canActivate: [AuthGuard]
  },

  // Safety Drills
  {
    path: "safety_drills",
    component: SafetyDrillsComponent,
    canActivate: [AuthGuard]
  },

  // assets module
  {
    path: "assets",
    loadChildren: () =>
      import("./assets/assets.module").then(m => m.AssetsModule)
  },

  // licenses Reports module
  {
    path: "license_reports/client_license",
    component: LicenseReportsComponent,
    canActivate: [AuthGuard]
  },

  // ongoing projects module
  {
    path: "ongoing_projects",
    component: OngoingProjectsComponent,
    canActivate: [AuthGuard]
  },

  // ongoing projects module
  {
    path: "business_continuity",
    component: BusinessContinuityComponent
  },
  // Feild Pass
  {
    path: "field_pass",
    component: FieldPassComponent,
    canActivate: [AuthGuard]
  },
  // emergency
  {
    path: "emergencyO",
    component: EmergencyResponseComponent
  },
  // Vendor Management
  {
    path: "vendor_management",
    component: VendorManagementComponent,
    canActivate: [AuthGuard]
  },
  // Safety meetings
  {
    path: "safety_meetings",
    component: SafetyMeetingsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "notification",
    component: NotificationsComponent
    // canActivate: [AuthGuard]
  },
  {
    path: "risk-assessment",
    component: RiskAssessmentComponent
    // canActivate: [AuthGuard]
  },
  {
    path: "generic-risk-assessment",
    component: GenericRiskAssessmentComponent
    // canActivate: [AuthGuard]
  },
  {
    path: "emerg_dashboard",
    component: EmergencyResponsedashboardComponent,
    canActivate: [AuthGuard]
  },

  {
    path: "gatepass",
    loadChildren: () =>
      import("./gatepass/training.module").then(m => m.TrainingModule),
    canActivate: [AuthGuard]
  },
  {
    path: "disaster_recovery",
    component: DisasterRecoveryComponent,
    canActivate: [AuthGuard]
  },
  // Inspection Reports
  {
    path: "inspectionDashboard",
    component: InspectionReportsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "test-component",
    component: TestComponentComponent,
    canActivate: [AuthGuard]
  },

  { path: "", redirectTo: "dashboard", pathMatch: "full" },
  { path: "**", redirectTo: "dashboard", pathMatch: "full" }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
