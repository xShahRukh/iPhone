import { environment } from '../../environments/environment';

export class licenseSettings {
  public static API = {
    ADD_COMPANY_LICENSES_API: environment.apiUrl + 'licenses/addcompanylicenses',
    GETCOMPANY_LIST: environment.apiUrl + 'licenses/company/list',
    GET_CONTRACT_COMPANY_LIST: environment.apiUrl + 'licenses/company/contract/list',
    ADDCONTRACT_COMPANY_LIST: environment.apiUrl + 'licenses/addcontractcompany/licenses',
    GET_LICENSES_API: environment.apiUrl + 'get/contract/lincenses/types'

  };
}
