import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from '../common/services/api.service';
import { licenseSettings } from './licenses.settings';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class LicenseService {
  headers;
  options;
  constructor(private _apiService: ApiService, private http: Http) {
    this.headers = new Headers({ 'Content-Type': 'application/json' });
    this.options = new RequestOptions({ headers: this.headers });
  }

  // ADD_DOCUMENT_DETAI
  addcompanylicenses(body) {
    return this._apiService.callApi(licenseSettings.API.ADD_COMPANY_LICENSES_API, 'post', body);
  }
  getcompanylicensseslist() {
    // return this.http.get('http://localhost:9848/list', this.options).map((response: Response) => response.json());
    return this._apiService.callApi(licenseSettings.API.GETCOMPANY_LIST, 'get', {});
  }
  getcontractcomplicense() {
    return this._apiService.callApi(licenseSettings.API.GET_CONTRACT_COMPANY_LIST, 'get', {});
  }
  addcontractcompanylicenses(body) {
    return this._apiService.callApi(licenseSettings.API.ADDCONTRACT_COMPANY_LIST, 'post', body);
  }

  getlicenses_types() {
    return this._apiService.callApi(licenseSettings.API.GET_LICENSES_API, 'get', {});
  }
}
