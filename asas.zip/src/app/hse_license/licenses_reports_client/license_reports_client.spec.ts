import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LicenseReportsClientComponent } from './license_reports_client.component';


describe('LicenseReportsClientComponent', () => {
  let component: LicenseReportsClientComponent;
  let fixture: ComponentFixture<LicenseReportsClientComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LicenseReportsClientComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenseReportsClientComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
