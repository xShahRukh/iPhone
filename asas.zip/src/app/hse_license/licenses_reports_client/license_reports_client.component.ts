import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl,
  FormArray
} from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { GenericValidator } from '../../common/generic-validator';
import * as moment from 'moment';
import { LicenseService } from '../licenses.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';
declare var $;

@Component({
  selector: 'app-license-reports-client',
  templateUrl: './license_reports_client.component.html',
  styleUrls: ['./license_reports_client.component.css']
})
export class LicenseReportsClientComponent implements OnInit {
  loading: Boolean = false;
  license_from_date;
  status;

  contractList: any = [];

  public filterQuery = '';
  public rowsOnPage = 10;
  public sortBy = '';
  public sortOrder = 'desc';
  addcomplicenses: FormGroup;
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd-mmm-yyyy',
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};
  dropdownList2 = [];
  selectedItems2 = [];
  dropdownSettings2 = {};

  public myDatePickerOptions1: IMyDpOptions = {
    // other options...
    dateFormat: 'dd-mmm-yyyy',
    editableDateField: false,
    disableWeekends: false,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  addmore_length: number;
  rem_length: number;
  co_id: any;

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer,
    public licensesservice: LicenseService
  ) {}
  ngOnInit() {
    this.addcomplicenses = this.fb.group({
      company_name: ['', Validators.required],
      location: ['', Validators.required],
      license_no: ['', Validators.required],
      license_from: ['', Validators.required],
      license_to: ['', Validators.required],
      contact2: [''],
      contact1: [''],
      email: ['', Validators.required]
      // activeList: this.fb.array([this.initLink()]),
      // emails: this.fb.array([this.initLink2()])
    });
    this.getlistofcontractcomplicenses();
    this.getlicensestypes();
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select License Types',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class'
    };
    this.dropdownSettings2 = {
      singleSelection: true,
      text: 'Select Countries',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class'
    };
  }
  ShowDate(date) {
    return moment(date).format('MMM DD, YYYY');
  }
  getlistofcontractcomplicenses() {
    this.licensesservice.getcontractcomplicense().subscribe(data => {
      this.contractList = data.data;
    });
    console.log(this.contractList, 'hjxfgxjdvghsjkdfgskdjfgsdgjkfsdjk');
  }
  addactiveList() {
    const control = <FormArray>this.addcomplicenses.controls['activeList'];
    const addrCtrl = this.initLink();
    control.push(addrCtrl);
    this.addmore_length = control.length;
  }
  removeList(i: any) {
    const control = <FormArray>this.addcomplicenses.controls['activeList'];
    this.rem_length = (<FormArray>this.addcomplicenses.controls['activeList']).length;
    control.removeAt(i);
    this.addmore_length = this.rem_length - 1;
  }
  initLink() {
    return this.fb.group({
      contact: ['', Validators.required]
    });
  }
  addactiveList2() {
    const control = <FormArray>this.addcomplicenses.controls['emails'];
    const addrCtrl = this.initLink2();
    control.push(addrCtrl);
    this.addmore_length = control.length;
  }
  removeList2(j: any) {
    const control = <FormArray>this.addcomplicenses.controls['emails'];
    this.rem_length = (<FormArray>this.addcomplicenses.controls['emails']).length;
    control.removeAt(j);
    this.addmore_length = this.rem_length - 1;
  }
  initLink2() {
    return this.fb.group({
      email: ['', Validators.required]
    });
  }

  addcompanylicenses() {
    if (this.addcomplicenses.valid) {
      const element = [];
      let t;
      for (let index = 0; index < this.selectedItems.length; index++) {
        element.push(this.selectedItems[index].id);
      }
      console.log(element.toString());
      if (this.selectedItems2.length > 0) {
        t = this.selectedItems2[0].id;
      } else {
        t = null;
      }
      const body = {
        company_name: this.addcomplicenses.value.company_name,
        status: 1,
        co_id: null,
        license_no: this.addcomplicenses.value.license_no,
        valid_from: moment(this.addcomplicenses.value.license_from.jsdate).format('YYYY-MM-DD'),
        valid_to: moment(this.addcomplicenses.value.license_to.jsdate).format('YYYY-MM-DD'),
        contact1: this.addcomplicenses.value.contact1,
        contact2: this.addcomplicenses.value.contact2,
        email_id: this.addcomplicenses.value.email,
        location: this.addcomplicenses.value.location,
        types: element.toString(),
        country: t
      };
      console.log(body);
      this.licensesservice.addcontractcompanylicenses(body).subscribe(data => {
        if (!data.error) {
          this.getlistofcontractcomplicenses();
          this.addcomplicenses.reset();
          this.selectedItems = [];
          this.selectedItems2 = [];
          $('#adddeptPop2').modal('hide');
          this.toastr.successToastr('Company License added successfully');
        } else {
          this.toastr.warningToastr('Error while adding');
        }
      });
    } else {
      this.toastr.warningToastr('Please Fill the Input fields');
    }
  }

  updatecompanylicenses() {
    const element = [];
    let t;
    for (let index = 0; index < this.selectedItems.length; index++) {
      element.push(this.selectedItems[index].id);
    }
    console.log(element.toString());
    if (this.selectedItems2.length > 0) {
      t = this.selectedItems2[0].id;
    } else {
      t = null;
    }
    console.log(this.addcomplicenses.value.license_from.jsdate);
    const body = {
      company_name: this.addcomplicenses.value.company_name,
      status: this.status,
      co_id: this.co_id,
      license_no: this.addcomplicenses.value.license_no,
      valid_from: moment(this.addcomplicenses.value.license_from.jsdate).format('YYYY-MM-DD'),
      valid_to: moment(this.addcomplicenses.value.license_to.jsdate).format('YYYY-MM-DD'),
      contact1: this.addcomplicenses.value.contact1,
      contact2: this.addcomplicenses.value.contact2,
      email_id: this.addcomplicenses.value.email,
      location: this.addcomplicenses.value.location,
      types: element.toString(),
      country: t
    };

    this.licensesservice.addcontractcompanylicenses(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr('Company License added successfully');
        this.addcomplicenses.reset();
        this.getlistofcontractcomplicenses();
        this.co_id = '';
        this.co_id = null;
        this.selectedItems = [];
        this.selectedItems2 = [];
      } else {
        this.toastr.warningToastr('Error while adding');
      }
    });
  }
  ChangeDate2(event: IMyDateModel) {
    this.myDatePickerOptions1.disableUntil.year = event.date.year;
    this.myDatePickerOptions1.disableUntil.month = event.date.month;
    this.myDatePickerOptions1.disableUntil.day = event.date.day;
  }
  editlicense(item) {
    this.selectedItems = [];
    this.selectedItems2 = [];
    this.addcomplicenses.reset();
    console.log(item);
    this.co_id = item.co_id;
    this.status = item.status;
    (this.license_from_date = { jsdate: new Date(item.valid_from) }),
      this.addcomplicenses.patchValue(item);
    const c = item.types.split(',');
    for (let jk = 0; jk < c.length; jk++) {
      for (let index = 0; index < this.dropdownList.length; index++) {
        if (c[jk] === this.dropdownList[index].id) {
          this.selectedItems.push({
            id: this.dropdownList[index].id,
            itemName: this.dropdownList[index].itemName
          });
        }
      }
    }
    for (let ik = 0; ik < this.dropdownList2.length; ik++) {
      if (item.country === this.dropdownList2[ik].id) {
        this.selectedItems2.push({
          id: this.dropdownList2[ik].id,
          itemName: this.dropdownList2[ik].itemName
        });
      }
    }
    console.log(this.selectedItems);

    this.addcomplicenses.patchValue({
      license_from: {
        jsdate: new Date(item.valid_from)
      },

      license_to: {
        jsdate: new Date(item.valid_to)
      },
      email: item.email_id
    });
  }
  reset() {
    this.co_id = null;
    this.addcomplicenses.reset();
    this.selectedItems = [];
    this.selectedItems2 = [];
  }
  getlicensestypes() {
    this.licensesservice.getlicenses_types().subscribe(data => {
      this.dropdownList = data.data;
      this.dropdownList2 = data.data2;
      console.log(this.dropdownList);
    });
  }
  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    console.log(items);
  }
  onDeSelectAll(items: any) {
    console.log(items);
  }
  onItemSelect1(item: any) {
    console.log(item);
    console.log(this.selectedItems2);
  }
  OnItemDeSelect1(item: any) {
    console.log(item);
    console.log(this.selectedItems2);
  }
  onSelectAll1(items: any) {
    console.log(items);
  }
  onDeSelectAll1(items: any) {
    console.log(items);
  }
}
