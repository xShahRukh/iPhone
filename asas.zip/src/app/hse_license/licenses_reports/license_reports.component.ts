import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { GenericValidator } from '../../common/generic-validator';
import { LicenseService } from '../licenses.service';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import * as moment from 'moment';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-license-reports',
  templateUrl: './license_reports.component.html',
  styleUrls: ['./license_reports.component.css']
})
export class LicenseReportsComponent implements OnInit {
  loading: Boolean = true;

  licenseList: any = [];
  license_type: any;
  license_from;
  license_to;
  d = new Date();
  license_no;
  status: any;
  company_lid;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = '';
  public sortOrder = 'desc';
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };

  public myDatePickerOptions1: IMyDpOptions = {
    // other options...
    dateFormat: 'dd-mmm-yyyy',
    editableDateField: false,
    disableWeekends: false,
    disableUntil: { year: 2018, month: 8, day: 1 }
  };

  constructor(
    public fb: FormBuilder,
    public _apiService: ApiService,
    public licensesservice: LicenseService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {}
  ngOnInit() {
    this.loading = false;
    this.getlistofcompanylicenses();
    this.licenseList = [
      {
        license_type: 'Open General Licence (OGL)',
        description:
          // tslint:disable-next-line:max-line-length
          'An OGL allows the export of specific goods by any exporter to a range of destinations. Open licences may be available for less restricted controlled items. You must register for these licences and adhere to all terms and conditions. If you cannot fulfil all the terms and conditions you will need to apply for a Standard Individual Export Licence, as detailed below.'
      },

      {
        license_type: 'Standard Individual Export Licence',
        description:
          'An SIEL allows the export of a quantity of specified goods to a specified importer as set out in the licence.'
      },

      {
        license_type: 'Open Individual Export Licence',
        description:
          // tslint:disable-next-line:max-line-length
          'This is specific to an individual exporter and allows multiple shipments of specified goods to specified destinations. It is a concessionary form of licence available to exporters with a track record in export licence applications only.'
      },

      {
        license_type: 'Exports of chemicals and pesticides',
        description:
          // tslint:disable-next-line:max-line-length
          'If you’re planning to export certain pesticides or hazardous chemicals outside of the European Union (EU) you may need to go through a notification procedure and, in some cases, obtain prior informed consent (PIC) from the importing country before the export can take place. This procedure is overseen by the Health & Safety Executive (HSE).'
      },

      {
        license_type: 'Imports of medicinal products',
        description: 'Imports of medicinal products are subject to licensing.'
      }
    ];
  }
  ChangeDate2(event: IMyDateModel) {
    this.myDatePickerOptions1.disableUntil.year = event.date.year;
    this.myDatePickerOptions1.disableUntil.month = event.date.month;
    this.myDatePickerOptions1.disableUntil.day = event.date.day;
  }
  getlistofcompanylicenses() {
    this.licensesservice.getcompanylicensseslist().subscribe(data => {
      this.licenseList = data.data;
    });
  }

  addcompanylicenses() {
    if (this.license_type != null) {
      const body = {
        license_type: this.license_type,
        status: 1,
        c_id: null,
        license_no: this.license_no,
        valid_from: moment(this.license_from.jsdate).format('YYYY-MM-DD'),
        valid_to: moment(this.license_to.jsdate).format('YYYY-MM-DD')
      };
      console.log(body);
      this.licensesservice.addcompanylicenses(body).subscribe(data => {
        if (!data.error) {
          this.toastr.successToastr('Company License added successfully');
          this.license_type = '';
          this.license_from = '';
          this.license_to = '';
          this.license_no = '';
          this.getlistofcompanylicenses();
        } else {
          this.toastr.warningToastr('Error while adding');
        }
      });
    } else {
      console.log('hjdgfjhsdfgh');
      this.toastr.warningToastr('Please Fill the required fields');
    }
  }

  updatecompanylicenses() {
    const body = {
      license_type: this.license_type,
      status: this.status,
      c_id: this.company_lid,
      license_no: this.license_no,
      valid_from: moment(this.license_from.jsdate).format('YYYY-MM-DD'),
      valid_to: moment(this.license_to.jsdate).format('YYYY-MM-DD')
    };

    this.licensesservice.addcompanylicenses(body).subscribe(data => {
      if (!data.error) {
        this.toastr.successToastr('Company License added successfully');
        this.license_type = '';
        this.license_from = '';
        this.license_to = '';
        this.license_no = '';
        this.company_lid = '';
        this.getlistofcompanylicenses();
      } else {
        this.toastr.warningToastr('Error while adding');
      }
    });
  }
  editlicense(item) {
    this.license_type = item.license_type;
    this.license_from = {
      date: {
        year: new Date(item.valid_from).getFullYear(),
        month: new Date(item.valid_from).getMonth() + 1,
        day: new Date(item.valid_from).getDate()
      }
    };
    this.license_to = {
      date: {
        year: new Date(item.valid_to).getFullYear(),
        month: new Date(item.valid_to).getMonth() + 1,
        day: new Date(item.valid_to).getDate()
      }
    };
    this.license_no = item.license_no;
    this.status = item.status;
    this.company_lid = item.c_id;
  }

  ShowDate(date) {
    return moment(date).format('MMM DD, YYYY');
  }
}
