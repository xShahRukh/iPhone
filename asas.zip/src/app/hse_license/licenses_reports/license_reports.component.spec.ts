import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LicenseReportsComponent } from './license_reports.component';

describe('LicenseReportsComponent', () => {
  let component: LicenseReportsComponent;
  let fixture: ComponentFixture<LicenseReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LicenseReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenseReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
