import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LicenseReportsPTWComponent } from './license_reports_ptw.component';



describe('LicenseReportsPTWComponent', () => {
  let component: LicenseReportsPTWComponent;
  let fixture: ComponentFixture<LicenseReportsPTWComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LicenseReportsPTWComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LicenseReportsPTWComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
