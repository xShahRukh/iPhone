import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-license-reports-ptw',
  templateUrl: './license_reports_ptw.component.html',
  styleUrls: ['./license_reports_ptw.component.css']
})
export class LicenseReportsPTWComponent implements OnInit {
  loading: Boolean = true;
  public filterQuery = '';
  public rowsOnPage = 5;
  public sortBy = '';
  public sortOrder = 'desc';
  permitlist: any = [];
  permitlist1: any = [];
  permitlist2: any = [];
  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public sanitizer: DomSanitizer
  ) {}
  ngOnInit() {
    this.getpermitconfiglist();
  }
  getpermitconfiglist() {
    this.loading = true;
    this._apiService.getlistofpermits().subscribe(data => {
      console.log('Permit Data list', data);
      if (data.error) {
        this.loading = false;
        this.permitlist = data.data[0].work_permits;
        if (this.permitlist.length > 0) {
          this.permitlist1 = this.permitlist.slice(0, Math.ceil(this.permitlist.length / 2));
          this.permitlist2 = this.permitlist.slice(
            Math.ceil(this.permitlist.length / 2),
            this.permitlist.length
          );
        }
      } else {
        this.permitlist = [];
        this.loading = false;
      }
    });
  }
  // getpermitconfiglist() {
  //   this.loading = true;
  //   this._apiService.getlistofpermits().subscribe(data => {
  //     console.log('Permit Data list', data);
  //     if (data.error) {
  //       this.loading = false;
  //       this.permitlist = data.data[0].work_permits;
  //     } else {
  //       this.permitlist = [];
  //       this.loading = false;
  //     }
  //   });
  // }
}
