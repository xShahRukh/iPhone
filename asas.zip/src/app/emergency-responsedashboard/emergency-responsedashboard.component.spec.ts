import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmergencyResponsedashboardComponent } from './emergency-responsedashboard.component';

describe('EmergencyResponsedashboardComponent', () => {
  let component: EmergencyResponsedashboardComponent;
  let fixture: ComponentFixture<EmergencyResponsedashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmergencyResponsedashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmergencyResponsedashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
