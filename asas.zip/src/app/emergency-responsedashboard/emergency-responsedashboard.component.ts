import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emergency-responsedashboard',
  templateUrl: './emergency-responsedashboard.component.html',
  styleUrls: ['./emergency-responsedashboard.component.css']
})
export class EmergencyResponsedashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
