import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewTrainingReportsComponent } from './new-training-reports.component';

describe('NewTrainingReportsComponent', () => {
  let component: NewTrainingReportsComponent;
  let fixture: ComponentFixture<NewTrainingReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewTrainingReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewTrainingReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
