import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { ScheduleTrainingComponent } from './schedule_training/schedule_training.component';
import { QuizComponent } from './quiz/quiz.component';
import { CertificateComponent } from './quiz/certificate/certificate.component';
import { TrainingReportsComponent } from './training-reports/training-reports.component';
import { TrainingDashboardComponent } from './training-dashboard/training-dashboard.component';
import { NewTrainingReportsComponent } from './new-training-reports/new-training-reports.component';

const routes: Routes = [
  {
    path: 'schedule_training',
    component: ScheduleTrainingComponent
  },
  {
    path: 'quiz',
    component: QuizComponent
  },
  {
    path: 'certificate',
    component: CertificateComponent
  },
  {
    path: 'training-reports',
    component: TrainingReportsComponent
  },
  {
    path: 'training-dashboard',
    component: TrainingDashboardComponent
  },
  {
    path: 'new-training-dashboard',
    component: NewTrainingReportsComponent
  },

  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'dashboard' }
];

// export const routing = RouterModule.forChild(routes);
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
