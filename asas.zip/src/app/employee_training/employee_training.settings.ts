import { environment } from '../../environments/environment';

export class EmployeeTrainingSettings {
  public static API = {
    GET_DEPT: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    TRAINING: environment.apiUrl + 'training',
    TRAINING_LIST: environment.apiUrl + 'getEmployeeTraining',
    QUESTIONS_LIST: environment.apiUrl + 'getQuestions',
    RESULT: environment.apiUrl + 'examResult',
    GET_TRAINING_TYPES: environment.apiUrl + 'getTrainings',
    GET_ALL_TRAINING_TYPES: environment.apiUrl + 'getAllTrainings',
    GET_EMP_SCORE: environment.apiUrl + 'getEmployeesScore',
    OPT_QUESTIONS_LIST: environment.apiUrl + 'getOptQuestions',
    GET_EMPLOYEE_REPORT: environment.apiUrl + 'employeeReports',
    GET_USER_LIST: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',
    GET_EMPLOYEES_TRAININGS: environment.apiUrl + 'getEmpTraining'
    // traingingNotiications: environment.apiUrl + 'getTrainingCount',
    // OPT_TRAINING_LIST: environment.apiUrl + 'getOptTrainingList',
  };
  public static image_path = environment.apiUrl + 'image/';
}
