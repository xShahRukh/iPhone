import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { QuizService } from './quizservice';
// import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { ToastrManager } from 'ng6-toastr-notifications';

import { DomSanitizer } from '@angular/platform-browser';
import { EmployeeTrainingSettings } from '../employee_training.settings';

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  validity: any;
  passPercent: any;
  showQuiz = false;
  showVideos = false;
  optional = false;
  showResult = false;
  spinner = true;
  optPass: boolean;
  trainingList = [];
  optTrainingList = [];
  yourResult;
  trainingVideoId;
  count = 0;
  questionDatalength = 0;
  emp_id = sessionStorage.getItem('userid');
  departmentId = sessionStorage.getItem('departmentId');
  department = sessionStorage.getItem('department');
  imagePath = '';
  questionsData = [];
  answer = [];
  result;
  dept = '';
  tname = '';
  trainingnotCompleted = [];
  ct = [];
  totalData = [];
  certificate = false;
  constructor(
    public router: Router,
    public toastr: ToastrManager,
    private route: ActivatedRoute,
    private _quizService: QuizService,
    public vcr: ViewContainerRef
  ) {
    // this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.getTriningList();
    // this.getEmpTraining();
  }

  getTriningList() {
    this.spinner = true;
    this.trainingList = [];
    this.trainingnotCompleted = [];
    this.optTrainingList = [];
    this._quizService
      .gettraining(this.emp_id, this.department)
      .subscribe(data => {
        this.trainingList = [];
        this.trainingnotCompleted = [];
        this.optTrainingList = [];
        if (data.success) {
          this.totalData = data.data;
          data.data.forEach(item => {
            if (item.status === 1 && item.optStatus !== 2) {
              this.trainingList.push({
                training_id: item.training_id,
                emp_score: item.emp_score,
                training_name: item.training_name,
                due_dt: moment(item.due_date).format('MMM DD, YYYY')
              });
            } else {
              if (item.optStatus !== 2 && item.status === 0) {
                this.trainingnotCompleted.push({
                  training_id: item.training_id,
                  emp_score: item.emp_score,
                  training_name: item.training_name
                  // due_dt: moment(item.due_dt).format('YYYY-MM-DD')
                });
              }
            }
            if (item.optStatus === 2) {
              if (item.status === 1) {
                this.optPass = true;
              } else {
                this.optPass = false;
              }
              this.optTrainingList.push({
                training_id: item.training_id,
                emp_score: item.emp_score,
                training_name: item.training_name,
                due_date:
                  item.due_date === null
                    ? ''
                    : moment(item.due_date).format('MMM DD, YYYY'),
                status: item.status
              });
            }
            console.log('opt length', this.optTrainingList.length);
          });
          data.dataOne.forEach(ele => {
            this.optTrainingList.push({
              training_id: ele.training_id,
              training_name: ele.training_name
            });
          });
          console.log(
            'ddsa',
            this.trainingnotCompleted.length,
            this.trainingList.length,
            this.optTrainingList.length
          );
          this.spinner = false;
          // this.trainingList = data.data;
        } else {
          this.spinner = false;
        }
      });
  }

  // getEmpTraining() {
  //   this._quizService.getOptTraining(this.department).subscribe( data => {
  //     if (data.success) {
  //       // this.optTrainingList = data.data;
  //     }
  //   });
  // }

  showVideo(id, name) {
    this.spinner = true;
    this.showVideos = true;
    sessionStorage.setItem('tname', name);
    this.tname = sessionStorage.getItem('tname');
    this.trainingVideoId = id;
    this.questionDatalength = 0;
    this._quizService.getquestions(id).subscribe(data => {
      console.log(data)
      if (data.success) {
        this.imagePath = EmployeeTrainingSettings.image_path + data.video;
        this.questionsData = data.data;
        this.passPercent = data.pass_percent;
        this.validity = data.validity;
        this.result = data.result;
        this.dept = data.dept;
        this.spinner = false;
      } else {
        this.spinner = true;
       
      }
      if (this.result === 'fail' || this.result === null) {
        this.showQuiz = true;
      } else {
        this.showQuiz = true;
        // this.toastr.success('You have cleared this Exam');
      }
    }), error => {
      this.toastr.errorToastr('Server timedout')
    };
  }

  showOptVideo(id, name) {
    this.spinner = true;
    this.showVideos = true;
    this.optional = true;
    sessionStorage.setItem('tname', name);
    this.tname = sessionStorage.getItem('tname');
    this.trainingVideoId = id;
    this.questionDatalength = 0;
    this._quizService.getOptQuestions(id, this.departmentId).subscribe(data => {
      if (data.success) {
        this.imagePath = EmployeeTrainingSettings.image_path + data.video;
        this.questionsData = data.data;
        this.passPercent = data.pass_percent;
        this.validity = data.validity;
        this.result = data.result;
        this.dept = data.dept;
        this.spinner = false;
      } else {
        this.spinner = false;
      }
      if (this.result === 'fail' || this.result === null) {
        this.showQuiz = true;
      } else {
        this.showQuiz = true;
        // this.toastr.success('You have cleared this Exam');
      }
    });
  }

  Selection(value, index) {
    // if (value.target.value) {
    //   this.ct.push(value.target.value);
    // }
    console.log('ct', this.ct);
    console.log(value.target.value, index);
    this.answer[index] = value.target.value;
    console.log('dd', this.answer.length);
  }

  questions() {
    this.showVideos = false;
  }

  submit() {
    this.spinner = true;
    const body = {};
    this.count = 0;
    if (this.optional === true) {
      body['status'] = 2;
    } else {
      body['status'] = 1;
    }
    for (let i = 0; i < this.answer.length; i++) {
      this.ct.push(this.answer);
      if (parseInt(this.answer[i], 10) === this.questionsData[i].answer) {
        this.count++;
      }
    }
    console.log('length', this.ct.length, this.questionsData.length);
    if (this.questionsData.length !== this.ct.length) {
      this.toastr.errorToastr('Answer all the questions');
      return;
    } else {
      this.showResult = true;
      console.log('test');
      this.result = this.count;

      if (this.result >= this.passPercent) {
        this.yourResult = 'Passed';
        body['result'] = 'pass';
        body['validity'] = this.validity;
      } else {
        this.yourResult = 'Failed';
        body['result'] = 'fail';
      }
      body['score'] = this.result;
      body['training_id'] = this.trainingVideoId;
      body['dept'] = this.departmentId;
      console.log('body', body, this.yourResult);
      this._quizService.result(body).subscribe(async data => {
        if (data.success) {
          if (data.result === 'pass') {
            this.certificate = true;
            await sessionStorage.setItem(
              'dueDate',
              moment(data.dueDate).format('MMM DD, YYYY')
            );
          } else {
          }

          console.log('success', data.dueDate);
          this.getTriningList();
          this.spinner = false;
          this.ct = [];
          this.optional = false;
          console.log(data.data);
        } else {
          this.spinner = false;
          this.ct = [];
        }
      });
    }
  }

  OK() {
    console.log('tregtefa');
    this.showQuiz = false;
    this.showResult = false;
    this.showVideos = false;
    this.count = 0;
    this.result = null;
    this.answer = [];
    this.certificate = false;
    this.getTriningList();
    this.ct = [];
    this.yourResult = '';
  }

  back() {
    console.log('test');
    this.router.navigate(['/schedule_training']);
    this.yourResult = '';
    this.certificate = false;
  }

  goToFirstPage(value) {
    // this.showVideos = false;
    console.log(value);
    this.showQuiz = false;
    this.showResult = false;
    this.showVideos = false;
    this.yourResult = '';
    this.questionsData = [];
    this.answer = [];
    this.ct = [];
    this.certificate = false;
  }
}
