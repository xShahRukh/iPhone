import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'app-certificate',
  templateUrl: './certificate.component.html',
  styleUrls: ['./certificate.component.css']
})
export class CertificateComponent implements OnInit {
  name = '';
  tname = '';
  dt = moment().format('YYYY-MM-DD');
  dueDt = '';
  constructor(
    public router: Router,
    private route: ActivatedRoute,
    public vcr: ViewContainerRef
  ) {}

  ngOnInit() {
    this.tname = sessionStorage.getItem('tname');
    this.name = sessionStorage.getItem('name');
    this.dueDt = sessionStorage.getItem('dueDate');
  }

  print() {
    window.print();

    // let printContents, popupWin;
    // printContents = document.getElementById('print-section').innerHTML;
    // popupWin = window.open('', '_blank', 'top=0,left=0,height=100%,width=auto');
    // popupWin.document.open();
    // popupWin.document.write(`
    //   <html>
    // <body onload="window.print();window.close()">${printContents}</body>
    //   </html>`);
    // popupWin.document.close();
  }
}
