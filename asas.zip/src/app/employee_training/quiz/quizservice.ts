import { Injectable } from '@angular/core';
import { EmployeeTrainingApiService } from '../trainingApi.service';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import { ApiService } from '../../common/services/api.service';

import {
  Http,
  Headers,
  Response,
  RequestOptions,
  ResponseContentType
} from '@angular/http';

@Injectable()
export class QuizService {
  constructor(
    private http: Http,
    public _empTraingApiService: EmployeeTrainingApiService,
    public _apiService: ApiService
  ) {}
  gettraining(id, department) {
    const url = EmployeeTrainingSettings.API.TRAINING_LIST + `/${id}` + `/${department}`;
    console.log('url', url);
    return this._apiService.callApi(url, 'get', null);
  }
  getquestions(id) {
    const url = EmployeeTrainingSettings.API.QUESTIONS_LIST + `/${id}`;
    console.log('url', url);
    return this._apiService.callApi(url, 'get', null);
  }

  getOptQuestions(id, departmentId) {
    const url = EmployeeTrainingSettings.API.OPT_QUESTIONS_LIST + `/${id}` + `/${departmentId}`;
    console.log('url', url);
    return this._apiService.callApi(url, 'get', null);
  }

  // getOptTraining(value) {
  //   const url = EmployeeTrainingSettings.API.OPT_TRAINING_LIST + `/${value}`;
  //   console.log('url', url);
  //   return this._apiService.callApi(url, 'get', null);
  // }

  result(values: any) {
    const body = values;
    const url = EmployeeTrainingSettings.API.RESULT;
    return this._apiService.callApi(url, 'POST', body);
  }

  //   getvidoesUrl(body) {
  //     return this._apiService.callApi(
  //       EmployeeTrainingSettings.API.GET_VIDEOS_URL,
  //       'POST',
  //       body
  //     );
  //   }

  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
