import { IMyDpOptions } from 'mydatepicker';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { ToastrManager } from 'ng6-toastr-notifications';

import { DomSanitizer } from '@angular/platform-browser';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import { TrainingReportsService } from './training-reports.service';

@Component({
  selector: 'app-training-reports',
  templateUrl: './training-reports.component.html',
  styleUrls: ['./training-reports.component.css']
})
export class TrainingReportsComponent implements OnInit {
  showTraining = false;
  trainingNames = [];
  trainingDept = [];
  trainingDepts = [];
  trainingTypeData = [];
  userScore = [];
  deptTable = true;
  empScoreTable = false;
  traingGraph = false;
  deptGraph = false;
  deptList = [];
  trainingList = [];
  training = [];
  deptName = [];
  options1: Object;
  options2: Object;
  spinner = true;
  deptPage = false;
  trainingPage = false;
  deptNameSet = '';
  trainingName = '';
  employeePage = false;
  deptUser = '0';
  tid = '';
  userTraining = [];
  usersList = [];
  showMessage = false;
  constructor(
    public router: Router,
    public toastr: ToastrManager,
    private route: ActivatedRoute,
    public _dashboardService: TrainingReportsService,
    public vcr: ViewContainerRef
  ) {
    // this.toastr.setRootViewContainerRef(vcr);
  }

  ngOnInit() {
    this.graph();
    this.graph1();
    this.getTrainings();
    this.getData();
    this.getUsersList();
  }
  backToPage() {
    console.log('backtoPage');
    this.showTraining = false;
    this.empScoreTable = false;
    this.traingGraph = false;
    this.deptGraph = false;
    this.deptPage = false;
    this.trainingPage = false;
    this.spinner = false;
  }

  backToDept() {
    console.log('backtoDept');
    this.showTraining = true;
    this.empScoreTable = false;
    this.traingGraph = false;
    this.deptGraph = false;
    this.deptPage = true;
    this.trainingPage = false;
    this.spinner = false;
  }

  backToTraining() {
    console.log('backtoTraining');
    this.showTraining = true;
    this.empScoreTable = false;
    this.traingGraph = false;
    this.deptGraph = false;
    this.deptPage = false;
    this.trainingPage = true;
    this.spinner = false;
  }

  getTrainings() {
    this._dashboardService.getTrainings().subscribe(data => {
      if (data.success) {
        this.trainingNames = data.data;
      }
    });
  }

  getUsersList() {
    console.log('dd');
    this._dashboardService.getUserList().subscribe(data => {
      if (!data.success) {
        this.usersList = data.data;
        console.log('user', this.usersList);
      }
    });
  }

  Trainig() {
    this.showTraining = true;
    this.deptTable = true;
    this.deptPage = false;
    this.spinner = true;
    this.getData();
    // this.close();
  }
  getData() {
    this._dashboardService.getAllTrainings().subscribe(
      data => {
        this.spinner = false;
        this.trainingDepts = [];
        if (data.success) {
          this.spinner = false;
          data.data.forEach(item => {
            this.trainingDepts.push({
              name: item.short_name,
              id: item.id
            });
          });
          this.trainingDepts = _.uniq(this.trainingDepts, 'name');

          // var unique = this.trainingDepts.filter(function(x, i) {
          //   console.log('dad', x);
          //   return this.trainingDepts[i].id.indexOf(x.id) === i;
          // });

          this.trainingTypeData = data.data;
          // this.trainingNames = _.unique(this.trainingTypeData, 'training_name')
        } else {
          this.spinner = false;
        }
      },
      error => {
        this.spinner = false;
      }
    );
  }

  dept(values) {
    this.trainingDept = values.split(',');
    const evens = _.filter(this.trainingNames, function(num) {
      const evens1 = _.filter(this.trainingDept, function(o) {
        return num.training_id === o;
      });
    });
    return 'tect';
  }

  getTrainingDepts(did, tid, type) {
    // if (type == 'training') {
    //   console.log('ds', did, tid);
    //   var evens = _.filter(this.trainingTypeData, function(num) {
    //     return num.id == did && num.training_id == tid;
    //   });

    //   return evens.length;
    // }

    if (type === 'dept') {
      const evens = _.filter(this.trainingTypeData, function(num) {
        return num.id === did && num.training_id === tid;
      });
      return evens;
    }
  }
  empScore(did, tid) {
    this.spinner = true;
    this.empScoreTable = true;
    this.deptTable = false;
    console.log('ids', did, tid);
    this._dashboardService.empScore({ deptId: did, trainingId: tid }).subscribe(data => {
      if (data.success) {
        data.data.forEach(item => {
          this.userScore = data.data;
          this.spinner = false;
          // this.userScore.push({
          //   emp_id: item.emp_id,
          //   emp_score: item.emp_score,
          //   due_date: moment(item.due_date).format('YYYY-MM-DD'),
          //   exam_dt: moment(item.due_date).format('YYYY-MM-DD')
          // });
        });
      } else {
        this.spinner = false;
      }
    });
  }

  close() {
    this.empScoreTable = false;
    this.deptTable = false;
    this.deptGraph = false;
    this.traingGraph = false;
    this.deptPage = true;
  }

  depart(values) {
    this.deptGraph = true;
    this.deptTable = false;
    this.deptPage = false;
    sessionStorage.setItem('dept', values.name);
    this.deptNameSet = sessionStorage.getItem('dept');
    console.log('values', values, this.trainingTypeData);
    const test = _.filter(this.trainingTypeData, function(num) {
      return num.id === values.id;
    });
    console.log('test', test);
    this.deptList = [];
    this.trainingList = [];
    test.forEach(item => {
      this.deptList.push(item.pass_percent);
    });
    test.forEach(item => {
      this.trainingList.push(item.training_name);
    });
    console.log(this.trainingList, this.deptList);
    this.graph1();
  }

  callTraining(id, name) {
    sessionStorage.setItem('trainingName', name);
    this.trainingName = sessionStorage.getItem('trainingName');
    this.traingGraph = true;
    this.deptTable = false;
    this.trainingPage = false;
    console.log('values', id, this.trainingTypeData);
    const test1 = _.filter(this.trainingTypeData, function(num) {
      return num.training_id === id;
    });
    console.log('test', test1);
    this.deptName = [];
    this.training = [];
    test1.forEach(item => {
      this.training.push(item.pass_percent);
    });
    test1.forEach(item => {
      this.deptName.push(item.short_name);
    });
    console.log(this.training, this.deptName);
    this.graph();
  }

  back() {
    console.log('back');
    this.showTraining = false;
  }

  backuser() {
    console.log('back');
    this.employeePage = false;
    this.showTraining = false;
    this.deptUser = '0';
    this.tid = '';
    this.userTraining = [];
    this.trainingList = [];
    this.showMessage = false;
    this.spinner = false;
  }

  homePage() {
    this.router.navigate(['/dashboard']);
  }

  async graph() {
    // chart for Training
    this.options1 = {
      chart: {
        type: 'column',
        renderTo: 'con'
      },
      title: {
        text: 'Training compliance by Departments'
      },
      xAxis: {
        categories: this.deptName,
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score'
        }
      },
      credits: {
        enabled: false
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} </b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          name: 'Score',
          data: this.training
        }
      ]
    };

    // Department Score chart
  }

  async graph1() {
    this.options2 = {
      chart: {
        type: 'column',
        renderTo: 'contain'
      },
      title: {
        text: 'Training Score per Department'
      },
      xAxis: {
        categories: this.trainingList,
        crosshair: true
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Score (%)'
        }
      },
      tooltip: {
        headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
        pointFormat:
          '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
          '<td style="padding:0"><b>{point.y:.1f} %</b></td></tr>',
        footerFormat: '</table>',
        shared: true,
        useHTML: true
      },
      plotOptions: {
        column: {
          pointPadding: 0.2,
          borderWidth: 0
        }
      },
      series: [
        {
          name: 'Trainings',
          data: this.deptList
        }
      ]
    };
  }

  backToTable() {
    console.log('backtoTable');
    this.Trainig();
    this.empScoreTable = false;
    this.traingGraph = false;
    this.deptGraph = false;
    this.spinner = false;
  }

  deptReport() {
    this.deptPage = true;
    this.showTraining = true;
    this.deptTable = false;
    this.spinner = true;
    this.trainingPage = false;
    this._dashboardService.getAllTrainings().subscribe(
      data => {
        this.spinner = false;
        this.trainingDepts = [];
        if (data.success) {
          data.data.forEach(item => {
            this.trainingDepts.push({
              name: item.short_name,
              id: item.id
            });
          });
          this.trainingDepts = _.uniq(this.trainingDepts, 'name');

          // var unique = this.trainingDepts.filter(function(x, i) {
          //   console.log('dad', x);
          //   return this.trainingDepts[i].id.indexOf(x.id) === i;
          // });

          this.trainingTypeData = data.data;
          // this.trainingNames = _.unique(this.trainingTypeData, 'training_name')
        } else {
          this.spinner = false;
        }
      },
      error => {
        this.spinner = false;
      }
    );
  }
  close1() {
    this.empScoreTable = false;
    this.deptTable = true;
    this.spinner = false;
  }
  close2() {
    this.empScoreTable = false;
    this.deptTable = false;
    this.deptGraph = false;
    this.traingGraph = false;
    this.deptPage = false;
    this.trainingPage = true;
    this.spinner = false;
  }
  trainReport() {
    this.spinner = false;
    this.trainingPage = true;
    this.showTraining = true;
    this.deptTable = false;
    this.deptPage = false;
    this.spinner = false;
  }

  employeeReport() {
    this.employeePage = true;
    this.showTraining = true;
    this.deptTable = false;
    this.spinner = false;
  }

  Ondepart(id) {
    console.log('id', this.usersList);
    if (id === '0') {
      this.toastr.errorToastr('Plese select employee');
      return;
    } else {
      const test = _.filter(this.usersList, function(num) {
        return parseInt(num.dept_short, 0) === id;
      });
      console.log('test', test);
      this.trainingList = [];

      test.forEach(item => {
        this.trainingList.push({
          name: item.emp_name,
          id: item.emp_id
        });
      });
      this.tid = this.trainingList[0].id;
      console.log('dsds', this.trainingList);
    }
  }
  getEmpReport() {
    this.spinner = true;
    this.showMessage = true;
    this.userTraining = [];
    if (this.deptUser !== '0' && this.tid !== '0') {
      this._dashboardService
        .getUserReport({ deptId: this.deptUser, emp_code: this.tid })
        .subscribe(data => {
          if (data.success) {
            this.spinner = false;
            data.data.forEach(item => {
              this.userTraining.push({
                training_name: item.training_name,
                emp_score: item.emp_score,
                result: item.result,
                due_date: item.due_date
              });
            });
            // this.userTraining = data.data;
            console.log('dda', data.data);
          } else {
            this.spinner = false;
          }
        });
    } else {
      this.spinner = false;
      this.toastr.errorToastr('Plese select employee');
    }
    // const body = { dept_id: this.deptUser, training_id: this.tid };
  }
}
