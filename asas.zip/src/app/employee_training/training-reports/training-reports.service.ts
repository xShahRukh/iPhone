import { Injectable } from '@angular/core';
import { EmployeeTrainingApiService } from '../trainingApi.service';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import { ApiService } from '../../common/services/api.service';
import {
  Http,
  Headers,
  Response,
  RequestOptions,
  ResponseContentType
} from '@angular/http';

@Injectable()
export class TrainingReportsService {
  constructor(
    private http: Http,
    public _empTraingApiService: EmployeeTrainingApiService,
    public _apiService: ApiService
  ) {}

  getAllTrainings() {
    const url = EmployeeTrainingSettings.API.GET_ALL_TRAINING_TYPES;
    return this._apiService.callApi(url, 'GET', null);
  }

  getTrainings() {
    const url = EmployeeTrainingSettings.API.GET_TRAINING_TYPES;
    return this._apiService.callApi(url, 'GET', null);
  }
  empScore(ids) {
    console.log('dss', ids);
    const deptid = ids.deptId;
    const trainingId = ids.trainingId;
    console.log('dd', deptid, trainingId);
    // const did = body[].deptid;
    const url =
      EmployeeTrainingSettings.API.GET_EMP_SCORE +
      `/${deptid}` +
      `/${trainingId}`;
    return this._apiService.callApi(url, 'GET', null);
  }

  getUserReport(ids) {
    const deptid = ids.deptId;
    const emp_code = ids.emp_code;
    const url =
      EmployeeTrainingSettings.API.GET_EMPLOYEES_TRAININGS +
      `/${emp_code}` +
      `/${deptid}`;

    return this._apiService.callApi(url, 'GET', null);
  }
  getUserList() {
    const url = EmployeeTrainingSettings.API.GET_USER_LIST;
    return this._apiService.callApi(url, 'GET', null);
  }
}
