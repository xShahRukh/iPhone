import { Injectable } from '@angular/core';

import { EmployeeTrainingApiService } from '../trainingApi.service';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import { ApiService } from '../../common/services/api.service';
import { environment } from 'src/environments/environment';

@Injectable()
export class TrainingDashboardService {
  constructor(private _apiEService: EmployeeTrainingApiService,
    public _apiService: ApiService) {}


  //   deleteManager(id) {
  //     const url = AuditSettings.API.DELETE_AUIDT + `/${id}`;
  //     return this._auditapiService.callApi(url, 'delete', null);
  //   }

  getdashboardDepartments() {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardDepartments',
      'get',
      {}
    );
  }

  getTrainingModule(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'dashboardTrainingModule/' + date,
      'get',
      {}
    );
  }

  getTraining(date) {
    return this._apiService.callApi(
      environment.apiUrl + 'getDashboardTraining/' + date,
      'get',
      {}
    );
  }
}

