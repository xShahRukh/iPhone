import { Component, OnInit } from '@angular/core';
import { TrainingDashboardService } from './training-dashboard.service';
import * as _ from 'underscore';
import * as moment from 'moment';

declare let require: any;
const Highcharts = require('highcharts');
declare var $;
Highcharts.setOptions({
  // time: {
  //   timezone: 'Asia/Kolkata'
  // },

  global: {
    useUTC: false
  },
  colors: [
    '#379a24',
    // '#379af6',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8',
    '#c42525',
    '#8bbc21',
    '#da4398',
    '#bf7138',
    '#0d9398',
    '#7a36cd',
    '#6784f0'
  ],

  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});


@Component({
  selector: 'app-training-dashboard',
  templateUrl: './training-dashboard.component.html',
  styleUrls: ['./training-dashboard.component.css']
})

export class TrainingDashboardComponent implements OnInit {
  templatecount: any = [];
  dashboardcount: any = {};
  ncdata: any[];
  auditdata: any = [];
  todayDate: any;
  trainingdata: any = {};
  pass = [];
  deptdata: any = [];
  trainingmoduledata = [];
  gateexamdata: any = [];
  gatepassdata: any = [];
  audit_report_data: any = [];
  dept_list = [];
  ergono_list = [];

  displayDate: any = new Date();
  selectedDate1: any = new Date();
  selectedDate2: any = new Date();
  selectedDate3: any = new Date();
  selectedDate4: any = new Date();
  card_show_two: boolean;

  options3: Object;
  options4: Object;
  options5: Object;
  options9: Object;
  options10: Object;

  audit_details = false;
  training_details = false;
  ergonomics_graph = false;
  gatepass_details = false;
  loading: boolean;

  final_dept: any = [];
  final_totCount: any = [];
  final_pass: any = [];
  ergopiearray: any = [];
  dept_id = '1';
  selectedDept: Number = 0;
  monthPass: any;

  config = {
    monthFormat: 'YYYY-MM',
    allowMultiSelect: false,
    enableMonthSelector: true,
    format: 'DD-MM-YYYY',
    yearFormat: 'YYYY',
    showGoToCurrent: true,
    isMonthDisabledCallback: false,
    monthBtnFormat: 'MMM',
    // multipleYearsNavigateBy: 10,
    // showMultipleYearsNavigation: false,
    // min: moment(this.displayDate).format('YYYY-MM-dd'),
    max: moment(this.displayDate).format('YYYY-MM-dd')
  };
  getergonomic: any;

  constructor(public dashService: TrainingDashboardService) {}

  ngOnInit() {
    this.Open_card5();
    this.monthPass = new Date(moment(new Date()).format('YYYY/MM/DD'));
    console.log('month pass', this.monthPass)

  }

  onChange(value) {
    console.log(value);
    this.selectedDate2 = moment(this.monthPass).format('YYYY-MM');
    this.Open_card5();
  }

  Open_card5() {
    this.pass = [];
    this.final_dept = [];
    this.final_totCount = [];
    this.final_pass = [];

    this.loading = true;
    this.dashService.getdashboardDepartments().subscribe(data => {
      if (data.success) {
        this.deptdata = data.data;
      } else {
        this.deptdata = [];
      }
    });

    this.dashService
      .getTrainingModule(moment(this.selectedDate2).format('YYYY-MM'))
      // .getTrainingModule('2018-06')
      .subscribe(traingData => {
        if (traingData.success) {
          this.trainingdata = traingData.result;
        } else {
          this.trainingdata = [];
        }
      });

    this.dashService
      .getTraining(moment(this.selectedDate2).format('YYYY-MM'))
      // .getTrainingModule('2018-06')
      .subscribe(traingmodData => {
        this.loading = true;
        if (traingmodData.success) {
          this.trainingmoduledata = traingmodData.input;

          for (let t = 0; t < this.deptdata.length; t++) {
            const d1 = _.findWhere(this.trainingmoduledata, {
              short_name: this.deptdata[t].short_name
            });
            console.log('d1', d1);
            if (d1) {
              this.pass.push({
                short_name: this.deptdata[t].short_name,
                fullname: this.deptdata[t].fullname,
                totalcount: d1.totalCount,
                pass: d1.pass === undefined ? 0 : d1.pass
              });
            } else {
              this.pass.push({
                short_name: this.deptdata[t].short_name,
                fullname: this.deptdata[t].fullname,
                totalcount: 0,
                pass: 0
              });
            }
          }
          console.log(this.pass, 'finala passssss');
          this.final_dept = _.pluck(this.pass, 'fullname');
          this.final_totCount = _.pluck(this.pass, 'totalcount');
          this.final_pass = _.pluck(this.pass, 'pass');
          this.loading = false;
        } else {
          this.trainingmoduledata = [];
          this.pass = [];
          this.final_dept = [];
          this.final_totCount = [];
          this.final_pass = [];
          this.loading = false;
        }
        this.options9 = {
          chart: {
            type: 'column',
            inverted: true
          },

          title: {
            text: ''
          },

          xAxis: {
            categories: this.final_dept
          },

          yAxis: {
            allowDecimals: false,
            min: 0,
            title: {
              text: 'Number'
            }
          },

          credits: {
            enabled: false
          },

          // legend: {
          //   enabled: false
          // },

          exporting: {
            enabled: false
          },

          tooltip: {
            formatter: function() {
              return (
                '<b>' +
                this.x +
                '</b><br/>' +
                this.series.name +
                ': ' +
                this.y +
                '<br/>' +
                'Total: ' +
                this.point.stackTotal
              );
            }
          },

          plotOptions: {
            column: {
              stacking: 'normal'
            }
          },

          series: [
            {
              name: 'Total Count',
              data: this.final_totCount,
              stack: 'male'
            },
            {
              name: 'Pass',
              data: this.final_pass,
              stack: 'male'
            }
          ]
        };
      });

    // this.dashService.card_show = false;
    // this.dashService.card_show_two = true;
    // this.dashService.card_show_three = false;
    // this.dashService.card_show1 = false;
    // this.dashService.card_show2 = false;
    // this.dashService.card_show3 = false;
    // this.dashService.card_show4 = false;
    // this.dashService.card_show5 = false;
    // this.dashService.card_show6 = true;
    // this.dashService.card_show7 = false;
    // this.dashService.card_show8 = false;
    // this.dashService.card_show9 = false;
    // this.dashService.card_show10 = false;
    this.audit_details = false;
    this.training_details = true;
    this.ergonomics_graph = false;
    this.gatepass_details = false;
    window.scroll(0, 0)
    $('#auditpopup').modal('hide');
  }

}
