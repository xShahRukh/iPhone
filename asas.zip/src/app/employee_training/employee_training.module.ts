import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown/angular2-multiselect-dropdown';
// import { DataTableModule } from 'angular2-datatable';
import { DataTableModule } from 'angular-6-datatable';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';


import { ScheduleTrainingComponent } from './schedule_training/schedule_training.component';
// import { SharedsModule } from '../common/shareds.module';
import { EmployeeTrainingScheduleService } from './schedule_training/schedule_training.service';
import { SharedModule } from '../common/shareds.module';

import { routing } from './employee_training.routes';
import { EmployeeTrainingApiService } from './trainingApi.service';
import { QuizComponent } from './quiz/quiz.component';
import { QuizService } from './quiz/quizservice';
import { MyDatePickerModule } from 'mydatepicker';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import * as highcharts from 'highcharts';
import { CertificateComponent } from './quiz/certificate/certificate.component';
import { TrainingDashboardComponent } from './training-dashboard/training-dashboard.component';
import { TrainingReportsComponent } from './training-reports/training-reports.component';
import { TrainingReportsService } from './training-reports/training-reports.service'
import { TrainingDashboardService } from './training-dashboard/training-dashboard.service'
import { CalendarModule } from 'primeng/primeng';
import { NewTrainingReportsComponent } from './new-training-reports/new-training-reports.component';
import { TrainingTopMenuComponent } from './training-top-menu/training-top-menu.component';


declare var require;

export function highchartsFactory() {
  const hc = require('highcharts');
  const hcm = require('highcharts/highcharts-more');
  const exp = require('highcharts/modules/drilldown');
  const sg = require('highcharts/modules/solid-gauge');
  hcm(hc);
  exp(hc);
  sg(hc);
  return hc;
}

@NgModule({
  declarations: [
    ScheduleTrainingComponent,
    QuizComponent,
    CertificateComponent,
    TrainingDashboardComponent,
    TrainingReportsComponent,
    NewTrainingReportsComponent,
    TrainingTopMenuComponent
  ],
  imports: [
    CommonModule,
    // SharedsModule,
    routing,
    FormsModule,
    ReactiveFormsModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    // DataTableModule,
    DataTableModule,
    ChartModule,
    SharedModule,
    CalendarModule
  ],
  providers: [
    EmployeeTrainingScheduleService,
    EmployeeTrainingApiService,
    TrainingReportsService,
    TrainingDashboardService,
    QuizService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    }
  ]
})
export class EmployeeTrainingModule {}
