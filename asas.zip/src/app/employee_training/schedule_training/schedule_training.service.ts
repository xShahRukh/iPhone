import { Injectable } from '@angular/core';

import { EmployeeTrainingApiService } from '../trainingApi.service';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import { ApiService } from '../../common/services/api.service';

@Injectable()
export class EmployeeTrainingScheduleService {
  constructor(private _apiEService: EmployeeTrainingApiService,
    public _apiService: ApiService) {}

  get_dept() {
    const url = EmployeeTrainingSettings.API.GET_DEPT;
    return this._apiService.callApi(url, 'get', null);
  }

  training(values: any) {
    const url = EmployeeTrainingSettings.API.TRAINING;
    return this._apiService.callApi(url, 'FILE_UPLOAD', values);
  }

  getTrainingList() {
    const url = EmployeeTrainingSettings.API.TRAINING;
    return this._apiService.callApi(url, 'get', null);
  }
  editTraining(id) {
    const url = EmployeeTrainingSettings.API.TRAINING + `/${id}`;
    return this._apiService.callApi(url, 'get', null);
  }

  //   deleteManager(id) {
  //     const url = AuditSettings.API.DELETE_AUIDT + `/${id}`;
  //     return this._auditapiService.callApi(url, 'delete', null);
  //   }
}
