import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormArray, FormBuilder, Validators } from '@angular/forms';
import { EmployeeTrainingScheduleService } from './schedule_training.service';
import { EmployeeTrainingSettings } from '../employee_training.settings';
import * as _ from 'underscore';

@Component({
  selector: 'app-schedule_training',
  templateUrl: './schedule_training.component.html',
  styleUrls: ['./schedule_training.component.css']
})
export class ScheduleTrainingComponent implements OnInit {
  schueduleForm = false;
  public myForm: FormGroup;
  dropdownList = [];
  selectedItems = [];
  selectedDept = [];
  dropdownSettings = {};
  dept_list = [];
  deptSettings = {};
  images = '';
  trainingList = [];
  imagePath = EmployeeTrainingSettings.image_path;
  videoPath;
  editId = '';
  spinner = true;
  constructor(
    public router: Router,
    private _fb: FormBuilder,
    private _empTrainingService: EmployeeTrainingScheduleService
  ) {}

  async ngOnInit() {
    this.imagePath = EmployeeTrainingSettings.image_path;
    console.log('images', this.imagePath);
    this.getTrainingList();
    this.get_dept();
    this.dropdownList = [
      { id: 1, itemName: 'Employee' },
      { id: 2, itemName: 'Contractor' }
    ];
    this.selectedItems = [];
    this.selectedDept = [];
    this.dropdownSettings = {
      singleSelection: false,
      text: 'Select Applicable for',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class'
    };
    this.deptSettings = {
      singleSelection: false,
      text: 'Select Department',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class'
    };

    this.myForm = this._fb.group({
      training_name: ['', Validators.required],
      validity: ['30', Validators.required],
      status: ['1', Validators.required],
      pass_percent: ['', Validators.required],
      applicable_to: [[1], Validators.required],
      departments: [[1], Validators.required],
      questions: this._fb.array([this.initAddress()])
    });
  }
  get_dept() {
    this._empTrainingService.get_dept().subscribe(data => {
      // console.log('data', data);
      data.data.forEach(item => {
        this.dept_list.push({
          id: item.id,
          itemName: item.fullname
        });
      });
      // console.log(this.dept_list);
    });
  }

  onItemSelect(item: any) {
    console.log(item);
    console.log(this.selectedItems);
  }
  OnItemDeSelect(item: any) {
    // console.log(item);
    // console.log(this.selectedItems);
  }
  onSelectAll(items: any) {
    // console.log(items);
  }
  onDeSelectAll(items: any) {
    // console.log(items);
  }

  initAddress() {
    return this._fb.group({
      question_id: [''],
      question: ['', Validators.required],
      option1: ['', Validators.required],
      option2: ['', Validators.required],
      option3: ['', Validators.required],
      option4: ['', Validators.required],
      answer: ['', Validators.required]
    });
  }

  addAddress() {
    console.log('testsdjknklj');
    const control = <FormArray>this.myForm.controls['questions'];
    control.push(this.initAddress());
  }

  removeAddress(i: number) {
    const control = <FormArray>this.myForm.controls['questions'];
    control.removeAt(i);
  }

  showScheduleForm() {
    console.log('dds', this.myForm.controls['questions'].value.length);
    this.schueduleForm = true;
    this.initAddress();
  }

  //   video upload
  onFileChange(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.images = file;
      //   this.myForm.get('video').setValue(file);
    }
  }
  private prepareSave(): any {
    const input = new FormData();
    input.append('video', this.images);
    input.append('data', JSON.stringify(this.myForm.value));
    input.append('training_id', JSON.stringify(this.editId));
    // if (this.editId) {
    //   input.append('training_id', this.editId);
    // }
    console.log(this.images, this.myForm.value, this.editId)
    console.log('input', input)
    return input;
  }

  save() {
    console.log(
      'ds',
      this.myForm.controls['pass_percent'].value,
      <FormArray>this.myForm.controls['questions'].value.length
    );
    this.spinner = true;

    const formModel = this.prepareSave();
    console.log('formodal', formModel)
    this._empTrainingService.training(formModel).subscribe(
      data => {
        if (data.success) {
          this.spinner = false;

          this.getTrainingList();
          this.schueduleForm = false;
          this.editId = '';
          this.initAddress();
          this.back();
        } else {
          this.spinner = false;
        }
      },
      error => {
        this.spinner = false;
      }
    );
  }

  getTrainingList() {
    this.spinner = true;
    this.trainingList = [];
    this._empTrainingService.getTrainingList().subscribe(
      data => {
        if (data.success) {
          this.spinner = false;
          this.trainingList = data.data;
          console.log('ddsd', this.trainingList);
        } else {
          this.spinner = false;

          console.log('error');
        }
      },
      error => {
        this.spinner = false;
      }
    );
  }

  editTraining(id) {
    this.spinner = true;
    this.editId = id;
    this.schueduleForm = true;
    const deptArray = [];
    const applicabeArray = [];
    this._empTrainingService.editTraining(id).subscribe(
      data => {
        if (data.success) {
          this.spinner = false;
          this.videoPath = this.imagePath + data.data.video;
          this.images = data.data.video;

          // departments
          data.data.departments.forEach(dept => {
            const depts = _.filter(this.dept_list, function(num) {
              return num.id == dept.department_id;
            });
            console.log('det', depts);
            depts.forEach(item => {
              deptArray.push({
                id: item.id,
                itemName: item.itemName
              });
            });
            console.log('1', deptArray);
          });
          console.log('deptarray', deptArray);
          this.selectedDept = deptArray;

          // applicable to
          data.data.applicable_to.forEach(dept => {
            const appArray = _.filter(this.dropdownList, function(num) {
              return num.id == dept.id;
            });
            appArray.forEach(item => {
              applicabeArray.push({
                id: item.id,
                itemName: item.itemName
              });
            });
          });
          this.selectedItems = applicabeArray;
          this.myForm.patchValue({
            training_name: data.data.training_name,
            validity: data.data.validity,
            status: data.data.status,
            pass_percent: data.data.pass_percent
          });
          const arr = [];
          data.data.questions.forEach(item => {
            arr.push(
              this._fb.group({
                question_id: item.question_id,
                question: item.question,
                option1: item.option1,
                option2: item.option2,
                option3: item.option3,
                option4: item.option4,
                answer: item.answer
                // score_percent: item.score_percent
              })
            );
          });
          this.myForm.setControl('questions', this._fb.array(arr));
        } else {
          this.spinner = false;
        }
      },
      error => {
        this.spinner = false;
      }
    );
  }

  homePage() {
    this.router.navigate(['/dashboard']);
  }

  back() {
    console.log('dd', this.myForm.controls['questions'].value.length);
    this.schueduleForm = false;
    this.editId = '';
    this.selectedItems = [];
    this.selectedDept = [];
    this.dropdownSettings = {};
    this.myForm.setControl('questions', this._fb.array([this.initAddress()]));

    this.myForm.reset();
    this.myForm.controls['validity'].setValue('30');
    this.myForm.controls['status'].setValue('1');
    this.videoPath = '';
  }
}

