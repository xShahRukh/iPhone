import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  page_module: string;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private vcr: ViewContainerRef,
    public service: ApiService
  ) {}

  ngOnInit() {}
}
