import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { map } from 'rxjs/operators';
import { AppSettings } from '../../app.settings';

@Injectable()
export class ApiService {
  page = '';
  incideType = '';
  rolesArray: any = [];

  // Document Module
  selectedDoc: any;

  docobject: any = {};
  incidentObj: any = [];
  incidentAddFormCheck = false;
  Coordinator = false;
  headers = { headers: new Headers({ 'content-type': 'application/Json' }) };
  options = new RequestOptions();
  headerMenu = 1;

  constructor(private _http: Http) {
    this.getRolesFromSec();
  }

  getRolesFromSec() {
    if (sessionStorage.getItem('userid')) {
      this.getRoles1({ emp_id: sessionStorage.getItem('userid') }).subscribe(data => {
        console.log(data);
        // this.rolesArray.length = 0;
        this.rolesArray.splice(0, this.rolesArray.length - 1);
        this.rolesArray = data.data;
      });
    }
  }

  getlistoflocat() {
    const body = {};
    return this.callApi(AppSettings.API.GET_LOCATIONS, 'GET', body);
  }

  lowStockItemsCount() {
    const body = {};
    return this.callApi(AppSettings.API.LOW_STOCK_ITEMS_COUNT, 'GET', body);
  }

  getRoles1(body) {
    this.rolesArray = [];
    return this.callApi(AppSettings.API.GET_ROLES_LIST1, 'post', body);
  }

  // GET_ROLES_USERS_LIST
  getRolesUserslist(body) {
    return this.callApi(AppSettings.API.GET_ROLES_USERS_LIST, 'post', body);
  }

  getlistoflocats() {
    return this.callApi(AppSettings.API.GETLISTLOCATIONS, 'get', {});
  }
  getlistofpermits() {
    return this.callApi(AppSettings.API.GET_PERMITS_LIST, 'get', {});
  }

  codeToName(code) {
    let name = code
      .toLowerCase()
      .split('_')
      .join(' ');
    name = this.capital_letter(name);
    return name;
  }

  capital_letter(str) {
    str = str.split(' ');
    for (let i = 0, x = str.length; i < x; i++) {
      str[i] = str[i][0].toUpperCase() + str[i].substr(1);
    }
    return str.join(' ');
  }

  findIndexInData1(optionsArg) {
    // this.rolesArray = JSON.parse(sessionStorage.roles)
    const options = {
      data: JSON.parse(sessionStorage.roles), // roles array
      where1: optionsArg.where1, // parameter name1 -> module_name
      where2: optionsArg.where2, // parameter name2 -> role_name
      what1: optionsArg.what1, //  module_name -> value to check
      what2: optionsArg.what2 // role_name -> value to check
    };

    let result = -1;
    options.data.some(function (item, i) {
      // if (item[options.where1] === options.what1 && item[options.where2] === options.what2) {
      if (item[options.where1] === options.what1 && options.what2.includes(item[options.where2])) {
        result = i;
        return true;
      }
    });
    return result;
  }

  // Employee Dashboard
  employeeDashboard() {
    return this.callApi(AppSettings.API.EMPLOYEE_DASHBOARD, 'get', {});
  }

  callApi(url, method, body = null): Observable<any> {
    if (sessionStorage.getItem('token')) {
      this.token();
    }

    switch (method.toUpperCase()) {
      case 'LOGIN':
        return this._http.post(url, body).pipe(map((response: Response) => response.json()));
      case 'POST':
        return this._http
          .post(url, body, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'PATCH':
        return this._http
          .patch(url, body, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'DELETE':
        return this._http
          .delete(url, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'GET':
        return this._http.get(url, this.token()).pipe(map((response: Response) => response.json()));

      case 'FILE_UPLOAD':
        return this._http.post(url, body).pipe(map((response: Response) => response.json()));
    }
  }

  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
