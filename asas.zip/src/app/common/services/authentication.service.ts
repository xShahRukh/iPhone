import { Injectable } from '@angular/core';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { AppSettings } from '../../app.settings';
import { map } from 'rxjs/operators';
import { ApiService } from './api.service';

@Injectable()
export class AuthenticationService {
  public userLoggedIn = false;

  headers = new Headers({ 'Content-Type': 'application/json' });
  options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http, private _apiService: ApiService) { }

  // login api
  login(body) {
    return this.http
      .post(AppSettings.API.LOGIN, JSON.stringify(body), this.options)
      .pipe(
        map((response: Response) => {
          const data = response.json();
          console.log(data);
          if (!data.error) {
            if (data && data.token) {
              sessionStorage.setItem('token', data.token);
              sessionStorage.setItem('name', data.data.name);
              sessionStorage.setItem('email', data.data.email);
              sessionStorage.setItem('mobile', data.data.contact1);
              sessionStorage.setItem('userid', data.data.userid);
              sessionStorage.setItem('departmentId', data.data.department_id);
              sessionStorage.setItem('uid', data.data.uid);
              sessionStorage.setItem('designation', data.data.designation);
              sessionStorage.setItem('department', data.data.department);

              sessionStorage.setItem('roles', data.roles.toString());
              this._apiService
                .getRoles1({ emp_id: data.data.userid })
                .subscribe(datas => {
                  console.log(datas);
                  this._apiService.rolesArray = datas.data;
                });
            }
          }
          return data;
        })
      );
  }

  logout() {
    sessionStorage.removeItem('token');
  }
}
