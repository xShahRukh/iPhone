import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import * as _ from 'underscore';
declare var $;

@Component({
  selector: 'app-sidemenu',
  templateUrl: './sidemenu.component.html',
  styleUrls: ['./sidemenu.component.css']
})
export class SideMenuComponent implements OnInit {
  // page = this.service.page;
  pageType = '';
  role;
  Coordinator = false;
  pageNavValue = '';
  rolesData: any[];
  designation = sessionStorage.getItem('designation');
  constructor(
    public router: Router,
    public service: ApiService,
    public _route: ActivatedRoute,
    public _apiService: ApiService
  ) { }

  ngOnInit() {
    this.getRoles();
    this.pageType = this._route.snapshot.url[0].path;
    console.log(this.pageType, 'pageType', this._route.snapshot.url);
    if (this._route.snapshot.url[0].path !== 'incidentsview') {
      this._apiService.incideType = this.pageType;
    }

    if (
      this._route.snapshot.url[0].path === 'manager' &&
      this._route.snapshot.url[1].path === 'categoriesQuestions'
    ) {
      this.pageType = this._route.snapshot.url[1].path;
    } else if (
      this._route.snapshot.url[0].path === 'reports' &&
      this._route.snapshot.url[1].path === 'auditReports'
    ) {
      this.pageType = this._route.snapshot.url[1].path;
    }
    this.role = sessionStorage.getItem('role');
    this.getAllLocations();
    // $('body').toggleClass('nav-toggle');

    $(document).ready(function () {
      // Handle minimize left menu
      // $('.left-nav-toggle a').on('click', function (event) {
      //   event.preventDefault();
      //   $('body').toggleClass('nav-toggle');
      // });

      // $('.navigation .nav li').on('click', function () {
      //   $('body').addClass('nav-toggle');
      // });
    });
  }

  getRoles() {
    this.rolesData = [];
    this._apiService.getRoles1({ emp_id: sessionStorage.getItem('userid') }).subscribe(datas => {
      console.log(datas);
      if (!datas.success) {
        this._apiService.rolesArray = datas.data;
        this.rolesData = this._apiService.rolesArray;
        console.log(this.rolesData);
      }
    });
  }

  async getAllLocations() {
    this.Coordinator = false;
    await this._apiService.getlistoflocat().subscribe(async data => {
      if (!data.error) {
        const ListDisp = await _.filter(data.data, function (o) {
          return o.coordinator === sessionStorage.getItem('userid');
        });
        if (ListDisp.length) {
          this.Coordinator = true;
          this._apiService.Coordinator = true;
        }
      }
    });
  }

  getPageValue(value) {
    this.pageNavValue = value;
    // if (!this._apiService.incidentAddFormCheck) {
    //   $('#navigateConformation').modal('hide');
    this.router.navigate([this.pageNavValue]);

    // }
  }

  notInterested() {
    $('#navigateConformation').modal('hide');
    return;
  }

  wantToNavigate() {
    this._apiService.incidentAddFormCheck = false;
    this.router.navigate([this.pageNavValue]);
  }

  checkRole(role) {
    const tempRoles = _.pluck(this.rolesData, 'role_name');
    if (tempRoles.indexOf(role) > -1) {
      return true;
    } else {
      return false;
    }
  }

  auditReport() {
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/schedule']);
    }
    if (this.checkRole('Auditor')) {
      sessionStorage.setItem('auditRole', 'auditor');
      this.router.navigate(['/audit/auditor/dashboard']);
    }
  }

  trainingSchedule() {
    this.router.navigate(['/employee_training/schedule_training']);
  }

  categories() {
    this.pageType = 'categoriesQuestions';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/manager/categoriesQuestions']);
    }
  }

  audit_reports() {
    this.pageType = 'auditReports';
    if (this.checkRole('Audit Manager')) {
      sessionStorage.setItem('auditRole', 'manager');
      this.router.navigate(['/audit/reports/auditReports']);
    }
  }

  non_conformence() {
    this.router.navigate(['regular_audit/non-conformence']);
  }

  ergonomics(item) {
    if (item === 'templates') {
      this.router.navigate(['/ergonomicsModule/template']);
    } else if (item === 'assign') {
      this.router.navigate(['/ergonomicsModule/assignDept']);
    } else if (item === 'check') {
      this.router.navigate(['/ergonomicsModule/checkErgonomics']);
    } else if (item === 'reports') {
      this.router.navigate(['/ergonomicsModule/reports']);
    }
  }
}
