import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './header/header.component';
import { DataFilterPipe } from './data-filter.pipe';
import { DataTablesPipe } from './datatables.pipe';
import { TruncatePipe } from './truncate.pipe';
import { SearchPipe } from './search.pipe';
import { SideMenuComponent } from './sidemenu/sidemenu.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from '@angular/router';
// import { HttpModule } from '@angular/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TopMenuComponent } from './top-menu/top-menu.component';
import { TopNavComponent } from './top-nav/top-nav.component';
@NgModule({
  declarations: [
    HeaderComponent,
    SideMenuComponent,
    FooterComponent,
    DataFilterPipe,
    DataTablesPipe,
    TruncatePipe,
    SearchPipe,
    TopMenuComponent,
    TopNavComponent
  ],
  // imports: [CommonModule, RouterModule, HttpModule, FormsModule, ReactiveFormsModule],
  imports: [CommonModule, RouterModule, FormsModule, ReactiveFormsModule],
  exports: [
    HeaderComponent,
    SideMenuComponent,
    FooterComponent,
    DataFilterPipe,
    DataTablesPipe,
    TruncatePipe,
    SearchPipe,
    TopMenuComponent,
    TopNavComponent
  ]
})
export class SharedModule { }
