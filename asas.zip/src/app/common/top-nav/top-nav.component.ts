import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import * as _ from 'underscore';
declare var $;
@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.styl']
})
export class TopNavComponent implements OnInit {
  pageType = '';
  constructor(public router: Router,
    public service: ApiService,
    public _route: ActivatedRoute,
    public _apiService: ApiService) { }

  ngOnInit() {
    this.pageType = this._route.snapshot.url[0].path;
    console.log(this.pageType, 'pageType', this._route.snapshot.url);
  }

}
