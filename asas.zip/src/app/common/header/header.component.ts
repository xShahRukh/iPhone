import { HeaderService } from './header.service';
import {
  Component,
  OnInit,
  ViewContainerRef,
  Output,
  EventEmitter
} from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../services/api.service';
import { GenericValidator } from '../generic-validator';
import { environment } from '../../../environments/environment';

declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;
  timer;
  headername: any;
  designation: string;
  assignedroles: any = [];
  role = '';
  name = '';
  PersonalData = {};
  j = 1;
  headerMenu: any = 0;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    public service: ApiService,
    public _headearService: HeaderService,
    public vcr: ViewContainerRef,
    public fb: FormBuilder,
    public _apiservice: ApiService
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.PersonalData['name'] = sessionStorage.getItem('name');
    this.PersonalData['email'] = sessionStorage.getItem('email');
    this.PersonalData['mobile'] = sessionStorage.getItem('mobile');
    this.PersonalData['userid'] = sessionStorage.getItem('userid');
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);

    this.role = sessionStorage.getItem('role');
    this.name = sessionStorage.getItem('name');


    const body = document.getElementsByTagName('html')[0];
    $('html').removeClass();
    $('html').addClass('theme-orange');


    setTimeout(() => {
      $(document).ready(function () {
        $('[data-toggle="tooltip"]').tooltip();
      });
    }, 1000);

  }

  logout() {
    this.router.navigate(['/login']);
    sessionStorage.clear();
    localStorage.clear();
  }

  sidebarToggle() {
    //  this.j = 1
    // console.log(this.j);
    const body = document.getElementsByTagName('body')[0];
    if (this._apiservice.headerMenu === 1) {
      console.log('nav opened');
      this._apiservice.headerMenu = 0;
      body.classList.remove('nav-toggle');
    } else {
      console.log('nav closed');
      this._apiservice.headerMenu = 1;
      body.classList.add('nav-toggle');
    }

  }
}
