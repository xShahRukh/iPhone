import { environment } from '../../environments/environment';

export class HSEHrSettings {
  public static API = {
    GET_DEPARTMENT_LIST: environment.apiUrl + 'emp_mgmt/dept/getdept_list/',
    ADD_DEPARTMENT_LIST: environment.apiUrl + 'emp_mgmt/health/common_aDD/',
    EDIT_DEPARTMENT_LIST: environment.apiUrl + 'emp_mgmt/health/common_Update/',
    GET_ALLERGIE_LIST:
      environment.apiUrl + 'emp_mgmt/health/get_all_health_issue/',
    // ADD_EMPLOYEE: environment.apiUrl + 'emp_mgmt/emp/add_Employee/',
    ADD_EMPLOYEE: environment.apiUrl + 'emp_mgmt/emp/add_Employee1/',
    GET_DESIGNATIONS: environment.apiUrl + 'emp_mgmt/dept/get_designation/',
    // GET_EMPLOYEES_LIST: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',
    GET_EMPLOYEES_LIST: environment.apiUrl + 'emp_mgmt/emp/get_All_Employees/',
    UPDATE_EMPLOYEE: environment.apiUrl + 'emp_mgmt/emp/update_Employee/',
    GET_MODULES_LIST: environment.apiUrl + 'roles/get/all/modules/',
    GET_ROLES_LIST: environment.apiUrl + 'roles/get/all/roles/',
    ADD_UPDATE_MODULES: environment.apiUrl + 'roles/add/update/module/',
    ADD_UPDATE_ROLES: environment.apiUrl + 'roles/add/update/role/',
    EMPLOYEES_EXCEL: environment.apiUrl + 'emp_mgmt/dept/emp_excel_upload/',
    GET_MODULES_ROLES_LIST: environment.apiUrl + 'roles/get/all/roles/modules/',
    ADD_UPDATE_MODULES_ROLES:
      environment.apiUrl + 'roles/add/update/roles/modules/',
    GET_ROLES_LIST_STATUS_1:
      environment.apiUrl + 'roles/get/all/roles/status/1',
    GET_MODULES_LIST_STATUS_1:
      environment.apiUrl + 'roles/get/all/modules/status/1',
    GET__ROLES_MODULES_LIST_STATUS_1:
      environment.apiUrl + 'roles/get/all/roles/modules/status/1',
    GET_EMP_ROLE_PRESENT_BY_ID:
      environment.apiUrl + 'roles/get/all/roles/employee/present',
    GET_EMP_ROLE_FUTURE_BY_ID:
      environment.apiUrl + 'roles/get/all/roles/employee/futher',
    LINK_ROLES_EMP_BY_PROCESS:
      environment.apiUrl + 'roles/assign/all/roles/employees/by/process',
    ADD_NEW_ROLE_EMP: environment.apiUrl + 'roles/assign/all/roles/employees',
    GET_VENDERDET: environment.apiUrl + 'vender/getVenderDet',
    EMPLOYEES_EXCEL_UPDATE:
      environment.apiUrl + 'emp_mgmt/dept/emp_excel_upload_update/',
    ASSIGNED_ROLES_EMPLOYEES: environment.apiUrl + 'roles/get/list/assignRoles'
  };
}
