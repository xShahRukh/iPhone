import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

// Third Party Plugins
import { ModalModule } from 'ngx-modal';
import { CalendarModule } from 'primeng/primeng';
import { MyDatePickerModule } from 'mydatepicker';
import { CustomFormsModule } from 'ng2-validation';
import { EditorModule } from 'primeng/editor';
import { CKEditorModule } from 'ng2-ckeditor';
import { AutoCompleteModule } from 'primeng/primeng';
import { DataTableModule } from 'angular-6-datatable';
import { ToastrModule } from 'ng6-toastr-notifications';

// common Services
import { SharedModule } from '../common/shareds.module';
import { ApiService } from '../common/services/api.service';
import { HseHrDashboardComponent } from './hse-hr-dashboard/hse-hr-dashboard.component';
import { hrRouting } from './hse_hr.routing';
import { ModulesComponent } from './modules/modules.component';
import { RolesComponent } from './roles/roles.component';
import { HrLinkModuleRoleComponent } from './hr-link-module-role/hr-link-module-role.component';
import { HrLinkEmpRoleComponent } from './hr-link-emp-role/hr-link-emp-role.component';
import { ModulesService } from './modules/modules.service';
import { HrAssignedrolesViewComponent } from './hr-assignedroles-view/hr-assignedroles-view.component';
import { UploadService } from '../common/services/upload.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';

@NgModule({
  declarations: [
    HseHrDashboardComponent,
    ModulesComponent,
    RolesComponent,
    HrLinkModuleRoleComponent,
    HrLinkEmpRoleComponent,
    HrAssignedrolesViewComponent
  ],
  imports: [
    CommonModule,
    hrRouting,
    FormsModule,
    EditorModule,
    CKEditorModule,
    ReactiveFormsModule,
    CustomFormsModule,
    DataTableModule,
    AutoCompleteModule,
    ModalModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    CKEditorModule,
    CalendarModule,
    EditorModule,
    SharedModule,
    ToastrModule.forRoot()
  ],

  providers: [ApiService, ModulesService, UploadService]
})
export class HseHrModule {}
