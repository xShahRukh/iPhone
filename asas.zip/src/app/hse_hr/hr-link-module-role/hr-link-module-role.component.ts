import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { ModulesService } from '../modules/modules.service';

@Component({
  selector: 'app-hr-link-module-role',
  templateUrl: './hr-link-module-role.component.html',
  styleUrls: ['./hr-link-module-role.component.css']
})
export class HrLinkModuleRoleComponent implements OnInit {
  ModulesList: any;
  RolesList: any;
  modulesRolesList: any[];
  loading: Boolean = true;
  dataItem: any = {
    id: null
  };
  AddRoleModuleForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _moduleServices: ModulesService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      module_name: {
        required: 'Module Name is required'
      },
      role_name: {
        required: 'Role Name is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const module_name = new FormControl({ value: '', disabled: false }, [
      Validators.required
    ]);
    const role_name = new FormControl({ value: '', disabled: false }, [
      Validators.required
    ]);
    const status = new FormControl({ value: 1, disabled: false }, [
      Validators.required
    ]);

    this.AddRoleModuleForm = this.fb.group({
      module_name: module_name,
      role_name: role_name,
      status: status
    });

    this.getModulesRolesList();
    this.getRolesListbystatus();
    this.getModulesListbystatus();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AddRoleModuleForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
      );
      Observable.arguments
        .merge(this.AddRoleModuleForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(
            this.AddRoleModuleForm
          );
        });
    }
  }

  getRolesListbystatus() {
    this._moduleServices.getRolesListbystatus().subscribe(data => {
      console.log('Roles list with status 1', data);
      if (!data.error) {
        this.RolesList = data.data;
        this.loading = false;
      } else {
        this.RolesList = [];
        this.loading = false;
      }
    });
  }

  getModulesListbystatus() {
    this._moduleServices.getModulesListbystatus().subscribe(data => {
      console.log('Modules list with status 1', data);
      if (!data.error) {
        this.ModulesList = data.data;
        this.loading = false;
      } else {
        this.ModulesList = [];
        this.loading = false;
      }
    });
  }

  getModulesRolesList() {
    this._moduleServices.getModulesRolesList().subscribe(data => {
      console.log('Roles & Modules list', data);
      if (!data.error) {
        this.modulesRolesList = data.data;
        this.loading = false;
      } else {
        this.modulesRolesList = [];
        this.loading = false;
      }
    });
  }

  addNewRoleModule(type) {
    console.log('Modules Data', this.AddRoleModuleForm.value);
    const body = {
      roleid: this.AddRoleModuleForm.controls['role_name'].value.toString(),
      module: this.AddRoleModuleForm.controls['module_name'].value.toString(),
      status: this.AddRoleModuleForm.controls['status'].value,
      rid: this.dataItem.id
    };
    this._moduleServices.addeditforRolesModules(body).subscribe(addData => {
      console.log(addData);
      if (!addData.error) {
        if (type === 'add') {
          this.toastr.successToastr('Module linked to role added successfully');
        } else {
          this.toastr.successToastr(
            'Module linked to role updated successfully'
          );
        }
        this.AddRoleModuleForm.patchValue([
          {
            role_name: '',
            module_name: '',
            status: 1
          }
        ]);
        this.dataItem = {
          id: null
        };
        this.getModulesRolesList();
        this.getModulesListbystatus();
        this.getRolesListbystatus();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editModule(item) {
    console.log('From List', item);
    this.AddRoleModuleForm.patchValue({
      role_name: item.roleid,
      module_name: item.module,
      status: item.status
    });
    this.dataItem.id = item.rid.toString();
  }

  resetForm() {
    this.AddRoleModuleForm.reset();
    this.AddRoleModuleForm.patchValue({
      status: '1'
    });
  }
}
