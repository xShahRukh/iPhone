import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ModulesComponent } from './modules/modules.component';
import { RolesComponent } from './roles/roles.component';
import { HrLinkModuleRoleComponent } from './hr-link-module-role/hr-link-module-role.component';
import { HrLinkEmpRoleComponent } from './hr-link-emp-role/hr-link-emp-role.component';
import { HrAssignedrolesViewComponent } from './hr-assignedroles-view/hr-assignedroles-view.component';
import { HseHrDashboardComponent } from './hse-hr-dashboard/hse-hr-dashboard.component';

const hrroutes: Routes = [
  { path: 'hrDashboard', component: HseHrDashboardComponent },
  { path: 'hrAddModules', component: ModulesComponent },
  { path: 'hrAddRoles', component: RolesComponent },
  { path: 'hrLinkModulesRoles', component: HrLinkModuleRoleComponent },
  { path: 'hrLinkEmpRoles', component: HrLinkEmpRoleComponent },
  { path: 'HrAssignedrolesView', component: HrAssignedrolesViewComponent },

  { path: '', redirectTo: 'hrDashboard', pathMatch: 'full' },
  { path: '**', redirectTo: 'hrDashboard', pathMatch: 'full' }
];
export const hrRouting: ModuleWithProviders = RouterModule.forChild(hrroutes);
