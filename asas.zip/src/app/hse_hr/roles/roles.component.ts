import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { ModulesService } from '../modules/modules.service';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  styleUrls: ['./roles.component.css']
})
export class RolesComponent implements OnInit {
  RolesList: any[];
  loading: Boolean = true;
  dataItem: any = {
    id: null
  };
  AddRoleForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _moduleServices: ModulesService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    // 
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      role_name: {
        required: 'Name is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const role_name = new FormControl({ value: '', disabled: false }, [
      Validators.required
    ]);
    const status = new FormControl({ value: '1', disabled: false }, [
      Validators.required
    ]);

    this.AddRoleForm = this.fb.group({
      role_name: role_name,
      status: status
    });

    this.getRolesList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AddRoleForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
      );
      Observable.arguments
        .merge(this.AddRoleForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(
            this.AddRoleForm
          );
        });
    }
  }

  getRolesList() {
    this._moduleServices.getRolesList().subscribe(data => {
      console.log('Modules list', data);
      if (!data.error) {
        this.RolesList = data.data;
        this.loading = false;
      } else {
        this.RolesList = [];
        this.loading = false;
      }
    });
  }

  addNewRole() {
    console.log('Roles Data', this.AddRoleForm.value);
    const body = {
      role_name: this.AddRoleForm.controls['role_name'].value,
      status: this.AddRoleForm.controls['status'].value,
      rol_id: this.dataItem.id
    };
    this._moduleServices.addeditforRoles(body).subscribe(addData => {
      console.log(addData);
      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');
        this.AddRoleForm.reset();
        this.getRolesList();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editRole(item) {
    console.log('From List', item);
    this.AddRoleForm.patchValue({
      role_name: item.role_name,
      status: item.status
    });
    this.dataItem.id = item.rol_id;
  }

  resetForm() {
    this.AddRoleForm.reset();
    this.AddRoleForm.patchValue({
      status: '1'
    });
  }
}
