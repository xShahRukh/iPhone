import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
declare var jquery: any;
declare var $;
@Component({
  selector: 'app-hse-hr-dashboard',
  templateUrl: './hse-hr-dashboard.component.html',
  styleUrls: ['./hse-hr-dashboard.component.css']
})
export class HseHrDashboardComponent implements OnInit {
  constructor(
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    private router: Router
  ) {
    //
  }

  ngOnInit() {}

  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
}
