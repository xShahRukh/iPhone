import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { GenericValidator } from '../../common/generic-validator';
import { Observable } from 'rxjs/Observable';
import { EmpDepartmentComponent } from 'src/app/employee/department/department.component';
import { DepartmentService } from 'src/app/employee/department/department.service';

@Component({
  selector: 'app-hr-assignedroles-view',
  templateUrl: './hr-assignedroles-view.component.html',
  styleUrls: ['./hr-assignedroles-view.component.css']
})
export class HrAssignedrolesViewComponent implements OnInit {
  loading: Boolean = true;
  assignedroles: any[];
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _addDeptServices: DepartmentService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
  }

  ngOnInit() {
    this.getAssignedrolesList();
  }

  getAssignedrolesList() {
    this._addDeptServices.getAssignesroles().subscribe(data => {
      if (!data.error) {
        this.assignedroles = data.data;
        this.loading = false;
      } else {
        this.assignedroles = [];
        this.loading = false;
      }
      console.log('Assigned roles', this.assignedroles);
    });
  }
}
