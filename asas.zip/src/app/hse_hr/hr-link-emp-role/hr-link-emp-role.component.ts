import { IMyDpOptions } from 'mydatepicker';
import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { ModulesService } from '../modules/modules.service';

import * as moment from 'moment';

@Component({
  selector: 'app-hr-link-emp-role',
  templateUrl: './hr-link-emp-role.component.html',
  styleUrls: ['./hr-link-emp-role.component.css']
})
export class HrLinkEmpRoleComponent implements OnInit {
  disaply_name1: any;
  upto1: any = new Object();
  change_date1: any = new Object();
  ModuleRolesList: any[];
  EmployeeList: any[];
  employedata: any;
  roledata: any;
  id1: any = {};
  process = '';
  selectprocess: any;
  EmpList: any = [];
  EmployeesList: any[];
  ModulesRolesList: any[];
  FutureRolesList: any[];
  PresentRolesList: any[];
  loading: Boolean = true;
  loading1: Boolean = true;
  public view = true;
  public add: boolean;
  public edit: boolean;
  dataArray: any = [];
  EditedRolesEmployeesList = [];

  public filterQuery = '';
  public rowsOnPage = 10;
  public sortBy = '';
  public sortOrder = 'asc';
  public filterQuery1 = '';
  public rowsOnPage1 = 10;
  public sortBy1 = '';
  public sortOrder1 = 'asc';
  public filterQuery2 = '';
  public rowsOnPage2 = 10;
  public sortBy2 = '';
  public sortOrder2 = 'asc';
  public filterQuery3 = '';
  public rowsOnPage3 = 10;
  public sortBy3 = '';
  public sortOrder3 = 'asc';
  public filterQuery4 = '';
  public rowsOnPage4 = 10;
  public sortBy4 = '';
  public sortOrder4 = 'asc';
  public filterQuery5 = '';
  public rowsOnPage5 = 10;
  public sortBy5 = '';
  public sortOrder5 = 'asc';
  calledParamaters = {};

  constructor(
    private router: Router,
    public _apiService: ApiService,
    public _moduleServices: ModulesService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    //
  }

  public myDatePickerOptions1: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd', // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  public myDatePickerOptions2: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd',
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };

  ngOnInit() {
    this.getRolesModulesListbystatus();
    this.getEmployeesList();
  }

  getRolesModulesListbystatus() {
    this._moduleServices.getRolesModulesListbystatus().subscribe(data => {
      if (!data.error) {
        this.ModulesRolesList = data.data;
        for (let i = 0; i < this.ModulesRolesList.length; i++) {
          this.ModulesRolesList[i].checked = 0;
        }
        this.loading = false;
      } else {
        this.ModulesRolesList = [];
        this.loading = false;
      }
      console.log('Modules & Roles list with status 1', this.ModulesRolesList);
    });
  }

  getEmployeesList() {
    this._moduleServices.getEmployeesList().subscribe(data => {
      if (data.error) {
        this.EmployeesList = data.data;
        for (let e = 0; e < this.EmployeesList.length; e++) {
          this.EmployeesList[e].checked = 0;
        }
        this.loading1 = false;
      } else {
        this.EmployeesList = [];
        this.loading1 = false;
      }
      console.log('Employees List', this.EmployeesList);
    });
  }

  addNewRoleEmp() {
    const body = {
      dataArray: JSON.stringify(this.dataArray).toString()
    };
    this._moduleServices.addNewRoleEmp(body).subscribe(addData => {
      console.log(addData);
      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');

        this.getRolesModulesListbystatus();
        this.getEmployeesList();
        this.dataArray = [];
        this.process = '';
        this.selectprocess = '';
        this.view = true;
        this.edit = false;
        this.add = false;
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  checkboxaddrole(event, id, index, process) {
    console.log(
      'add form',
      event.target.checked,
      id,
      index,
      process,
      this.EmpList.length
    );
    this.ModulesRolesList[index].checked = 1;
    if (event.target.checked === true) {
      this.dataArray.push({
        urid: null,
        emp_id: id.emp_id,
        module_name: this.roledata.module_name,
        role: this.roledata.rid,
        role_name: this.roledata.role_name,
        display_name: '',
        change_date: null,
        upto: null
      });
    } else {
      for (let jk = 0; jk < this.dataArray.length; jk++) {
        if (this.dataArray[jk].emp_id === id.emp_id) {
          this.dataArray.splice(jk, 1);
        }
      }
    }
    console.log('selected Roles List', this.dataArray);
  }

  checkboxaddemp(event, id, index, process) {
    console.log(
      'add form',
      event.target.checked,
      id,
      index,
      process,
      this.EmpList.length
    );
    this.EmployeesList[index].checked = 1;
    if (event.target.checked === true) {
      this.dataArray.push({
        urid: null,
        emp_id: this.employedata.emp_id,
        module_name: id.module_name,
        role: id.rid,
        role_name: id.role_name,
        display_name: '',
        change_date: null,
        upto: null
      });
    } else {
      for (let jk = 0; jk < this.dataArray.length; jk++) {
        if (this.dataArray[jk].role === id.roleid) {
          this.dataArray.splice(jk, 1);
        }
      }
    }
    console.log('Selected Employee List', this.EmpList);
  }

  openadd() {
    this.add = true;
    this.view = false;
    this.edit = false;
  }

  closeadd() {
    this.add = true;
    this.view = false;
    this.edit = false;
    this.process = '';
    this.selectprocess = '';
    this.dataArray = [];
  }

  module(data1) {
    console.log(data1, 'update test');

    this.id1 = data1;
    // this.change_date1 = data1.change_date;
    // this.upto1 = data1.upto;
    this.disaply_name1 = data1.display_name;

    this.change_date1 = { jsdate: new Date(data1.dispchange_date) };
    this.id1['change_date'] = { jsdate: new Date(data1.dispchange_date) };

    if (data1.upto != null) {
      this.upto1 = { jsdate: new Date(data1.dispupto) };
      this.id1['upto'] = { jsdate: new Date(data1.dispupto) };
      this.onDateChanged({
        date: {
          year: new Date(data1.dispchange_date).getFullYear(),
          month: new Date(data1.dispchange_date).getMonth() + 1,
          day: new Date(data1.dispchange_date).getDate()
        }
      });
    } else {
      this.upto1 = null;
    }
  }

  submitediteddata() {
    this.id1.change_date = this.change_date1;
    this.id1.display_name = this.disaply_name1;
    if (this.upto1 != null) {
      this.id1.upto = this.upto1.formatted;
    } else {
      this.id1.upto = null;
    }
    console.log('Modules Data', this.id1);
    this.dataArray.push({
      urid: this.id1.urid,
      emp_id: this.id1.emp_id,
      role: this.id1.role,
      display_name: this.id1.display_name,
      change_date: this.id1.change_date
        ? moment(this.id1.change_date.jsdate).format('YYYY-MM-DD')
        : moment().format('YYYY-MM-DD'),
      upto: this.upto1 ? moment(this.upto1.jsdate).format('YYYY-MM-DD') : null
    });
    const body = {
      dataArray: JSON.stringify(this.dataArray).toString()
    };
    console.log(this.id1);

    this._moduleServices.addNewRoleEmp(body).subscribe(addData => {
      console.log(addData);
      if (!addData.error) {
        // success toaster
        this.toastr.successToastr(addData.message, 'Success!');
        this.change_date1 = '';
        this.upto1 = null;
        this.disaply_name1 = '';
        this.id1 = {};
        this.dataArray = [];
        this.openedit(
          this.calledParamaters['item'],
          this.calledParamaters['process'],
          this.calledParamaters['funct']
        );
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  closeedit(item) {
    this.add = false;
    this.view = true;
    this.edit = false;
  }

  selectionprocess(event) {
    // console.log(event.target.value, this.selectprocess);
    if (event === 1) {
      this.process = 'byrole';
      this.dataArray = [];
      this._moduleServices.getRolesModulesListbystatus().subscribe(data => {
        if (!data.error) {
          this.ModuleRolesList = data.data;
          for (let i = 0; i < this.ModuleRolesList.length; i++) {
            this.ModuleRolesList[i].checked = 0;
          }
          this.EmployeeList = [];
        } else {
          this.ModuleRolesList = [];
        }
        console.log('Modules & Roles list with status 1', this.ModuleRolesList);
      });
    } else {
      this.process = 'byemp';
      this.dataArray = [];
      this._moduleServices.getEmployeesList().subscribe(data => {
        if (data.error) {
          this.EmployeeList = data.data;
          for (let e = 0; e < this.EmployeeList.length; e++) {
            this.EmployeeList[e].checked = 0;
          }
          this.ModuleRolesList = [];
        } else {
          this.EmployeeList = [];
        }
        console.log('Employees List', this.EmployeesList);
      });
    }
  }

  processrole(data) {
    console.log(data);
    this.roledata = data;
    this.id1 = data.rid;
    this.dataArray = [];
    const body = {
      id: data.rid.toString(),
      process_type: this.process, // byrole, byemp
      function_type: 'add' // add, update
    };
    this._moduleServices.linkrolesempbyprocess(body).subscribe(Data => {
      console.log(Data);
      if (!Data.error) {
        console.log(Data.data);
        this.EmployeeList = Data.data;
        for (let e = 0; e < this.EmployeeList.length; e++) {
          this.EmployeeList[e].checked = 0;
        }
      } else {
        this.EmployeeList = [];
      }
    });
  }

  processemployee(data) {
    console.log(data);
    this.id1 = data.emp_id;
    this.dataArray = [];
    this.employedata = data;
    const body = {
      id: data.emp_id.toString(),
      process_type: this.process, // byrole, byemp
      function_type: 'add' // add, update
    };
    this._moduleServices.linkrolesempbyprocess(body).subscribe(Data => {
      console.log(Data);
      if (!Data.error) {
        this.ModuleRolesList = Data.data;
        for (let i = 0; i < this.ModuleRolesList.length; i++) {
          this.ModuleRolesList[i].checked = 0;
        }
      } else {
        this.ModuleRolesList = [];
      }
    });
  }

  selecteddate(event, item, index) {
    console.log('date', event);
    for (let dd = 0; dd < this.dataArray.length; dd++) {
      this.dataArray[index].change_date = event.formatted;
    }
  }

  selecteddate2(event, item, index) {
    console.log('date', event);
    for (let dd = 0; dd < this.dataArray.length; dd++) {
      this.dataArray[index].upto = event.formatted;
    }
    console.log(this.dataArray);
  }

  displayname(event, item, index) {
    console.log('Display Name', event.target.value);
    for (let dd = 0; dd < this.dataArray.length; dd++) {
      this.dataArray[index].display_name = event.target.value;
    }
  }

  // For view
  openedit(item, process, funct) {
    console.log('for view to dispay how many assigned', item, process, funct);
    this.calledParamaters = {
      item: item,
      process: process,
      funct: funct
    };
    this.add = false;
    this.view = false;
    this.edit = true;
    this.roledata = item;
    const body = {
      process_type: process, // byrole, byemp
      function_type: funct // add, update
    };
    if (process === 'byrole') {
      body['id'] = item.rid.toString();
    } else {
      body['id'] = item.emp_id;
    }
    this._moduleServices.linkrolesempbyprocess(body).subscribe(Data => {
      console.log(Data);
      if (!Data.error) {
        this.EditedRolesEmployeesList = Data.data;
        Data.data.forEach(element => {
          element['dispchange_date'] = element.change_date
            ? moment(element.change_date).format('YYYY MMM DD')
            : '-';
          element['dispupto'] = element.upto
            ? moment(element.upto).format('YYYY MMM DD')
            : '-';
        });
      } else {
        this.EditedRolesEmployeesList = [];
      }
      console.log(this.EditedRolesEmployeesList);
    });
  }

  onDateChanged(event) {
    console.log(event);
    this.myDatePickerOptions2 = {
      dateFormat: 'yyyy-mm-dd', // dd-mmm-yyyy
      editableDateField: false,
      showTodayBtn: true,
      sunHighlight: true,
      satHighlight: false,
      markCurrentDay: true,
      markCurrentMonth: true,
      markCurrentYear: true,
      inline: false,
      height: '32px',
      width: '100%',
      componentDisabled: false,
      showClearDateBtn: true,
      openSelectorOnInputClick: true,
      disableUntil: event.date
    };
  }
}
