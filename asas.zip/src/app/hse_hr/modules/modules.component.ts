import { Component, ElementRef, OnInit, ViewChildren, ViewContainerRef } from '@angular/core';
import { FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Observable } from 'rxjs/Observable';
import { GenericValidator } from '../../common/generic-validator';
import { ApiService } from '../../common/services/api.service';
import { ModulesService } from './modules.service';

@Component({
  selector: 'app-modules',
  templateUrl: './modules.component.html',
  styleUrls: ['./modules.component.css']
})
export class ModulesComponent implements OnInit {
  modulesList: any[];
  loading: Boolean = true;
  dataItem: any = {
    id: null
  };
  AddModuleForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public _moduleServices: ModulesService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      module_name: {
        required: 'Name is required'
      },
      module_code: {
        required: 'Code is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const module_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const module_code = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const status = new FormControl({ value: '1', disabled: false }, [Validators.required]);

    this.AddModuleForm = this.fb.group({
      module_name: module_name,
      module_code: module_code,
      status: status
    });

    this.getModulesList();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  ngAfterViewInit(): void {
    if (this.AddModuleForm) {
      const controlBlurs: Observable<any>[] = this.formInputElements.map(
        (formControl: ElementRef) =>
          Observable.arguments.fromEvent(formControl.nativeElement, 'blur')
      );
      Observable.arguments
        .merge(this.AddModuleForm.valueChanges, ...controlBlurs)
        .debounceTime(800)
        .subscribe(value => {
          this.displayMessage = this.genericValidator.processMessages(this.AddModuleForm);
        });
    }
  }

  getModulesList() {
    this._moduleServices.getModulesList().subscribe(data => {
      if (!data.error) {
        this.modulesList = data.data;
        this.loading = false;
      } else {
        this.modulesList = [];
        this.loading = false;
      }
    });
  }

  addNewModule() {
    if (
      !this.AddModuleForm.controls['module_code'].value.trim() ||
      !this.AddModuleForm.controls['module_name'].value.trim()
    ) {
      return this.toastr.warningToastr('Please Select correct data');
    }
    const body = {
      short_code: this.AddModuleForm.controls['module_code'].value.trim(),
      module_name: this.AddModuleForm.controls['module_name'].value.trim(),
      status: this.AddModuleForm.controls['status'].value,
      md_id: this.dataItem.id
    };
    this._moduleServices.addeditforModules(body).subscribe(addData => {
      if (!addData.error) {
        // success toaster
        if (this.dataItem.id) {
          this.toastr.successToastr('Module created successfully', 'Success!');
        } else {
          this.toastr.successToastr('Module updated successfully', 'Success!');
        }
        this.AddModuleForm.reset();
        this.getModulesList();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editModule(item) {
    this.AddModuleForm.patchValue({
      module_code: item.short_code,
      module_name: item.module_name,
      status: item.status
    });
    this.dataItem.id = item.md_id;
  }

  resetForm() {
    this.AddModuleForm.reset();
    this.AddModuleForm.patchValue({
      status: '1'
    });
  }
}
