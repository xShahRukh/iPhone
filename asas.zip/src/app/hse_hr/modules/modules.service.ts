import { Injectable } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { HSEHrSettings } from '../hse_hr.settings';

@Injectable()
export class ModulesService {
  constructor(private _apiService: ApiService) {}
  // ADD_UPDATE_ROLES
  addeditforRoles(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.ADD_UPDATE_ROLES,
      'post',
      body
    );
  }

  // ADD_UPDATE_MODULES
  addeditforModules(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.ADD_UPDATE_MODULES,
      'post',
      body
    );
  }

  // GET_MODULES_LIST
  getModulesList() {
    const body = {};
    return this._apiService.callApi(
      HSEHrSettings.API.GET_MODULES_LIST,
      'get',
      body
    );
  }

  // GET_ROLES_LIST
  getRolesList() {
    const body = {};
    return this._apiService.callApi(
      HSEHrSettings.API.GET_ROLES_LIST,
      'get',
      body
    );
  }

  // GET_ROLES_LIST_STATUS_1
  getRolesListbystatus() {
    return this._apiService.callApi(
      HSEHrSettings.API.GET_ROLES_LIST_STATUS_1,
      'get',
      {}
    );
  }

  // GET_MODULES_LIST_STATUS_1
  getModulesListbystatus() {
    return this._apiService.callApi(
      HSEHrSettings.API.GET_MODULES_LIST_STATUS_1,
      'get',
      {}
    );
  }

  // GET__ROLES_MODULES_LIST_STATUS_1
  getRolesModulesListbystatus() {
    return this._apiService.callApi(
      HSEHrSettings.API.GET__ROLES_MODULES_LIST_STATUS_1,
      'get',
      {}
    );
  }

  // GET_MODULES_ROLES_LIST
  getModulesRolesList() {
    const body = {};
    return this._apiService.callApi(
      HSEHrSettings.API.GET_MODULES_ROLES_LIST,
      'get',
      body
    );
  }

  // ADD_UPDATE_MODULES_ROLES
  addeditforRolesModules(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.ADD_UPDATE_MODULES_ROLES,
      'post',
      body
    );
  }

  // GET_EMP_ROLE_PRESENT_BY_ID
  getEmprolepresentbyid(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.GET_EMP_ROLE_PRESENT_BY_ID,
      'post',
      body
    );
  }

  // GET_EMP_ROLE_FUTURE_BY_ID
  getEmprolefuturebyid(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.GET_EMP_ROLE_FUTURE_BY_ID,
      'post',
      body
    );
  }

  // GET_EMPLOYEE_LIST
  getEmployeesList() {
    return this._apiService.callApi(
      HSEHrSettings.API.GET_EMPLOYEES_LIST,
      'get',
      {}
    );
  }

  // LINK_ROLES_EMP_BY_PROCESS
  linkrolesempbyprocess(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.LINK_ROLES_EMP_BY_PROCESS,
      'post',
      body
    );
  }

  // ADD_NEW_ROLE_EMP
  addNewRoleEmp(body) {
    return this._apiService.callApi(
      HSEHrSettings.API.ADD_NEW_ROLE_EMP,
      'post',
      body
    );
  }
}
