import { Component, OnInit, ViewContainerRef, ViewChildren, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControlName, FormControl } from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import * as _ from 'underscore';
import { GenericValidator } from '../../common/generic-validator';
import { ApiService } from '../../common/services/api.service';
import { AssetsapiService } from '../common/assets.service';

@Component({
  selector: 'app-maintenanceservices',
  templateUrl: './maintenanceservices.component.html',
  styleUrls: ['./maintenanceservices.component.css']
})
export class MaintenanceservicesComponent implements OnInit {
  ModulesList: any;
  RolesList: any;
  modulesRolesList: any[];
  loading: Boolean = true;
  dataItem: any = {
    id: null
  };
  AddRoleModuleForm: FormGroup;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;
  settings: {};
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';
  selectitem = [];
  SelectedItems = [];
  selectedItems = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public locationsservice: AssetsapiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef
  ) {
    // document.body.style.background = '#f0f1f0';

    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      service_name: {
        required: 'Module Name is required'
      },
      service_supervisor: {
        required: 'Role Name is required'
      },
      status: {
        required: 'Status is required'
      }
    };
  }

  ngOnInit() {
    this.genericValidator = new GenericValidator(this.validationMessages);
    const service_name = new FormControl({ value: '', disabled: false }, [Validators.required]);
    const service_supervisor = new FormControl({ value: [], disabled: false }, [
      Validators.required
    ]);
    const status = new FormControl({ value: '1', disabled: false });

    this.AddRoleModuleForm = this.fb.group({
      service_name: service_name,
      service_supervisor: service_supervisor,
      status: status
    });
    this.settings = {
      text: 'Select Supervisors',
      selectAllText: 'Select All',
      singleSelection: true,
      unSelectAllText: 'UnSelect All',
      classes: 'myclass custom-class',
      badgeShowLimit: 5
    };

    this.maintenanceserlist();
    this.getSupervisorsList();
    // this.getModulesListbystatus();
  }

  // tslint:disable-next-line:use-life-cycle-interface
  // ngAfterViewInit(): void {
  //   if (this.AddRoleModuleForm) {
  //     const controlBlurs: Observable<any>[] = this.formInputElements.map(
  //       (formControl: ElementRef) =>
  //         Observable.fromEvent(formControl.nativeElement, 'blur')
  //     );
  //     Observable.merge(this.AddRoleModuleForm.valueChanges, ...controlBlurs)
  //       .debounceTime(800)
  //       .subscribe(value => {
  //         this.displayMessage = this.genericValidator.processMessages(
  //           this.AddRoleModuleForm
  //         );
  //       });
  //   }
  // }

  getSupervisorsList() {
    this.locationsservice.getsupervisors().subscribe(data => {
      if (!data.error) {
        this.selectitem = data.data;
        this.loading = false;
      } else {
        this.ModulesList = [];
        this.loading = false;
      }
    });
  }
  onItemSelect(item: any) { }
  OnItemDeSelect(item: any) { }
  onSelectAll(items: any) { }
  onDeSelectAll(items: any) { }
  maintenanceserlist() {
    this.loading = true;
    this.modulesRolesList = [];
    this.locationsservice.maintenanceservicelist().subscribe(data => {
      if (!data.error) {
        this.modulesRolesList = data.data;
        this.modulesRolesList.forEach(element => {
          element.d = element.d ? element.d.split(',') : [];
          element.d.forEach(val => {
            val.split('-');
          });
        });
        console.log(this.modulesRolesList, 'modulesRolesList');
      }
      this.loading = false;
    }, error => {
      this.loading = false;
    });
  }

  addNewRoleModule() {
    const p = [];

    for (let k = 0; k < this.AddRoleModuleForm.controls['service_supervisor'].value.length; k++) {
      p.push(this.AddRoleModuleForm.controls['service_supervisor'].value[k].id);
    }
    const body = {
      ms_id: null,
      service_name: this.AddRoleModuleForm.controls['service_name'].value.toString(),
      service_supervisor: p.toString(),
      status: '1'
    };
    this.locationsservice.addnewmainservice(body).subscribe(addData => {
      if (!addData.error) {
        // success toaster
        this.toastr.successToastr('Added Details Successfully', 'Success!');
        this.AddRoleModuleForm.reset();
        this.SelectedItems = [];
        this.AddRoleModuleForm.patchValue([
          {
            role_name: '',
            module_name: '',
            status: 1
          }
        ]);
        this.dataItem = {
          id: null
        };
        this.maintenanceserlist();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }

  editModule(item) {
    this.SelectedItems = [];
    const emps = item.d.split(',');

    const len = emps.length;
    for (let i = 0; i < len; i++) {
      this.SelectedItems.push({
        id: emps[i].split('-')[0],
        itemName: emps[i].split('-')[1]
      });
    }
    this.AddRoleModuleForm.patchValue({
      service_name: item.service_name,
      service_supervisor: this.SelectedItems,
      status: item.status
    });
    this.dataItem.id = item.ms_id.toString();
  }

  updtaemodule() {
    const p2 = [];
    for (let k = 0; k < this.AddRoleModuleForm.controls['service_supervisor'].value.length; k++) {
      p2.push(this.AddRoleModuleForm.controls['service_supervisor'].value[k].id);
    }
    const body = {
      ms_id: this.dataItem.id,
      service_name: this.AddRoleModuleForm.controls['service_name'].value.toString(),
      service_supervisor: p2.toString(),
      status: this.AddRoleModuleForm.controls['status'].value.toString()
    };
    this.locationsservice.addnewmainservice(body).subscribe(addData => {
      if (!addData.error) {
        // success toaster
        this.toastr.successToastr('Updated Details Successfully', 'Success!');
        this.AddRoleModuleForm.reset();
        this.SelectedItems = [];
        this.AddRoleModuleForm.patchValue([
          {
            role_name: '',
            module_name: '',
            status: 1
          }
        ]);
        this.dataItem = {
          id: null
        };
        this.maintenanceserlist();
      } else {
        // warning toaster
        this.toastr.warningToastr(addData.message, 'Warning!');
      }
    });
  }
  emptyform() {
    this.SelectedItems = [];
    this.AddRoleModuleForm.reset();
  }
}
