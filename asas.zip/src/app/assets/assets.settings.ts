import { environment } from '../../environments/environment';

export class AssetsSettings {
  public static API = {
    GET_SUPPLIER_LIST: environment.apiUrl + 'supplier/getSupplierList',
    ADD_TYPES: environment.apiUrl + 'equipments/add_type',
    ADD_LOCATIONS: environment.apiUrl + 'add/locations',
    GET_LOCATIONS: environment.apiUrl + 'get/locations',
    GET_LIST_OF_SUPERVISIORSLIST: environment.apiUrl + 'get/supervisorslist',
    ADDNEW_MAINTENANCE: environment.apiUrl + 'add/newmaintainence/service',
    GET_MAINTENANCESERVICESLIST: environment.apiUrl + 'get/maintain/services',
    ADD_SUPPLIER_LIST: environment.apiUrl + 'supplier/addSupplierList',
    GET_EMPLS: environment.apiUrl + 'supplier/getemployees',
    ADD_EQUIPMENTS: environment.apiUrl + 'equipments/addequipments',
    GET_LISTOFEQU: environment.apiUrl + 'equipments/getequipments',
    GET_EQ_TYPE_LIST: environment.apiUrl + 'equipments/gettypedetails',
    GETFULLDETAILS: environment.apiUrl + 'equipments/getequipmentsdetails',
    LINK_MAINTENANCE: environment.apiUrl + 'equipments/maintenance',
    GETSUPERVISORLIST: environment.apiUrl + 'equipments/supervisour',
    GETSUPERVISORUNDER: environment.apiUrl + 'employee/underreportingmanager',
    LINK_MAINTENANCE_EMPS: environment.apiUrl + 'maintenance/addmaintenancedet',
    GETUSERSLIST: environment.apiUrl + 'equipments/listtomatainuser',
    ADDMIANTENANCE_USER: environment.apiUrl + 'maintenance/addhistorybyuser',
    GET_OWNERS: environment.apiUrl + 'equipments/owername',
    GETLIST_OF_DASHBOARD: environment.apiUrl + 'dashboard/type',
    CLOSE_ACTION: environment.apiUrl + 'close/service',
    GET_SUPPLIER_DASH: environment.apiUrl + 'dashboard/Suppliertype',
    GET_MAINTENAANCELST: environment.apiUrl + 'suppliers/getlist',
    GET_DASH: environment.apiUrl + 'equipments/equipmentCountByLocation',
    // GET_DASH: environment.apiUrl + 'dashboard/Suppliertype/count',
    GET_WORKING_STATUS:
      environment.apiUrl + 'equipments/equipmentBytypeLocation',
    GET_SUPERVISOR_LIST: environment.apiUrl + 'incidents/get/supervisors/list/',


    GET_ASSETS_ROLES: environment.apiUrl + 'employee/gettype',
    GET_ASSETS_DASHBOARD_DATA: environment.apiUrl + 'assets/dashboard',
  };
}
