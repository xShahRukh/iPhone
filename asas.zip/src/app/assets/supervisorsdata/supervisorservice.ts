import { Injectable, Output, EventEmitter } from '@angular/core';
import { AssetsSettings } from '../assets.settings';
import { ApiService } from '../../common/services/api.service';

@Injectable()
export class SupervisorService {
  constructor(private _apiService: ApiService) { }

  GETSUPERVISORLIST(id) {
    return this._apiService.callApi(
      AssetsSettings.API.GETSUPERVISORLIST + `/${id}/${sessionStorage.getItem('designation')}`,
      'get',
      {}
    );
  }
  addmaintennaceemp(body) {
    return this._apiService.callApi(
      AssetsSettings.API.LINK_MAINTENANCE_EMPS,
      'post',
      body
    );
  }
  getsupervisor(body) {
    return this._apiService.callApi(
      AssetsSettings.API.GETSUPERVISORUNDER + `/${body}`,
      'get',
      {}
    );
  }

  GETUSERLIST(body) {
    return this._apiService.callApi(
      AssetsSettings.API.GETUSERSLIST + `/${body}`,
      'get',
      {}
    );
  }

  addmaintennaceuser(body) {
    return this._apiService.callApi(
      AssetsSettings.API.ADDMIANTENANCE_USER,
      'post',
      body
    );
  }

  close_action(body) {
    return this._apiService.callApi(
      AssetsSettings.API.CLOSE_ACTION,
      'post',
      body
    );
  }
  getmaintenance(body) {
    return this._apiService.callApi(
      AssetsSettings.API.GET_MAINTENAANCELST,
      'post',
      body
    );
  }

  // GET_INCIDENTS_LIST
  getlistoflocat() {
    const body = {};
    return this._apiService.callApi(
      AssetsSettings.API.GET_LOCATIONS,
      'get',
      body
    );
  }
}
