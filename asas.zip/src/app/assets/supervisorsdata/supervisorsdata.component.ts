import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild,
  Pipe,
  PipeTransform
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { ToastrManager } from 'ng6-toastr-notifications';
import { GenericValidator } from '../../common/generic-validator';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { DomSanitizer, BrowserModule, SafeResourceUrl } from '@angular/platform-browser';
import * as _ from 'underscore';
import { SupervisorService } from './supervisorservice';

@Component({
  selector: 'app-supervisorsdata',
  templateUrl: './supervisorsdata.component.html',
  styleUrls: ['./supervisorsdata.component.css']
})
export class SupervisorsdataComponent implements OnInit {
  incident_action_data: any = [];
  user_id: any = '';
  type_det: any = '';
  pop_data: any = '';
  dropdownSettings: {};
  loading: boolean;
  incidentslist: any = [];
  id: any = new Object();
  investigatorslist: any = [];
  InvestigationForm: FormGroup;
  InvestigationForm2: FormGroup;
  closeForm: FormGroup;
  selectedlist: any = [];
  supervisorlist = {
    pending: [],
    today: [],
    future: []
  };
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'created_at';
  public sortOrder = 'desc';
  listofequipments: any = [];
  text: any = '';
  textShow: any = '';
  selectedlist2 = [];
  maintenancelist: any = [];
  locations = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public sanitizer: DomSanitizer,
    public superservice: SupervisorService,
    public vcr: ViewContainerRef
  ) { }

  ngOnInit() {
    this.user_id = sessionStorage.getItem('userid');
    this._apiService.page = 'supervisordata';
    const eq_id = new FormControl('', [Validators.required]);
    const ms_id = new FormControl('', [Validators.required]);
    const investigators = new FormControl('', [Validators.required]);
    const notes = new FormControl('', [Validators.required]);
    const m_id = new FormControl('', [Validators.required]);
    const maintenance = new FormControl('', [Validators.required]);

    this.InvestigationForm = this.fb.group({
      eq_id: eq_id,
      ms_id: ms_id,
      investigators: investigators,
      notes: notes
    });
    this.InvestigationForm2 = this.fb.group({
      eq_id: eq_id,
      ms_id: ms_id,
      maintenance: maintenance,
      notes: notes
    });

    this.closeForm = this.fb.group({
      m_id: m_id,
      closed: new FormControl('', [Validators.required])
    });
    this.loading = true;

    this.getIncidents_list_mr();
    this.getlistoflocations();
    this.superservice.getsupervisor(this.user_id).subscribe(data => {
      this.incident_action_data = data.data;
    });
  }

  getIncidents_list_mr() {
    this.user_id = sessionStorage.getItem('userid');
    this.superservice.GETSUPERVISORLIST(this.user_id).subscribe(docs => {
      this.loading = false;
      if (docs.success) {
        const supervisorlist2 = docs.data;
        this.supervisorlist = docs.data;
        this.incidentslist = _.toArray(supervisorlist2);
        this.getItems('today');
      } else {
        this.incidentslist = [];
      }
    });
  }

  add_investigation(value) {
    this.dropdownSettings = {
      text: 'Select Service Person',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: 'myclass custom-class',
      singleSelection: true
    };
    this.InvestigationForm.patchValue({
      eq_id: JSON.stringify(value.eq_id),
      ms_id: value.ms_id
    });
  }

  getmaintenanceservices(value) {
    this.superservice.getmaintenance({ id: value.ms_id }).subscribe(dtaa => {
      this.maintenancelist = dtaa.data;
    });
    this.InvestigationForm2.patchValue({
      eq_id: JSON.stringify(value.eq_id),
      ms_id: value.ms_id
    });
  }

  addinvestigation() {
    if (this.InvestigationForm.value.investigators.length > 0) {
      const body_submit = {
        eq_id: this.InvestigationForm.value.eq_id,
        ms_id: this.InvestigationForm.value.ms_id,
        userid: this.InvestigationForm.value.investigators[0].id,
        notes: this.InvestigationForm.value.notes,
        maintenance_type: 'internal'
      };

      this.superservice.addmaintennaceemp(body_submit).subscribe(docs => {
        if (docs.success) {
          this.toastr.successToastr('Service Person Added Successfully');
          this.InvestigationForm.reset();
          this.getIncidents_list_mr();
        } else {
          this.toastr.errorToastr('Error..!', 'There was a issue in adding service person');
        }
      });
    } else {
      this.toastr.errorToastr('Error..!', 'There was a issue in adding service person');
    }
  }

  closeexternal() {
    if (this.InvestigationForm2.value.maintenance.length > 0) {
      const body_submit = {
        eq_id: this.InvestigationForm2.value.eq_id,
        ms_id: this.InvestigationForm2.value.ms_id,
        userid: this.InvestigationForm2.value.maintenance[0].id,
        notes: this.InvestigationForm2.value.notes,
        maintenance_type: 'External'
      };

      this.superservice.addmaintennaceemp(body_submit).subscribe(docs => {
        if (docs.success) {
          this.toastr.successToastr('Service Person Added Successfully');
          this.InvestigationForm2.reset();
          this.getIncidents_list_mr();
        } else {
          this.toastr.errorToastr('Error..!', 'There was a issue in adding service person');
        }
      });
    } else {
      this.toastr.errorToastr('Error..!', 'There was a issue in adding service person');
    }
  }

  open_close_pop(value) {
    this.closeForm.reset();
    this.closeForm.patchValue({
      m_id: value.m_id
    });
  }

  getItems(text) {
    this.text = text;
    if (text === 'pending') {
      this.textShow = 'Pending Services';
      this.listofequipments = this.supervisorlist['pending'];
    }
    if (text === 'today') {
      this.textShow = 'Today Services';
      this.listofequipments = this.supervisorlist['today'];
    }
    if (text === 'future') {
      this.textShow = 'Future Services';
      this.listofequipments = this.supervisorlist['future'];
    }
    this.listofequipments.forEach(element => {
      element['locationDisplay'] = this.getLocationHistory(element.location);
    });
  }

  close_action() {
    if (this.closeForm.valid) {
      this.superservice.close_action(this.closeForm.value).subscribe(docs => {
        if (!docs.error) {
          this.toastr.successToastr('', 'Action Closed successfully');
          this.closeForm.reset();
          this.getIncidents_list_mr();
        } else {
          this.toastr.errorToastr('', docs.message);
        }
      });
    } else {
      this.toastr.warningToastr('', 'Please enter Comments');
    }
  }

  get_name_status(value) {
    if (value === null) {
      return '<i class="fa fa-plus" aria-hidden="true"></i> Add Service Persons';
    } else if (value === 1) {
      return '<i class="fa fa-close" aria-hidden="true"></i> Close Services';
    } else {
      return '--';
    }
  }

  getlistoflocations() {
    this.superservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const df2 = data.data;
        this.locations = _.filter(df2, function (km1) {
          return km1.status === 1;
        });
        this.loading = false;
      } else {
        this.locations = [];
        this.loading = false;
      }
    });
  }

  getLocationHistory(value) {
    const data = {
      parent_id: value.split('$')[0],
      location_name: value.split('$')[1]
    };
    value = data;
    const loc_nam = [];
    let demo = '';
    while (true) {
      loc_nam.push(value.location_name);
      if (value.parent_id) {
        const pids = parseInt(value.parent_id, 0);
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === pids;
        });
        if (!withpids.length) {
          return (demo = loc_nam.toString() + '.');
        } else {
          // loc_nam.push(withpids[0].location_name);
          value = withpids[0];
        }
      } else {
        demo = loc_nam.toString() + '.';
        break;
      }
    }
    return demo;
  }
}
