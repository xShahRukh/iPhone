import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild,
  Pipe,
  PipeTransform
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  ReactiveFormsModule,
  Validators,
  FormControlName,
  FormControl
} from '@angular/forms';
import { CustomValidators } from 'ng2-validation';
import { ToastrManager } from 'ng6-toastr-notifications';
import { GenericValidator } from '../../common/generic-validator';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { DomSanitizer, BrowserModule, SafeResourceUrl } from '@angular/platform-browser';
import * as _ from 'underscore';
import { SupervisorService } from '../supervisorsdata/supervisorservice';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  incident_action_data: any = [];
  user_id: any = '';
  type_det: any = '';
  pop_data: any = '';
  dropdownSettings: {};
  loading: boolean;
  incidentslist: any = [];
  id: any = new Object();
  investigatorslist: any = [];
  InvestigationForm: FormGroup;
  closeForm: FormGroup;
  selectedlist: any = [];
  supervisorlist = [];
  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'created_at';
  public sortOrder = 'desc';
  listofequipments: any = [];
  text: any;
  value = false;

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public sanitizer: DomSanitizer,
    public superservice: SupervisorService,
    public vcr: ViewContainerRef
  ) { }

  d = new Date();
  public startDateOptions: IMyDpOptions = {
    dateFormat: 'yyyy-mm-dd',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    // disableUntil: {
    //   year: this.d.getFullYear(),
    //   month: this.d.getMonth() + 1,
    //   day: this.d.getDate() - 1
    // },
    disableSince: {
      year: this.d.getFullYear(),
      month: this.d.getMonth() + 1,
      day: this.d.getDate() + 1
    }
  };

  ngOnInit() {
    this.user_id = sessionStorage.getItem('userid');
    this._apiService.page = 'supervisordata';
    const eq_id = new FormControl('', [Validators.required]);
    const m_id = new FormControl('', [Validators.required]);
    const failed = new FormControl('No', [Validators.required]);
    const failed_date = new FormControl('', [Validators.required]);
    const failed_reasons = new FormControl('', [Validators.required]);
    const notes = new FormControl('', [Validators.required]);
    const maintenance_cost = new FormControl('', [Validators.required]);

    this.InvestigationForm = this.fb.group({
      eq_id: eq_id,
      m_id: m_id,
      failed: failed,
      failed_date: failed_date,
      notes: notes,
      failed_reasons: failed_reasons,
      maintenance_cost: maintenance_cost
    });

    this.closeForm = this.fb.group({
      incident_id: new FormControl('', [Validators.required]),
      management_comments: new FormControl('', [Validators.required])
    });
    this.loading = true;

    this.getIncidents_list_mr();

    this.superservice.getsupervisor(this.user_id).subscribe(data => {
      this.incident_action_data = data.data;
    });
  }

  getIncidents_list_mr() {
    this.user_id = sessionStorage.getItem('userid');
    this.superservice.GETUSERLIST(this.user_id).subscribe(docs => {
      this.loading = false;
      if (docs.success) {
        const listofequipments1 = docs.data;
        this.listofequipments = _.filter(listofequipments1, function (o) {
          return o.m_staus === 0;
        });
      } else {
        this.listofequipments = [];
      }
    });
  }

  add_investigation(value) {
    this.InvestigationForm.patchValue({
      eq_id: JSON.stringify(value.eq_id),
      m_id: value.m_id
    });
  }

  addinvestigation() {
    let dt = null;
    let f = null;
    if (this.InvestigationForm.value.failed === 'Yes') {
      (dt = this.InvestigationForm.value.failed_date.formatted), (f = 'true');
    } else {
      dt = null;
      f = false;
    }
    const body_submit = {
      eq_id: this.InvestigationForm.value.eq_id,
      m_id: this.InvestigationForm.value.m_id,
      result: this.InvestigationForm.value.notes,
      failed_reasons: this.InvestigationForm.value.failed_reasons,
      maintenance_cost: this.InvestigationForm.value.maintenance_cost,
      failed_on: dt,
      failed: f
    };

    this.superservice.addmaintennaceuser(body_submit).subscribe(docs => {
      if (docs.success) {
        this.toastr.successToastr('Service Person Added Successfully');
        this.InvestigationForm.reset();
        this.getIncidents_list_mr();
        this.value = false;
        this.ngOnInit();
      } else {
        this.toastr.errorToastr('Error..!', 'There was a issue in adding service person');
      }
    });
  }

  open_close_pop(value) {
    this.closeForm.reset();
    this.closeForm.patchValue({
      incident_id: value.incident_id.toString()
    });
  }

  getfailed($event) {
    if ($event.target.value === 'Yes') {
      this.value = true;
    } else {
      this.value = false;
    }
  }

  // close_action() {
  //   if (this.closeForm.valid) {
  //     this._incidents_list_mr_service
  //       .close_action(this.closeForm.value)
  //       .subscribe(docs => {
  //         if (!docs.error) {
  //           this.toastr.successToastr('', 'Action Closed successfully');
  //           this.closeForm.reset();
  //           this.getIncidents_list_mr();
  //         } else {
  //           this.toastr.errorToastr('', docs.message);
  //         }
  //       });
  //   } else {
  //     this.toastr.warningToastr('', 'Please enter Comments');
  //   }
  // }

  get_name_status(value) {
    if (value === 1) {
      return '<i class="fa fa-close" aria-hidden="true"></i> Close Service';
    } else if (value === 3) {
      return 'Add Actioner';
    } else {
      return '--';
    }
  }
}
