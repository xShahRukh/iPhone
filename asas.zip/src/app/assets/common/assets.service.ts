import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/timeout';

import {
  Http,
  Headers,
  Response,
  RequestOptions,
  ResponseContentType
} from '@angular/http';
import { AppSettings } from '../../app.settings';
import 'rxjs/add/operator/map';
import { ApiService } from 'src/app/common/services/api.service';
import { AssetsSettings } from '../assets.settings';
import { map } from 'rxjs/operators';

@Injectable()
export class AssetsapiService {
  headers = { headers: new Headers({ 'content-type': 'application/Json' }) };
  options = new RequestOptions();

  constructor(private _http: Http, public _apiService: ApiService) { }

  // ADD_DOCUMENT_DETAI
  addlocat(body) {
    return this._apiService.callApi(
      AssetsSettings.API.ADD_LOCATIONS,
      'post',
      body
    );
  }

  // GET_INCIDENTS_LIST
  getlistoflocat() {
    const body = {};
    return this._apiService.callApi(
      AssetsSettings.API.GET_LOCATIONS,
      'get',
      body
    );
  }
  getsupervisors() {
    return this._apiService.callApi(
      AssetsSettings.API.GET_LIST_OF_SUPERVISIORSLIST,
      'get',
      {}
    );
  }
  addnewmainservice(body) {
    return this._apiService.callApi(
      AssetsSettings.API.ADDNEW_MAINTENANCE,
      'post',
      body
    );
  }

  maintenanceservicelist() {
    return this._apiService.callApi(
      AssetsSettings.API.GET_MAINTENANCESERVICESLIST,
      'get',
      {}
    );
  }
  getUsersList() {
    return this._apiService.callApi(
      AssetsSettings.API.GET_SUPERVISOR_LIST,
      'get',
      {}
    );
  }
  geteqtypeList() {
    return this._apiService.callApi(
      AssetsSettings.API.GET_EQ_TYPE_LIST,
      'get',
      {}
    );
  }
  getownerList() {
    return this._apiService.callApi(AssetsSettings.API.GET_OWNERS, 'get', {});
  }

  callApi(url, method, body = null): Observable<any> {
    if (sessionStorage.getItem('token')) {
      this.token();
    }

    switch (method.toUpperCase()) {
      case 'LOGIN':
        return this._http.post(url, body).pipe(map((response: Response) => response.json()));
      case 'POST':
        return this._http
          .post(url, body, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'PATCH':
        return this._http
          .patch(url, body, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'DELETE':
        return this._http
          .delete(url, this.token())
          .pipe(map((response: Response) => response.json()));

      case 'GET':
        return this._http.get(url, this.token()).pipe(map((response: Response) => response.json()));

      case 'FILE_UPLOAD':
        return this._http
          .post(url, body, this.token())
          .pipe(map((response: Response) => response.json()));
    }
  }

  extraData(response: Response): Response {
    return response.json();
  }
  token() {
    return new RequestOptions({
      headers: new Headers({
        'Content-Type': 'application/json',
        Authorization: 'BEARER ' + sessionStorage.getItem('token')
      })
    });
  }
}
