import { Injectable } from '@angular/core';
import {
  Headers,
  Http,
  RequestOptions,
  Response,
  ResponseContentType
} from '@angular/http';
import { ApiService } from '../../common/services/api.service';
import { AssetsSettings } from '../assets.settings';
import { AssetsapiService } from '../common/assets.service';

@Injectable()
export class SupplierService {
  constructor(
    public _apiService: ApiService,
    public _assetsservice: AssetsapiService,
    private http: Http
  ) { }

  getsupplierlist() {
    const url = AssetsSettings.API.GET_SUPPLIER_LIST;
    return this._assetsservice.callApi(url, 'GET', null);
  }

  addsupplierlist(value) {
    const url = AssetsSettings.API.ADD_SUPPLIER_LIST;
    return this._assetsservice.callApi(url, 'POST', value);
  }

  getServices() {
    const url = AssetsSettings.API.GET_MAINTENANCESERVICESLIST;
    return this._assetsservice.callApi(url, 'GET', null);
  }

  getLocationDetails() {
    const url = AssetsSettings.API.GET_LOCATIONS;
    return this._assetsservice.callApi(url, 'GET', null);
  }

  getlistoflocat() {
    const body = {};
    return this._apiService.callApi(
      AssetsSettings.API.GET_LOCATIONS,
      'get',
      body
    );
  }
}
