import { Component, OnInit, ViewContainerRef } from '@angular/core';
import { IMyDpOptions } from 'mydatepicker';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { ToastrManager } from 'ng6-toastr-notifications';
import { Router, ActivatedRoute } from '@angular/router';
import { ApiService } from '../../common/services/api.service';
import * as _ from 'underscore';
import { DomSanitizer } from '@angular/platform-browser';
import { SupplierService } from './supplier.service';

@Component({
  selector: 'app-supplier',
  templateUrl: './supplier.component.html',
  styleUrls: ['./supplier.component.css']
})
export class SupplierComponent implements OnInit {
  spinner: boolean;
  nameDisp = '';
  // todelete: any = [];
  SuppliersForm: FormGroup;
  supplierList: any = [];
  addForm = false;
  dropdownSettings_list: any = [];
  dropdownSettings_location: any = [];
  servicetype = [];
  servicetype_selected = [];
  location_selected = [];

  public filterQuery = '';
  public rowsOnPage = 20;
  public sortBy = 'color';
  public sortOrder = 'asc';

  public responsedateOptions: IMyDpOptions = {
    dateFormat: 'dd mmm yyyy',
    monthSelector: true,
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: '232px',
    selectorWidth: '252px',
    height: '34px',
    width: '100%',
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableUntil: {
      year: new Date().getFullYear(),
      month: new Date().getUTCMonth() + 1,
      day: new Date().getDate()
    }
  };
  locationtype: any[];
  locations = [];

  constructor(
    public router: Router,
    private _route: ActivatedRoute,
    public fb: FormBuilder,
    public _apiService: ApiService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    private _sanitizer: DomSanitizer,
    public _supplierService: SupplierService
  ) {

  }

  ngOnInit() {
    this.spinner = false;
    this.SuppliersForm = this.fb.group({
      supplier_name: new FormControl('', [Validators.required]),
      supplier_address: new FormControl('', [Validators.required]),
      contact_no: new FormControl('', [Validators.required]),
      email_id: new FormControl('', [Validators.required]),
      status: new FormControl('', [Validators.required]),
      servicetype: new FormControl([], [Validators.required]),
      location_id: new FormControl([], [Validators.required]),
      responsetime: new FormControl('', [Validators.required]),
      responsetype: new FormControl('Days', [Validators.required]),
      serviceprovided: new FormControl('', [Validators.required]),
      servicecharges: new FormControl('', [Validators.required]),
      s_id: new FormControl('')
    });
    this.dropdownSettings_list = {
      text: 'Select Service',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      classes: 'myclass custom-class',
      singleSelection: false
    };
    this.dropdownSettings_location = {
      text: 'Select Location',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: false,
      classes: 'myclass custom-class',
      singleSelection: true
    };
    this.getsupplierlist();
    this.getServiceslist();
    // this.getLocationDetails();
    // this.getlistoflocations();
  }

  getsupplierlist() {
    this.spinner = false;
    this.supplierList = [];
    this._supplierService.getsupplierlist().subscribe(docs => {
      this.spinner = true;
      if (docs.success) {
        this.spinner = true;
        this.supplierList = docs.data;
      } else {
        this.spinner = true;
      }
      this.getlistoflocations();
    }, error => {
      this.getlistoflocations();
    });
  }

  getServiceslist() {
    this.servicetype = [];
    this._supplierService.getServices().subscribe(docs => {
      if (!docs.error) {
        // this.servicetype = docs.data;
        docs.data.forEach(element => {
          this.servicetype.push({
            id: element.ms_id,
            itemName: element.service_name
          });
        });
      }
    });
  }

  addNewRow() {
    this.addForm = !this.addForm;
    this.nameDisp = 'Add New Supplier';
  }

  SubmitSupplier() {
    const body = this.SuppliersForm.value;
    body['location_id'] = this.SuppliersForm.value.location_id[0].id;
    this._supplierService
      .addsupplierlist(body)
      .subscribe(docs => {
        if (docs.success) {
          this.servicetype_selected = [];
          this.location_selected = [];
          if (!this.SuppliersForm.value.s_id) {
            this.toastr.successToastr('Added Successfully');
          } else {
            this.toastr.successToastr('Updated Successfully');
          }
          this.cancel();
        } else {
          this.toastr.errorToastr('Please try again');
        }
      });
  }

  cancel() {
    this.SuppliersForm.reset();
    this.addForm = false;
    this.getsupplierlist();
  }

  editForm(value) {
    this.nameDisp = 'Edit Supplier Details';
    this.servicetype_selected = [];
    this.servicetype.forEach(element => {
      if (
        _.find(value.servicetype.split(','), function (num) {
          return parseInt(num, 0) === element['id'];
        })
      ) {
        this.servicetype_selected.push(element);
      }
    });
    this.location_selected = [];
    this.location_selected = _.filter(this.locationtype, function (o) {
      return o.id === value.location_id;
    });
    this.SuppliersForm.patchValue({
      s_id: value.s_id,
      supplier_name: value.supplier_name,
      supplier_address: value.supplier_address,
      contact_no: value.contact_no,
      email_id: value.email_id,
      status: value.status,
      responsetime: value.responsetime,
      responsetype: value.responsetype,
      serviceprovided: value.serviceprovided,
      servicecharges: value.servicecharges
    });
    this.addForm = true;
  }

  getlistoflocations() {
    this._supplierService.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const df2 = data.data;
        this.locations = _.filter(df2, function (km1) {
          return km1.status === 1;
        });
        this.locationtype = [];
        this.locations.forEach(element => {
          this.locationtype.push({
            id: element.loc_id,
            itemName: this.getlocation_history(
              element.parent_id + '$' + element.location_name
            )
          });
        });
        this.supplierList.forEach(element => {
          element['locationDisplay'] = this.getlocation_history(element.location);
        });
      } else {
        this.locations = [];
      }
    });
  }

  getlocation_history(value) {
    const data = {
      parent_id: value.split('$')[0],
      location_name: value.split('$')[1]
    };
    value = data;
    const loc_nam = [];
    let demo = '';
    while (true) {
      loc_nam.push(value.location_name);
      if (value.parent_id) {
        const pids = parseInt(value.parent_id, 0);
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === pids;
        });
        if (!withpids.length) {
          return (demo = loc_nam.toString() + '.');
        } else {
          value = withpids[0];
        }
      } else {
        demo = loc_nam.toString() + '.';
        break;
      }
    }
    return demo;
  }
}
