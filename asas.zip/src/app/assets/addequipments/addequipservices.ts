import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from 'src/app/common/services/api.service';
import { AppSettings } from 'src/app/app.settings';
import { AssetsSettings } from '../assets.settings';

@Injectable()
export class AddAssetService {
  constructor(private _apiService: ApiService) { }
  getlistofequip() {
    const body = {};
    return this._apiService.callApi(AppSettings.API.GET_LISTOFEQU, 'get', body);
  }
  addequipments(post) {
    return this._apiService.callApi(
      AssetsSettings.API.ADD_EQUIPMENTS,
      'post',
      post
    );
  }
  getfulllist(id) {
    return this._apiService.callApi(
      AssetsSettings.API.GETFULLDETAILS + `/${id}`,
      'get',
      {}
    );
  }
  linkmaintenance(body) {
    return this._apiService.callApi(
      AssetsSettings.API.LINK_MAINTENANCE,
      'post',
      body
    );
  }
  getlistfordashboard(body) {
    return this._apiService.callApi(AssetsSettings.API.GET_DASH, 'post', body);
  }
  getlistforsupplier(body) {
    return this._apiService.callApi(
      AssetsSettings.API.GET_SUPPLIER_DASH,
      'post',
      body
    );
  }
  getdtaa() {
    return this._apiService.callApi(
      AssetsSettings.API.GET_EQ_TYPE_LIST,
      'get',
      {}
    );
  }

  getlistofdsf(body) {
    return this._apiService.callApi(AssetsSettings.API.GET_DASH, 'post', body);
  }
  getworking(body) {
    return this._apiService.callApi(
      AssetsSettings.API.GET_WORKING_STATUS,
      'post',
      body
    );
  }

  getsupplierlist() {
    const url = AssetsSettings.API.GET_SUPPLIER_LIST;
    return this._apiService.callApi(url, 'GET', null);
  }

  addtypes(post) {
    const url = AssetsSettings.API.ADD_TYPES;
    return this._apiService.callApi(url, 'POST', post);
  }

  getServices() {
    const url = AssetsSettings.API.GET_MAINTENANCESERVICESLIST;
    return this._apiService.callApi(url, 'GET', null);
  }

  addsupplierlist(value) {
    const url = AssetsSettings.API.ADD_SUPPLIER_LIST;
    return this._apiService.callApi(url, 'POST', value);
  }

  // ------------------------------------
  getforassest(id) {
    return this._apiService.callApi(AssetsSettings.API.GET_ASSETS_ROLES + `/${id}`, 'get', {});
  }
}
