import { IMyDpOptions } from "mydatepicker";
import * as moment from "moment";
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from "@angular/forms";
import { ToastrManager } from "ng6-toastr-notifications";
import { Router, ActivatedRoute } from "@angular/router";
import { Observable } from "rxjs/Observable";
import * as _ from "underscore";
import { ApiService } from "src/app/common/services/api.service";
import { AddAssetService } from "src/app/addassests/assetsservice";
import { AssetsapiService } from "../common/assets.service";

declare var $;

@Component({
  selector: "app-addequipments",
  templateUrl: "./addequipments.component.html",
  styleUrls: ["./addequipments.component.css"]
})
export class AddequipmentsComponent implements OnInit {
  venderdet: any = [];
  result1;
  picName: any = [];
  file_exist: any;
  fileformat;
  alphabetRegex: any;
  mobileex: any;
  emailRegex: any;
  item: any = new Object();
  UsersList: any;
  loading: Boolean = true;
  dataItem: any = new Object();
  AdduserForm: FormGroup;
  public tableList = true;
  public addform: boolean;
  public excelupload: boolean;
  public result: any;
  cur_emp_id = null;
  emp;
  eqip_type;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  health_issues_list: any = [];
  disabilities_list: any = [];
  phobias_list: any = [];
  allergies_list: any = [];
  dept_list: any = [];
  designations_list: any = [];
  model;
  model1;
  model2;
  model6;
  query;
  query2;
  searchedvalue;
  searchedvalue2;
  query1 = true;
  query3 = true;
  locs = false;
  pos = false;
  listofequipments = [];
  @ViewChild("myInput", {static:false})
  myInputVariable: any;
  servicetype_selected = [];

  id = 0;
  emp_radio_type = null;
  @ViewChild("ref", {static:false})
  ref: ElementRef;
  locations: any = [];
  fulldetails: any = [];
  modulesRolesList: any = [];
  selectedItems: any = [];
  dropdownSettings = {};
  incident_action_data: any = [];
  eq_type: any[];
  eq_type_data: string;
  servicetype: any[];
  SuppliersForm: FormGroup;
  dropdownSettings_list: any = [];
  dropdownSettings_location: any = [];
  checked = false;
  manufact = new Date();
  LocationsListStatic = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public addequipservice: AddAssetService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public locationservice: AssetsapiService,
    public _route: ActivatedRoute
  ) { }
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: "dd-mmm-yyyy", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  public myDatePickerOptions1: IMyDpOptions = {
    dateFormat: "dd-mmm-yyyy", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableUntil: {
    //   year: new Date().getFullYear() - 48,
    //   month: new Date().getMonth() + 1,
    //   day: new Date().getDate() - 1
    // }
  };
  public myDatePickerOptions2: IMyDpOptions = {
    dateFormat: "dd-mmm-yyyy", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() + 1
    }
  };
  async ngOnInit() {
    this.emailRegex = "/^w+([.-]?w+)*@w+([.-]?w+)*(.w{2,3})+$/";
    this.mobileex = "[7-9]{1}[0-9]{9}";
    this.alphabetRegex = "/^[a-zA-Z ]*$/";

    const store_name = new FormControl({ value: "" }, [Validators.required]);
    const category = new FormControl({ value: "" }, [Validators.required]);
    const equ_name = new FormControl({ value: "" }, [Validators.required]);
    const serial_number = new FormControl({ value: "" }, [Validators.required]);
    const specifications = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const date_of_purchase = new FormControl({ value: "" });
    const impact = new FormControl({ value: "" }, [Validators.required]);
    const original_location = new FormControl({ value: "" });
    const unit_price = new FormControl({ value: "" }, [Validators.required]);
    const supplier = new FormControl({ value: "" }, [Validators.required]);
    const warrenty_status = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const expired_date = new FormControl({ value: "" }, [Validators.required]);
    const UOM = new FormControl({ value: "" });
    const Units = new FormControl({ value: "" });
    const current_owner = new FormControl({ value: "" });
    const comments = new FormControl({ value: "" });
    const model_no = new FormControl({ value: "" }, [Validators.required]);
    const manufacture = new FormControl({ value: "" }, [Validators.required]);
    const requested_purpose = new FormControl({ value: "" }, [
      Validators.required
    ]);
    const requested_by = new FormControl({ value: "" }, [Validators.required]);
    const current_location = new FormControl({ value: "" });
    const start_date = new FormControl({ value: "" });
    const end_date = new FormControl({ value: "" });
    const type = new FormControl({ value: "" });
    const pre_condition = new FormControl({ value: "" });
    const manufature_date = new FormControl({ value: new Date() }, [
      Validators.required
    ]);
    const mainmonths = new FormControl({ value: "" }, [Validators.required]);
    const eq_type = new FormControl({ value: "" }, [Validators.required]);
    // const eq_type_id = new FormControl({ value: '' });

    this.AdduserForm = this.fb.group({
      store_name: store_name,
      category: category,
      equ_name: equ_name,
      serial_number: serial_number,
      impact: impact,
      date_of_purchase: date_of_purchase,
      original_location: original_location,
      unit_price: unit_price,
      supplier: supplier,
      warrenty_status: warrenty_status,
      expired_date: expired_date,
      UOM: UOM,
      Units: Units,
      current_owner: current_owner,
      comments: comments,
      specifications: specifications,
      model_no: model_no,
      manufacture: manufacture,
      current_location: current_location,
      requested_purpose: requested_purpose,
      requested_by: requested_by,
      start_date: start_date,
      end_date: end_date,
      type: type,
      pre_condition: pre_condition,
      manufature_date: manufature_date,
      mainmonths: mainmonths,
      eq_type: eq_type,
      eq_type_id: new FormControl("")
    });
    this.SuppliersForm = this.fb.group({
      supplier_name: new FormControl("", [Validators.required]),
      supplier_address: new FormControl("", [Validators.required]),
      contact_no: new FormControl("", [Validators.required]),
      email_id: new FormControl("", [Validators.required]),
      status: new FormControl("1", [Validators.required]),
      servicetype: new FormControl([], [Validators.required]),
      location_id: new FormControl([], [Validators.required]),
      responsetime: new FormControl("", [Validators.required]),
      responsetype: new FormControl("Days", [Validators.required]),
      serviceprovided: new FormControl("", [Validators.required]),
      servicecharges: new FormControl("", [Validators.required]),
      s_id: new FormControl("")
    });
    this.dropdownSettings_list = {
      text: "Select Service",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: false,
      classes: "myclass custom-class",
      singleSelection: false
    };
    this.dropdownSettings_location = {
      text: "Select Location",
      selectAllText: "Select All",
      unSelectAllText: "UnSelect All",
      enableSearchFilter: false,
      classes: "myclass custom-class",
      singleSelection: true
    };
    if (this._route.snapshot.url[0].path === "assetsList") {
      this.closeaddform();
    } else {
      this.openaddform();
      this.patchvalues();
    }
    await this.getServiceslist();
    // this.getLocationDetails();

    await this.getsupplierlist();
    await this.getlistofequipments();
    await this.getusersList();
    await this.maintenanceserlist();
    await this.geteqtypelist();
    this.dropdownSettings = {
      text: "Select Services",
      selectAllText: "Select All",
      singleSelection: false,
      unSelectAllText: "UnSelect All",
      classes: "myclass custom-class",
      badgeShowLimit: 5
    };
  }

  getusersList() {
    this.locationservice.getUsersList().subscribe(docs => {
      if (docs.success) {
        this.UsersList = docs.data;
        this.loading = false;
      } else {
        this.UsersList = [];
      }
    });
  }
  getServiceslist() {
    this.servicetype = [];
    this.addequipservice.getServices().subscribe(docs => {
      if (!docs.error) {
        // this.servicetype = docs.data;
        docs.data.forEach(element => {
          this.servicetype.push({
            id: element.ms_id,
            itemName: element.service_name
          });
        });
      }
    });
  }

  geteqtypelist() {
    this.eq_type = [];
    this.locationservice.geteqtypeList().subscribe(docs => {
      if (docs.success) {
        this.eq_type = docs.data;
      } else {
        this.eq_type = [];
      }
    });
  }

  getlocations($event) {
    if (this.checked === true) {
      this.pos = false;
      this.locs = true;
    } else {
      this.pos = true;
      this.locs = false;
    }
  }

  getlistoflocations() {
    this.locations = [];
    this.locationservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const response = data.data;
        this.LocationsListStatic = data.data;
        data.data.forEach(element => {
          const len = _.filter(response, function (o) {
            return o.parent_id === element.loc_id;
          });
          if (len.length) {
            element["lastAdd"] = true;
          } else {
            element["lastAdd"] = false;
          }
        });
        this.locations = _.filter(response, function (o) {
          return o.lastAdd === false;
        });
        this.listofequipments.forEach(element => {
          const a = this.getlocation_nameReverse(element.location);
          element["displayLocation"] = a ? a : [];
        });
        this.loading = false;
      } else {
        this.LocationsListStatic = [];
        this.loading = false;
      }
    });
  }

  getsupplierlist() {
    this.addequipservice.getsupplierlist().subscribe(data => {
      if (data.success) {
        const df = data.data;
        this.dept_list = _.filter(df, function (km) {
          return km.status === 1;
        });
      } else {
        this.dept_list = [];
      }
    });
  }

  getlistofequipments() {
    this.listofequipments = [];
    this.addequipservice.getlistofequip().subscribe(async data => {
      if (data.success) {
        this.listofequipments = data.data;
        await this.getlistoflocations();
      }
    });
  }

  openaddform() {
    this.tableList = false;
    this.id = 0;
    this.AdduserForm.reset();
    this.addform = true;
    this.query2 = "";
    this.query = "";
    this.checked = false;
    this.SuppliersForm.reset();
    this.router.navigate(["/assets/addequipment"]);
  }

  patchvalues() {
    this.AdduserForm.patchValue({ manufature_date: this.manufact });
  }

  closeaddform() {
    this.tableList = true;
    this.addform = false;
    this.excelupload = false;
    this.router.navigate(["/assets/assetsList"]);
  }

  addNewUser() {
    const dofpur = moment(
      this.AdduserForm.value.date_of_purchase["date"]["year"] +
      "-" +
      ("0" + this.AdduserForm.value.date_of_purchase["date"]["month"]).slice(
        -2
      ) +
      "-" +
      ("0" + this.AdduserForm.value.date_of_purchase["date"]["day"]).slice(-2)
    );
    const ware = moment(
      this.AdduserForm.value.expired_date["date"]["year"] +
      "-" +
      ("0" + this.AdduserForm.value.expired_date["date"]["month"]).slice(-2) +
      "-" +
      ("0" + this.AdduserForm.value.expired_date["date"]["day"]).slice(-2)
    );
    const manu = moment(this.manufact).format("YYYY-MM");

    // if (this.id > 0) {
    const body = {};
    body["store_name"] = this.AdduserForm.value.store_name;
    body["category"] = this.AdduserForm.value.category;
    body["equ_name"] = this.AdduserForm.value.equ_name;
    body["serial_number"] = this.AdduserForm.value.serial_number;
    body["pre_condition"] = this.AdduserForm.value.pre_condition;
    body["impact"] = this.AdduserForm.value.impact;
    body["manufacture"] = this.AdduserForm.value.manufacture;
    body["model"] = this.AdduserForm.value.model_no;
    body["specifications"] = this.AdduserForm.value.specifications;
    body["date_of_purchase"] = dofpur["_i"];
    body["unit_price"] = this.AdduserForm.value.unit_price;
    body["supplier"] = this.AdduserForm.value.supplier;
    body["warrenty_date"] = ware["_i"];
    body["warrenty_status"] = this.AdduserForm.value.warrenty_status;
    body["requested_by"] = this.AdduserForm.value.requested_by;
    body["UOM"] = "0";
    body["Units"] = "0";
    body["current_owner"] = this.AdduserForm.value.current_owner;
    body["comments"] = this.AdduserForm.value.comments;
    body["requested_purpose"] = this.AdduserForm.value.requested_purpose;
    body["type"] = this.AdduserForm.value.type;
    body["location_id"] = this.AdduserForm.value.type;
    body["status"] = "1";
    body["eq_id"] = this.id;
    body["year_of_manufacture"] = manu;
    body["maintenance_days"] = this.AdduserForm.value.mainmonths;

    // if (this.AdduserForm.value.eq_type === '0') {
    body["eq_type"] = this.AdduserForm.value.eq_type;
    // }

    if (this.checked === true) {
      body["location_id"] = this.AdduserForm.value.current_location;
      const temps = moment(
        this.AdduserForm.value.start_date["date"]["year"] +
        "-" +
        ("0" + this.AdduserForm.value.start_date["date"]["month"]).slice(-2) +
        "-" +
        ("0" + this.AdduserForm.value.start_date["date"]["day"]).slice(-2)
      );
      const temps2 = moment(
        this.AdduserForm.value.end_date["date"]["year"] +
        "-" +
        ("0" + this.AdduserForm.value.end_date["date"]["month"]).slice(-2) +
        "-" +
        ("0" + this.AdduserForm.value.end_date["date"]["day"]).slice(-2)
      );
      body["fromdate"] = temps["_i"];
      body["todate"] = temps2["_i"];
      body["type1"] = "temporary";
    }

    body["permanent_id"] = this.AdduserForm.value.original_location;
    // body['fromdate'] = null;
    // body['todate'] = null;
    body["type"] = "permanent";

    this.addequipservice.addequipments(body).subscribe(res => {
      if (res.success) {
        this.toastr.successToastr(res.message, "Success!");
        this.router.navigate(["/assets/assetsList"]);
        this.id = 0;
        this.AdduserForm.reset();
        this.getusersList();
        this.getlistofequipments();
        this.geteqtypelist();
        this.addform = false;
        this.tableList = true;
        this.checked = false;
        this.locs = false;
      } else {
        this.toastr.warningToastr(res.message, "Warning!");
        this.addform = true;
        this.tableList = false;
      }
    });
  }

  onDateChangedMonth(event) {
    this.AdduserForm.patchValue({ manufature_date: event });
  }

  editUser(item) {
    this.id = item.eq_id;
    this.query1 = false;
    this.query3 = false;
    this.addequipservice.getfulllist(this.id).subscribe(dtaa => {
      this.fulldetails = dtaa.data;
      this.addform = true;
      this.tableList = false;
      this.query = item.current_owner;
      this.query2 = item.requested_by;

      const k = _.max(this.fulldetails.locationHistory, function (stooge) {
        return stooge.lc_id;
      });

      if (this.fulldetails.temporary_location != null) {
        this.checked = true;
        this.locs = true;
        this.AdduserForm.patchValue({
          start_date: {
            date: {
              year: new Date(k["fromdate"]).getFullYear(),
              month: new Date(k["fromdate"]).getMonth() + 1,
              day: new Date(k["fromdate"]).getDate()
            }
          },
          end_date: {
            date: {
              year: new Date(k["todate"]).getFullYear(),
              month: new Date(k["todate"]).getMonth() + 1,
              day: new Date(k["todate"]).getDate()
            }
          },
          type: k["type"],
          current_location: k["location_id"]
        });
      } else {
      }

      this.manufact = new Date(
        moment(this.fulldetails.year_of_manufacture).format("YYYY/MM/DD")
      );
      this.AdduserForm.patchValue(item);
      this.AdduserForm.patchValue({
        model_no: item.model,
        original_location: this.fulldetails["permanent_location"],
        expired_date: {
          date: {
            year: new Date(item.warrenty_date).getFullYear(),
            month: new Date(item.warrenty_date).getMonth() + 1,
            day: new Date(item.warrenty_date).getDate()
          }
        },
        date_of_purchase: {
          date: {
            year: new Date(item.date_of_purchase).getFullYear(),
            month: new Date(item.date_of_purchase).getMonth() + 1,
            day: new Date(item.date_of_purchase).getDate()
          }
        },

        mainmonths: item.maintenance_days
      });
      this.eq_type_data = item.eq_type;
      // this.eq_type_data = item.eq_type;
      this.AdduserForm.patchValue({
        eq_type: item.eq_type
      });
    });
  }

  getresult(item) {
    this.id = item.eq_id;
    this.selectedItems = [];
    this.fulldetails = [];
    this.addequipservice.getfulllist(this.id).subscribe(response => {
      this.fulldetails = response.data;
      for (let ko = 0; ko < this.fulldetails.maintenance.length; ko++) {
        this.selectedItems.push({
          id: this.fulldetails.maintenance[ko].ms_id,
          itemName: this.fulldetails.maintenance[ko].service_name
        });
      }
    });
  }

  maintenanceserlist() {
    this.locationservice.maintenanceservicelist().subscribe(data => {
      if (!data.error) {
        this.modulesRolesList = data.data;
        for (let kow = 0; kow < this.modulesRolesList.length; kow++) {
          this.incident_action_data.push({
            id: this.modulesRolesList[kow].ms_id,
            itemName: this.modulesRolesList[kow].service_name
          });
        }
        this.loading = false;
      } else {
        this.modulesRolesList = [];
        this.loading = false;
      }
    });
  }

  viewCategory(item) {
    this.id = item.eq_id;
    this.fulldetails = [];
    this.addequipservice.getfulllist(this.id).subscribe(dtaa => {
      this.fulldetails = dtaa.data;
      if (this.fulldetails.locationHistory.length) {
        this.fulldetails[
          "location"
        ] = this.fulldetails.locationHistory[0].location_name;
      } else {
        this.fulldetails["location"] = "";
      }
    });
  }

  reset() {
    this.myInputVariable.nativeElement.value = "";
  }

  get_Employee_name(emp_id) {
    if (emp_id) {
      this.emp = _.findWhere(this.UsersList, { emp_id: emp_id }).emp_name;
      return this.emp;
    } else {
      return "";
    }
  }

  save(value) {
    this.searchedvalue = value.emp_id;
    this.query = value.emp_id;
    this.query1 = false;
  }

  save2(value) {
    this.searchedvalue2 = value.emp_id;
    this.query2 = value.emp_id;
    this.query3 = false;
  }

  valuechange(e) {
    this.query1 = true;
  }

  valuechange2(e) {
    this.query3 = true;
  }

  onItemSelect(item: any) { }

  OnItemDeSelect(item: any) { }

  onSelectAll(items: any) { }

  onDeSelectAll(items: any) { }

  addservices() {
    if (this.selectedItems.length) {
      this.addequipservice
        .linkmaintenance({ eq_id: this.id, maintenance: this.selectedItems })
        .subscribe(dtaa => {
          if (dtaa.success) {
            this.toastr.successToastr("Services linked Successfully");
            this.selectedItems = [];
          } else {
            this.toastr.errorToastr(dtaa.message);
          }
        });
    } else {
      this.toastr.warningToastr("Please select Services");
    }
  }

  getlocation_history(value) {
    const data = {
      parent_id: value.split("$")[0],
      location_name: value.split("$")[1]
    };
    value = data;
    const loc_nam = [];
    let demo = "";
    while (true) {
      if (value.parent_id) {
        const pids = value.parent_id;
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        value = withpids[0];
      } else {
        demo = loc_nam.toString() + ".";
        break;
      }
    }
    return demo;
  }

  getassets($event) {
    if ($event.target.value === "0") {
      $("#addtype").modal("show");
    }
  }
  getsuppliers($event) {
    if ($event.target.value === "0" || $event.target.value === 0) {
      $("#addsuppliers").modal("show");
    }
  }
  addtype() {
    this.addequipservice
      .addtypes({ eq_type: this.eqip_type })
      .subscribe(data => {
        if (data.success) {
          this.toastr.successToastr("Type Added Successfully");
          this.geteqtypelist();
          this.AdduserForm.patchValue({
            eq_type: this.eqip_type
          });
          this.eqip_type = "";
        }
      });
  }

  SubmitSupplier() {
    this.addequipservice
      .addsupplierlist(this.SuppliersForm.value)
      .subscribe(docs => {
        if (docs.success) {
          this.getsupplierlist();
          this.SuppliersForm.reset();
          if (!this.SuppliersForm.value.s_id) {
            this.toastr.successToastr("Added Successfully");
            $("#addsuppliers").modal("hide");
          } else {
            this.toastr.successToastr("Updated Successfully");
          }
          this.AdduserForm.patchValue({
            supplier: docs.data
          });
        } else {
          this.toastr.errorToastr("Please try again");
        }
      });
  }

  getLocName(value) {
    const res = [];
    const det = _.filter(this.LocationsListStatic, function (o) {
      return o.loc_id === parseInt(value, 0);
    });
    let check = [];
    if (det.length) {
      res.push(det[0].location_name);
      check = det;
    }
    return res;
  }

  getlocation_nameReverse(value) {
    let text = _.filter(this.LocationsListStatic, function (o) {
      return o.loc_id === parseInt(value, 0);
    });
    text = text[0];
    let loc_nam = [];
    if (text) {
      loc_nam.push(text.location_name);
    }
    while (true) {
      if (text && text.parent_id) {
        const pids = text.parent_id;
        const withpids = _.filter(this.LocationsListStatic, function (o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam.push(withpids[0].location_name);
        text = withpids[0];
      } else {
        loc_nam = loc_nam;
        break;
      }
    }
    return _.chain(loc_nam)
      .reverse()
      .value();
  }
}
