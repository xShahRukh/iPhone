import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from '../common/guards/auth.guard';
import { SupplierComponent } from './supplier/supplier.component';
import { MaintenanceservicesComponent } from './maintenanceservices/maintenanceservices.component';
import { AddequipmentsComponent } from './addequipments/addequipments.component';
import { SupervisorsdataComponent } from './supervisorsdata/supervisorsdata.component';
import { UserComponent } from './user/user.component';
import { ReportassestComponent } from './reportassest/reportassest.component';
import { AssetdashComponent } from './assetdash/assetdash.component';
import { SupplierdashComponent } from './supplierdash/supplierdash.component';
import { AssetsDashboardComponent } from './assets-dashboard/assets-dashboard.component';


const assetsroutes: Routes = [
  {
    path: 'assetDashboard',
    component: AssetsDashboardComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'supplier',
    component: SupplierComponent,
    canActivate: [AuthGuard]
  },

  {
    path: 'maintainservice',
    component: MaintenanceservicesComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'addequipment',
    component: AddequipmentsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'assetsList',
    component: AddequipmentsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'supervisordata',
    component: SupervisorsdataComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'usercomp',
    component: UserComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'reportassest',
    component: ReportassestComponent,
    canActivate: [AuthGuard]

  },
  {
    path: 'assetdash',
    component: AssetdashComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'supplierdash',
    component: SupplierdashComponent,
    canActivate: [AuthGuard]
  },

  { path: '', redirectTo: 'assetdash', pathMatch: 'full' },
  { path: '**', redirectTo: 'assetdash' }
];

export const assetsRouting: ModuleWithProviders = RouterModule.forChild(
  assetsroutes
);
