import { Injectable } from '@angular/core';
import { AssetsapiService } from '../common/assets.service';
import { AssetsSettings } from '../assets.settings';


@Injectable()
export class AssetsDashboardService {
    constructor(private _assetsService: AssetsapiService) { }

    getAssetsDashboardData(value) {
        const url = AssetsSettings.API.GET_ASSETS_DASHBOARD_DATA;
        return this._assetsService.callApi(url, 'get', null);
    }

    getScheduledServices(value) {
        const url = AssetsSettings.API.GETSUPERVISORLIST + `/${value}/${sessionStorage.getItem('designation')}`;
        return this._assetsService.callApi(url, 'get', null);
    }
}
