import { Component, OnInit } from '@angular/core';
import { AssetsDashboardService } from './assets-dashboard.service';
import * as _ from 'underscore';
// import { element } from '@angular/core/src/render3';

declare let require: any;
const Highcharts = require('highcharts');
declare var $: any;
Highcharts.setOptions({
  global: {
    useUTC: false
  },
  colors: [
    '#7ACC86',
    '#F9E570',
    '#60A6C1',
    '#FF887F',
    '#F0B67F',
    '#379a24',
    '#df6810',
    '#2d99b8',
    '#7f6b7e',
    '#2f7ed8'
  ],
  animation: {
    duration: 1000
  },
  lang: {
    decimalPoint: '.',
    thousandsSep: ','
  }
});

@Component({
  selector: 'app-assets-dashboard',
  templateUrl: './assets-dashboard.component.html',
  styleUrls: ['./assets-dashboard.component.css']
})
export class AssetsDashboardComponent implements OnInit {
  spinner = true;
  typesCount: Object;
  AssetsWithStatus: Object;
  ScheduledServices: Object;

  constructor(public _assetsDashboardService: AssetsDashboardService) { }

  ngOnInit() {
    this.getAssetsDashboardData();
    this.getScheduledServices();
  }

  getAssetsDashboardData() {
    this._assetsDashboardService
      .getAssetsDashboardData('')
      .subscribe(response => {
        if (response.success) {
          this.typesCount = {
            chart: {
              type: 'column',
              height: '40%'
            },
            title: {
              text: 'Available',
              style: {
                font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            exporting: {
              enabled: false
            },
            credits: {
              enabled: false
            },
            xAxis: {
              categories: _.pluck(response.data.typesCount, 'name')
            },
            tooltip: {
              headerFormat: '<b>{point.name}</b><br/>',
              pointFormat: 'Count: {point.y}'
            },
            legend: {
              align: 'center',
              alignColumns: 'true',
              borderRadius: '0',
              borderWidth: '0',
              itemDistance: 5,
              itemMarginTop: 0,
              itemMarginBottom: 3,
              itemStyle: {
                align: 'center',
                itemMarginLeft: 0,
                itemMarginRight: 10,
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              },
              itemHoverStyle: {
                color: 'gray'
              }
            },
            series: [
              {
                type: 'column',
                colorByPoint: true,
                data: response.data.typesCount,
                showInLegend: false
              }
            ]
          };
          const MaleFemaleChart = [];
          const types = [];
          MaleFemaleChart.push({ name: 'Working', data: [] });
          MaleFemaleChart.push({ name: 'Not Working', data: [] });
          MaleFemaleChart.push({ name: 'Under Repair', data: [] });
          MaleFemaleChart.push({ name: 'Written Off', data: [] });
          response.data.typesCount.forEach(element1 => {
            types.push(element1.name);
          });
          response.data.typesCount.forEach(element1 => {
            const b = [];
            MaleFemaleChart.forEach(element2 => {
              const a = _.filter(response.data.typesCondition, function (o) {
                return o.con === element2.name && o.eq_type === element1.name;
              });
              element2.data.push(a.length ? a[0].y : 0);
            });
          });
          this.AssetsWithStatus = {
            chart: {
              type: 'column',
              height: '84%'
            },
            title: {
              text: 'Condition',
              style: {
                font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            xAxis: {
              // categories: ['Working', 'Not Working', 'Under Repair', 'Written Off'],
              categories: types,
              crosshair: true
            },
            exporting: {
              enabled: false
            },
            credits: {
              enabled: false
            },
            yAxis: {
              min: 0,
              title: {
                text: 'Assets'
              }
            },
            tooltip: {
              headerFormat:
                '<span style="font-size:10px">{point.key}</span><table>',
              pointFormat:
                '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}</b></td></tr>',
              footerFormat: '</table>',
              shared: true,
              useHTML: true
            },
            legend: {
              align: 'center',
              itemDistance: 5,
              itemMarginTop: 0,
              itemMarginBottom: 3,
              itemStyle: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              },
              itemHoverStyle: {
                color: 'gray'
              }
            },
            plotOptions: {
              column: {
                pointPadding: 0.2,
                borderWidth: 0
              }
            },
            series: MaleFemaleChart
          };
        }
      });
  }

  getScheduledServices() {
    this._assetsDashboardService
      .getScheduledServices(sessionStorage.getItem('userid'))
      .subscribe(response => {
        if (response.success) {
          this.ScheduledServices = {
            chart: {
              height: '40%',
              plotBackgroundColor: null,
              plotBorderWidth: null,
              plotShadow: false,
              type: 'pie'
            },
            title: {
              text: 'Services Scheduled',
              style: {
                font: 'bold 16px "Trebuchet MS", Verdana, sans-serif'
              }
            },
            tooltip: {
              pointFormat: '{series.name}: <b>{point.y}</b>'
            },
            plotOptions: {
              pie: {
                size: '130%',
                innerSize: 45,
                depth: 45,
                allowPointSelect: false,
                cursor: 'pointer',
                dataLabels: {
                  enabled: false,
                  format: '<b>{point.name}</b>: {point.y}',
                  style: {
                    color:
                      (Highcharts.theme &&
                        Highcharts.theme.contrastTextColor) ||
                      'black'
                  }
                },
                showInLegend: true
              }
            },
            exporting: {
              enabled: false
            },
            credits: {
              enabled: false
            },
            legend: {
              layout: 'vertical',
              x: -90,
              align: 'right',
              verticalAlign: 'middle',
              y: 0,
              itemDistance: 3,
              itemMarginBottom: 4,
              itemStyle: {
                font: '8pt Trebuchet MS, Verdana, sans-serif',
                color: '#000'
              },
              itemHoverStyle: {
                color: 'gray'
              }
            },
            series: [
              {
                name: 'Scheduled',
                colorByPoint: true,
                data: [
                  {
                    name: 'Today',
                    y: response.data.today.length,
                    sliced: true,
                    selected: true,
                    color: '#7ACC86'
                  },
                  {
                    name: 'Pending',
                    y: response.data.pending.length,
                    color: '#ff887f'
                  },
                  {
                    name: 'Future',
                    y: response.data.future.length,
                    color: '#60A6C1'
                  }
                ]
              }
            ]
          };
        }
      });
  }
}
