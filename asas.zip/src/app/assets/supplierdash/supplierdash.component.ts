import { IMyDpOptions } from "mydatepicker";
import * as moment from "moment";
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName
} from "@angular/forms";
import { ToastrManager } from "ng6-toastr-notifications";
import { Router } from "@angular/router";
import { ApiService } from "../../common/services/api.service";
import { GenericValidator } from "../../common/generic-validator";
import * as _ from "underscore";
import { SupplierService } from "../supplier/supplier.service";
import { AssetsapiService } from "../common/assets.service";
import { AddAssetService } from "src/app/addassests/assetsservice";

@Component({
  selector: "app-supplierdash",
  templateUrl: "./supplierdash.component.html",
  styleUrls: ["./supplierdash.component.css"]
})
export class SupplierdashComponent implements OnInit {
  venderdet: any = [];
  result1;
  picName: any = [];
  file_exist: any;
  fileformat;
  alphabetRegex: any;
  mobileex: any;
  emailRegex: any;
  item: any = new Object();
  UsersList: any;
  loading: Boolean = true;
  dataItem: any = new Object();
  AdduserForm: FormGroup;
  public tableList = true;
  public addform: boolean;
  public excelupload: boolean;
  public result: any;
  cur_emp_id = null;
  emp;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  health_issues_list: any = [];
  disabilities_list: any = [];
  phobias_list: any = [];
  allergies_list: any = [];
  dept_list: any = [];
  designations_list: any = [];
  model;
  model1;
  model2;
  model6;
  query;
  query2;
  searchedvalue;
  searchedvalue2;
  query1 = true;
  query3 = true;
  locs = false;
  pos = false;
  listofequipments = [];
  @ViewChild("myInput", {static:false}) myInputVariable: any;

  id = 0;
  emp_radio_type = null;
  @ViewChild("ref", {static:false}) ref: ElementRef;
  locations: any = [];
  fulldetails: any = [];
  modulesRolesList: any = [];
  selectedItems: any = [];
  dropdownSettings = {};
  incident_action_data: any = [];
  listofdata: any = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public addequipservice: AddAssetService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public locationservice: AssetsapiService,
    public supservice: SupplierService
  ) { }

  ngOnInit() {
    this.AdduserForm = this.fb.group({
      assets: ["All", Validators.required],
      location: ["All", Validators.required],
      type: ["supply", Validators.required]
    });

    this.getlistoflocations();
    this.getsupplierlist();
    this.getlistofequipments();
    this.getownersList();
    this.addNewUser();
  }
  getownersList() {
    this.locationservice.getownerList().subscribe(docs => {
      if (docs.success) {
        this.UsersList = docs.data;
        this.loading = false;
      } else {
        this.UsersList = [];
      }
    });
  }

  getlocations($event) {
    if ($event.target.value === "temporary") {
      this.pos = false;
      this.locs = true;
    } else {
      this.pos = true;
      this.locs = false;
    }
  }

  getlistoflocations() {
    this.locationservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const df2 = data.data;
        this.locations = _.filter(df2, function (km1) {
          return km1.status === 1;
        });
        this.loading = false;
      } else {
        this.locations = [];
        this.loading = false;
      }
    });
  }

  getsupplierlist() {
    this.supservice.getsupplierlist().subscribe(data => {
      if (data.success) {
        const df = data.data;
        this.dept_list = _.filter(df, function (km) {
          return km.status === 1;
        });
      } else {
        this.dept_list = [];
      }
    });
  }

  getlistofequipments() {
    this.addequipservice.getlistofequip().subscribe(data => {
      this.listofequipments = data.data;
    });
  }

  openaddform() {
    this.tableList = false;
    this.AdduserForm.controls["store_name"].enable();
    this.AdduserForm.controls["equ_name"].enable();
    this.AdduserForm.reset();
    this.addform = true;
  }

  closeaddform() {
    this.tableList = true;
    this.addform = false;
    this.excelupload = false;
  }

  addNewUser() {
    const body = {};
    const temp2 = this.AdduserForm.value.location;
    body["location_id"] = this.AdduserForm.value.location;
    body["serviceType"] = this.AdduserForm.value.type;
    body["eq_id"] = this.AdduserForm.value.assets;
    this.addequipservice.getlistforsupplier(body).subscribe(res => {
      if (res.success) {
        this.listofdata = res.data;
      } else {
        this.toastr.warningToastr(res.message, "Warning!");
        this.addform = true;
        this.tableList = false;
      }
    });
  }

  getresult(item) {
    this.id = item.eq_id;
    this.selectedItems = [];
    this.fulldetails = [];
    this.addequipservice.getfulllist(this.id).subscribe(dtaa => {
      this.fulldetails = dtaa.data;

      for (let ko = 0; ko < this.fulldetails.maintenance.length; ko++) {
        this.selectedItems.push({
          id: this.fulldetails.maintenance[ko].ms_id,
          itemName: this.fulldetails.maintenance[ko].service_name
        });
      }
    });
  }
  viewCategory(item) {
    this.id = item.eq_id;
    this.fulldetails = [];
    this.addequipservice.getfulllist(this.id).subscribe(dtaa => {
      this.fulldetails = dtaa.data;
    });
  }

  reset() {
    this.myInputVariable.nativeElement.value = "";
  }

  get_Employee_name(emp_id) {
    if (emp_id) {
      this.emp = _.findWhere(this.UsersList, { emp_id: emp_id }).emp_name;
      return this.emp;
    } else {
      return "";
    }
  }

  getlocation_history(value) {
    const data = {
      parent_id: value.split("$")[0],
      location_name: value.split("$")[1]
    };
    value = data;
    const loc_nam = [];
    let demo = "";
    while (true) {
      loc_nam.push(value.location_name);
      if (value.parent_id) {
        const pids = parseInt(value.parent_id, 0);
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === pids;
        });
        if (!withpids.length) {
          return (demo = loc_nam.toString() + ".");
        } else {
          value = withpids[0];
        }
      } else {
        demo = loc_nam.toString() + ".";
        break;
      }
    }
    return demo;
  }
}
