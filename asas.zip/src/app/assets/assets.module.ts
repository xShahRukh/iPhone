import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ApiService } from '../common/services/api.service';

// 3rd party
import { ModalModule } from 'ngx-modal';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { MyDatePickerModule } from 'mydatepicker';
import { CustomFormsModule } from 'ng2-validation';
import { EditorModule } from 'primeng/editor';
import { CKEditorModule } from 'ng2-ckeditor';
import { AutoCompleteModule, CalendarModule } from 'primeng/primeng';
import { SpinnerModule } from 'angular2-spinner/dist';
import { assetsRouting } from './assets.routes';
import { SupplierComponent } from './supplier/supplier.component';
import { SupplierService } from './supplier/supplier.service';
import { MaintenanceservicesComponent } from './maintenanceservices/maintenanceservices.component';
import { AddequipmentsComponent } from './addequipments/addequipments.component';
import { AssetsapiService } from './common/assets.service';
import { AddAssetService } from './addequipments/addequipservices';
import { SupervisorsdataComponent } from './supervisorsdata/supervisorsdata.component';
import { SupervisorService } from './supervisorsdata/supervisorservice';
import { UserComponent } from './user/user.component';
import { ReportassestComponent } from './reportassest/reportassest.component';
import { AssetdashComponent } from './assetdash/assetdash.component';
import { SupplierdashComponent } from './supplierdash/supplierdash.component';

import { DataTableModule } from 'angular-6-datatable';
import { SharedModule } from '../common/shareds.module';
import { ToastrModule } from 'ng6-toastr-notifications';
import { AssetsDashboardComponent } from './assets-dashboard/assets-dashboard.component';
import { AssetsDashboardService } from './assets-dashboard/assets-dashboard.service';
import { ChartModule } from 'angular2-highcharts';
import { HighchartsStatic } from 'angular2-highcharts/dist/HighchartsService';
import * as highcharts from 'highcharts';
import { TopMenuComponent } from './common/top-menu/top-menu.component';

declare var require;

export function highchartsFactory() {
  const hc = require('highcharts');
  const hcm = require('highcharts/highcharts-more');
  const exp = require('highcharts/modules/drilldown');
  const sg = require('highcharts/modules/solid-gauge');
  hcm(hc);
  exp(hc);
  sg(hc);
  return hc;
}

@NgModule({
  declarations: [
    SupplierComponent,
    MaintenanceservicesComponent,
    AddequipmentsComponent,
    SupervisorsdataComponent,
    UserComponent,
    ReportassestComponent,
    AssetdashComponent,
    SupplierdashComponent,
    AssetsDashboardComponent,
    TopMenuComponent
  ],
  imports: [
    assetsRouting,
    CommonModule,
    FormsModule,
    EditorModule,
    CKEditorModule,
    ReactiveFormsModule,
    CustomFormsModule,
    DataTableModule,
    AutoCompleteModule,
    SharedModule,
    ModalModule,
    AngularMultiSelectModule,
    MyDatePickerModule,
    CKEditorModule,
    CalendarModule,
    ToastrModule.forRoot(),
    EditorModule,
    SpinnerModule,
    ChartModule
  ],

  providers: [
    ApiService,
    AssetsapiService,
    SupplierService,
    AddAssetService,
    SupervisorService,
    AssetsDashboardService,
    {
      provide: HighchartsStatic,
      useFactory: highchartsFactory
    },
  ]
})
export class AssetsModule { }
