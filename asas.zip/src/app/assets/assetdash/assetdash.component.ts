import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../common/services/api.service';
import { Router } from '../../../../node_modules/@angular/router';
import { AddAssetService } from '../addequipments/addequipservices';

@Component({
  selector: 'app-assetdash',
  templateUrl: './assetdash.component.html',
  styleUrls: ['./assetdash.component.css']
})
export class AssetdashComponent implements OnInit {
  sessionRole: string;
  rolesList: any = [];
  approverole: any;
  reviewrole: any;
  reqroles: string[];

  user_id: any = sessionStorage.getItem('userid');
  designation: any = sessionStorage.getItem('designation');
  asestsroels: any;

  constructor(
    public _apiService: ApiService,
    public _addEquipService: AddAssetService,
    private router: Router
  ) {
    this.user_id = sessionStorage.getItem('userid');
  }

  ngOnInit() {
    this.sessionRole = sessionStorage.getItem('roles');
    this.reqroles = this.sessionRole.split(',');
    this.user_id = sessionStorage.getItem('userid');
    // this.getUserRole();
    this._apiService.rolesArray = JSON.parse(sessionStorage.getItem('roles'));
  }

  getUserRole() {
    this._addEquipService.getforassest(this.user_id).subscribe(data => {
      this.asestsroels = data.data;
    });
  }

  gotodashboard() {
    this.router.navigate(['/dashboard']);
  }
}
