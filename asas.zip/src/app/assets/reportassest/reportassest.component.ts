import { IMyDpOptions } from "mydatepicker";
import * as moment from "moment";
import {
  Component,
  OnInit,
  ViewContainerRef,
  ViewChildren,
  ElementRef,
  ViewChild
} from "@angular/core";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControlName,
  FormControl
} from "@angular/forms";
import { ToastrManager } from "ng6-toastr-notifications";
import { Router } from "@angular/router";
import { ApiService } from "../../common/services/api.service";
import { GenericValidator } from "../../common/generic-validator";
import { Observable } from "rxjs/Observable";
// import { UploadService } from '../../upload.service';
// import { XlsxToJsonService } from '../../xlsx-to-json-service';
import * as _ from "underscore";
import { SupplierService } from "../supplier/supplier.service";
import { AddAssetService } from "src/app/addassests/assetsservice";
import { AssetsapiService } from "../common/assets.service";

@Component({
  selector: "app-reportassest",
  templateUrl: "./reportassest.component.html",
  styleUrls: ["./reportassest.component.css"]
})
export class ReportassestComponent implements OnInit {
  venderdet: any = [];
  result1;
  picName: any = [];
  file_exist: any;
  fileformat;
  alphabetRegex: any;
  mobileex: any;
  emailRegex: any;
  item: any = new Object();
  UsersList: any;
  loading: Boolean = true;
  dataItem: any = new Object();
  AdduserForm: FormGroup;
  public tableList = true;
  public addform: boolean;
  public excelupload: boolean;
  public result: any;
  cur_emp_id = null;
  emp;

  @ViewChildren(FormControlName, { read: ElementRef })
  formInputElements: ElementRef[];
  displayMessage: { [key: string]: string } = {};
  public validationMessages: { [key: string]: { [key: string]: string } };
  public genericValidator: GenericValidator;

  public filterQuery = "";
  public rowsOnPage = 20;
  public sortBy = "color";
  public sortOrder = "asc";

  health_issues_list: any = [];
  disabilities_list: any = [];
  phobias_list: any = [];
  allergies_list: any = [];
  dept_list: any = [];
  designations_list: any = [];
  model;
  model1;
  model2;
  model6;
  query;
  query2;
  searchedvalue;
  searchedvalue2;
  query1 = true;
  query3 = true;
  locs = false;
  pos = false;
  listofequipments = [];
  @ViewChild("myInput", {static:false}) myInputVariable: any;

  id = 0;
  emp_radio_type = null;
  @ViewChild("ref", {static:false}) ref: ElementRef;
  locations: any = [];
  fulldetails: any = [];
  modulesRolesList: any = [];
  selectedItems: any = [];
  dropdownSettings = {};
  incident_action_data: any = [];
  listofdata: any = [];
  eq_type2: any[];
  assets: any = [];
  workingdays: number;
  name: "";
  finaldata = [];
  notworking: any;
  underrepair: any;
  written_off: any;
  working2: any = [];

  constructor(
    public fb: FormBuilder,
    private router: Router,
    public _apiService: ApiService,
    public addequipservice: AddAssetService,
    public toastr: ToastrManager,
    public vcr: ViewContainerRef,
    public locationservice: AssetsapiService,
    public supservice: SupplierService
  ) {
    this.genericValidator = new GenericValidator(this.validationMessages);
    this.validationMessages = {
      emp_name: { required: "Name is required" },
      emp_id: { required: "User Id is required" },
      email: {
        required: "Email Id is required",
        pattern: "Email Id should Contain atleast @ , . characters. "
      },
      contact1: {
        required: "Contact1 no. is required",
        pattern: "Contact1 no. should start with [789]{1}[0-9]{9}"
      },
      contact2: {
        required: "Alternate Contact no. is required",
        pattern: "Alternate Contact2 no. should start with [789]{1}[0-9]{9}",
        notEqualTo: "Alternate Contact2 no. should not match with Contact1 no."
      },
      emergency_contact1: { required: "Emergency1 contact is required" },
      emergency_contact2: {
        required: "Emergency contact is required"
      },
      designation: { required: "Designation is required" },
      department: { required: "Department is required" },
      prev_experience: { required: "prev_Experience is required" },
      gender: { required: "Gender is required" },
      date_of_birth: { required: "DOB is required" },
      date_of_joining: { required: "Date of Joining required" },
      date_of_leaving: { required: "Date of Leaving required" },
      health_issues: { required: "Health Issues required" },
      disabilities: { required: "Disabilities required" },
      phobias: { required: "Phobias Required" },
      allergies: { required: "Allergies Required" },
      emp_type: { required: "Emp type Required" },
      report_to: { required: "Reporting to is Required" }
    };
  }
  public myDatePickerOptions: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true,
    disableSince: {
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
      day: new Date().getDate() - 1
    }
  };
  public myDatePickerOptions1: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableUntil: {
    //   year: new Date().getFullYear() - 48,
    //   month: new Date().getMonth() + 1,
    //   day: new Date().getDate() - 1
    // }
  };
  public myDatePickerOptions2: IMyDpOptions = {
    dateFormat: "yyyy-mm-dd", // dd-mmm-yyyy
    editableDateField: false,
    showTodayBtn: true,
    sunHighlight: true,
    satHighlight: false,
    markCurrentDay: true,
    markCurrentMonth: true,
    markCurrentYear: true,
    inline: false,
    selectorHeight: "232px",
    selectorWidth: "252px",
    height: "34px",
    width: "100%",
    componentDisabled: false,
    showClearDateBtn: true,
    openSelectorOnInputClick: true
    // disableUntil: {
    //   year: new Date().getFullYear(),
    //   month: new Date().getMonth() + 1,
    //   day: new Date().getDate() - 1
    // }
  };
  async ngOnInit() {
    this.AdduserForm = this.fb.group({
      assets: ["All", Validators.required],
      person: ["All", Validators.required],
      status: ["All", Validators.required],
      location: ["All", Validators.required]
    });

    await this.getlistoflocations();
    await this.getsupplierlist();
    await this.getlistofequipments();
    await this.getownersList();
    await this.getreport();
  }
  getownersList() {
    this.locationservice.getownerList().subscribe(docs => {
      if (docs.success) {
        this.UsersList = docs.data;
        this.loading = false;
      } else {
        this.UsersList = [];
      }
    });
  }

  getlocations($event) {
    if ($event.target.value === "temporary") {
      this.pos = false;
      this.locs = true;
    } else {
      this.pos = true;
      this.locs = false;
    }
  }

  getreport() {
    const body = {};
    const temp2 = this.AdduserForm.value.location;
    body["location"] = this.AdduserForm.value.location;
    body["type"] = this.AdduserForm.value.assets;
    this.listofdata = [];
    this.addequipservice.getlistfordashboard(body).subscribe(res => {
      if (res.success) {
        this.finaldata = res.data;
        this.finaldata.forEach(element => {
          element["locDisp"] = this.getlocation_history(element.location);
        });
      } else {
        this.toastr.warningToastr(res.message, "Warning!");
        this.addform = true;
        this.tableList = false;
      }
    });
  }

  getlistoflocations() {
    this.locationservice.getlistoflocat().subscribe(data => {
      if (!data.error) {
        const df2 = data.data;
        this.locations = _.filter(df2, function (km1) {
          return km1.status === 1;
        });
        this.loading = false;
      } else {
        this.locations = [];
        this.loading = false;
      }
    });
  }

  getsupplierlist() {
    this.supservice.getsupplierlist().subscribe(data => {
      if (data.success) {
        const df = data.data;
        this.dept_list = _.filter(df, function (km) {
          return km.status === 1;
        });
      } else {
        this.dept_list = [];
      }
    });
  }

  getlistofequipments() {
    this.eq_type2 = [];
    this.locationservice.geteqtypeList().subscribe(docs => {
      if (docs.success) {
        this.eq_type2 = docs.data;
      } else {
        this.eq_type2 = [];
      }
    });
  }

  openaddform() {
    this.tableList = false;
    this.AdduserForm.controls["store_name"].enable();
    this.AdduserForm.controls["equ_name"].enable();
    this.AdduserForm.reset();
    this.addform = true;
  }

  closeaddform() {
    this.tableList = true;
    this.addform = false;
    this.excelupload = false;
  }

  getassets($event) {
    this.AdduserForm.patchValue({
      location: "All"
    });
  }

  viewCategory(item) {
    this.id = item.eq_id;
    this.fulldetails = [];
    this.addequipservice.getfulllist(this.id).subscribe(dtaa => {
      this.fulldetails = dtaa.data;
      if (this.fulldetails.locationHistory.length) {
        this.fulldetails[
          "location"
        ] = this.fulldetails.locationHistory[0].location_name;
      } else {
        this.fulldetails["location"] = "";
      }
    });
  }

  working(data, works) {
    this.addequipservice
      .getworking({
        location_name: data.location.substring(2),
        type: data.eq_type,
        condition: works
      })
      .subscribe(demo => {
        this.working2 = demo.data;
      });
  }

  getlocation_history(value) {
    const data = {
      parent_id: value.split("$")[0],
      location_name: value.split("$")[1]
    };
    value = data;
    const loc_nam = [];
    let demo = "";
    while (true) {
      loc_nam.push(value.location_name);
      if (value.parent_id) {
        const pids = parseInt(value.parent_id, 0);
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === pids;
        });
        if (!withpids.length) {
          return (demo = loc_nam.toString() + ".");
        } else {
          value = withpids[0];
        }
      } else {
        demo = loc_nam.toString() + ".";
        break;
      }
    }
    return demo;
  }

  getlocation_name(value) {
    let loc_nam = value.location_name;
    while (true) {
      if (value.parent_id) {
        const pids = value.parent_id;
        const withpids = _.filter(this.locations, function (o) {
          return o.loc_id === parseInt(pids, 0);
        });
        loc_nam = loc_nam + ", " + withpids[0].location_name;
        value = withpids[0];
      } else {
        loc_nam = loc_nam + ".";
        break;
      }
    }
    return loc_nam;
  }
}
